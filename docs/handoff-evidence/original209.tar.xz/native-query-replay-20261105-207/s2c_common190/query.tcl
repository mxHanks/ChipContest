# Own9c16 read-only query. Placeholder substitutions are literal, not globs.
if {[catch {
set_app_var link_path [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db}]
redirect -file tool-version.rpt {puts $sh_product_version}
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/s2c-ppa-campaign-20261103-01/s2c/ppa/mapped.v}
if {![link_design {xu_soc_ppa_top}]} {error {ownS2c177 link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
foreach xu_pair {{xu_hfextclk 6.666666667} {xu_lfextclk 30517.578125} {xu_jtag_tck 100.0}} {
  set xu_clock [get_clocks -quiet [lindex $xu_pair 0]]
  if {[sizeof_collection $xu_clock] != 1} {error "missing primary clock $xu_pair"}
  if {abs([get_attribute $xu_clock period]-[lindex $xu_pair 1]) > 0.000001} {error "wrong clock period $xu_pair"}
}
if {[sizeof_collection [get_clocks -quiet xu_plldiv_envelope]] != 1} {error {default conservative divider clock is missing}}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
update_timing

# Query compatibility only. Native pin/clock/library objects remain unmodified.
set xu207_clock_map [open pin-clocks207.tsv w]
puts $xu207_clock_map "request\tpin_handle\tpin_name\tpin_class\tattribute_status\traw_attribute\tclock_handle\tclock_name\tclock_class\tdiagnostics"
set xu207_lib_map [open pin-lib207.tsv w]
puts $xu207_lib_map "pin_handle\tpin_name\towner_handle\towner_name\tlibcell_handle\tlibcell_name\tlibpin_handle\tlibpin_name"
set xu207_requests 0
set xu207_known_clocks [dict create]
foreach_in_collection c [all_clocks] {
  set n [get_object_name $c]
  if {[dict exists $xu207_known_clocks $n]} {error "XU207 duplicate native clock name: $n"}
  if {[get_attribute $c object_class] ne {clock}} {error "XU207 all_clocks returned nonclock: $n"}
  dict set xu207_known_clocks $n $c
}
proc xu207_row {fd values} {
  set clean {}
  foreach value $values {lappend clean [string map [list "\t" { } "\n" { | } "\r" { }] $value]}
  puts $fd [join $clean "\t"]
  flush $fd
}
proc xu207_pin_clocks {pins} {
  global xu207_clock_map xu207_requests xu207_known_clocks
  incr xu207_requests
  set result {};set seen [dict create]
  # A clocks attribute is read from one native pin/port at a time. In
  # particular, never reinterpret a multi-pin attribute list as one handle.
  foreach_in_collection p $pins {
    set name [get_object_name $p];set class [get_attribute $p object_class]
    if {$class ni {pin port}} {error "XU207 clocks requested on nonpin/nonport: $name"}
    set value {};set diagnostics {}
    set rc [catch {redirect -variable diagnostics {set value [get_attribute -quiet $p clocks]}} msg]
    if {[regexp {(^|\n)Error:} $diagnostics]} {
      xu207_row $xu207_clock_map [list $xu207_requests $p $name $class FAILED_NATIVE_DIAGNOSTICS $value {} {} {} "$diagnostics | $msg"]
      error "XU207 native clocks attribute emitted Error for $name"
    }
    if {$rc} {
      xu207_row $xu207_clock_map [list $xu207_requests $p $name $class UNAVAILABLE $value {} {} {} "$diagnostics | $msg"]
      error "XU207 native clocks attribute query failed for $name: $msg"
    }
    if {$value eq {}} {
      xu207_row $xu207_clock_map [list $xu207_requests $p $name $class ABSENT_OR_EMPTY {} {} {} {} "$diagnostics | $msg"]
      continue
    }
    if {[catch {sizeof_collection $value} count] || $count < 1} {
      xu207_row $xu207_clock_map [list $xu207_requests $p $name $class INVALID_COLLECTION $value {} {} {} "$diagnostics | $msg"]
      error "XU207 native clocks attribute is not a nonempty collection: $name"
    }
    foreach_in_collection c $value {
      set cname [get_object_name $c];set cclass [get_attribute $c object_class]
      if {$cclass ne {clock} || ![dict exists $xu207_known_clocks $cname]} {
        xu207_row $xu207_clock_map [list $xu207_requests $p $name $class INVALID_CLOCK_OBJECT $value $c $cname $cclass "$diagnostics | $msg"]
        error "XU207 pin clocks attribute has non-native/unregistered clock: $name/$cname"
      }
      xu207_row $xu207_clock_map [list $xu207_requests $p $name $class NATIVE_CLOCK_COLLECTION $value $c $cname $cclass "$diagnostics | $msg"]
      if {![dict exists $seen $cname]} {
        dict set seen $cname 1
        set result [add_to_collection $result $c]
      }
    }
  }
  return $result
}
proc xu207_libpin {pin} {
  global xu207_lib_map
  if {[sizeof_collection $pin] != 1 || [get_attribute $pin object_class] ne {pin}} {error {XU207 libpin requires exactly one design pin}}
  set owner [get_cells -quiet -of_objects $pin]
  if {[sizeof_collection $owner] != 1} {error {XU207 libpin owner absent/ambiguous}}
  # Both get_lib_cells -of_objects design-cell (actual130/132) and
  # get_lib_pins -of_objects lib-cell (actual177) already ran natively.
  set lc [get_lib_cells -of_objects $owner]
  if {[sizeof_collection $lc] != 1} {error {XU207 native owner library cell absent/ambiguous}}
  set pn [get_object_name $pin];set on [get_object_name $owner];set ln [get_object_name $lc]
  if {[string first "$on/" $pn] != 0} {error {XU207 exact design pin is not below its native owner}}
  set leaf [string range $pn [expr {[string length $on]+1}] end]
  set want "$ln/$leaf";set result {};set count 0
  foreach_in_collection lp [get_lib_pins -of_objects $lc] {
    if {[get_object_name $lp] eq $want} {incr count;set result $lp}
  }
  if {$count != 1} {error "XU207 exact native library pin absent/ambiguous: $pn -> $want"}
  xu207_row $xu207_lib_map [list $pin $pn $owner $on $lc $ln $result [get_object_name $result]]
  return $result
}

set xu_status [open query-status.tsv w]
puts $xu_status "report\tcatch_code\tmessage"
proc xu177_report {filename script} {
  global xu_status
  puts "XU177_REPORT_BEGIN $filename"
  set rc [catch {uplevel #0 [list redirect -file $filename $script]} msg]
  puts "XU177_REPORT_END $filename catch=$rc"
  puts $xu_status [join [list $filename $rc [string map [list "\n" { | } "\t" { }] $msg]] "\t"]
  flush $xu_status
}
proc xu177_attr {obj attr} {
  set rc [catch {get_attribute -quiet $obj $attr} value]
  if {$rc} {return "UNAVAILABLE:$attr:$value"}
  if {$value eq {}} {return "ABSENT_OR_EMPTY:$attr"}
  return $value
}
set xu_exact {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_mems/u_sirv_mem_fab/u_sirv_gnrl_icb_buffer/u_sirv_gnrl_rsp_fifo/dp_gt0.vec_31_dfflr/qout_r_reg[0]}
set xu_cell [get_cells -quiet __XU177_INTENTIONALLY_ABSENT__]
# Enumerate a reference class and compare native full_name by Tcl string equality.
# In particular dp_gt0.vec_31_dfflr and qout_r_reg[0] retain their literal spelling.
foreach_in_collection c [get_cells -quiet -hierarchical -filter {ref_name == DRNQV0_12TR40}] {
  if {[get_object_name $c] eq $xu_exact} {set xu_cell [add_to_collection $xu_cell $c]}
}
if {[sizeof_collection $xu_cell] != 1} {error {XU177 exact cell is absent or ambiguous}}
if {[get_attribute $xu_cell ref_name] ne {DRNQV0_12TR40}} {error {XU177 target reference changed}}
set xu_pins [dict create]
foreach_in_collection p [get_pins -quiet -of_objects $xu_cell] {
  set pname [get_object_name $p]
  foreach leaf {D CK Q RDN} {
    if {$pname eq "$xu_exact/$leaf"} {
      if {[dict exists $xu_pins $leaf]} {error {XU177 duplicate exact pin}}
      dict set xu_pins $leaf $p
    }
  }
}
if {[dict size $xu_pins] != 4} {error {XU177 exact D CK Q RDN pin set missing}}
foreach leaf {D CK Q RDN} {
  set p [dict get $xu_pins $leaf]
  set want in
  if {$leaf eq {Q}} {set want out}
  if {[get_attribute $p direction] ne $want} {error "XU177 wrong direction $leaf"}
}
set xu_D [dict get $xu_pins D]
set xu_CK [dict get $xu_pins CK]
set xu_Q [dict get $xu_pins Q]
set xu_RDN [dict get $xu_pins RDN]
redirect -file target-native.rpt {
  puts "XU177_CELL name=[get_object_name $xu_cell] ref=[get_attribute $xu_cell ref_name]"
  report_attribute -application $xu_cell
  foreach leaf {D CK Q RDN} {
    set p [dict get $xu_pins $leaf]
    puts "XU177_PIN leaf=$leaf name=[get_object_name $p] direction=[get_attribute $p direction] owner=[get_object_name [get_cells -of_objects $p]]"
    report_attribute -application $p
  }
}
redirect -file direct-connectivity.rpt {
  foreach leaf {D CK Q RDN} {
    set p [dict get $xu_pins $leaf]
    puts "XU177_NETS leaf=$leaf pin=[get_object_name $p]"
    foreach_in_collection n [get_nets -quiet -of_objects $p] {
      puts "NET [get_object_name $n]"
      foreach_in_collection a [all_connected -leaf $n] {
        puts "CONNECTED name=[get_object_name $a] class=[get_attribute $a object_class] direction=[xu177_attr $a direction]"
        set owners [get_cells -quiet -of_objects $a]
        foreach_in_collection owner $owners {
          puts "OWNER name=[get_object_name $owner] ref=[get_attribute $owner ref_name] sequential=[xu177_attr $owner is_sequential]"
        }
      }
    }
  }
}
xu177_report target-libpins.rpt {
  set lc [get_lib_cells -quiet */DRNQV0_12TR40]
  if {[sizeof_collection $lc] != 1} {error {target lib-cell is absent or ambiguous}}
  puts "XU177_LIBCELL [get_object_name $lc]"
  foreach_in_collection lp [get_lib_pins -of_objects $lc] {
    puts "LIBPIN [get_object_name $lp] direction=[get_attribute $lp direction]"
    report_attribute -application $lp
  }
}
xu177_report target-clock-reset.rpt {
  foreach leaf {CK RDN} {
    set p [dict get $xu_pins $leaf]
    puts "XU177_CLOCK_RESET leaf=$leaf pin=[get_object_name $p]"
    foreach a {case_value constant_value is_clock_pin clocks} {puts "$a=[xu177_attr $p $a]"}
    puts "CLOCKS [get_object_name [xu207_pin_clocks $p]]"
    puts "FANIN_STARTPOINTS [get_object_name [all_fanin -flat -startpoints_only -to $p]]"
  }
}
xu177_report min-to-D.rpt {report_timing -delay_type min -to $xu_D -path_type full_clock_expanded -input_pins -nets -transition_time -capacitance -significant_digits 12 -max_paths 20 -nworst 20}
xu177_report max-to-D.rpt {report_timing -delay_type max -to $xu_D -path_type full_clock_expanded -input_pins -nets -transition_time -capacitance -significant_digits 12 -max_paths 5}
xu177_report min-path-native.rpt {
  set paths [get_timing_paths -delay_type min -to $xu_D -max_paths 20 -nworst 20]
  puts "XU177_MIN_PATH_COUNT [sizeof_collection $paths]"
  foreach_in_collection path $paths {report_attribute -application $path}
}
xu177_report min-to-D-no-slack-filter.rpt {report_timing -delay_type min -to $xu_D -path_type full_clock_expanded -input_pins -nets -transition_time -significant_digits 12 -exceptions all}
xu177_report clock-latency-to-CK.rpt {report_clock_timing -type latency -to $xu_CK}
xu177_report check-timing.rpt {check_timing -verbose}
xu177_report units.rpt {report_units}
xu177_report clocks.rpt {report_clock}
xu177_report clock-attributes.rpt {foreach_in_collection c [all_clocks] {report_attribute -application $c}}
xu177_report analysis-coverage.rpt {report_analysis_coverage -status_details untested}
xu177_report violations.rpt {report_constraint -all_violators}
xu177_report case-analysis.rpt {report_case_analysis}
xu177_report disabled-timing.rpt {report_disable_timing}
xu177_report target-exceptions.rpt {report_exceptions -to $xu_D}
xu177_report annotated-check-annotated.rpt {report_annotated_check -list_annotated}
xu177_report annotated-check-not-annotated.rpt {report_annotated_check -list_not_annotated}
# all_fanout default timing graph stops at sequential endpoints; never use
# -trace_arcs all or flatten a sequential arc into a combinational-causality claim.
xu177_report Q-first-state-boundaries.rpt {
  puts {SEMANTICS native timing-graph potential fanout only; STOP at every endpoint/state boundary; no Boolean sensitization or unknown-causality proof.}
  set ends [all_fanout -flat -endpoints_only -from $xu_Q]
  puts "ENDPOINT_COUNT [sizeof_collection $ends]"
  foreach_in_collection e $ends {
    puts "ENDPOINT name=[get_object_name $e] class=[get_attribute $e object_class]"
    foreach_in_collection owner [get_cells -quiet -of_objects $e] {
      puts "STOP_OWNER name=[get_object_name $owner] ref=[get_attribute $owner ref_name] sequential=[xu177_attr $owner is_sequential]"
    }
  }
  set xu_bias_exact {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/u_linear_compute_core/io_cacheWriteEnable}
  set found 0
  foreach_in_collection p [get_pins -quiet -hierarchical -filter {direction == out}] {
    if {[get_object_name $p] eq $xu_bias_exact} {incr found; puts "BIAS_NATIVE_PIN [get_object_name $p]"}
  }
  puts "BIAS_PIN_MATCHES $found"
  puts {No traversal beyond the listed state boundaries is performed. A missing direct fanout endpoint does not prove disconnectedness.}
}
close $xu207_clock_map
close $xu207_lib_map
close $xu_status
puts {XU_OWN_S2C_READONLY177_COMPLETE_NOT_QUALIFIED}
} xu_error]} {
  puts stderr "XU177_FATAL: $xu_error"
  exit 1
}
exit 0
