# xu S2e130 独立功耗测量工具

130修复原124在raw SAIF身份字典字段形状上的误拒。原124代码和实际early failure保持不动。本工具仍使用S2e自身89映射/109证明和actual120完整12任务活动，先重做全部raw→normalized校验，再实际导出自己的336×67 PT inventory，最后运行12个独立全SoC PT窗口。没有更改Chisel、RTL、工艺DB、网表、SDC、向量或数值格式。

`xu_s2e_full_soc_power130.py`为49,042字节，SHA `95caa5fab255c5126e5b51f6f0b06c9bf63283f9bbf89dd310202abc87515d46`。launcher SHA `82ed8f7db2bf88643d320ea9016b0435c2c6dc11363825d5a024efb4c2f2a3b2`。

身份比较要求原path、SHA相同，并分别读取两种收据指向的实际正文核对SHA和声明bytes；合法省略bytes不会误拒，有声明则严格核对实际整数大小。43项host检查已经通过，其中新增actual120全部12任务的raw/normalized身份形状与正文bytes/SHA正例，以及错误bytes、SHA、path和bool大小负例。

run会强制implementation等于原own89 prepared，核对own inventory/actual120路径和窗口，再从冻结common为每份任务重建完整Tcl并逐字比较。改变netlist、wrapper strip或伪造零活动，即使同步更新保存的脚本SHA，仍由新guard拒绝。原两库、SDC、mapped及common资产SHA不变。

actual131快照已证明PID135097当时活着，原driver.log完成了task0、1、2的raw/normalized重放；**这只是准备中快照，不是全12重放、PT inventory、功耗或终态通过。** 后续原件应另立新编号归档，不能改写131。全部PT结果仍是`NOT_QUALIFIED`，保留TX/TZ/TB、原生getter、annotation来源与SRAM条件功耗限制；不能代入比赛评分。

服务器已启动原130；不要重新运行以下启动命令。它只供新环境复现时参考，既有launch/output均会拒绝覆盖：

```bash
python3 "$HOME/Desktop/launch_s2e_power130.py"
```

输出为`~/Desktop/xu-score-optimization-20261102/s2e-full-soc-power12-20261105-130`，launch/log为同父目录`s2e-full-soc-power-launch-20261105-130`。prepare先校验全部活动，之后才创建output/preparation-state；先用同一PID的实际`/proc`和原driver.log观察，再看inventory/state、last_prepared_task及execution/current_task_id。观察超时不重启任务。

本地聚焦复现（需要同一actual125活动正文、actual57原报告和clean原109工具checkout）：

```bash
python3 build/xu-s2e-power130/check_power130.py \
  --frozen-tools build/xu-s2e-power124/frozen-tools109
```

host检查中的合成DB/TSV只测试生成器或parser，没有执行EDA，不冒充工艺库。host检查没有替代服务器own89/109/runtime绝对路径的完整重哈希，也没有授予完整150MHz或能量资格。
