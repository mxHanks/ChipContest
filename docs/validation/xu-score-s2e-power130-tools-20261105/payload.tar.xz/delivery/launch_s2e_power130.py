#!/usr/bin/env python3
"""Launch a fresh detached actual S2e130 diagnostic campaign; no credentials."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE = Path.home() / 'Desktop/xu-score-optimization-20261102'
OUTPUT = BASE / 's2e-full-soc-power12-20261105-130'
LAUNCH = BASE / 's2e-full-soc-power-launch-20261105-130'
PRODUCER = Path.home() / 'Desktop/xu_s2e_full_soc_power130.py'
PRODUCER_SHA = '95caa5fab255c5126e5b51f6f0b06c9bf63283f9bbf89dd310202abc87515d46'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    if OUTPUT.exists() or OUTPUT.is_symlink() or LAUNCH.exists() or LAUNCH.is_symlink():
        raise ValueError('130 output/launch already exists; observe original process, never restart or overwrite')
    if not PRODUCER.is_file() or PRODUCER.is_symlink() or sha(PRODUCER) != PRODUCER_SHA:
        raise ValueError('130 producer missing/type/SHA differs')
    activity = BASE / 's2e-formal-activity12-20261105-120/result.json'
    report = json.loads(activity.read_text())
    if (report.get('status') != 'COLLECTED_12_TASKS_REVIEW_PENDING' or report.get('taskset_complete') is not True or
            report.get('requested_task_ids') != list(range(12)) or [t.get('task_id') for t in report.get('tasks', [])] != list(range(12))):
        raise ValueError('actual120 full12 terminal result required')
    LAUNCH.mkdir()
    copied = LAUNCH / 'xu_s2e_full_soc_power130.py'
    shutil.copy2(str(PRODUCER), str(copied))
    if sha(copied) != PRODUCER_SHA:
        raise ValueError('frozen130 producer copy differs')
    command = [sys.executable, '-u', str(copied), 'campaign',
        '--activity', str(activity), '--source-root', str(BASE / 'ChipContest-s2e-74'),
        '--tool-root', str(BASE / 'ChipContest-s2e-activity-tools-109'),
        '--ppa-root', str(BASE / 's2e-ppa-campaign-20261104-89'),
        '--formality-root', str(BASE / 's2e-own-formality-audit-20261104-109'),
        '--out', str(OUTPUT), '--pt', '/eda/synopsys/prime/prime_2022.03-SP5-1/bin/pt_shell',
        '--lc-root', '/eda/synopsys/lib_compiler/lib_compiler_2022.03-SP5', '--inventory-timeout', '900', '--timeout', '21600']
    receipt = dict(status='LAUNCHING_NOT_QUALIFIED', producer_sha256=PRODUCER_SHA,
        frozen_producer=str(copied), source_producer=str(PRODUCER), activity=str(activity), activity_sha256=sha(activity),
        command=command, output=str(OUTPUT), started_epoch=time.time(), qualification='NOT_QUALIFIED')
    (LAUNCH / 'launch-state.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    try:
        with (LAUNCH / 'driver.log').open('x') as stream:
            stream.write(json.dumps(receipt, sort_keys=True) + '\n')
            stream.flush()
            process = subprocess.Popen(command, cwd=str(LAUNCH), stdin=subprocess.DEVNULL, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
        receipt.update(status='STARTED_NOT_QUALIFIED', pid=process.pid)
    except BaseException as error:
        receipt.update(status='LAUNCH_FAILED', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (LAUNCH / 'launch-state.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print('XU_S2E130_POWER_SPAWNED pid=%d NOT_QUALIFIED' % process.pid, flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
