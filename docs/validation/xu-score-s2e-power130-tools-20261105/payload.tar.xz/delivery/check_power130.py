#!/usr/bin/env python3
"""Focused host checks for130; never executes EDA or substitutes server guards."""
import argparse
import ast
import copy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location('xu_check130_driver', str(HERE / 'xu_s2e_full_soc_power130.py'))
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frozen-tools', type=Path, default=HERE / 'frozen-tools109')
    parser.add_argument('--activity', type=Path, default=ROOT / 'build/xu-score-resume-20261103/activity125/s2e-formal-activity12-20261105-120/result.json')
    parser.add_argument('--source', type=Path, default=Path('/home/mxhanks/Projects/ChipContest-xu-s2e-paired-hi'))
    parser.add_argument('--original57', type=Path, default=ROOT / 'build/xu-score-resume-20261103/next-results-export-69/s2c-full-soc-power12-20261104-57')
    parser.add_argument('--out', type=Path, default=HERE / 'host-check130.json')
    args = parser.parse_args()
    checks = []

    def passed(name):
        checks.append(dict(name=name, status='PASS'))
        print('PASS', name, flush=True)

    def reject(name, callback):
        try:
            callback()
        except (ValueError, KeyError, TypeError):
            passed(name)
            return
        raise AssertionError('mutant was accepted: ' + name)

    ast.parse((HERE / 'xu_s2e_full_soc_power130.py').read_text(), feature_version=(3, 6))
    passed('Python36 grammar')
    modules = driver.Modules(args.frozen_tools)
    ctx = modules.ctx(args.source)
    ctx.recheck()
    passed('actual clean original109 tool modules and frozen S2e source guards')
    report = driver.read(args.activity)
    driver.complete_taskset(report)
    passed('actual120 completed 12-task metadata accepted')
    pair_records = {}
    for task in report['tasks']:
        task_id = task['task_id']
        for key, filename in (('raw_saif', 'task.saif'), ('saif', 'task-normalized.saif')):
            left = copy.deepcopy(task[key])
            right = copy.deepcopy(task['normalization']['raw_saif' if key == 'raw_saif' else 'normalized_saif'])
            local = str(args.activity.parent / ('task_%02d' % task_id) / filename)
            left['path'] = right['path'] = local
            actual = driver.checked_capture_pair(left, right, pair_records)
            assert actual['sha256'] == task[key]['sha256']
        passed('actual120 task%02d raw and normalized receipt shapes, complete bytes and SHA' % task_id)
    source = report['tasks'][0]
    good_left = copy.deepcopy(source['raw_saif'])
    good_right = copy.deepcopy(source['normalization']['raw_saif'])
    good_left['path'] = good_right['path'] = str(args.activity.parent / 'task_00/task.saif')
    for label, mutation in [
        ('reject false declared raw byte count', lambda row: row.update(bytes=row['bytes'] + 1)),
        ('reject false declared raw SHA', lambda row: row.update(sha256='0' * 64)),
        ('reject changed original raw path', lambda row: row.update(path=row['path'] + '.changed')),
        ('reject bool byte count', lambda row: row.update(bytes=True)),
    ]:
        changed = copy.deepcopy(good_right)
        mutation(changed)
        reject(label, lambda: driver.checked_capture_pair(good_left, changed, {}))
    for label, mutation in [
        ('reject running120', lambda j: j.update(status='RUNNING')),
        ('reject task00 only', lambda j: j.update(requested_task_ids=[0], tasks=j['tasks'][:1], taskset_complete=False)),
        ('reject absent task11', lambda j: j.update(tasks=j['tasks'][:-1])),
        ('reject false completion flag', lambda j: j.update(taskset_complete=False)),
        ('reject duplicated task10', lambda j: j['tasks'][-1].update(task_id=10)),
    ]:
        changed = copy.deepcopy(report)
        mutation(changed)
        reject(label, lambda: driver.complete_taskset(changed))
    native57 = driver.read(args.original57 / 'prepared.json')
    execution57 = driver.read(args.original57 / 'execution.json')
    task57 = native57['tasks'][0]
    log57 = args.original57 / 'task_00/pt.log'
    driver.checked_native_log(log57, task57['completion_marker'], execution57['tasks'][0]['execution']['returncode'])
    passed('actual native PT57 original unique-marker/version/error parser')
    reject('reject native returncode failure', lambda: driver.checked_native_log(log57, task57['completion_marker'], 1))
    with tempfile.TemporaryDirectory(prefix='xu-check130-') as temp:
        temp = Path(temp)
        original_log = log57.read_text()
        for label, text in [
            ('reject marker echo only', original_log.replace('\n' + task57['completion_marker'] + '\n', '\n')),
            ('reject duplicate native marker', original_log + '\n' + task57['completion_marker'] + '\n'),
            ('reject rc0 native error', original_log + '\nError: synthetic injected failure\n'),
        ]:
            mutated = temp / 'pt-mutated.log'
            mutated.write_text(text)
            reject(label, lambda: driver.checked_native_log(mutated, task57['completion_marker'], 0))
        original_power = (args.original57 / 'task_00/power.rpt').read_text()
        power_dir = temp / 'power'
        power_dir.mkdir()
        (power_dir / 'power.rpt').write_text(original_power)
        synthetic_task = dict(activity_window=report['tasks'][0]['activity_window'], measured_summary={'HOST_CHECK_ONLY': True})
        diagnostic = driver.diagnostic(power_dir, synthetic_task)
        duration = Decimal(report['tasks'][0]['activity_window']['duration_ticks']) * Decimal('1e-15')
        assert Decimal(diagnostic['diagnostic_energy_j']) == Decimal(diagnostic['power_components']['total_power_w']) * duration
        assert diagnostic['qualification'] == 'NOT_QUALIFIED'
        passed('actual native57 power parser and120 duration diagnostic arithmetic only')
        (power_dir / 'power.rpt').write_text(original_power.replace('Power Units = 1 W', 'Power Units = 1 mW'))
        # Native spacing varies, mutate the unit token independently.
        import re
        (power_dir / 'power.rpt').write_text(re.sub(r'(Power Units\s*=\s*1\s+)W\b', r'\1mW', original_power))
        reject('reject mW reinterpretation', lambda: driver.diagnostic(power_dir, synthetic_task))
        (power_dir / 'power.rpt').write_text(original_power.replace('xu_soc_ppa_top', 'accelerator_wrapper_only'))
        reject('reject wrapper-only report', lambda: driver.diagnostic(power_dir, synthetic_task))
        mapping = report['configuration']['sram_alias']
        actual = {}
        for macro in mapping['macros']:
            full = modules.alias.slash(macro['instance'])
            relative = full[len(driver.STRIP) + 1:]
            names = sorted(modules.common.mapped_macros.PIN_NAMES)
            actual[relative] = dict(pins=[dict(name=n, full_name=relative + '/' + n) for n in names])
        local_saif = args.activity.parent / 'task_00/task-normalized.saif'
        measured = driver.measured_pins(modules, local_saif, actual, report['tasks'][0]['normalization']['alias_unknown_bit_ticks'])
        assert len(measured['pins']) == 22512 and measured['measured_summary']['q_pin_count'] == 5376
        passed('actual120 SAIF22512 pin input-layout and unknown dwell preservation; no mapped inventory claim')
        reject('reject modified unknown dwell', lambda: driver.measured_pins(modules, local_saif, actual, measured['alias_unknown_bit_ticks'] + 1))
        # Synthetic DB files exercise only Tcl generation; no EDA is run and
        # these are never supplied to the production mapped-context guard.
        impl = driver.read(ROOT / 'build/xu-score-resume-20261103/core-results-107/s2e-ppa-campaign-20261104-89/ppa/prepared.json')['implementation']
        synthetic_impl = copy.deepcopy(impl)
        for i, library in enumerate(synthetic_impl['libraries']):
            path = temp / ('HOST_SYNTHETIC_library_%d.db' % i)
            path.write_text('HOST SYNTHETIC ONLY\n')
            library.update(path=str(path), sha256=driver.sha(path))
        synthetic_item = dict(task_id=0, macro_names=sorted(actual), saif=dict(path=str(temp / 'mapped.saif')))
        text = modules.common.generate_tcl(synthetic_impl, dict(path='/HOST_SYNTHETIC/mapped.v'),
                                            dict(path='/HOST_SYNTHETIC/constraints.sdc'), synthetic_item, 'HOST_SYNTHETIC_COMPLETE')
        assert 'set_app_var power_analysis_mode averaged' in text
        assert '-strip_path {tb_xu_soc_ppa/dut}' in text
        assert 'report_switching_activity -list_by_source propagated -show_pin' in text
        assert 'report_attribute -application $xu_p' in text
        assert 'report_lib -power_arcs' in text
        assert text.count('\nupdate_power\n') == 1
        assert not re.search(r'\b(?:set_case_analysis|set_switching_activity)\b', text)
        passed('frozen common Tcl keeps full-DUT scope, native pin/source/Liberty reports, no invented activity')
        synthetic_item.update(completion_marker='HOST_SYNTHETIC_COMPLETE', script={'path':str(temp / 'HOST_SYNTHETIC_power.tcl')})
        net = dict(path='/HOST_SYNTHETIC/mapped.v')
        constraints = dict(path='/HOST_SYNTHETIC/constraints.sdc')
        expected_tcl = driver.power_tcl(modules, synthetic_impl, net, constraints, synthetic_item)
        script = Path(synthetic_item['script']['path'])
        script.write_text(expected_tcl)
        driver.checked_power_tcl(modules, synthetic_impl, net, constraints, synthetic_item)
        passed('130 actual Tcl reconstruction verifier accepts frozen-common generated script')
        for label, old, new in [
            ('reject Tcl netlist rewrite even when stored hash updated', '/HOST_SYNTHETIC/mapped.v', '/HOST_SYNTHETIC/other.v'),
            ('reject Tcl wrapper strip even when stored hash updated', '-strip_path {tb_xu_soc_ppa/dut}', '-strip_path {tb_xu_soc_ppa/dut/u_accel}'),
            ('reject invented zero switching even when stored hash updated', '\nupdate_timing\n', '\nupdate_timing\nset_switching_activity -toggle_rate 0 [all_inputs]\n'),
        ]:
            assert old in expected_tcl
            script.write_text(expected_tcl.replace(old, new, 1))
            synthetic_item['script'].update(sha256=driver.sha(script), bytes=script.stat().st_size)
            reject(label, lambda: driver.checked_power_tcl(modules, synthetic_impl, net, constraints, synthetic_item))
        script.write_text(expected_tcl)
        inventory_text = driver.inventory_tcl(modules.ppa, synthetic_impl, dict(path='/HOST_SYNTHETIC/mapped.v'),
                                               dict(path='/HOST_SYNTHETIC/constraints.sdc'), 'HOST_SYNTHETIC_INVENTORY')
        assert 'set XU_CLOCK_MODE envelope' in inventory_text and 'source {/HOST_SYNTHETIC/constraints.sdc}' in inventory_text
        assert 'if {$nc != 336 || $np != 22512}' in inventory_text
        passed('own inventory Tcl exact netlist/SDC/clocks/336x67 export guards')
        table = temp / 'HOST_SYNTHETIC_macro-pins.tsv'
        rows = ['kind\tcell\tref_or_pin\tlibcell_or_direction']
        for name, record in sorted(actual.items()):
            rows.append('MACRO\t%s\tRAMSP1024X16\tRAMSP1024X16_ss_0p99v_0p99v_125c/RAMSP1024X16' % name)
            for pin in record['pins']:
                rows.append('PIN\t%s\t%s\t%s' % (name, pin['full_name'], 'out' if pin['name'].startswith('Q[') else 'in'))
        table.write_text('\n'.join(rows) + '\n')
        parsed = driver.inventory_rows(table)
        assert len(parsed) == 336 and sum(len(row['pins']) for row in parsed) == 22512
        passed('synthetic complete336x67 raw inventory TSV parser')
        table.write_text('\n'.join(rows + [rows[-1]]) + '\n')
        reject('reject duplicate native pin TSV row', lambda: driver.inventory_rows(table))
        table.write_text('\n'.join(rows[:-1]) + '\n')
        reject('reject absent native pin TSV row', lambda: driver.inventory_rows(table))
    driver.write(args.out, dict(status='FOCUSED_HOST_CHECKS_PASS_NOT_SERVER_EXECUTION_OR_QUALIFICATION',
        producer=driver.identity(HERE / 'xu_s2e_full_soc_power130.py'), checks=checks,
        total=len(checks), source=driver.identity(args.activity),
        limitations=['No PT, own inventory, own89/109 server file rehash, full120 server runtime rehash, or energy qualification was executed locally.']))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
