# xu实验总控153（延续150原目录）

所有状态均为NOT_QUALIFIED；诊断完成不代表比赛资格。

|实验|状态|原始状态|PID|
|---|---|---|---|
|activity145_baseline_h1_h2|WAIT_DEPENDENCY|||
|activity145_compact32_128|WAIT_DEPENDENCY|||
|activity145_pe32|WAIT_DEPENDENCY|||
|activity145_pe64|WAIT_DEPENDENCY|||
|activity145_s1_h2_only|WAIT_DEPENDENCY|||
|activity145_s1_sram_bias|WAIT_DEPENDENCY|||
|activity145_s2b|WAIT_DEPENDENCY|||
|activity145_s2d|WAIT_DEPENDENCY|||
|baseline_rdc142|COMPLETED_DIAGNOSTIC_NOT_QUALIFIED|EXECUTED_SAME116_READ_ONLY_RECOVERY_VISIBILITY_NOT_QUALIFIED|167711|
|eight_freeze138|COMPLETED_DIAGNOSTIC_NOT_QUALIFIED|INPUTS_AND_ADOPTIONS_COMPLETE_REMAINING_PHASES_PENDING_NOT_QUALIFIED||
|mapped_private147|WAIT_DEPENDENCY|||
|power146_baseline_h1_h2|WAIT_DEPENDENCY|||
|power146_compact32_128|WAIT_DEPENDENCY|||
|power146_pe32|WAIT_DEPENDENCY|||
|power146_pe64|WAIT_DEPENDENCY|||
|power146_s1_h2_only|WAIT_DEPENDENCY|||
|power146_s1_sram_bias|WAIT_DEPENDENCY|||
|power146_s2b|WAIT_DEPENDENCY|||
|power146_s2d|WAIT_DEPENDENCY|||
|s2e_power130|COMPLETED_DIAGNOSTIC_NOT_QUALIFIED|EXECUTED_12_TASKS_DIAGNOSTIC_REVIEW_PENDING|135097|
|s2e_streamaudit156|WAIT_DEPENDENCY|||
|s2e_timing134|FAILED_REVIEW_REQUIRED|FAILED_NOT_QUALIFIED|161452|
|s2e_timing155|RUNNING|RUNNING_NOT_QUALIFIED|228701|
|zz_campaign_report154|WAIT_DEPENDENCY|||

资源及许可证：{"cpu_count": 96, "disk_available_bytes": 1460491255808, "epoch": 1793848872.1827054, "license_capacity": "UNKNOWN_NO_SPARE_SEATS_CLAIMED", "mem_available_bytes": 755014103040, "native_policy": "EXCLUSIVE_SINGLE_EXISTING_JOB_OR_ONE_NEW_JOB", "native_processes": [{"argv": ["/bin/sh", "/eda/synopsys/fm/fm_2020.09-SP5/bin/fm_shell", "-f", "verify.tcl"], "pid": 229241, "start_ticks": 118040734, "uid": 14023}, {"argv": ["/eda/synopsys/fm/fm_2020.09-SP5/linux64/fm/bin/fm_shell_exec", "-r", "/eda/synopsys/fm/fm_2020.09-SP5", "-f", "verify.tcl"], "pid": 229263, "start_ticks": 118040738, "uid": 14023}]}

已完成/失败的原结果和日志保持在各自目录；总控不删除、覆盖或自动重启。
