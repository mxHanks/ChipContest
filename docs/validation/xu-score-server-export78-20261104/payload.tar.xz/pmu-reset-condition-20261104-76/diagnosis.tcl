if {[catch {
set_app_var link_path [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db}]
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-reset-buffer-20261104-61-from50-n4/mapped.v}
if {![link_design xu_soc_ppa_top]} {error {actual61 mapped PT link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
set xu_unknown [open unknowns.tsv w]
puts $xu_unknown "scope\tdetail"
set xu_pins [open pins.tsv w]
puts $xu_pins "cell\tpin\tfield\tvalue"
set xu_arcs [open timing-arcs.tsv w]
puts $xu_arcs "cell\tobject_class\tarc\tfield\tvalue"
set xu_library [open library-properties.tsv w]
puts $xu_library "cell\tobject_class\tobject\tfield\tvalue"
set xu_paths [open reset-paths.tsv w]
puts $xu_paths "index\tpin\tcheck\tpath_count\tworst_slack\tstatus"
proc xu_safe_value {o a} {
 if {[catch {get_attribute -quiet $o $a} v]} {return [list QUERY_ERROR $v]}
 if {[regexp {^(from_pin|to_pin|from_lib_pin|to_lib_pin|clocks|launch_clocks|constrained_launch_clocks|dynamic_clocks)$} $a]} {
  if {[catch {get_object_name $v} xu_names]} {return [list COLLECTION_NAME_ERROR $xu_names]}
  return [list VALUE_NAMES $xu_names]
 }
 return [list VALUE $v]
}
proc xu_capture {filename command scope} {
 global xu_unknown
 if {[catch {redirect -file $filename {uplevel #0 $command}} v]} {
  puts $xu_unknown [join [list $scope QUERY_ERROR $v] "\t"]
  set f [open $filename a];puts $f "XU_QUERY_ERROR: $v";close $f
 }
}
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DSNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]
xu_capture {reset-0-recovery.rpt} [list report_timing -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/recovery}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/recovery} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/recovery} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 0 [get_object_name $xu_p] recovery $xu_count $xu_slack $xu_status] "\t"]
xu_capture {reset-0-removal.rpt} [list report_timing -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/removal}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/removal} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/removal} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 0 [get_object_name $xu_p] removal $xu_count $xu_slack $xu_status] "\t"]
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DSNQNV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]
xu_capture {reset-1-recovery.rpt} [list report_timing -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/recovery}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/recovery} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/recovery} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 1 [get_object_name $xu_p] recovery $xu_count $xu_slack $xu_status] "\t"]
xu_capture {reset-1-removal.rpt} [list report_timing -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/removal}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/removal} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/removal} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 1 [get_object_name $xu_p] removal $xu_count $xu_slack $xu_status] "\t"]
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DRNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN}]
xu_capture {reset-2-recovery.rpt} [list report_timing -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/recovery}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/recovery} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/recovery} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 2 [get_object_name $xu_p] recovery $xu_count $xu_slack $xu_status] "\t"]
xu_capture {reset-2-removal.rpt} [list report_timing -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/removal}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/removal} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/removal} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 2 [get_object_name $xu_p] removal $xu_count $xu_slack $xu_status] "\t"]
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DRNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN}]
xu_capture {reset-3-recovery.rpt} [list report_timing -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/recovery}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/recovery} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/recovery} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 3 [get_object_name $xu_p] recovery $xu_count $xu_slack $xu_status] "\t"]
xu_capture {reset-3-removal.rpt} [list report_timing -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/removal}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/removal} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/removal} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 3 [get_object_name $xu_p] removal $xu_count $xu_slack $xu_status] "\t"]
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DRNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN}]
xu_capture {reset-4-recovery.rpt} [list report_timing -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/recovery}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type max -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/recovery} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/recovery} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 4 [get_object_name $xu_p] recovery $xu_count $xu_slack $xu_status] "\t"]
xu_capture {reset-4-removal.rpt} [list report_timing -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/removal}
set xu_count UNKNOWN
set xu_slack UNKNOWN
set xu_status UNKNOWN
if {[catch {get_timing_paths -delay_type min -to $xu_p -slack_lesser_than 1000000 -max_paths 10} xu_ps]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/removal} paths_QUERY_ERROR $xu_ps] "\t"]
} else {
 set xu_count [sizeof_collection $xu_ps]
 if {$xu_count>0} {set xu_slack [get_attribute [index_collection $xu_ps 0] slack];set xu_status PATHS_PRESENT_DIAGNOSTIC_ONLY} else {
  puts $xu_unknown [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/removal} no_path_NOT_PASS]
 }
}
puts $xu_paths [join [list 4 [get_object_name $xu_p] removal $xu_count $xu_slack $xu_status] "\t"]
flush $xu_paths
flush $xu_unknown
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DSNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_cp [get_pins -of_objects $xu_c]
foreach_in_collection xu_p $xu_cp {
 set xu_pn [get_object_name $xu_p]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {actual_min_clock_pulse_width_high} [xu_safe_value $xu_p {actual_min_clock_pulse_width_high}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {actual_min_clock_pulse_width_low} [xu_safe_value $xu_p {actual_min_clock_pulse_width_low}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {case_value} [xu_safe_value $xu_p {case_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_capture_arrival_dynamic} [xu_safe_value $xu_p {clock_capture_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_capture_arrival_static} [xu_safe_value $xu_p {clock_capture_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_latency_fall_max} [xu_safe_value $xu_p {clock_latency_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_latency_fall_min} [xu_safe_value $xu_p {clock_latency_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_latency_rise_max} [xu_safe_value $xu_p {clock_latency_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_latency_rise_min} [xu_safe_value $xu_p {clock_latency_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_launch_arrival_dynamic} [xu_safe_value $xu_p {clock_launch_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_launch_arrival_static} [xu_safe_value $xu_p {clock_launch_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_early_fall_max} [xu_safe_value $xu_p {clock_source_latency_early_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_early_fall_min} [xu_safe_value $xu_p {clock_source_latency_early_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_early_rise_max} [xu_safe_value $xu_p {clock_source_latency_early_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_early_rise_min} [xu_safe_value $xu_p {clock_source_latency_early_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_late_fall_max} [xu_safe_value $xu_p {clock_source_latency_late_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_late_fall_min} [xu_safe_value $xu_p {clock_source_latency_late_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_late_rise_max} [xu_safe_value $xu_p {clock_source_latency_late_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clock_source_latency_late_rise_min} [xu_safe_value $xu_p {clock_source_latency_late_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {clocks} [xu_safe_value $xu_p {clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {constant_value} [xu_safe_value $xu_p {constant_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {constrained_launch_clocks} [xu_safe_value $xu_p {constrained_launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {direction} [xu_safe_value $xu_p {direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {disable_timing} [xu_safe_value $xu_p {disable_timing}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {dynamic_clocks} [xu_safe_value $xu_p {dynamic_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {escaped_full_name} [xu_safe_value $xu_p {escaped_full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {full_name} [xu_safe_value $xu_p {full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {has_model_mismatch_clock} [xu_safe_value $xu_p {has_model_mismatch_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_async_pin} [xu_safe_value $xu_p {is_async_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_exclusivity} [xu_safe_value $xu_p {is_clock_exclusivity}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_gating_pin} [xu_safe_value $xu_p {is_clock_gating_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_network} [xu_safe_value $xu_p {is_clock_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_pin} [xu_safe_value $xu_p {is_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_source} [xu_safe_value $xu_p {is_clock_source}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_source_network} [xu_safe_value $xu_p {is_clock_source_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_used_as_clock} [xu_safe_value $xu_p {is_clock_used_as_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_clock_used_as_data} [xu_safe_value $xu_p {is_clock_used_as_data}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_preset_pin} [xu_safe_value $xu_p {is_preset_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {launch_clocks} [xu_safe_value $xu_p {launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {min_launch_clock_period} [xu_safe_value $xu_p {min_launch_clock_period}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {pin_direction} [xu_safe_value $xu_p {pin_direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {power_base_clock} [xu_safe_value $xu_p {power_base_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {propagated_clock} [xu_safe_value $xu_p {propagated_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn {user_case_value} [xu_safe_value $xu_p {user_case_value}]] "\t"]
 if {[catch {get_nets -of_objects $xu_p} xu_ns]} {
  puts $xu_unknown [join [list $xu_pn nets_QUERY_ERROR $xu_ns] "\t"]
 } else {
  puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn nets [get_object_name $xu_ns]] "\t"]
  foreach_in_collection xu_n $xu_ns {
   if {[catch {all_connected -leaf $xu_n} xu_con]} {puts $xu_unknown [join [list $xu_pn connections_QUERY_ERROR $xu_con] "\t"]} else {
    foreach_in_collection xu_o $xu_con {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn leaf_connection [get_object_name $xu_o] [xu_safe_value $xu_o direction]] "\t"]}
   }
  }
 }
 if {[get_attribute $xu_p direction] eq "in"} {
  if {[catch {all_fanin -flat -startpoints_only -to $xu_p} xu_starts]} {puts $xu_unknown [join [list $xu_pn fanin_QUERY_ERROR $xu_starts] "\t"]} else {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} $xu_pn fanin_startpoints [get_object_name $xu_starts]] "\t"]}
 }
}
xu_capture {cell-0-all-design-arcs.rpt} [list report_attribute -application [get_timing_arcs -of_objects $xu_c]] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg}
set xu_lc [get_lib_cells -of_objects $xu_c]
set xu_lps [get_lib_pins -of_objects $xu_lc]
foreach_in_collection xu_lo $xu_lc {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {function_id} [xu_safe_value $xu_lo {function_id}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {is_case_sequential_propagation} [xu_safe_value $xu_lo {is_case_sequential_propagation}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {is_integrated_clock_gating_cell} [xu_safe_value $xu_lo {is_integrated_clock_gating_cell}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {is_sequential} [xu_safe_value $xu_lo {is_sequential}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {is_shared_timing_model} [xu_safe_value $xu_lo {is_shared_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {master_timing_model} [xu_safe_value $xu_lo {master_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {shared_timing_models} [xu_safe_value $xu_lo {shared_timing_models}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {timing_model_type} [xu_safe_value $xu_lo {timing_model_type}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_cell} [get_object_name $xu_lo] {user_function_class} [xu_safe_value $xu_lo {user_function_class}]] "\t"]
}
foreach_in_collection xu_lo $xu_lps {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {clock} [xu_safe_value $xu_lo {clock}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {direction} [xu_safe_value $xu_lo {direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {is_clock_pin} [xu_safe_value $xu_lo {is_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {pin_direction} [xu_safe_value $xu_lo {pin_direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {power_down_function} [xu_safe_value $xu_lo {power_down_function}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {related_ground_pin} [xu_safe_value $xu_lo {related_ground_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_pin} [get_object_name $xu_lo] {related_power_pin} [xu_safe_value $xu_lo {related_power_pin}]] "\t"]
}
set xu_owner $xu_c
if {[catch {get_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {get_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {annotated_delay_delta_max} [xu_safe_value $xu_a {annotated_delay_delta_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {annotated_delay_delta_max_fall} [xu_safe_value $xu_a {annotated_delay_delta_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {annotated_delay_delta_max_rise} [xu_safe_value $xu_a {annotated_delay_delta_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {annotated_delay_delta_min} [xu_safe_value $xu_a {annotated_delay_delta_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {annotated_delay_delta_min_fall} [xu_safe_value $xu_a {annotated_delay_delta_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {annotated_delay_delta_min_rise} [xu_safe_value $xu_a {annotated_delay_delta_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {delay_max} [xu_safe_value $xu_a {delay_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {delay_max_fall} [xu_safe_value $xu_a {delay_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {delay_max_rise} [xu_safe_value $xu_a {delay_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {delay_min} [xu_safe_value $xu_a {delay_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {delay_min_fall} [xu_safe_value $xu_a {delay_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {delay_min_rise} [xu_safe_value $xu_a {delay_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {from_pin} [xu_safe_value $xu_a {from_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_constraint_scaled_max_fall} [xu_safe_value $xu_a {is_constraint_scaled_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_constraint_scaled_max_rise} [xu_safe_value $xu_a {is_constraint_scaled_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_constraint_scaled_min_fall} [xu_safe_value $xu_a {is_constraint_scaled_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_constraint_scaled_min_rise} [xu_safe_value $xu_a {is_constraint_scaled_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_db_inherited_disabled} [xu_safe_value $xu_a {is_db_inherited_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {sdf_cond_end} [xu_safe_value $xu_a {sdf_cond_end}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {sdf_cond_start} [xu_safe_value $xu_a {sdf_cond_start}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {to_pin} [xu_safe_value $xu_a {to_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
set xu_owner [get_lib_cells -of_objects $xu_c]
if {[catch {get_lib_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {get_lib_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {from_lib_pin} [xu_safe_value $xu_a {from_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {has_arc_related_power_pins} [xu_safe_value $xu_a {has_arc_related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {related_power_pins} [xu_safe_value $xu_a {related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {to_lib_pin} [xu_safe_value $xu_a {to_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {unrelated_power_pins} [xu_safe_value $xu_a {unrelated_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg} {lib_timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
xu_capture {cell-0-disabled.rpt} [list report_disable_timing $xu_c] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg}
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DSNQNV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_cp [get_pins -of_objects $xu_c]
foreach_in_collection xu_p $xu_cp {
 set xu_pn [get_object_name $xu_p]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {actual_min_clock_pulse_width_high} [xu_safe_value $xu_p {actual_min_clock_pulse_width_high}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {actual_min_clock_pulse_width_low} [xu_safe_value $xu_p {actual_min_clock_pulse_width_low}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {case_value} [xu_safe_value $xu_p {case_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_capture_arrival_dynamic} [xu_safe_value $xu_p {clock_capture_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_capture_arrival_static} [xu_safe_value $xu_p {clock_capture_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_latency_fall_max} [xu_safe_value $xu_p {clock_latency_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_latency_fall_min} [xu_safe_value $xu_p {clock_latency_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_latency_rise_max} [xu_safe_value $xu_p {clock_latency_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_latency_rise_min} [xu_safe_value $xu_p {clock_latency_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_launch_arrival_dynamic} [xu_safe_value $xu_p {clock_launch_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_launch_arrival_static} [xu_safe_value $xu_p {clock_launch_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_early_fall_max} [xu_safe_value $xu_p {clock_source_latency_early_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_early_fall_min} [xu_safe_value $xu_p {clock_source_latency_early_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_early_rise_max} [xu_safe_value $xu_p {clock_source_latency_early_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_early_rise_min} [xu_safe_value $xu_p {clock_source_latency_early_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_late_fall_max} [xu_safe_value $xu_p {clock_source_latency_late_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_late_fall_min} [xu_safe_value $xu_p {clock_source_latency_late_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_late_rise_max} [xu_safe_value $xu_p {clock_source_latency_late_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clock_source_latency_late_rise_min} [xu_safe_value $xu_p {clock_source_latency_late_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {clocks} [xu_safe_value $xu_p {clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {constant_value} [xu_safe_value $xu_p {constant_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {constrained_launch_clocks} [xu_safe_value $xu_p {constrained_launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {direction} [xu_safe_value $xu_p {direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {disable_timing} [xu_safe_value $xu_p {disable_timing}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {dynamic_clocks} [xu_safe_value $xu_p {dynamic_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {escaped_full_name} [xu_safe_value $xu_p {escaped_full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {full_name} [xu_safe_value $xu_p {full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {has_model_mismatch_clock} [xu_safe_value $xu_p {has_model_mismatch_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_async_pin} [xu_safe_value $xu_p {is_async_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_exclusivity} [xu_safe_value $xu_p {is_clock_exclusivity}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_gating_pin} [xu_safe_value $xu_p {is_clock_gating_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_network} [xu_safe_value $xu_p {is_clock_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_pin} [xu_safe_value $xu_p {is_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_source} [xu_safe_value $xu_p {is_clock_source}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_source_network} [xu_safe_value $xu_p {is_clock_source_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_used_as_clock} [xu_safe_value $xu_p {is_clock_used_as_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_clock_used_as_data} [xu_safe_value $xu_p {is_clock_used_as_data}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_preset_pin} [xu_safe_value $xu_p {is_preset_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {launch_clocks} [xu_safe_value $xu_p {launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {min_launch_clock_period} [xu_safe_value $xu_p {min_launch_clock_period}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {pin_direction} [xu_safe_value $xu_p {pin_direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {power_base_clock} [xu_safe_value $xu_p {power_base_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {propagated_clock} [xu_safe_value $xu_p {propagated_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn {user_case_value} [xu_safe_value $xu_p {user_case_value}]] "\t"]
 if {[catch {get_nets -of_objects $xu_p} xu_ns]} {
  puts $xu_unknown [join [list $xu_pn nets_QUERY_ERROR $xu_ns] "\t"]
 } else {
  puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn nets [get_object_name $xu_ns]] "\t"]
  foreach_in_collection xu_n $xu_ns {
   if {[catch {all_connected -leaf $xu_n} xu_con]} {puts $xu_unknown [join [list $xu_pn connections_QUERY_ERROR $xu_con] "\t"]} else {
    foreach_in_collection xu_o $xu_con {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn leaf_connection [get_object_name $xu_o] [xu_safe_value $xu_o direction]] "\t"]}
   }
  }
 }
 if {[get_attribute $xu_p direction] eq "in"} {
  if {[catch {all_fanin -flat -startpoints_only -to $xu_p} xu_starts]} {puts $xu_unknown [join [list $xu_pn fanin_QUERY_ERROR $xu_starts] "\t"]} else {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} $xu_pn fanin_startpoints [get_object_name $xu_starts]] "\t"]}
 }
}
xu_capture {cell-1-all-design-arcs.rpt} [list report_attribute -application [get_timing_arcs -of_objects $xu_c]] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg}
set xu_lc [get_lib_cells -of_objects $xu_c]
set xu_lps [get_lib_pins -of_objects $xu_lc]
foreach_in_collection xu_lo $xu_lc {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {function_id} [xu_safe_value $xu_lo {function_id}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {is_case_sequential_propagation} [xu_safe_value $xu_lo {is_case_sequential_propagation}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {is_integrated_clock_gating_cell} [xu_safe_value $xu_lo {is_integrated_clock_gating_cell}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {is_sequential} [xu_safe_value $xu_lo {is_sequential}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {is_shared_timing_model} [xu_safe_value $xu_lo {is_shared_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {master_timing_model} [xu_safe_value $xu_lo {master_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {shared_timing_models} [xu_safe_value $xu_lo {shared_timing_models}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {timing_model_type} [xu_safe_value $xu_lo {timing_model_type}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_cell} [get_object_name $xu_lo] {user_function_class} [xu_safe_value $xu_lo {user_function_class}]] "\t"]
}
foreach_in_collection xu_lo $xu_lps {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {clock} [xu_safe_value $xu_lo {clock}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {direction} [xu_safe_value $xu_lo {direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {is_clock_pin} [xu_safe_value $xu_lo {is_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {pin_direction} [xu_safe_value $xu_lo {pin_direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {power_down_function} [xu_safe_value $xu_lo {power_down_function}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {related_ground_pin} [xu_safe_value $xu_lo {related_ground_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_pin} [get_object_name $xu_lo] {related_power_pin} [xu_safe_value $xu_lo {related_power_pin}]] "\t"]
}
set xu_owner $xu_c
if {[catch {get_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {get_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {annotated_delay_delta_max} [xu_safe_value $xu_a {annotated_delay_delta_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {annotated_delay_delta_max_fall} [xu_safe_value $xu_a {annotated_delay_delta_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {annotated_delay_delta_max_rise} [xu_safe_value $xu_a {annotated_delay_delta_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {annotated_delay_delta_min} [xu_safe_value $xu_a {annotated_delay_delta_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {annotated_delay_delta_min_fall} [xu_safe_value $xu_a {annotated_delay_delta_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {annotated_delay_delta_min_rise} [xu_safe_value $xu_a {annotated_delay_delta_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {delay_max} [xu_safe_value $xu_a {delay_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {delay_max_fall} [xu_safe_value $xu_a {delay_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {delay_max_rise} [xu_safe_value $xu_a {delay_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {delay_min} [xu_safe_value $xu_a {delay_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {delay_min_fall} [xu_safe_value $xu_a {delay_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {delay_min_rise} [xu_safe_value $xu_a {delay_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {from_pin} [xu_safe_value $xu_a {from_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_constraint_scaled_max_fall} [xu_safe_value $xu_a {is_constraint_scaled_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_constraint_scaled_max_rise} [xu_safe_value $xu_a {is_constraint_scaled_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_constraint_scaled_min_fall} [xu_safe_value $xu_a {is_constraint_scaled_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_constraint_scaled_min_rise} [xu_safe_value $xu_a {is_constraint_scaled_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_db_inherited_disabled} [xu_safe_value $xu_a {is_db_inherited_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {sdf_cond_end} [xu_safe_value $xu_a {sdf_cond_end}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {sdf_cond_start} [xu_safe_value $xu_a {sdf_cond_start}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {to_pin} [xu_safe_value $xu_a {to_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
set xu_owner [get_lib_cells -of_objects $xu_c]
if {[catch {get_lib_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {get_lib_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {from_lib_pin} [xu_safe_value $xu_a {from_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {has_arc_related_power_pins} [xu_safe_value $xu_a {has_arc_related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {related_power_pins} [xu_safe_value $xu_a {related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {to_lib_pin} [xu_safe_value $xu_a {to_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {unrelated_power_pins} [xu_safe_value $xu_a {unrelated_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg} {lib_timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
xu_capture {cell-1-disabled.rpt} [list report_disable_timing $xu_c] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg}
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DRNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_cp [get_pins -of_objects $xu_c]
foreach_in_collection xu_p $xu_cp {
 set xu_pn [get_object_name $xu_p]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {actual_min_clock_pulse_width_high} [xu_safe_value $xu_p {actual_min_clock_pulse_width_high}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {actual_min_clock_pulse_width_low} [xu_safe_value $xu_p {actual_min_clock_pulse_width_low}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {case_value} [xu_safe_value $xu_p {case_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_capture_arrival_dynamic} [xu_safe_value $xu_p {clock_capture_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_capture_arrival_static} [xu_safe_value $xu_p {clock_capture_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_latency_fall_max} [xu_safe_value $xu_p {clock_latency_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_latency_fall_min} [xu_safe_value $xu_p {clock_latency_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_latency_rise_max} [xu_safe_value $xu_p {clock_latency_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_latency_rise_min} [xu_safe_value $xu_p {clock_latency_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_launch_arrival_dynamic} [xu_safe_value $xu_p {clock_launch_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_launch_arrival_static} [xu_safe_value $xu_p {clock_launch_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_early_fall_max} [xu_safe_value $xu_p {clock_source_latency_early_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_early_fall_min} [xu_safe_value $xu_p {clock_source_latency_early_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_early_rise_max} [xu_safe_value $xu_p {clock_source_latency_early_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_early_rise_min} [xu_safe_value $xu_p {clock_source_latency_early_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_late_fall_max} [xu_safe_value $xu_p {clock_source_latency_late_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_late_fall_min} [xu_safe_value $xu_p {clock_source_latency_late_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_late_rise_max} [xu_safe_value $xu_p {clock_source_latency_late_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clock_source_latency_late_rise_min} [xu_safe_value $xu_p {clock_source_latency_late_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {clocks} [xu_safe_value $xu_p {clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {constant_value} [xu_safe_value $xu_p {constant_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {constrained_launch_clocks} [xu_safe_value $xu_p {constrained_launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {direction} [xu_safe_value $xu_p {direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {disable_timing} [xu_safe_value $xu_p {disable_timing}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {dynamic_clocks} [xu_safe_value $xu_p {dynamic_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {escaped_full_name} [xu_safe_value $xu_p {escaped_full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {full_name} [xu_safe_value $xu_p {full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {has_model_mismatch_clock} [xu_safe_value $xu_p {has_model_mismatch_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_async_pin} [xu_safe_value $xu_p {is_async_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_exclusivity} [xu_safe_value $xu_p {is_clock_exclusivity}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_gating_pin} [xu_safe_value $xu_p {is_clock_gating_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_network} [xu_safe_value $xu_p {is_clock_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_pin} [xu_safe_value $xu_p {is_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_source} [xu_safe_value $xu_p {is_clock_source}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_source_network} [xu_safe_value $xu_p {is_clock_source_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_used_as_clock} [xu_safe_value $xu_p {is_clock_used_as_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_clock_used_as_data} [xu_safe_value $xu_p {is_clock_used_as_data}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_preset_pin} [xu_safe_value $xu_p {is_preset_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {launch_clocks} [xu_safe_value $xu_p {launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {min_launch_clock_period} [xu_safe_value $xu_p {min_launch_clock_period}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {pin_direction} [xu_safe_value $xu_p {pin_direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {power_base_clock} [xu_safe_value $xu_p {power_base_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {propagated_clock} [xu_safe_value $xu_p {propagated_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn {user_case_value} [xu_safe_value $xu_p {user_case_value}]] "\t"]
 if {[catch {get_nets -of_objects $xu_p} xu_ns]} {
  puts $xu_unknown [join [list $xu_pn nets_QUERY_ERROR $xu_ns] "\t"]
 } else {
  puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn nets [get_object_name $xu_ns]] "\t"]
  foreach_in_collection xu_n $xu_ns {
   if {[catch {all_connected -leaf $xu_n} xu_con]} {puts $xu_unknown [join [list $xu_pn connections_QUERY_ERROR $xu_con] "\t"]} else {
    foreach_in_collection xu_o $xu_con {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn leaf_connection [get_object_name $xu_o] [xu_safe_value $xu_o direction]] "\t"]}
   }
  }
 }
 if {[get_attribute $xu_p direction] eq "in"} {
  if {[catch {all_fanin -flat -startpoints_only -to $xu_p} xu_starts]} {puts $xu_unknown [join [list $xu_pn fanin_QUERY_ERROR $xu_starts] "\t"]} else {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} $xu_pn fanin_startpoints [get_object_name $xu_starts]] "\t"]}
 }
}
xu_capture {cell-2-all-design-arcs.rpt} [list report_attribute -application [get_timing_arcs -of_objects $xu_c]] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg}
set xu_lc [get_lib_cells -of_objects $xu_c]
set xu_lps [get_lib_pins -of_objects $xu_lc]
foreach_in_collection xu_lo $xu_lc {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {function_id} [xu_safe_value $xu_lo {function_id}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {is_case_sequential_propagation} [xu_safe_value $xu_lo {is_case_sequential_propagation}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {is_integrated_clock_gating_cell} [xu_safe_value $xu_lo {is_integrated_clock_gating_cell}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {is_sequential} [xu_safe_value $xu_lo {is_sequential}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {is_shared_timing_model} [xu_safe_value $xu_lo {is_shared_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {master_timing_model} [xu_safe_value $xu_lo {master_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {shared_timing_models} [xu_safe_value $xu_lo {shared_timing_models}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {timing_model_type} [xu_safe_value $xu_lo {timing_model_type}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_cell} [get_object_name $xu_lo] {user_function_class} [xu_safe_value $xu_lo {user_function_class}]] "\t"]
}
foreach_in_collection xu_lo $xu_lps {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {clock} [xu_safe_value $xu_lo {clock}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {direction} [xu_safe_value $xu_lo {direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {is_clock_pin} [xu_safe_value $xu_lo {is_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {pin_direction} [xu_safe_value $xu_lo {pin_direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {power_down_function} [xu_safe_value $xu_lo {power_down_function}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {related_ground_pin} [xu_safe_value $xu_lo {related_ground_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_pin} [get_object_name $xu_lo] {related_power_pin} [xu_safe_value $xu_lo {related_power_pin}]] "\t"]
}
set xu_owner $xu_c
if {[catch {get_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {get_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max} [xu_safe_value $xu_a {annotated_delay_delta_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max_fall} [xu_safe_value $xu_a {annotated_delay_delta_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max_rise} [xu_safe_value $xu_a {annotated_delay_delta_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min} [xu_safe_value $xu_a {annotated_delay_delta_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min_fall} [xu_safe_value $xu_a {annotated_delay_delta_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min_rise} [xu_safe_value $xu_a {annotated_delay_delta_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {delay_max} [xu_safe_value $xu_a {delay_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {delay_max_fall} [xu_safe_value $xu_a {delay_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {delay_max_rise} [xu_safe_value $xu_a {delay_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {delay_min} [xu_safe_value $xu_a {delay_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {delay_min_fall} [xu_safe_value $xu_a {delay_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {delay_min_rise} [xu_safe_value $xu_a {delay_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {from_pin} [xu_safe_value $xu_a {from_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_constraint_scaled_max_fall} [xu_safe_value $xu_a {is_constraint_scaled_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_constraint_scaled_max_rise} [xu_safe_value $xu_a {is_constraint_scaled_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_constraint_scaled_min_fall} [xu_safe_value $xu_a {is_constraint_scaled_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_constraint_scaled_min_rise} [xu_safe_value $xu_a {is_constraint_scaled_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_db_inherited_disabled} [xu_safe_value $xu_a {is_db_inherited_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {sdf_cond_end} [xu_safe_value $xu_a {sdf_cond_end}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {sdf_cond_start} [xu_safe_value $xu_a {sdf_cond_start}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {to_pin} [xu_safe_value $xu_a {to_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
set xu_owner [get_lib_cells -of_objects $xu_c]
if {[catch {get_lib_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {get_lib_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {from_lib_pin} [xu_safe_value $xu_a {from_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {has_arc_related_power_pins} [xu_safe_value $xu_a {has_arc_related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {related_power_pins} [xu_safe_value $xu_a {related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {to_lib_pin} [xu_safe_value $xu_a {to_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {unrelated_power_pins} [xu_safe_value $xu_a {unrelated_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg} {lib_timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
xu_capture {cell-2-disabled.rpt} [list report_disable_timing $xu_c] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg}
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DRNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_cp [get_pins -of_objects $xu_c]
foreach_in_collection xu_p $xu_cp {
 set xu_pn [get_object_name $xu_p]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {actual_min_clock_pulse_width_high} [xu_safe_value $xu_p {actual_min_clock_pulse_width_high}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {actual_min_clock_pulse_width_low} [xu_safe_value $xu_p {actual_min_clock_pulse_width_low}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {case_value} [xu_safe_value $xu_p {case_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_capture_arrival_dynamic} [xu_safe_value $xu_p {clock_capture_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_capture_arrival_static} [xu_safe_value $xu_p {clock_capture_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_latency_fall_max} [xu_safe_value $xu_p {clock_latency_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_latency_fall_min} [xu_safe_value $xu_p {clock_latency_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_latency_rise_max} [xu_safe_value $xu_p {clock_latency_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_latency_rise_min} [xu_safe_value $xu_p {clock_latency_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_launch_arrival_dynamic} [xu_safe_value $xu_p {clock_launch_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_launch_arrival_static} [xu_safe_value $xu_p {clock_launch_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_early_fall_max} [xu_safe_value $xu_p {clock_source_latency_early_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_early_fall_min} [xu_safe_value $xu_p {clock_source_latency_early_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_early_rise_max} [xu_safe_value $xu_p {clock_source_latency_early_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_early_rise_min} [xu_safe_value $xu_p {clock_source_latency_early_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_late_fall_max} [xu_safe_value $xu_p {clock_source_latency_late_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_late_fall_min} [xu_safe_value $xu_p {clock_source_latency_late_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_late_rise_max} [xu_safe_value $xu_p {clock_source_latency_late_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clock_source_latency_late_rise_min} [xu_safe_value $xu_p {clock_source_latency_late_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {clocks} [xu_safe_value $xu_p {clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {constant_value} [xu_safe_value $xu_p {constant_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {constrained_launch_clocks} [xu_safe_value $xu_p {constrained_launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {direction} [xu_safe_value $xu_p {direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {disable_timing} [xu_safe_value $xu_p {disable_timing}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {dynamic_clocks} [xu_safe_value $xu_p {dynamic_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {escaped_full_name} [xu_safe_value $xu_p {escaped_full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {full_name} [xu_safe_value $xu_p {full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {has_model_mismatch_clock} [xu_safe_value $xu_p {has_model_mismatch_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_async_pin} [xu_safe_value $xu_p {is_async_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_exclusivity} [xu_safe_value $xu_p {is_clock_exclusivity}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_gating_pin} [xu_safe_value $xu_p {is_clock_gating_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_network} [xu_safe_value $xu_p {is_clock_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_pin} [xu_safe_value $xu_p {is_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_source} [xu_safe_value $xu_p {is_clock_source}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_source_network} [xu_safe_value $xu_p {is_clock_source_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_used_as_clock} [xu_safe_value $xu_p {is_clock_used_as_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_clock_used_as_data} [xu_safe_value $xu_p {is_clock_used_as_data}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_preset_pin} [xu_safe_value $xu_p {is_preset_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {launch_clocks} [xu_safe_value $xu_p {launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {min_launch_clock_period} [xu_safe_value $xu_p {min_launch_clock_period}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {pin_direction} [xu_safe_value $xu_p {pin_direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {power_base_clock} [xu_safe_value $xu_p {power_base_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {propagated_clock} [xu_safe_value $xu_p {propagated_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn {user_case_value} [xu_safe_value $xu_p {user_case_value}]] "\t"]
 if {[catch {get_nets -of_objects $xu_p} xu_ns]} {
  puts $xu_unknown [join [list $xu_pn nets_QUERY_ERROR $xu_ns] "\t"]
 } else {
  puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn nets [get_object_name $xu_ns]] "\t"]
  foreach_in_collection xu_n $xu_ns {
   if {[catch {all_connected -leaf $xu_n} xu_con]} {puts $xu_unknown [join [list $xu_pn connections_QUERY_ERROR $xu_con] "\t"]} else {
    foreach_in_collection xu_o $xu_con {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn leaf_connection [get_object_name $xu_o] [xu_safe_value $xu_o direction]] "\t"]}
   }
  }
 }
 if {[get_attribute $xu_p direction] eq "in"} {
  if {[catch {all_fanin -flat -startpoints_only -to $xu_p} xu_starts]} {puts $xu_unknown [join [list $xu_pn fanin_QUERY_ERROR $xu_starts] "\t"]} else {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} $xu_pn fanin_startpoints [get_object_name $xu_starts]] "\t"]}
 }
}
xu_capture {cell-3-all-design-arcs.rpt} [list report_attribute -application [get_timing_arcs -of_objects $xu_c]] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg}
set xu_lc [get_lib_cells -of_objects $xu_c]
set xu_lps [get_lib_pins -of_objects $xu_lc]
foreach_in_collection xu_lo $xu_lc {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {function_id} [xu_safe_value $xu_lo {function_id}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {is_case_sequential_propagation} [xu_safe_value $xu_lo {is_case_sequential_propagation}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {is_integrated_clock_gating_cell} [xu_safe_value $xu_lo {is_integrated_clock_gating_cell}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {is_sequential} [xu_safe_value $xu_lo {is_sequential}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {is_shared_timing_model} [xu_safe_value $xu_lo {is_shared_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {master_timing_model} [xu_safe_value $xu_lo {master_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {shared_timing_models} [xu_safe_value $xu_lo {shared_timing_models}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {timing_model_type} [xu_safe_value $xu_lo {timing_model_type}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_cell} [get_object_name $xu_lo] {user_function_class} [xu_safe_value $xu_lo {user_function_class}]] "\t"]
}
foreach_in_collection xu_lo $xu_lps {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {clock} [xu_safe_value $xu_lo {clock}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {direction} [xu_safe_value $xu_lo {direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {is_clock_pin} [xu_safe_value $xu_lo {is_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {pin_direction} [xu_safe_value $xu_lo {pin_direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {power_down_function} [xu_safe_value $xu_lo {power_down_function}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {related_ground_pin} [xu_safe_value $xu_lo {related_ground_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_pin} [get_object_name $xu_lo] {related_power_pin} [xu_safe_value $xu_lo {related_power_pin}]] "\t"]
}
set xu_owner $xu_c
if {[catch {get_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {get_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max} [xu_safe_value $xu_a {annotated_delay_delta_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max_fall} [xu_safe_value $xu_a {annotated_delay_delta_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max_rise} [xu_safe_value $xu_a {annotated_delay_delta_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min} [xu_safe_value $xu_a {annotated_delay_delta_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min_fall} [xu_safe_value $xu_a {annotated_delay_delta_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min_rise} [xu_safe_value $xu_a {annotated_delay_delta_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {delay_max} [xu_safe_value $xu_a {delay_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {delay_max_fall} [xu_safe_value $xu_a {delay_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {delay_max_rise} [xu_safe_value $xu_a {delay_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {delay_min} [xu_safe_value $xu_a {delay_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {delay_min_fall} [xu_safe_value $xu_a {delay_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {delay_min_rise} [xu_safe_value $xu_a {delay_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {from_pin} [xu_safe_value $xu_a {from_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_constraint_scaled_max_fall} [xu_safe_value $xu_a {is_constraint_scaled_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_constraint_scaled_max_rise} [xu_safe_value $xu_a {is_constraint_scaled_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_constraint_scaled_min_fall} [xu_safe_value $xu_a {is_constraint_scaled_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_constraint_scaled_min_rise} [xu_safe_value $xu_a {is_constraint_scaled_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_db_inherited_disabled} [xu_safe_value $xu_a {is_db_inherited_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {sdf_cond_end} [xu_safe_value $xu_a {sdf_cond_end}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {sdf_cond_start} [xu_safe_value $xu_a {sdf_cond_start}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {to_pin} [xu_safe_value $xu_a {to_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
set xu_owner [get_lib_cells -of_objects $xu_c]
if {[catch {get_lib_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {get_lib_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {from_lib_pin} [xu_safe_value $xu_a {from_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {has_arc_related_power_pins} [xu_safe_value $xu_a {has_arc_related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {related_power_pins} [xu_safe_value $xu_a {related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {to_lib_pin} [xu_safe_value $xu_a {to_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {unrelated_power_pins} [xu_safe_value $xu_a {unrelated_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg} {lib_timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
xu_capture {cell-3-disabled.rpt} [list report_disable_timing $xu_c] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg}
set xu_c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg}]
if {[sizeof_collection $xu_c]!=1 || [get_attribute $xu_c ref_name] ne {DRNQV0_12TR40}} {error {actual61 endpoint identity changed}}
set xu_cp [get_pins -of_objects $xu_c]
foreach_in_collection xu_p $xu_cp {
 set xu_pn [get_object_name $xu_p]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {actual_min_clock_pulse_width_high} [xu_safe_value $xu_p {actual_min_clock_pulse_width_high}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {actual_min_clock_pulse_width_low} [xu_safe_value $xu_p {actual_min_clock_pulse_width_low}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {case_value} [xu_safe_value $xu_p {case_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_capture_arrival_dynamic} [xu_safe_value $xu_p {clock_capture_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_capture_arrival_static} [xu_safe_value $xu_p {clock_capture_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_latency_fall_max} [xu_safe_value $xu_p {clock_latency_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_latency_fall_min} [xu_safe_value $xu_p {clock_latency_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_latency_rise_max} [xu_safe_value $xu_p {clock_latency_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_latency_rise_min} [xu_safe_value $xu_p {clock_latency_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_launch_arrival_dynamic} [xu_safe_value $xu_p {clock_launch_arrival_dynamic}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_launch_arrival_static} [xu_safe_value $xu_p {clock_launch_arrival_static}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_early_fall_max} [xu_safe_value $xu_p {clock_source_latency_early_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_early_fall_min} [xu_safe_value $xu_p {clock_source_latency_early_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_early_rise_max} [xu_safe_value $xu_p {clock_source_latency_early_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_early_rise_min} [xu_safe_value $xu_p {clock_source_latency_early_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_late_fall_max} [xu_safe_value $xu_p {clock_source_latency_late_fall_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_late_fall_min} [xu_safe_value $xu_p {clock_source_latency_late_fall_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_late_rise_max} [xu_safe_value $xu_p {clock_source_latency_late_rise_max}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clock_source_latency_late_rise_min} [xu_safe_value $xu_p {clock_source_latency_late_rise_min}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {clocks} [xu_safe_value $xu_p {clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {constant_value} [xu_safe_value $xu_p {constant_value}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {constrained_launch_clocks} [xu_safe_value $xu_p {constrained_launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {direction} [xu_safe_value $xu_p {direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {disable_timing} [xu_safe_value $xu_p {disable_timing}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {dynamic_clocks} [xu_safe_value $xu_p {dynamic_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {escaped_full_name} [xu_safe_value $xu_p {escaped_full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {full_name} [xu_safe_value $xu_p {full_name}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {has_model_mismatch_clock} [xu_safe_value $xu_p {has_model_mismatch_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_async_pin} [xu_safe_value $xu_p {is_async_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_exclusivity} [xu_safe_value $xu_p {is_clock_exclusivity}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_gating_pin} [xu_safe_value $xu_p {is_clock_gating_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_network} [xu_safe_value $xu_p {is_clock_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_pin} [xu_safe_value $xu_p {is_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_source} [xu_safe_value $xu_p {is_clock_source}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_source_network} [xu_safe_value $xu_p {is_clock_source_network}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_used_as_clock} [xu_safe_value $xu_p {is_clock_used_as_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_clock_used_as_data} [xu_safe_value $xu_p {is_clock_used_as_data}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_p {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_preset_pin} [xu_safe_value $xu_p {is_preset_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_p {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {launch_clocks} [xu_safe_value $xu_p {launch_clocks}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {min_launch_clock_period} [xu_safe_value $xu_p {min_launch_clock_period}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {pin_direction} [xu_safe_value $xu_p {pin_direction}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {power_base_clock} [xu_safe_value $xu_p {power_base_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {propagated_clock} [xu_safe_value $xu_p {propagated_clock}]] "\t"]
 puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn {user_case_value} [xu_safe_value $xu_p {user_case_value}]] "\t"]
 if {[catch {get_nets -of_objects $xu_p} xu_ns]} {
  puts $xu_unknown [join [list $xu_pn nets_QUERY_ERROR $xu_ns] "\t"]
 } else {
  puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn nets [get_object_name $xu_ns]] "\t"]
  foreach_in_collection xu_n $xu_ns {
   if {[catch {all_connected -leaf $xu_n} xu_con]} {puts $xu_unknown [join [list $xu_pn connections_QUERY_ERROR $xu_con] "\t"]} else {
    foreach_in_collection xu_o $xu_con {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn leaf_connection [get_object_name $xu_o] [xu_safe_value $xu_o direction]] "\t"]}
   }
  }
 }
 if {[get_attribute $xu_p direction] eq "in"} {
  if {[catch {all_fanin -flat -startpoints_only -to $xu_p} xu_starts]} {puts $xu_unknown [join [list $xu_pn fanin_QUERY_ERROR $xu_starts] "\t"]} else {puts $xu_pins [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} $xu_pn fanin_startpoints [get_object_name $xu_starts]] "\t"]}
 }
}
xu_capture {cell-4-all-design-arcs.rpt} [list report_attribute -application [get_timing_arcs -of_objects $xu_c]] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg}
set xu_lc [get_lib_cells -of_objects $xu_c]
set xu_lps [get_lib_pins -of_objects $xu_lc]
foreach_in_collection xu_lo $xu_lc {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {function_id} [xu_safe_value $xu_lo {function_id}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {is_case_sequential_propagation} [xu_safe_value $xu_lo {is_case_sequential_propagation}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {is_integrated_clock_gating_cell} [xu_safe_value $xu_lo {is_integrated_clock_gating_cell}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {is_sequential} [xu_safe_value $xu_lo {is_sequential}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {is_shared_timing_model} [xu_safe_value $xu_lo {is_shared_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {master_timing_model} [xu_safe_value $xu_lo {master_timing_model}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {shared_timing_models} [xu_safe_value $xu_lo {shared_timing_models}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {timing_model_type} [xu_safe_value $xu_lo {timing_model_type}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_cell} [get_object_name $xu_lo] {user_function_class} [xu_safe_value $xu_lo {user_function_class}]] "\t"]
}
foreach_in_collection xu_lo $xu_lps {
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {clock} [xu_safe_value $xu_lo {clock}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {direction} [xu_safe_value $xu_lo {direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {disable_timing} [xu_safe_value $xu_lo {disable_timing}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {full_name} [xu_safe_value $xu_lo {full_name}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {is_clock_pin} [xu_safe_value $xu_lo {is_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {is_fall_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_fall_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {is_negative_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_negative_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {is_positive_level_sensitive_clock_pin} [xu_safe_value $xu_lo {is_positive_level_sensitive_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {is_rise_edge_triggered_clock_pin} [xu_safe_value $xu_lo {is_rise_edge_triggered_clock_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {pin_direction} [xu_safe_value $xu_lo {pin_direction}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {power_down_function} [xu_safe_value $xu_lo {power_down_function}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {related_ground_pin} [xu_safe_value $xu_lo {related_ground_pin}]] "\t"]
 puts $xu_library [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_pin} [get_object_name $xu_lo] {related_power_pin} [xu_safe_value $xu_lo {related_power_pin}]] "\t"]
}
set xu_owner $xu_c
if {[catch {get_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {get_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max} [xu_safe_value $xu_a {annotated_delay_delta_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max_fall} [xu_safe_value $xu_a {annotated_delay_delta_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {annotated_delay_delta_max_rise} [xu_safe_value $xu_a {annotated_delay_delta_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min} [xu_safe_value $xu_a {annotated_delay_delta_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min_fall} [xu_safe_value $xu_a {annotated_delay_delta_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {annotated_delay_delta_min_rise} [xu_safe_value $xu_a {annotated_delay_delta_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {delay_max} [xu_safe_value $xu_a {delay_max}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {delay_max_fall} [xu_safe_value $xu_a {delay_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {delay_max_rise} [xu_safe_value $xu_a {delay_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {delay_min} [xu_safe_value $xu_a {delay_min}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {delay_min_fall} [xu_safe_value $xu_a {delay_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {delay_min_rise} [xu_safe_value $xu_a {delay_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {from_pin} [xu_safe_value $xu_a {from_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_constraint_scaled_max_fall} [xu_safe_value $xu_a {is_constraint_scaled_max_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_constraint_scaled_max_rise} [xu_safe_value $xu_a {is_constraint_scaled_max_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_constraint_scaled_min_fall} [xu_safe_value $xu_a {is_constraint_scaled_min_fall}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_constraint_scaled_min_rise} [xu_safe_value $xu_a {is_constraint_scaled_min_rise}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_db_inherited_disabled} [xu_safe_value $xu_a {is_db_inherited_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {sdf_cond_end} [xu_safe_value $xu_a {sdf_cond_end}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {sdf_cond_start} [xu_safe_value $xu_a {sdf_cond_start}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {to_pin} [xu_safe_value $xu_a {to_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
set xu_owner [get_lib_cells -of_objects $xu_c]
if {[catch {get_lib_timing_arcs -of_objects $xu_owner} xu_as]} {
 puts $xu_unknown [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {get_lib_timing_arcs_QUERY_ERROR} $xu_as] "\t"]
} else {
 puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} ARC_COUNT [sizeof_collection $xu_as]] "\t"]
 set xu_arc_index 0
 foreach_in_collection xu_a $xu_as {
  set xu_an [format {arc_%03d} $xu_arc_index]; incr xu_arc_index
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {from_lib_pin} [xu_safe_value $xu_a {from_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {has_arc_related_power_pins} [xu_safe_value $xu_a {has_arc_related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {is_disabled} [xu_safe_value $xu_a {is_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {is_user_disabled} [xu_safe_value $xu_a {is_user_disabled}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {related_power_pins} [xu_safe_value $xu_a {related_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {sdf_cond} [xu_safe_value $xu_a {sdf_cond}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {sense} [xu_safe_value $xu_a {sense}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {to_lib_pin} [xu_safe_value $xu_a {to_lib_pin}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {unrelated_power_pins} [xu_safe_value $xu_a {unrelated_power_pins}]] "\t"]
  puts $xu_arcs [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg} {lib_timing_arc} $xu_an {when} [xu_safe_value $xu_a {when}]] "\t"]
 }
}
xu_capture {cell-4-disabled.rpt} [list report_disable_timing $xu_c] {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg}
xu_capture case-analysis.rpt {report_case_analysis} whole_design
xu_capture analysis-coverage.rpt {report_analysis_coverage -status_details untested} whole_design
xu_capture clocks.rpt {report_clock -attributes} whole_design
xu_capture setup.rpt {report_timing -delay_type max -slack_lesser_than 1000000 -max_paths 50 -significant_digits 8} whole_design
xu_capture hold.rpt {report_timing -delay_type min -slack_lesser_than 1000000 -max_paths 50 -significant_digits 8} whole_design
xu_capture constraints.rpt {report_constraint -all_violators -verbose -significant_digits 8} whole_design
close $xu_pins
close $xu_arcs
close $xu_library
close $xu_paths
close $xu_unknown

} xu_error xu_options]} {
 puts stderr "XU_FATAL: $xu_error"
 if {[dict exists $xu_options -errorinfo]} {puts stderr [dict get $xu_options -errorinfo]}
 exit 1
}
puts {XU_RESET76_READ_ONLY_DIAGNOSIS_DONE_NOT_QUALIFIED}
exit 0
