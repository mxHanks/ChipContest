if {[catch {
set_host_options -max_cores 2
set_app_var target_library [list {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db}]
set_app_var link_library [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db}]
set_svf repair.svf
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-unloaded-cell-cleanup-20261104-95/mapped.v}
current_design xu_soc_ppa_top
if {![link]} {error {DC link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
set_dont_touch [get_cells -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}] true

set xu116_first [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U149/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U150/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U160/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U165/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U178/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U188/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U196/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U201/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U202/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U245/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U246/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U256/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U334/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U337/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U377/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U475/ZN} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U476/ZN}]
set xu116_first_refs [dict create {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U149/ZN} {NOR4BBV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U150/ZN} {NOR2CV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U160/ZN} {OAI211V0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U165/ZN} {OAI211V0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U178/ZN} {NOR3CV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U188/ZN} {AOI21V0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U196/ZN} {NAND2CV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U201/ZN} {NAND2CV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U202/ZN} {NAND2CV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U245/ZN} {CLKINV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U246/ZN} {CLKINV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U256/ZN} {CLKINV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U334/ZN} {OAI21V0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U337/ZN} {AOI21V0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U377/ZN} {CLKINV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U475/ZN} {CLKINV0_12TR40} {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U476/ZN} {AOI21V0_12TR40}]
set xu116_front $xu116_first
set xu116_parent_counts [dict create]
foreach_in_collection h [get_cells -hierarchical -filter {is_hierarchical == true}] {dict incr xu116_parent_counts [get_attribute $h ref_name]}
set xu116_total 0
set xu116_removed {}
set xu116_before [sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]
set xf [open cleanup-rounds.tsv w]
set pf [open cleanup-preflight.tsv w]
set rf [open removed-cells.tsv w]
puts $xf "round\tfrontier\tremoved\tupstream"
puts $pf "round\tcell\tref\tis_sequential\toutput\tleaf_connections\towner_instance_count"
puts $rf "round\tcell\tref"
set xu116_converged 0
for {set wave 0} {$wave<16} {incr wave} {
 set planned [dict create]
 set upstream [dict create]
 foreach name [lsort -unique $xu116_front] {
  set p [get_pins -quiet $name]
  if {[sizeof_collection $p]!=1 || [get_attribute $p direction] ne "out"} {error {116 frontier exact output missing}}
  set c [get_cells -of_objects $p]
  if {[sizeof_collection $c]!=1 || [get_attribute $c is_hierarchical]} {error {116 candidate is not exact leaf}}
  set cn [get_object_name $c]
  set ref [get_attribute $c ref_name]
  if {$wave==0 && $ref ne [dict get $xu116_first_refs $name]} {error {116 initial17 native ref differs}}
  set unloaded 1
  set outputs [get_pins -of_objects $c -filter {direction == out}]
  if {[sizeof_collection $outputs]<1} {error {116 candidate output set empty}}
  foreach_in_collection op $outputs {
   set nets [get_nets -of_objects $op]
   if {[sizeof_collection $nets]!=1} {error {116 candidate output net missing/ambiguous}}
   set con [all_connected -leaf $nets]
   if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $op]} {set unloaded 0}
  }
  if {!$unloaded} {
   if {$wave==0} {error {116 initial17 output gained receiver}}
   continue
  }
  if {[dict exists $planned $cn]} {continue}
  if {[lsearch -exact $xu116_removed $cn]>=0} {error {116 candidate already removed}}
  if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {116 inout deletion forbidden}}
  set seq [get_attribute -quiet $c is_sequential]
  if {![string is boolean -strict $seq] || $seq} {error {116 sequential/unknown classification deletion forbidden}}
  set owner [get_cells -quiet [file dirname $cn]]
  if {[sizeof_collection $owner]!=1} {error {116 exact owner missing}}
  set oref [get_attribute $owner ref_name]
  if {![dict exists $xu116_parent_counts $oref] || [dict get $xu116_parent_counts $oref]!=1} {error {116 shared owner deletion forbidden}}
  foreach_in_collection op $outputs {
   set con [all_connected -leaf [get_nets -of_objects $op]]
   if {[get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {116 output terminal class differs}}
   puts $pf [join [list $wave $cn $ref $seq [get_object_name $op] [get_object_name $con] [dict get $xu116_parent_counts $oref]] "\t"]
  }
  foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
   foreach_in_collection n [get_nets -of_objects $ip] {
    foreach_in_collection d [all_connected -leaf $n] {
     if {[get_attribute $d object_class] eq "pin" && [get_attribute $d direction] eq "out"} {dict set upstream [get_object_name $d] 1}
    }
   }
  }
  dict set planned $cn $ref
 }
 if {$wave==0 && [dict size $planned]!=17} {error {116 first wave must delete exact17 cells}}
 if {$xu116_total+[dict size $planned]>1024} {error {116 bounded total deletion exceeded}}
 # The entire wave has passed before its first mutation.
 foreach cn [lsort [dict keys $planned]] {
  set c [get_cells -quiet $cn]
  remove_cell $c
  if {[sizeof_collection [get_cells -quiet $cn]]!=0} {error {116 native cell deletion failed}}
  lappend xu116_removed $cn
  puts $rf [join [list $wave $cn [dict get $planned $cn]] "\t"]
 }
 incr xu116_total [dict size $planned]
 if {[sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]!=$xu116_before-$xu116_total} {error {116 unexpected cell-count mutation}}
 puts $xf [join [list $wave [llength $xu116_front] [dict size $planned] [dict size $upstream]] "\t"]
 if {[dict size $planned]==0 || [dict size $upstream]==0} {set xu116_converged 1;break}
 set xu116_front [dict keys $upstream]
}
close $xf
close $pf
close $rf
if {!$xu116_converged} {error {116 bounded16 waves exhausted without fixed point}}

set xu_before_cells [sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]
set xu_parent_counts [dict create]
foreach_in_collection h [get_cells -hierarchical -filter {is_hierarchical == true}] {dict incr xu_parent_counts [get_attribute $h ref_name]}
set xu_original_driver [dict create]
set f [open reset-preflight.tsv w]
puts $f "reset_pin\tref\tleaf_connections\tunique_owner_ref\toriginal_driver"
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg}]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DSNQV0_12TR40} || [sizeof_collection $p]!=1 || [get_attribute $p direction] ne "in" || [sizeof_collection $owner]!=1} {error {exact reset endpoint identity changed}}
set owner_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $owner_ref] || [dict get $xu_parent_counts $owner_ref]!=1} {error {reset owner design is shared}}
set n [get_nets -of_objects $p]
if {[sizeof_collection $n]!=1} {error {reset endpoint net missing or ambiguous}}
set con [all_connected -leaf $n]
set drivers {}
foreach_in_collection o $con {
 if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend drivers [get_object_name $o]}
}
if {[llength $drivers]!=1} {error {reset endpoint original driver ambiguous}}
dict set xu_original_driver [get_object_name $p] [lindex $drivers 0]
puts $f [join [list [get_object_name $p] [get_attribute $c ref_name] [get_object_name $con] $owner_ref [lindex $drivers 0]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg}]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DSNQNV0_12TR40} || [sizeof_collection $p]!=1 || [get_attribute $p direction] ne "in" || [sizeof_collection $owner]!=1} {error {exact reset endpoint identity changed}}
set owner_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $owner_ref] || [dict get $xu_parent_counts $owner_ref]!=1} {error {reset owner design is shared}}
set n [get_nets -of_objects $p]
if {[sizeof_collection $n]!=1} {error {reset endpoint net missing or ambiguous}}
set con [all_connected -leaf $n]
set drivers {}
foreach_in_collection o $con {
 if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend drivers [get_object_name $o]}
}
if {[llength $drivers]!=1} {error {reset endpoint original driver ambiguous}}
dict set xu_original_driver [get_object_name $p] [lindex $drivers 0]
puts $f [join [list [get_object_name $p] [get_attribute $c ref_name] [get_object_name $con] $owner_ref [lindex $drivers 0]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg}]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN}]
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DRNQV0_12TR40} || [sizeof_collection $p]!=1 || [get_attribute $p direction] ne "in" || [sizeof_collection $owner]!=1} {error {exact reset endpoint identity changed}}
set owner_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $owner_ref] || [dict get $xu_parent_counts $owner_ref]!=1} {error {reset owner design is shared}}
set n [get_nets -of_objects $p]
if {[sizeof_collection $n]!=1} {error {reset endpoint net missing or ambiguous}}
set con [all_connected -leaf $n]
set drivers {}
foreach_in_collection o $con {
 if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend drivers [get_object_name $o]}
}
if {[llength $drivers]!=1} {error {reset endpoint original driver ambiguous}}
dict set xu_original_driver [get_object_name $p] [lindex $drivers 0]
puts $f [join [list [get_object_name $p] [get_attribute $c ref_name] [get_object_name $con] $owner_ref [lindex $drivers 0]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg}]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN}]
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DRNQV0_12TR40} || [sizeof_collection $p]!=1 || [get_attribute $p direction] ne "in" || [sizeof_collection $owner]!=1} {error {exact reset endpoint identity changed}}
set owner_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $owner_ref] || [dict get $xu_parent_counts $owner_ref]!=1} {error {reset owner design is shared}}
set n [get_nets -of_objects $p]
if {[sizeof_collection $n]!=1} {error {reset endpoint net missing or ambiguous}}
set con [all_connected -leaf $n]
set drivers {}
foreach_in_collection o $con {
 if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend drivers [get_object_name $o]}
}
if {[llength $drivers]!=1} {error {reset endpoint original driver ambiguous}}
dict set xu_original_driver [get_object_name $p] [lindex $drivers 0]
puts $f [join [list [get_object_name $p] [get_attribute $c ref_name] [get_object_name $con] $owner_ref [lindex $drivers 0]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg}]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN}]
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DRNQV0_12TR40} || [sizeof_collection $p]!=1 || [get_attribute $p direction] ne "in" || [sizeof_collection $owner]!=1} {error {exact reset endpoint identity changed}}
set owner_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $owner_ref] || [dict get $xu_parent_counts $owner_ref]!=1} {error {reset owner design is shared}}
set n [get_nets -of_objects $p]
if {[sizeof_collection $n]!=1} {error {reset endpoint net missing or ambiguous}}
set con [all_connected -leaf $n]
set drivers {}
foreach_in_collection o $con {
 if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend drivers [get_object_name $o]}
}
if {[llength $drivers]!=1} {error {reset endpoint original driver ambiguous}}
dict set xu_original_driver [get_object_name $p] [lindex $drivers 0]
puts $f [join [list [get_object_name $p] [get_attribute $c ref_name] [get_object_name $con] $owner_ref [lindex $drivers 0]] "\t"]
close $f
set lc [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
if {[sizeof_collection $lc]!=1} {error {actual library candidate missing}}

# Actual55 stopped here: an unset DC dont_use attribute returns the empty
# string, which is not a Tcl boolean. Preserve the raw value; do not invent
# or set a library attribute. The exact same DB and actual41 false palette
# record are frozen by the Python preflight, and native insertion must accept.
set xu_dont_use [get_attribute -quiet $lc dont_use]
set xu_dont_use_basis dc_explicit_false
if {$xu_dont_use eq ""} {
 set xu_dont_use_basis dc_absent_with_frozen_PT_palette_false_native_validation_required
} elseif {![string is boolean -strict $xu_dont_use]} {
 error {DC dont_use attribute is not a valid boolean}
} elseif {$xu_dont_use} {
 error {actual library candidate prohibited in DC}
}
set f [open reset-library-preflight.tsv w]
puts $f "libcell\tdc_dont_use_raw\tacceptance_basis"
puts $f [join [list [get_object_name $lc] $xu_dont_use $xu_dont_use_basis] "\t"]
close $f
set li [get_lib_pins -of_objects $lc -filter {direction == in}]
set lo [get_lib_pins -of_objects $lc -filter {direction == out}]
if {[sizeof_collection $li]!=1 || [sizeof_collection $lo]!=1 || [get_object_name $li] ne "scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40/I" || [get_object_name $lo] ne "scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40/ZN"} {error {actual library topology changed}}
# insert_buffer -inverter_pair performs the native inverter-function check.
# A name or absent PT function attribute is never taken as a logic proof.
set f [open inserted-reset-cells.tsv w]
puts $f "endpoint\tcell\tref"
current_instance {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu}
set p [get_pins -quiet {erst_reset_r_reg/SDN}]
if {[sizeof_collection $p]!=1} {error {scoped exact reset pin missing}}
set added [insert_buffer -inverter_pair -no_of_cells 4 -new_cell_names {xu_reset116_0} -new_net_names {xu_reset116_net_0} $p $lc]
if {[sizeof_collection $added]!=8} {error {native inverter-pair insertion failed}}
current_instance
set names [get_object_name $added]
foreach_in_collection c $added {if {[get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {inserted cell identity differs}};puts $f [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN} [get_object_name $c] [get_attribute $c ref_name]] "\t"]}
set cursor [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]
set seen {}
for {set k 0} {$k<8} {incr k} {
 set n [get_nets -of_objects $cursor]
 if {[sizeof_collection $n]!=1} {error {new reset chain net missing}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=2} {error {new reset buffer branch gained another receiver}}
 set dp {}
 foreach_in_collection o $con {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
 if {[llength $dp]!=1} {error {new reset chain driver ambiguous}}
 set driver [get_pins -quiet [lindex $dp 0]]
 set c [get_cells -of_objects $driver]
 set cn [get_object_name $c]
 if {[lsearch -exact $names $cn]<0 || [lsearch -exact $seen $cn]>=0 || [get_attribute $c ref_name] ne "CLKINV0_12TR40"} {error {new reset chain topology differs}}
 lappend seen $cn
 set cursor [get_pins -of_objects $c -filter {direction == in}]
 if {[sizeof_collection $cursor]!=1} {error {new reset buffer input differs}}
}
if {[lsort $seen] ne [lsort $names]} {error {inserted reset chain has unvisited cells}}
set dp {}
foreach_in_collection o [all_connected -leaf [get_nets -of_objects $cursor]] {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
if {$dp ne [list [dict get $xu_original_driver {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]]} {error {reset chain did not retain original driver}}
current_instance {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu}
set p [get_pins -quiet {erst_reset_r_r_reg/SDN}]
if {[sizeof_collection $p]!=1} {error {scoped exact reset pin missing}}
set added [insert_buffer -inverter_pair -no_of_cells 4 -new_cell_names {xu_reset116_1} -new_net_names {xu_reset116_net_1} $p $lc]
if {[sizeof_collection $added]!=8} {error {native inverter-pair insertion failed}}
current_instance
set names [get_object_name $added]
foreach_in_collection c $added {if {[get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {inserted cell identity differs}};puts $f [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN} [get_object_name $c] [get_attribute $c ref_name]] "\t"]}
set cursor [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]
set seen {}
for {set k 0} {$k<8} {incr k} {
 set n [get_nets -of_objects $cursor]
 if {[sizeof_collection $n]!=1} {error {new reset chain net missing}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=2} {error {new reset buffer branch gained another receiver}}
 set dp {}
 foreach_in_collection o $con {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
 if {[llength $dp]!=1} {error {new reset chain driver ambiguous}}
 set driver [get_pins -quiet [lindex $dp 0]]
 set c [get_cells -of_objects $driver]
 set cn [get_object_name $c]
 if {[lsearch -exact $names $cn]<0 || [lsearch -exact $seen $cn]>=0 || [get_attribute $c ref_name] ne "CLKINV0_12TR40"} {error {new reset chain topology differs}}
 lappend seen $cn
 set cursor [get_pins -of_objects $c -filter {direction == in}]
 if {[sizeof_collection $cursor]!=1} {error {new reset buffer input differs}}
}
if {[lsort $seen] ne [lsort $names]} {error {inserted reset chain has unvisited cells}}
set dp {}
foreach_in_collection o [all_connected -leaf [get_nets -of_objects $cursor]] {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
if {$dp ne [list [dict get $xu_original_driver {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]]} {error {reset chain did not retain original driver}}
current_instance {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0}
set p [get_pins -quiet {q_reg/RDN}]
if {[sizeof_collection $p]!=1} {error {scoped exact reset pin missing}}
set added [insert_buffer -inverter_pair -no_of_cells 4 -new_cell_names {xu_reset116_2} -new_net_names {xu_reset116_net_2} $p $lc]
if {[sizeof_collection $added]!=8} {error {native inverter-pair insertion failed}}
current_instance
set names [get_object_name $added]
foreach_in_collection c $added {if {[get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {inserted cell identity differs}};puts $f [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN} [get_object_name $c] [get_attribute $c ref_name]] "\t"]}
set cursor [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN}]
set seen {}
for {set k 0} {$k<8} {incr k} {
 set n [get_nets -of_objects $cursor]
 if {[sizeof_collection $n]!=1} {error {new reset chain net missing}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=2} {error {new reset buffer branch gained another receiver}}
 set dp {}
 foreach_in_collection o $con {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
 if {[llength $dp]!=1} {error {new reset chain driver ambiguous}}
 set driver [get_pins -quiet [lindex $dp 0]]
 set c [get_cells -of_objects $driver]
 set cn [get_object_name $c]
 if {[lsearch -exact $names $cn]<0 || [lsearch -exact $seen $cn]>=0 || [get_attribute $c ref_name] ne "CLKINV0_12TR40"} {error {new reset chain topology differs}}
 lappend seen $cn
 set cursor [get_pins -of_objects $c -filter {direction == in}]
 if {[sizeof_collection $cursor]!=1} {error {new reset buffer input differs}}
}
if {[lsort $seen] ne [lsort $names]} {error {inserted reset chain has unvisited cells}}
set dp {}
foreach_in_collection o [all_connected -leaf [get_nets -of_objects $cursor]] {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
if {$dp ne [list [dict get $xu_original_driver {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN}]]} {error {reset chain did not retain original driver}}
current_instance {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1}
set p [get_pins -quiet {q_reg/RDN}]
if {[sizeof_collection $p]!=1} {error {scoped exact reset pin missing}}
set added [insert_buffer -inverter_pair -no_of_cells 4 -new_cell_names {xu_reset116_3} -new_net_names {xu_reset116_net_3} $p $lc]
if {[sizeof_collection $added]!=8} {error {native inverter-pair insertion failed}}
current_instance
set names [get_object_name $added]
foreach_in_collection c $added {if {[get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {inserted cell identity differs}};puts $f [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN} [get_object_name $c] [get_attribute $c ref_name]] "\t"]}
set cursor [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN}]
set seen {}
for {set k 0} {$k<8} {incr k} {
 set n [get_nets -of_objects $cursor]
 if {[sizeof_collection $n]!=1} {error {new reset chain net missing}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=2} {error {new reset buffer branch gained another receiver}}
 set dp {}
 foreach_in_collection o $con {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
 if {[llength $dp]!=1} {error {new reset chain driver ambiguous}}
 set driver [get_pins -quiet [lindex $dp 0]]
 set c [get_cells -of_objects $driver]
 set cn [get_object_name $c]
 if {[lsearch -exact $names $cn]<0 || [lsearch -exact $seen $cn]>=0 || [get_attribute $c ref_name] ne "CLKINV0_12TR40"} {error {new reset chain topology differs}}
 lappend seen $cn
 set cursor [get_pins -of_objects $c -filter {direction == in}]
 if {[sizeof_collection $cursor]!=1} {error {new reset buffer input differs}}
}
if {[lsort $seen] ne [lsort $names]} {error {inserted reset chain has unvisited cells}}
set dp {}
foreach_in_collection o [all_connected -leaf [get_nets -of_objects $cursor]] {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
if {$dp ne [list [dict get $xu_original_driver {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN}]]} {error {reset chain did not retain original driver}}
current_instance {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2}
set p [get_pins -quiet {q_reg/RDN}]
if {[sizeof_collection $p]!=1} {error {scoped exact reset pin missing}}
set added [insert_buffer -inverter_pair -no_of_cells 4 -new_cell_names {xu_reset116_4} -new_net_names {xu_reset116_net_4} $p $lc]
if {[sizeof_collection $added]!=8} {error {native inverter-pair insertion failed}}
current_instance
set names [get_object_name $added]
foreach_in_collection c $added {if {[get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {inserted cell identity differs}};puts $f [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN} [get_object_name $c] [get_attribute $c ref_name]] "\t"]}
set cursor [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN}]
set seen {}
for {set k 0} {$k<8} {incr k} {
 set n [get_nets -of_objects $cursor]
 if {[sizeof_collection $n]!=1} {error {new reset chain net missing}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=2} {error {new reset buffer branch gained another receiver}}
 set dp {}
 foreach_in_collection o $con {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
 if {[llength $dp]!=1} {error {new reset chain driver ambiguous}}
 set driver [get_pins -quiet [lindex $dp 0]]
 set c [get_cells -of_objects $driver]
 set cn [get_object_name $c]
 if {[lsearch -exact $names $cn]<0 || [lsearch -exact $seen $cn]>=0 || [get_attribute $c ref_name] ne "CLKINV0_12TR40"} {error {new reset chain topology differs}}
 lappend seen $cn
 set cursor [get_pins -of_objects $c -filter {direction == in}]
 if {[sizeof_collection $cursor]!=1} {error {new reset buffer input differs}}
}
if {[lsort $seen] ne [lsort $names]} {error {inserted reset chain has unvisited cells}}
set dp {}
foreach_in_collection o [all_connected -leaf [get_nets -of_objects $cursor]] {if {[get_attribute $o object_class] eq "pin" && [get_attribute $o direction] eq "out"} {lappend dp [get_object_name $o]}}
if {$dp ne [list [dict get $xu_original_driver {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN}]]} {error {reset chain did not retain original driver}}
close $f
if {[sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]!=$xu_before_cells+40} {error {unexpected reset insertion cell count}}
# Exact post-elaboration macro groups; overlapping matches and missing/extra cells fail.
set xu_seen [dict create]
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_itcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: itcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP itcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_dtcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: dtcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP dtcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_shared/storage/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 256} {error {wrong macro count: shared}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP shared count=256 macro_ref=RAMSP1024X16 logical_bits=4194304 physical_bits=4194304 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 16} {error {wrong macro count: accelerator_weights}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP accelerator_weights count=16 macro_ref=RAMSP1024X16 logical_bits=262144 physical_bits=262144 padding_bits=0"
# RAMSP is the explicit technology SRAM namespace; reject every extra leaf/reference.
set xu_allowed_refs [list {RAMSP1024X16}]
set xu_all_macros [get_cells -quiet -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}]
if {[sizeof_collection $xu_all_macros] != 336 || [dict size $xu_seen] != 336} {error {full-SoC SRAM total must be exactly 336}}
foreach_in_collection xu_c $xu_all_macros {
  if {[lsearch -exact $xu_allowed_refs [get_attribute $xu_c ref_name]] < 0} {error {unexpected SRAM reference}}
  if {![dict exists $xu_seen [get_object_name $xu_c]]} {error {ungrouped/unaccounted SRAM macro}}
}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave && ref_name =~ accel_icb_slave*}]] != 1} {error {missing/wrong accelerator}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top && ref_name =~ e203_cpu_top*}]] != 1} {error {missing/wrong cpu}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab && ref_name =~ sirv_icb1to16_bus*}]] != 1} {error {missing/wrong interconnect}}
report_constraint -all_violators -verbose > dc-all-constraints.rpt
report_units > dc-units.rpt
report_area -hierarchy > area.rpt
report_qor > qor.rpt
report_timing -delay_type max -max_paths 50 > dc-setup.rpt
report_timing -delay_type min -max_paths 50 > dc-hold.rpt
write -format verilog -hierarchy -output mapped.v
write -format ddc -hierarchy -output mapped.ddc
write_sdc mapped.sdc

puts {XU_COMBINED116_DC_DONE_NOT_QUALIFIED}
} xu_error]} {
  puts stderr "XU_FATAL: $xu_error"
  exit 1
}
exit 0
