# xu实验总控150

所有状态均为NOT_QUALIFIED；诊断完成不代表比赛资格。

|实验|状态|原始状态|PID|
|---|---|---|---|
|baseline_rdc142|WAIT_DEPENDENCY|||
|eight_freeze138|COMPLETED_DIAGNOSTIC_NOT_QUALIFIED|INPUTS_AND_ADOPTIONS_COMPLETE_REMAINING_PHASES_PENDING_NOT_QUALIFIED||
|s2e_power130|RUNNING_ADOPTED|RUNNING_REVIEW_PENDING|135097|
|s2e_timing134|WAIT_DEPENDENCY|||

资源及许可证：{"cpu_count": 96, "disk_available_bytes": 1522007015424, "epoch": 1793841898.5960066, "license_capacity": "UNKNOWN_NO_SPARE_SEATS_CLAIMED", "mem_available_bytes": 761591107584, "native_policy": "EXCLUSIVE_SINGLE_EXISTING_JOB_OR_ONE_NEW_JOB", "native_processes": [{"argv": ["/bin/sh", "/eda/synopsys/prime/prime_2022.03-SP5-1/bin/pt_shell", "-f", "power.tcl"], "pid": 160066, "uid": 14023}, {"argv": ["/eda/synopsys/prime/prime_2022.03-SP5-1/linux64/syn/bin/pt_shell_exec", "-root_path", "/eda/synopsys/prime/prime_2022.03-SP5-1", "-shell", "Timing", "-f", "power.tcl"], "pid": 160080, "uid": 14023}]}

已完成/失败的原结果和日志保持在各自目录；总控不删除、覆盖或自动重启。
