`timescale 1ns/1ps
module tb_xu_udp108;
 localparam N=5;
 reg [N-1:0] p, v, base;
 wire original_q, first_q, last_q;
 integer i,j,k,a,b,steps=0,pair_diffs=0,original_last_diffs=0,original_first_diffs=0;
 integer q0=0,q1=0,qx=0;
 udp_tlatrf2 original_definition(original_q, p[0], p[1], p[2], p[3], p[4]);
 xu108_first_udp_tlatrf2 first_definition(first_q, p[0], p[1], p[2], p[3], p[4]);
 xu108_last_udp_tlatrf2 last_definition(last_q, p[0], p[1], p[2], p[3], p[4]);
 function [N-1:0] quad;
   input integer code;
   integer n;
   begin
     for(n=0;n<N;n=n+1) begin
       case(code % 4)
         0:quad[n]=1'b0; 1:quad[n]=1'b1; 2:quad[n]=1'bx; 3:quad[n]=1'bz;
       endcase
       code=code/4;
     end
   end
 endfunction
 task observe;
 begin
   #1; steps=steps+1;
   if(last_q===1'b0)q0=q0+1;else if(last_q===1'b1)q1=q1+1;else qx=qx+1;
   if(first_q !== last_q) begin
     pair_diffs=pair_diffs+1;
     if(pair_diffs <= 32)$display("XU_UDP108_DIFFERENCE step=%0d p=%b first=%b last=%b original=%b", steps,p,first_q,last_q,original_q);
   end
   if(original_q !== last_q)original_last_diffs=original_last_diffs+1;
   if(original_q !== first_q)original_first_diffs=original_first_diffs+1;
 end
 endtask
 initial begin
   p={N{1'bx}};observe;
   // Exhaustive binary predecessor -> 4-state target pairs, natural Q history.
   for(a=0;a<(1<<N);a=a+1)begin
     for(b=0;b<(1<<(2*N));b=b+1)begin
       p=a;observe;
       p=quad(b);observe;
     end
   end
   // All 4-state input vectors and single-input target symbols; restore base.
   for(a=0;a<(1<<(2*N));a=a+1)begin
     base=quad(a);p=base;observe;
     for(i=0;i<N;i=i+1)begin
       for(j=0;j<4;j=j+1)begin
         v=base;
         case(j)
           0:v[i]=1'b0;1:v[i]=1'b1;2:v[i]=1'bx;3:v[i]=1'bz;
         endcase
         p=v;observe;p=base;observe;
       end
     end
   end
   $display("XU_UDP108_RESULT steps=%0d pair_diffs=%0d original_last_diffs=%0d original_first_diffs=%0d last_q0=%0d last_q1=%0d last_qx=%0d",steps,pair_diffs,original_last_diffs,original_first_diffs,q0,q1,qx);
   $finish;
 end
endmodule
