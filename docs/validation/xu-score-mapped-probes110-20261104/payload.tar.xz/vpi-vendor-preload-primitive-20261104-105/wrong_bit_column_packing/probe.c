/* xu handle-only SRAM preload/observe primitive; no Q or control VPI writes. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include "vpi_user.h"
#define N 2
static const unsigned vals[N][4]={{0x1234,0x8001,0x55aa,0xf00d},{0x2468,0x1002,0xaa55,0x0ff0}};
static vpiHandle modules[N],mems[N],qs[N];
static unsigned seen[N],qchanges[N],read_checks,hold_checks,mem_writes,callbacks;
static uint32_t old_a[N],old_b[N];
static unsigned rises[N],falls[N],x_to_binary[N],binary_to_x[N];
static int failed,prepared;
static s_cb_data callbacks_record[N];
static s_vpi_time callbacks_time[N];
static s_vpi_value callbacks_value[N];
static void fail(const char *why){vpi_printf("XU_PRIMITIVE105_ERROR reason=%s\n",why);failed=1;}
static void canonical(const char *p,char *o,size_t n){size_t k=0;while(*p){unsigned char c=(unsigned char)*p++;if(c=='\\'||isspace(c))continue;if(k+1>=n){fail("name_length");break;}o[k++]=(char)c;}o[k]=0;}
static int getvec(vpiHandle h,uint32_t *a,uint32_t *b){s_vpi_value v;memset(&v,0,sizeof(v));v.format=vpiVectorVal;if(!h)return 0;vpi_get_value(h,&v);if(!v.value.vector)return 0;*a=(uint32_t)v.value.vector[0].aval;*b=(uint32_t)v.value.vector[0].bval;return 1;}
static PLI_INT32 changed(p_cb_data cb){unsigned i=(unsigned)(uintptr_t)cb->user_data;uint32_t a=0,b=0;if(i>=N||!getvec(qs[i],&a,&b)){fail("callback_handle");return 0;}a&=0xffff;b&=0xffff;++callbacks;{unsigned bit;for(bit=0;bit<16;++bit){uint32_t mask=1u<<bit;int ox=(old_b[i]&mask)!=0,nx=(b&mask)!=0;if(ox&&!nx)++x_to_binary[i];else if(!ox&&nx)++binary_to_x[i];else if(!ox&&!nx){if(!(old_a[i]&mask)&&(a&mask))++rises[i];if((old_a[i]&mask)&&!(a&mask))++falls[i];}}}if(a!=old_a[i]||b!=old_b[i]){++qchanges[i];old_a[i]=a;old_b[i]=b;}return 0;}
static void walk(vpiHandle mod){vpiHandle it,c;const char *r=vpi_get_str(vpiDefName,mod);if(r&&strcmp(r,"RAMSP1024X16")==0){const char *f=vpi_get_str(vpiFullName,mod);char name[2048];int i=-1;canonical(f?f:"",name,sizeof(name));if(strcmp(name,"tb_xu_vpi_preload105.ordinary")==0)i=0;if(strcmp(name,"tb_xu_vpi_preload105.macro_storage.depth_bank[0].width_lane[0].macro")==0)i=1;if(i<0)fail("unexpected_macro");else{++seen[i];modules[i]=mod;}}it=vpi_iterate(vpiModule,mod);if(it)while((c=vpi_scan(it))!=NULL)walk(c);}
/* The owning-memory relationship and all indexed identities are checked, not
 * an implementation-specific assumption that every simulator reports word
 * objects as vpiMemoryWord. VCS may expose a memory's indexed word as vpiReg.
 * Parent/scope/index metadata is retained verbatim in the diagnostic below. */
static void handle_info(unsigned tag,int row,const char *role,vpiHandle h){
 char name[2048]="",full[2048]="",parent[2048]="",scope[2048]="";
 vpiHandle p=NULL,sc=NULL,ix=NULL;s_vpi_value iv;int known=0,index=-1;
 if(h){const char *s=vpi_get_str(vpiName,h);canonical(s?s:"",name,sizeof(name));
  s=vpi_get_str(vpiFullName,h);canonical(s?s:"",full,sizeof(full));
  p=vpi_handle(vpiParent,h);sc=vpi_handle(vpiScope,h);
  if(p){s=vpi_get_str(vpiFullName,p);canonical(s?s:"",parent,sizeof(parent));}
  if(sc){s=vpi_get_str(vpiFullName,sc);canonical(s?s:"",scope,sizeof(scope));}
  if(row>=0){ix=vpi_handle(vpiIndex,h);if(ix){memset(&iv,0,sizeof(iv));iv.format=vpiIntVal;vpi_get_value(ix,&iv);known=1;index=iv.value.integer;}}
 }
 vpi_printf("XU_PRIMITIVE105_GEOMETRY tag=%u row=%d role=%s exists=%d type=%d size=%d name=%s full=%s parent_type=%d parent=%s scope_type=%d scope=%s index_handle=%d index_known=%d index=%d\n",tag,row,role,h!=NULL,h?vpi_get(vpiType,h):-1,h?vpi_get(vpiSize,h):-1,name,full,p?vpi_get(vpiType,p):-1,parent,sc?vpi_get(vpiType,sc):-1,scope,ix!=NULL,known,index);
}
static int geometry(unsigned tag){
 vpiHandle words[256];unsigned row,j;int ok=1;char modname[2048],memname[2048],want[2080],full[2048];const char *s;
 s=vpi_get_str(vpiFullName,modules[tag]);canonical(s?s:"",modname,sizeof(modname));
 s=mems[tag]?vpi_get_str(vpiFullName,mems[tag]):NULL;canonical(s?s:"",memname,sizeof(memname));
 handle_info(tag,-1,"module",modules[tag]);handle_info(tag,-1,"memory",mems[tag]);
 snprintf(want,sizeof(want),"%s.mem",modname);
 if(!mems[tag]||strcmp(want,memname)!=0||vpi_get(vpiSize,mems[tag])!=256||(vpi_get(vpiType,mems[tag])!=vpiMemory&&vpi_get(vpiType,mems[tag])!=vpiRegArray)){fail("owning_memory_name_type_or_256_rows");return 0;}
 for(row=0;row<256;++row){
  vpiHandle again,ix;int type;s_vpi_value iv;
  words[row]=vpi_handle_by_index(mems[tag],(PLI_INT32)row);
  handle_info(tag,(int)row,"indexed_word",words[row]);
  if(!words[row]){fail("indexed_word_missing");ok=0;continue;}
  type=vpi_get(vpiType,words[row]);
  if((type!=vpiMemoryWord&&type!=vpiReg)||vpi_get(vpiSize,words[row])!=64){fail("indexed_word_native_type_or_64_bits");ok=0;}
  s=vpi_get_str(vpiFullName,words[row]);canonical(s?s:"",full,sizeof(full));snprintf(want,sizeof(want),"%s[%u]",memname,row);
  if(strcmp(full,want)!=0){fail("indexed_word_not_in_exact_owning_memory");ok=0;}
  again=vpi_handle_by_index(mems[tag],(PLI_INT32)row);
  if(!again||!vpi_compare_objects(words[row],again)){fail("indexed_word_identity_not_repeatable");ok=0;}
  for(j=0;j<row;++j)if(words[j]&&vpi_compare_objects(words[row],words[j])){fail("indexed_word_aliases_another_row");ok=0;}
  {vpiHandle parent=vpi_handle(vpiParent,words[row]),scope=vpi_handle(vpiScope,words[row]);
   if(parent&&!vpi_compare_objects(parent,mems[tag])&&!vpi_compare_objects(parent,modules[tag])){fail("native_word_parent_disagrees");ok=0;}
   if(scope&&!vpi_compare_objects(scope,modules[tag])&&!vpi_compare_objects(scope,mems[tag])){fail("native_word_scope_disagrees");ok=0;}
  }
  ix=vpi_handle(vpiIndex,words[row]);if(ix){memset(&iv,0,sizeof(iv));iv.format=vpiIntVal;vpi_get_value(ix,&iv);if(iv.value.integer!=(PLI_INT32)row){fail("native_word_index_disagrees");ok=0;}}
 }
 if(tag&&mems[0]&&vpi_compare_objects(mems[0],mems[tag])){fail("two_macro_memories_alias");ok=0;}
 vpi_printf("XU_PRIMITIVE105_GEOMETRY_RESULT tag=%u status=%s owned_rows=256 word_bits=64 unique_rows_checked=256 native_type_constants_memory=%d regarray=%d memoryword=%d reg=%d\n",tag,ok?"PASS":"FAIL",vpiMemory,vpiRegArray,vpiMemoryWord,vpiReg);
 return ok;
}
static PLI_INT32 diagnose(PLI_BYTE8 *u){
 unsigned i;vpiHandle top=vpi_handle_by_name((PLI_BYTE8*)"tb_xu_vpi_preload105",NULL);(void)u;
 if(!top){fail("diagnostic_top_missing");return 0;}walk(top);
 for(i=0;i<N;++i){if(seen[i]!=1){fail("diagnostic_ordinary_escaped_bijection");continue;}
  mems[i]=vpi_handle_by_name((PLI_BYTE8*)"mem",modules[i]);qs[i]=vpi_handle_by_name((PLI_BYTE8*)"Q",modules[i]);
  (void)geometry(i);
 }
 vpi_printf("XU_PRIMITIVE105_DIAGNOSTIC status=%s macros=2 writes=0 NOT_FULL_SOC_OR_ACTIVITY_OR_ENERGY\n",failed?"FAIL":"PASS");
 if(failed){vpi_control(vpiFinish,1);}
 return 0;
}
static void packed(unsigned i,s_vpi_vecval row[2]){unsigned bit,col;memset(row,0,2*sizeof(*row));for(bit=0;bit<16;++bit)for(col=0;col<4;++col)if(vals[i][col]&(1u<<bit)){unsigned k=4*bit+(3-col);row[k/32].aval|=(PLI_INT32)(1u<<(k%32));}}
static void memory_check(unsigned i){vpiHandle w=vpi_handle_by_index(mems[i],3),untouched=vpi_handle_by_index(mems[i],4);s_vpi_value v; s_vpi_vecval want[2];unsigned j;if(!w||!untouched){fail("memory_recheck_handle_missing");return;}packed(i,want);memset(&v,0,sizeof(v));v.format=vpiVectorVal;vpi_get_value(w,&v);for(j=0;j<2;++j)if((uint32_t)v.value.vector[j].aval!=(uint32_t)want[j].aval||v.value.vector[j].bval!=0)fail("preload_row_changed");vpi_get_value(untouched,&v);for(j=0;j<2;++j)if((uint32_t)v.value.vector[j].bval!=0xffffffffu)fail("untouched_row_not_unknown");}
static PLI_INT32 preload(PLI_BYTE8 *u){unsigned i;vpiHandle top=vpi_handle_by_name((PLI_BYTE8*)"tb_xu_vpi_preload105",NULL);(void)u;if(prepared||!top){fail("duplicate_preload_or_no_top");return 0;}walk(top);for(i=0;i<N;++i){vpiHandle w;s_vpi_value v;s_vpi_vecval row[2];s_cb_data *cb=&callbacks_record[i];s_vpi_time *t=&callbacks_time[i];s_vpi_value *cv=&callbacks_value[i];uint32_t a=0,b=0;if(seen[i]!=1){fail("ordinary_escaped_bijection");continue;}mems[i]=vpi_handle_by_name((PLI_BYTE8*)"mem",modules[i]);qs[i]=vpi_handle_by_name((PLI_BYTE8*)"Q",modules[i]);w=mems[i]?vpi_handle_by_index(mems[i],3):NULL;if(!geometry(i)||!w){fail("native_memory_geometry");continue;}if(!getvec(qs[i],&a,&b)||(b&0xffff)!=0xffff){fail("initial_Q_not_unknown");continue;}old_a[i]=a&0xffff;old_b[i]=b&0xffff;packed(i,row);memset(&v,0,sizeof(v));v.format=vpiVectorVal;v.value.vector=row;vpi_put_value(w,&v,NULL,vpiNoDelay);++mem_writes;memory_check(i);if(!getvec(qs[i],&a,&b)||(b&0xffff)!=0xffff)fail("preload_wrote_Q");memset(cb,0,sizeof(*cb));memset(t,0,sizeof(*t));memset(cv,0,sizeof(*cv));t->type=vpiSimTime;cv->format=vpiSuppressVal;cb->reason=cbValueChange;cb->cb_rtn=changed;cb->obj=qs[i];cb->time=t;cb->value=cv;cb->user_data=(PLI_BYTE8*)(uintptr_t)i;if(!vpi_register_cb(cb))fail("Q_callback_registration");vpi_printf("XU_PRIMITIVE105_PRELOAD tag=%u mem_words=256 word_bits=64 writes=1 row=3 Q_uninitialized=1\n",i);}prepared=1;return 0;}
static PLI_INT32 expect(PLI_BYTE8 *u){vpiHandle call=vpi_handle(vpiSysTfCall,NULL),it=vpi_iterate(vpiArgument,call),arg=it?vpi_scan(it):NULL;s_vpi_value v;unsigned i,col;(void)u;memset(&v,0,sizeof(v));v.format=vpiIntVal;if(!arg){fail("missing_column");return 0;}vpi_get_value(arg,&v);col=(unsigned)v.value.integer;if(it)vpi_free_object(it);if(!prepared||col>=4){fail("column_range");return 0;}for(i=0;i<N;++i){uint32_t a=0,b=0;if(!getvec(qs[i],&a,&b)||(b&0xffff)||((a&0xffff)!=vals[i][col]))fail("actual_vendor_readback_mismatch");memory_check(i);vpi_printf("XU_PRIMITIVE105_READ tag=%u column=%u expected=%04x actual=%04x unknown_mask=%04x\n",i,col,vals[i][col],a&0xffff,b&0xffff);++read_checks;}return 0;}
static PLI_INT32 hold(PLI_BYTE8 *u){unsigned i;(void)u;for(i=0;i<N;++i){uint32_t a=0,b=0;if(!getvec(qs[i],&a,&b)||(b&0xffff)||((a&0xffff)!=vals[i][3]))fail("disabled_Q_not_held");memory_check(i);++hold_checks;}return 0;}
static PLI_INT32 done(PLI_BYTE8 *u){unsigned i;(void)u;for(i=0;i<N;++i){unsigned col,bit,er=0,ef=0;for(col=1;col<4;++col)for(bit=0;bit<16;++bit){unsigned mask=1u<<bit;if(!(vals[i][col-1]&mask)&&(vals[i][col]&mask))++er;if((vals[i][col-1]&mask)&&!(vals[i][col]&mask))++ef;}if(seen[i]!=1||rises[i]!=er||falls[i]!=ef||x_to_binary[i]!=16||binary_to_x[i]!=0)fail("Q_bit_edge_counts");vpi_printf("XU_PRIMITIVE105_EDGES tag=%u rises=%u falls=%u expected_rises=%u expected_falls=%u X_to_binary=%u binary_to_X=%u vector_notifications=%u\n",i,rises[i],falls[i],er,ef,x_to_binary[i],binary_to_x[i],qchanges[i]);}if(mem_writes!=2||read_checks!=8||hold_checks!=4)fail("operation_counts");vpi_printf("XU_PRIMITIVE105_RESULT status=%s macro_handles=2 memory_word_writes=%u read_checks=%u hold_checks=%u Q_callbacks=%u NOT_FULL_SOC_OR_ACTIVITY_OR_ENERGY\n",failed?"FAIL":"PASS",mem_writes,read_checks,hold_checks,callbacks);if(failed)vpi_control(vpiFinish,1);return 0;}
void xu_primitive105_register(void){s_vpi_systf_data r;const char *names[]={"$xu_preload105","$xu_expect105","$xu_hold105","$xu_done105","$xu_diagnose105"};PLI_INT32(*calls[])(PLI_BYTE8*)={preload,expect,hold,done,diagnose};unsigned i;for(i=0;i<5;++i){memset(&r,0,sizeof(r));r.type=vpiSysTask;r.tfname=(PLI_BYTE8*)names[i];r.calltf=calls[i];vpi_register_systf(&r);}}
void(*vlog_startup_routines[])(void)={xu_primitive105_register,NULL};
