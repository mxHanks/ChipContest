"""Actual VCS primitive evidence. It never opens or modifies mapped-task102."""
from pathlib import Path
import hashlib,json,subprocess,sys,os,time
B=Path.home()/'Desktop/xu-score-optimization-20261102'
O=B/'vpi-vendor-preload-primitive-20261104-105'
T=Path.home()/'Desktop/xu_vpi_preload105.c'
TB=Path.home()/'Desktop/tb_xu_vpi_preload105.sv'
M=Path('/storage1/admin_public_dir/SRAM_Lib_2025/RAMSP1024X16/verilog/RAMSP1024X16.v')
VCS=Path('/eda/synopsys/vcs/vcs_2020.03-SP2-6/bin/vcs')
CC=Path('/usr/bin/gcc')
HEADER=VCS.parent.parent/'include/vpi_user.h'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while True:
   b=f.read(1<<20)
   if not b: break
   h.update(b)
 return h.hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
if len(sys.argv)==1:
 O.mkdir(exist_ok=False)
 with(O/'driver.log').open('xb')as f:
  p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'run'],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print('VPI_PRIMITIVE105_STARTED',p.pid,flush=True)
 sys.exit(0)
s=dict(status='RUNNING_PRIMITIVE_NOT_FULL_SOC_OR_ENERGY',pid=os.getpid(),started_epoch=time.time(),cases=[])
def save():
 p=O/'state.tmp'
 p.write_text(json.dumps(s,sort_keys=True,indent=2)+'\n')
 os.replace(str(p),str(O/'state.json'))
save()
try:
 need(sha(T)=='9d8cca663a9d1a19d2fcf6f111eb1c63fac9c95087b37f39f6171749b98b2587','VPI source differs')
 need(sha(TB)=='71204ce4815d393e731742599458144a694273fb1594191828a717c949bb0403','testbench source differs')
 need(sha(M)=='81b55d87d5e6821d44037d6f0290ec89c9edb9582eb1932957f181aefc300d51','original vendor differs')
 inputs=[T,TB,M,VCS,CC,HEADER,Path(__file__).resolve()]
 s['input_sha256_before']={str(p):sha(p)for p in inputs}
 save()
 code=T.read_text();source=TB.read_bytes()
 wrong=code.replace('4*bit+col','4*bit+(3-col)')
 swapped=code.replace('ordinary")==0)i=0','ordinary")==0)i=1').replace('macro")==0)i=1','macro")==0)i=0')
 need(wrong!=code and swapped!=code and wrong!=swapped,'actual mutation patterns failed')
 cases=[('diagnostic_only',code,True),('reference',code,True),('wrong_bit_column_packing',wrong,False),('swapped_handle_tags',swapped,False)]
 for name,body,positive in cases:
  d=O/name;d.mkdir();(d/'probe.c').write_text(body);(d/'tb.sv').write_bytes(source)
  so=d/'probe.so';sim=d/'sim'
  vcs=[str(VCS),'-full64','-sverilog','-timescale=1ns/1fs','-debug_access+all','-debug_region+cell','+vpi','+define+ARM_UD_MODEL','-load',str(so)+':xu_primitive105_register','-top','tb_xu_vpi_preload105',str(d/'tb.sv'),str(M),'-Mdir='+str(d/'csrc'),'-o',str(sim)]
  if name=='diagnostic_only':vcs.append('+define+XU_PRIMITIVE105_DIAGNOSTIC')
  commands=[dict(name='cc',argv=[str(CC),'-std=gnu99','-Wall','-Wextra','-Werror','-fPIC','-shared','-isystem',str(HEADER.parent),str(d/'probe.c'),'-o',str(so)]),dict(name='vcs',argv=vcs),dict(name='sim',argv=[str(sim)])]
  runs=[]
  for i,row in enumerate(commands):
   log=d/(row['name']+'.log')
   with log.open('xb')as f:
    p=subprocess.run(row['argv'],cwd=str(d),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,timeout=600)
   runs.append(dict(command=row,returncode=p.returncode,log_sha256=sha(log)))
   if i<2:need(p.returncode==0,'actual primitive compile failed: '+name+'/'+row['name'])
  log=(d/'sim.log').read_text(errors='replace')
  marker='XU_PRIMITIVE105_DIAGNOSTIC status=PASS' if name=='diagnostic_only' else 'XU_PRIMITIVE105_RESULT status=PASS'
  passed=runs[-1]['returncode']==0 and log.count(marker)==1 and 'XU_PRIMITIVE105_ERROR'not in log
  result=dict(name=name,expected_pass=positive,actual_pass=passed,runs=runs,code_sha256=sha(d/'probe.c'),testbench_sha256=sha(d/'tb.sv'))
  s['cases'].append(result);save()
  need(passed==positive,'positive/negative actual behavior differs: '+name)
  if name=='diagnostic_only':
   need(log.count('XU_PRIMITIVE105_GEOMETRY_RESULT ')==2 and log.count('role=indexed_word ')==512,'full read-only geometry report missing')
   need('XU_PRIMITIVE105_PRELOAD'not in log and 'writes=0'in log,'diagnostic attempted write')
  elif positive:
   need(log.count('XU_PRIMITIVE105_READ ')==8 and log.count('XU_PRIMITIVE105_PRELOAD ')==2 and log.count('XU_PRIMITIVE105_EDGES ')==2,'complete ordinary/escaped primitive work missing')
   need(log.count('XU_PRIMITIVE105_GEOMETRY_RESULT ')==2 and log.count('role=indexed_word ')==512,'full geometry guard missing')
  else:
   need('XU_PRIMITIVE105_ERROR'in log and 'XU_PRIMITIVE105_RESULT status=PASS'not in log,'negative needs actual checker rejection')
  print('VPI_PRIMITIVE105_CASE',name,passed,flush=True)
 s['input_sha256_after']={str(p):sha(p)for p in inputs}
 need(s['input_sha256_after']==s['input_sha256_before'],'immutable source/tool inputs changed')
 s['status']='EXECUTED_READONLY_GEOMETRY_VENDOR_VPI_PRELOAD_AND_TWO_REJECTIONS_NOT_FULL_SOC_ACTIVITY_OR_ENERGY'
except BaseException as e:
 s.update(status='FAIL_PRIMITIVE_NOT_QUALIFIED',error=type(e).__name__+': '+str(e))
 raise
finally:
 s['finished_epoch']=time.time();save()
print('VPI_PRIMITIVE105_DONE',s['status'],flush=True)
