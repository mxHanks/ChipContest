#!/usr/bin/env python3
"""Start actual108 once in a fresh server output; no vendor body is exported."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base = Path.home() / 'Desktop/xu-score-optimization-20261102'
script = Path.home() / 'Desktop/xu_udp_review108.py'
launcher = base / 'mapped-udp-launch-20261104-108'
out = base / 'mapped-udp-review-20261104-108'
private = base / 'udp-definition-private-20261104-108'
assert not launcher.exists() and not out.exists() and not private.exists(), 'new actual108 outputs required'
launcher.mkdir()
command = [sys.executable, str(script), '--base', str(base), '--out', str(out), '--private-dir', str(private)]
with (launcher / 'driver.log').open('xb') as output:
    process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
                               cwd=str(base), start_new_session=True)
state = dict(status='LAUNCHED_NOT_QUALIFIED', qualification='NOT_QUALIFIED', pid=process.pid,
             command=command, started_epoch=time.time(),
             script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),
             private_vendor_directory=str(private), private_directory_must_not_be_exported=True)
(launcher / 'state.json').write_text(json.dumps(state, sort_keys=True, indent=2) + '\n')
print('XU_UDP108_LAUNCHED', process.pid, flush=True)
