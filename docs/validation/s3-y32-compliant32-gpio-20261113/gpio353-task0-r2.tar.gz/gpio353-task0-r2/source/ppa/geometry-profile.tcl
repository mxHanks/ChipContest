# Sealed exact hardware profile. No timing or constraint edits.
set sysbus32_hardware_profile {sysbus32-x-sram-353}
set sysbus32_production_defines [list SYNTHESIS DISABLE_SV_ASSERTION=1 XU_MATRIX_DMA XU_MATRIX_DMA_SYSBUS32 XU_MATRIX_X_SRAM]
set sysbus32_expected_total_macros 353
set sysbus32_expected_x_macros 16
set sysbus32_expected_internal_macros 33
