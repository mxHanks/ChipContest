# Read-only DC report collection. Unsupported reports remain explicit gaps.
# No false paths, multicycle paths, ideal networks, IO or clock edits are made.
if {![info exists XU_CLOCK_REVIEW_DIR]} {set XU_CLOCK_REVIEW_DIR dc-clock-reports}
file mkdir $XU_CLOCK_REVIEW_DIR
set xu_review_failures {}
set xu_required_failures {}
set xu_signoff_gaps {}
proc xu_clock_capture {filename command required} {
  global XU_CLOCK_REVIEW_DIR xu_review_failures xu_required_failures
  set target [file join $XU_CLOCK_REVIEW_DIR $filename]
  if {[catch {redirect -file $target $command} result options]} {
    set f [open ${target}.unavailable.txt w]
    puts $f "COMMAND=$command\nERROR=$result\nREQUIRED=$required"
    if {[dict exists $options -errorinfo]} {puts $f [dict get $options -errorinfo]}
    close $f
    lappend xu_review_failures [list $filename $required $result]
    if {$required} {lappend xu_required_failures $filename}
    return 0
  }
  return 1
}
xu_clock_capture check_timing.rpt {check_timing} 1
xu_clock_capture clocks.rpt {report_clock -attributes} 1
xu_clock_capture setup.rpt {report_timing -slack_lesser_than 1000000000 -delay_type max -max_paths 50 -nworst 1 -path_type full -significant_digits 8 -nets -input_pins -transition_time -capacitance} 1
xu_clock_capture hold.rpt {report_timing -slack_lesser_than 1000000000 -delay_type min -max_paths 50 -nworst 1 -path_type full -significant_digits 8 -nets -input_pins -transition_time -capacitance} 1
xu_clock_capture constraints.rpt {report_constraint -all_violators -verbose} 1
lappend xu_signoff_gaps exceptions.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR exceptions.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: report_exceptions unknown command CMD-005. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
xu_clock_capture case_analysis.rpt {report_case_analysis -all} 1
lappend xu_signoff_gaps recovery.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR recovery.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: report_constraint -recovery unsupported CMD-010. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
lappend xu_signoff_gaps removal.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR removal.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: report_constraint -removal unsupported CMD-010. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
lappend xu_signoff_gaps gating_setup.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR gating_setup.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: report_constraint -clock_gating_setup unsupported CMD-010. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
lappend xu_signoff_gaps gating_hold.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR gating_hold.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: report_constraint -clock_gating_hold unsupported CMD-010. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
xu_clock_capture pulse_width.rpt {report_constraint -min_pulse_width -all_violators -verbose} 1
xu_clock_capture max_transition.rpt {report_constraint -max_transition -all_violators -verbose} 1
xu_clock_capture max_capacitance.rpt {report_constraint -max_capacitance -all_violators -verbose} 1
xu_clock_capture min_capacitance.rpt {report_constraint -min_capacitance -all_violators -verbose} 1
xu_clock_capture max_fanout.rpt {report_constraint -max_fanout -all_violators -verbose} 1
# Coverage is a PT signoff requirement even if this DC version lacks it.
lappend xu_signoff_gaps analysis_coverage.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR analysis_coverage.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: report_analysis_coverage unknown command CMD-005. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
lappend xu_signoff_gaps async_pin_max.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR async_pin_max.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: all_registers -async_pins unsupported CMD-010. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
lappend xu_signoff_gaps async_pin_min.rpt
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR async_pin_min.rpt.unavailable.txt] w]
puts $xu_f {DC native old baseline: all_registers -async_pins unsupported CMD-010. Not invoked again. Required standalone PT report remains missing; all native DC violators retained.}
close $xu_f
foreach_in_collection xu_clock [get_clocks *] {
  set xu_name [get_object_name $xu_clock]
  set xu_safe [string map {/ _ " " _ \[ _ \] _} $xu_name]
  xu_clock_capture group-${xu_safe}-setup.rpt [list report_timing -slack_lesser_than 1000000000 -group $xu_name -delay_type max -max_paths 20 -nworst 1 -path_type full -significant_digits 8] 1
  xu_clock_capture group-${xu_safe}-hold.rpt [list report_timing -slack_lesser_than 1000000000 -group $xu_name -delay_type min -max_paths 20 -nworst 1 -path_type full -significant_digits 8] 1
}
# Observational-only omission after identical compile/map. Native baseline
# R5 spent >87min in this broad from/to register query without a report body.
# Keep all global/group/violator reports. Standalone PT provides coverage.
# This omission creates a report gap; it neither edits nor waives any path.
foreach xu_name {dma-register-setup.rpt dma-register-hold.rpt} {
  lappend xu_signoff_gaps $xu_name
  set xu_f [open [file join $XU_CLOCK_REVIEW_DIR ${xu_name}.unavailable.txt] w]
  puts $xu_f {STATUS=OMITTED_PROVEN_STALLED_BROAD_SCOPE_QUERY; NO_CONSTRAINT_CHANGE; STANDALONE_PT_REQUIRED}
  close $xu_f
}
# Never retry known-incompatible get_clocks -of_objects. Use the pin clocks
# attribute only if this native tool lists it explicitly as a collection.
xu_clock_capture native-lib-attributes.rpt {list_attributes -application -class lib} 0
set xu_association_status UNAVAILABLE_REQUIRES_PT
set xu_no_clock UNKNOWN
set xu_clock_pin_count UNKNOWN
set xu_sram_no_clock UNKNOWN
if {[xu_clock_capture native-pin-attributes.rpt {list_attributes -application -class pin} 0]} {
  set xu_f [open [file join $XU_CLOCK_REVIEW_DIR native-pin-attributes.rpt] r]
  set xu_attrs [read $xu_f]
  close $xu_f
  if {[regexp {(^|\n)[ \t]*clocks[ \t]+pin[ \t]+collection([ \t]|\r?\n)} $xu_attrs]} {
    if {[catch {
      set xu_f [open [file join $XU_CLOCK_REVIEW_DIR clock_endpoints.tsv] w]
      puts $xu_f "kind\tpin\tclock_count\tclocks"
      set xu_no_clock 0
      set xu_sram_no_clock 0
      set xu_clock_pin_count 0
      foreach_in_collection xu_pin [all_registers -clock_pins] {
        incr xu_clock_pin_count
        set xu_clks [get_attribute $xu_pin clocks]
        set xu_n [sizeof_collection $xu_clks]
        if {$xu_n == 0} {incr xu_no_clock}
        puts $xu_f "register\t[get_object_name $xu_pin]\t$xu_n\t[get_object_name $xu_clks]"
      }
      foreach_in_collection xu_cell [get_cells -quiet -hierarchical -filter {ref_name == RAMSP1024X16}] {
        set xu_pin [get_pins -quiet [format {%s/CLK} [get_object_name $xu_cell]]]
        if {[sizeof_collection $xu_pin] != 1} {error "missing SRAM clock: [get_object_name $xu_cell]"}
        set xu_clks [get_attribute $xu_pin clocks]
        set xu_n [sizeof_collection $xu_clks]
        if {$xu_n == 0} {incr xu_sram_no_clock}
        puts $xu_f "SRAM\t[get_object_name $xu_pin]\t$xu_n\t[get_object_name $xu_clks]"
      }
      close $xu_f
      set xu_association_status COLLECTED_REVIEW_REQUIRED
    } xu_reason]} {
      catch {close $xu_f}
      set xu_association_status QUERY_FAILED_REQUIRES_PT
      lappend xu_signoff_gaps clock_association
      set xu_f [open [file join $XU_CLOCK_REVIEW_DIR clock_association.unavailable.txt] w]
      puts $xu_f $xu_reason
      close $xu_f
    }
  } else {
    lappend xu_signoff_gaps clock_association_attribute_not_proven
    set xu_f [open [file join $XU_CLOCK_REVIEW_DIR clock_association.unavailable.txt] w]
    puts $xu_f {Native pin attribute inventory does not prove clocks collection support. No get_clocks -of_objects query or zero-clock fallback is used. Obtain complete association in standalone PT.}
    close $xu_f
  }
}
set xu_f [open [file join $XU_CLOCK_REVIEW_DIR review_status.txt] w]
puts $xu_f "MODE=$XU_CLOCK_MODE\nPLL_DIV=$XU_PLL_DIV\nREGISTER_CLOCK_PINS=$xu_clock_pin_count\nNO_CLOCK_ENDPOINTS=$xu_no_clock\nSRAM_NO_CLOCK_ENDPOINTS=$xu_sram_no_clock"
puts $xu_f "CLOCK_ASSOCIATION_STATUS=$xu_association_status"
puts $xu_f "REPORT_COMMAND_FAILURES=$xu_review_failures\nREQUIRED_REPORT_FAILURES=$xu_required_failures\nREQUIRED_REPORT_FAILURE_COUNT=[llength $xu_required_failures]"
puts $xu_f "SIGNOFF_REPORT_GAPS=$xu_signoff_gaps\nSIGNOFF_REPORT_GAPS_COUNT=[llength $xu_signoff_gaps]"
puts $xu_f {STATUS=COLLECTION_REVIEW_REQUIRED_NOT_TIMING_PASS}
puts $xu_f {TIMING_CLOSURE=UNREVIEWED; missing/unsupported reports are gaps, not passes}
close $xu_f
