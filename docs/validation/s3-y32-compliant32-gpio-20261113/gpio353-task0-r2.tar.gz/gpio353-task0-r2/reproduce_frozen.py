#!/usr/bin/env python3
"""Verify or replay the compact frozen353 GPIO single-task evidence bundle."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    bundle = args.bundle.resolve()
    expected = json.loads((bundle / 'files.json').read_text())
    for name, digest in expected.items():
        path = bundle / name
        if path.is_symlink() or not path.is_file() or sha(path) != digest:
            raise ValueError('bundle drift: ' + name)
    original = json.loads((bundle / 'evidence/result.json').read_text())
    if original['status'] != 'PASS' or original['outputs'] != 25344:
        raise ValueError('not original completed GPIO single-task evidence')
    for name, digest in original['source_sha256'].items():
        if sha(bundle / 'source' / name) != digest:
            raise ValueError('frozen source mismatch: ' + name)
    for name, key in [('dma_day_soc', 'elf_sha256'), ('dma_day_soc.verilog', 'image_sha256')]:
        if sha(bundle / 'firmware' / name) != original['firmware'][key]:
            raise ValueError('frozen firmware mismatch')
    for path in sorted((bundle / 'vectors').rglob('*.mem')):
        name = str(path.relative_to(bundle / 'vectors'))
        if sha(path) != original['vector_byte_sha256'][name]:
            raise ValueError('selected task0 vector mismatch')
    helper = load('frozen_gpio_math', bundle / 'source/firmware_helpers.py')
    audit = helper.check_vectors(bundle / 'vectors', 1)
    checker = load('frozen_gpio_checker', bundle / 'source/check_results.py')
    checked = checker.check_log((bundle / 'evidence/simulation.log').read_text(), 1, 8, True, x_macros=True)
    if checked['total_cycles'] != original['total_cycles']:
        raise ValueError('original raw log and result differ')
    if args.verify_only:
        print(json.dumps(dict(status='PASS_FROZEN_CONTENT_AND_RAW_LOG_REPLAY_NO_NEW_SIMULATION',
                             source_files=len(original['source_sha256']), outputs=checked['outputs'],
                             total_cycles=checked['total_cycles'], vector_integer_MAC_RNE=audit)))
        return 0
    if args.out is None:
        parser.error('--out is required for a new simulation')
    out = args.out.resolve()
    if out.exists():
        parser.error('output must be new')
    out.mkdir(parents=True)
    shutil.copytree(bundle / 'source', out / 'source')
    shutil.copytree(bundle / 'firmware', out / 'firmware')
    old_out = str(Path(original['firmware']['elf']).parent.parent)
    (out / 'rtl.f').write_text((bundle / 'evidence/rtl.f').read_text().replace(old_out, str(out)))
    command = [str(item).replace(old_out, str(out)) for item in original['build_command']]
    with (out / 'build.log').open('w') as stream:
        subprocess.run(command, cwd=out, stdout=stream, stderr=subprocess.STDOUT, check=True)
    runtime = [str(item).replace(old_out, str(out)) for item in original['run_command']]
    runtime = ['+VECTORS=' + str(bundle / 'vectors') if item.startswith('+VECTORS=') else item for item in runtime]
    with (out / 'simulation.log').open('w') as stream:
        subprocess.run(runtime, cwd=out, stdout=stream, stderr=subprocess.STDOUT, check=True)
    actual = checker.check_log((out / 'simulation.log').read_text(), 1, 8, True, x_macros=True)
    if actual['layers'] != checked['layers'] or actual['warmup'] != checked['warmup']:
        raise ValueError('new CPU simulation differs from frozen functional/cycle evidence')
    result = dict(status='PASS_NEW_SIMULATION_SAME_SINGLE_TASK_COUNTS_AND_CYCLES', functional=actual,
                  simulator_sha256=sha(Path(runtime[0])), build_command=command, run_command=runtime,
                  limitation='Single-task353 generic functional evidence; no full12 throughput, STA, area, mapped equivalence or power qualification.')
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], outputs=actual['outputs'], total_cycles=actual['total_cycles'])))
    return 0


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())
