if {[catch {
set_host_options -max_cores 2
set_app_var target_library [list {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db}]
set_app_var link_library [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db}]
set_svf repair.svf
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-unloaded-cell-cleanup-20261103-50/mapped.v}
current_design xu_soc_ppa_top
if {![link]} {error {DC link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
set_dont_touch [get_cells -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}] true

set xu_before_cells [sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]
set xu_parent_counts [dict create]
foreach_in_collection h [get_cells -hierarchical -filter {is_hierarchical == true}] {dict incr xu_parent_counts [get_attribute $h ref_name]}
set xu_remove {}
set xu_upstream [dict create]
set f [open removal-preflight.tsv w]
puts $f "cell\tref\tis_sequential\toutput\tleaf_connections\tparent_ref_instance_count"
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U105}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U105/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U107}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U107/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U109}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U109/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U111}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U111/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U113}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U113/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U115}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U115/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U117}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U117/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U119}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U119/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U121}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U121/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U123}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U123/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U125}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U125/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U127}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U127/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U129}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U129/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U131}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U131/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U133}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U133/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U135}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U135/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U137}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U137/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U139}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U139/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U141}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U141/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U143}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U143/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U145}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U145/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U147}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U147/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U149}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U149/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U151}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U151/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U153}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U153/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U155}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U155/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U157}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U157/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U159}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U159/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U161}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U161/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U163}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U163/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U165}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U165/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U59}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/U59/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U100}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U100/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U101}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U101/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U102}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U102/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U103}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U103/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U104}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U104/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U105}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U105/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U106}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U106/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U107}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U107/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U108}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U108/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U109}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U109/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U110}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U110/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U111}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U111/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U112}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U112/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U113}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U113/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U114}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U114/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U115}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U115/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U116}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U116/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U117}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U117/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U118}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U118/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U119}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U119/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U120}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U120/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U121}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U121/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U122}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U122/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U123}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U123/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U124}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U124/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U125}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U125/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U126}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U126/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U127}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U127/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U128}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U128/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U129}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U129/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U130}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U130/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U131}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U131/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U132}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U132/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U133}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U133/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U134}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U134/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U135}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U135/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U136}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U136/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U137}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U137/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U138}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U138/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U139}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U139/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U140}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U140/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U141}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AO222V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U141/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U142}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U142/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U143}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U143/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U71}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U71/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U75}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U75/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U80}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U80/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U82}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U82/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U83}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U83/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U84}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U84/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U85}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U85/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U86}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U86/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U87}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U87/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U88}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U88/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U89}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U89/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U90}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U90/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U91}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U91/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U92}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U92/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U93}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U93/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U94}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U94/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U95}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U95/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U96}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U96/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U97}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U97/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U98}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2BV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U98/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U393}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U393/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U404}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U404/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U406}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U406/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U409}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U409/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U411}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U411/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U415}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U415/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U416}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U416/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U428}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U428/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U430}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U430/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U444}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U444/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U446}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U446/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U448}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U448/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U450}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U450/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U452}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U452/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U521}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U521/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U525}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U525/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U533}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U533/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U17}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOAI211V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U17/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U206}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR4CV1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U206/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U248}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U248/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U259}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U259/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U261}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U261/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U263}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U263/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U264}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U264/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U302}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U302/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U304}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U304/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U306}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U306/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U308}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U308/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U312}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U312/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U313}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U313/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U316}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U316/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U322}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U322/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U324}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U324/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U327}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U327/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U328}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U328/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U331}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U331/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U333}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U333/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U339}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U339/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U343}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U343/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U348}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U348/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U352}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U352/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U371}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR4BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U371/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U375}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U375/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U388}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U388/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U390}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U390/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U397}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U397/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U403}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U403/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U406}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U406/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U409}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U409/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U412}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U412/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U413}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND3CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U413/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U415}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U415/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U416}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U416/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U421}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U421/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U426}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U426/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U430}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U430/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U436}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U436/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U446}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U446/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U448}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U448/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U450}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OA31V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U450/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U453}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U453/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U458}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U458/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U459}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U459/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U462}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U462/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U479}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI222V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U479/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U480}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U480/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U482}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U482/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U485}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U485/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U501}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U501/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U511}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U511/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U514}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U514/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U515}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OA22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U515/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U518}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U518/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U521}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U521/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U522}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U522/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U524}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U524/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U526}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U526/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U528}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U528/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U530}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U530/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U532}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U532/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U72}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOAI211V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U72/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U73}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOAI211V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U73/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U74}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOAI211V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U74/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U75}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOAI211V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U75/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_mems/u_sirv_mem_fab/u_i_icb_splt/U462}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_mems/u_sirv_mem_fab/u_i_icb_splt}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_mems/u_sirv_mem_fab/u_i_icb_splt/U462/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_spictrl/U270}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_spictrl}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_spictrl/U270/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_spictrl/U271}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_spictrl}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_spictrl/U271/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_spictrl/U270}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_spictrl}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_spictrl/U270/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_spictrl/U271}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_spictrl}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_spictrl/U271/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab/u_buf_icb_splt/U1064}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab/u_buf_icb_splt}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab/u_buf_icb_splt/U1064/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab/u_buf_icb_splt/U942}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup63 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup63 cannot prove combinational cell classification}}
if {$seq} {error {cleanup63 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab/u_buf_icb_splt}]
if {[sizeof_collection $owner]!=1} {error {cleanup63 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup63 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup63 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab/u_buf_icb_splt/U942/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup63 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup63 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup63 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]

close $f
if {[llength $xu_remove]!=187 || [llength [lsort -unique $xu_remove]]!=187} {error {cleanup63 must remove exact187 cells}}
# All187 candidates have passed before the first deletion. No remove_port or
# hierarchy cleanup, and no recursive deletion of newly dangling upstream logic.
set f [open removed-cells.tsv w]
puts $f "cell\tremoved"
foreach name $xu_remove {
 set c [get_cells -quiet $name]
 if {[sizeof_collection $c]!=1} {error {cleanup63 preflight cell vanished}}
 remove_cell $c
 if {[sizeof_collection [get_cells -quiet $name]]!=0} {error {cleanup63 exact removal did not apply}}
 puts $f [join [list $name 1] "\t"]
}
close $f
if {[sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]!=$xu_before_cells-187} {error {cleanup63 unexpected leaf-cell change}}
set f [open post-cleanup-upstream.tsv w]
puts $f "driver\towner_ref\tnet_count\tleaf_connections\tsource_only"
foreach name [lsort [dict keys $xu_upstream]] {
 set p [get_pins -quiet $name]
 if {[sizeof_collection $p]==0} {continue}
 if {[sizeof_collection $p]!=1} {error {cleanup63 upstream pin ambiguous}}
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]>1} {error {cleanup63 upstream output net ambiguous}}
 set con {}
 if {[sizeof_collection $n]==1} {set con [all_connected -leaf $n]}
 set source_only [expr {[sizeof_collection $n]==0 || ([sizeof_collection $con]==1 && [get_object_name $con] eq [get_object_name $p])}]
 puts $f [join [list $name [get_attribute [get_cells -of_objects $p] ref_name] [sizeof_collection $n] [get_object_name $con] $source_only] "\t"]
}
close $f
# Exact post-elaboration macro groups; overlapping matches and missing/extra cells fail.
set xu_seen [dict create]
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_itcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: itcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP itcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_dtcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: dtcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP dtcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_shared/storage/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 256} {error {wrong macro count: shared}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP shared count=256 macro_ref=RAMSP1024X16 logical_bits=4194304 physical_bits=4194304 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 16} {error {wrong macro count: accelerator_weights}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP accelerator_weights count=16 macro_ref=RAMSP1024X16 logical_bits=262144 physical_bits=262144 padding_bits=0"
# RAMSP is the explicit technology SRAM namespace; reject every extra leaf/reference.
set xu_allowed_refs [list {RAMSP1024X16}]
set xu_all_macros [get_cells -quiet -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}]
if {[sizeof_collection $xu_all_macros] != 336 || [dict size $xu_seen] != 336} {error {full-SoC SRAM total must be exactly 336}}
foreach_in_collection xu_c $xu_all_macros {
  if {[lsearch -exact $xu_allowed_refs [get_attribute $xu_c ref_name]] < 0} {error {unexpected SRAM reference}}
  if {![dict exists $xu_seen [get_object_name $xu_c]]} {error {ungrouped/unaccounted SRAM macro}}
}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave && ref_name =~ accel_icb_slave*}]] != 1} {error {missing/wrong accelerator}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top && ref_name =~ e203_cpu_top*}]] != 1} {error {missing/wrong cpu}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab && ref_name =~ sirv_icb1to16_bus*}]] != 1} {error {missing/wrong interconnect}}
report_constraint -all_violators -verbose > dc-all-constraints.rpt
report_units > dc-units.rpt
report_area -hierarchy > area.rpt
report_qor > qor.rpt
report_timing -delay_type max -max_paths 50 > dc-setup.rpt
report_timing -delay_type min -max_paths 50 > dc-hold.rpt
report_constraint -all_violators > dc-violations.rpt
write -format verilog -hierarchy -output mapped.v
write -format ddc -hierarchy -output mapped.ddc
write_sdc mapped.sdc

puts {XU_CLEANUP63_DC_DONE_NOT_QUALIFIED}
} xu_error]} {
  puts stderr "XU_FATAL: $xu_error"
  exit 1
}
exit 0
