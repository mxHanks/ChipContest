/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/s2c-ppa-campaign-20261103-01/s2c/ppa/mapped.v
/storage1/admin_public_dir/SRAM_Lib_2025/RAMSP1024X16/verilog/RAMSP1024X16.v
/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/standard-cell-model-private-20261104-90/scc40nll_vhsc40_rvt.v
/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/mapped-elaboration-probe-20261104-97/tb_xu_mapped_inventory74.sv
