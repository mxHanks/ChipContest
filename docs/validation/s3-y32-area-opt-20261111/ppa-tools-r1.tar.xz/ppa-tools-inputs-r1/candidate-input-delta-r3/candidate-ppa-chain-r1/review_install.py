from pathlib import Path
import ast,base64,contextlib,gzip,hashlib,io,json,os
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;OUT=HERE/'offline-install-fixtures';assert not OUT.exists();OUT.mkdir(mode=0o700)
s=(HERE/'install-and-start-chain-r1.sh').read_text();code=s.split("<<'PY_XU_SERIAL_CHAIN_INSTALL'\n",1)[1].rsplit('\nPY_XU_SERIAL_CHAIN_INSTALL',1)[0]
t=ast.parse(code);vals={n.targets[0].id:ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['EXPECTED','PAYLOAD']}
assert gzip.decompress(base64.b64decode(vals['PAYLOAD'],validate=True))==(HERE/'watcher.py').read_bytes()
original_glob=Path.glob;rows=[]
class FakeProcess:pid=424242
for case in ['happy','missing-owner','ambiguous-owner','existing-top','deadline','payload-drift']:
 p=OUT/case;p.mkdir(mode=0o700);scratch=p/'codex-area-opt-20261111-installer-review';scratch.mkdir(mode=0o700);owner={'schema':'s3-areaopt-owned-scratch-v1','uid':os.getuid(),'mode':'0700','purpose':'own PT/candidate EDA outputs; preserve existing Desktop evidence','created_epoch':1794379000};(scratch/'owner.json').write_text(json.dumps(owner));entries=[scratch];testcode=code;top=scratch/'candidate-ppa-chain-r1'
 if case=='missing-owner':entries=[]
 if case=='ambiguous-owner':
  other=p/'codex-area-opt-20261111-other';other.mkdir(mode=0o700);(other/'owner.json').write_text(json.dumps(owner));entries.append(other)
 if case=='existing-top':top.mkdir(mode=0o700)
 if case=='payload-drift':testcode=code.replace('EXPECTED='+repr(vals['EXPECTED']),'EXPECTED='+repr('0'*64),1)
 def mock_glob(self,pattern,**kwargs):return iter(entries) if self==Path('/tmp') and pattern=='codex-area-opt-20261111-*' else original_glob(self,pattern,**kwargs)
 launches=[]
 def fake_popen(cmd,**kwargs):launches.append(cmd);return FakeProcess()
 error=None;capture=io.StringIO()
 with patch('pathlib.Path.glob',mock_glob),patch('subprocess.Popen',fake_popen),patch('time.time',return_value=1794412740 if case=='deadline' else 1794380000),contextlib.redirect_stdout(capture):
  try:exec(compile(testcode,'exact-installer','exec'),{'__name__':'__offline_review__'})
  except RuntimeError as exc:error=str(exc)
 if case=='happy':
  assert error is None and len(launches)==1 and launches[0]==['python3',str(top/'watcher.py'),'--run'];assert (top/'watcher.py').read_bytes()==(HERE/'watcher.py').read_bytes();assert json.loads((top/'install-receipt.json').read_text())['pid']==424242
 else:
  expected={'missing-owner':'owned_scratch_not_unique','ambiguous-owner':'owned_scratch_not_unique','existing-top':'refuse_existing_chain_package','deadline':'experiment_deadline_reached','payload-drift':'watcher_payload_identity'}[case];assert error==expected and not launches,(case,error);assert not (top/'watcher.py').exists()
 rows.append({'case':case,'status':'PASS','rejection':error,'mock_launches':len(launches)})
receipt={'status':'PASS_EXACT_ASCII_INSTALLER_OFFLINE','scope':'No network/UI/credentials/EDA. Exact emitted installer source with only own /tmp fixture discovery, time and Popen mocked.','checks':rows,'installer_sha256':hashlib.sha256((HERE/'install-and-start-chain-r1.sh').read_bytes()).hexdigest(),'watcher_sha256':hashlib.sha256((HERE/'watcher.py').read_bytes()).hexdigest(),'review_tool_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
p=HERE/'installer-offline-review-receipt.json';p.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'checks':len(rows),'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
