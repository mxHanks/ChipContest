#!/usr/bin/env python3
"""Native gate fixtures and mocked sequencing only; no EDA/network."""
from pathlib import Path
import copy,hashlib,json,os,shutil,types
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
fixture=HERE/'offline-fixtures';assert not fixture.exists();fixture.mkdir(mode=0o700)
ns={'__name__':'__offline_chain_review__','__file__':str(HERE/'watcher.py')};exec(compile((HERE/'watcher.py').read_text(),str(HERE/'watcher.py'),'exec'),ns)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
rows=[]
def check(case,fn,expect=None):
 try:got=fn()
 except RuntimeError as e:
  assert expect and str(e).startswith(expect),(case,str(e));got={'rejection':str(e)}
 else:assert expect is None,(case,'expected rejection absent')
 rows.append({'case':case,'status':'PASS','expected_rejection':expect,'result':got})
# Assert embedded B Python is byte-identical to the reviewed exact source.
orig=HERE.parent/'launch-candidate-b-r3.sh';body=orig.read_text().split("<<'PY_XU_AREA_CANDIDATE_LAUNCH'\n",1)[1].rsplit('\nPY_XU_AREA_CANDIDATE_LAUNCH',1)[0]
assert ns['B_BODY']==body and hashlib.sha256(body.encode()).hexdigest()==ns['B_BODY_SHA']
rows.append({'case':'exact_reviewed_B_body','status':'PASS','body_sha256':ns['B_BODY_SHA']})
scratch=fixture/'codex-area-opt-20261111-local';scratch.mkdir(mode=0o700)
owner={'schema':'s3-areaopt-owned-scratch-v1','uid':os.getuid(),'mode':'0700','purpose':'own PT/candidate EDA outputs; preserve existing Desktop evidence','created_epoch':1794379000};dump(scratch/'owner.json',owner)
root=scratch/'candidate-a-r3/candidate';shutil.copytree(HERE.parent/'independent-offline-review/codex-area-opt-20261111-happy-a/candidate-a-r3/candidate',root)
r=json.loads((HERE.parent/'independent-offline-review/codex-area-opt-20261111-happy-a/candidate-a-r3/transport-reconstruction.json').read_text());r.update(scratch=str(scratch),candidate=str(root),scratch_owner_sha256=sha(scratch/'owner.json'));dump(root.parent/'transport-reconstruction.json',r)
for name in ns['REQUIRED_MAP']:
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('OFFLINE_SYNTHETIC_GATE_FIXTURE_ONLY\n')
log='OFFLINE_SYNTHETIC_GATE_FIXTURE_ONLY\n'+''.join(('P4K_COUNT %s actual=%d expected=%d\n'%(n,c,c))*2 for n,c in [('tile_pes',64),('tile_engines',8),('weights',16),('bias',1),('all_ramsp',337)])
(root/'dc.log').write_text(log);(root/'dc-clock-reports/review_status.txt').write_text('REQUIRED_REPORT_FAILURE_COUNT=0\nSIGNOFF_REPORT_GAPS_COUNT=10\nSTATUS=COLLECTION_REVIEW_REQUIRED_NOT_TIMING_PASS\n')
base={'status':'SYNTHESIS_COMPLETE_NOT_QUALIFIED','returncode':0,'completion_marker':True,'source_drift':[],'native_tool_errors':[],'deadline_terminated':False,'mapping_outputs_complete':True,'manifest_sha256':ns['MANIFESTS']['a'],'inputs':242,'max_cores':2,'tool':{'sha256':ns['DC_SHA']},'libraries':[{'role':n,'sha256':h} for n,h in ns['LIBS'].items()],'report_collection_status':'COLLECTED_REVIEW_REQUIRED','outputs':{n:{'bytes':(root/n).stat().st_size,'sha256':sha(root/n)} for n in ns['REQUIRED_MAP']}}
dump(root/'execution.json',base);goodhash=sha(root/'execution.json')
check('clean_DC_identity_not_timing_PASS',lambda:ns['verify_dc'](root,'a',base,goodhash))
for case,field,value,expected in [
 ('failed_DC','status','FAILED','DC_not_clean_completed:'),('missing_completion','completion_marker',False,'DC_not_clean_completed:'),('source_drift','source_drift',['source/rtl/perips/LinearTileDmaCore.sv'],'DC_failure_or_drift:'),('native_tool_error','native_tool_errors',['Error: native failure'],'DC_failure_or_drift:'),('deadline_terminated','deadline_terminated',True,'DC_failure_or_drift:'),('wrong_manifest','manifest_sha256','0'*64,'DC_receipt_identity:'),('wrong_core_limit','max_cores',4,'DC_receipt_identity:'),('incomplete_collection','report_collection_status','INCOMPLETE','DC_reports_incomplete')]:
 r=copy.deepcopy(base);r[field]=value;check(case,lambda r=r:ns['verify_dc'](root,'a',r,goodhash),expected)
for case,mut,expected in [('missing_output_record',lambda r:r['outputs'].pop('mapped.v'),'missing_required_output_records'),('output_byte_drift',lambda r:r['outputs']['mapped.v'].update(bytes=999),'native_output_identity:'),('output_hash_drift',lambda r:r['outputs']['mapped.v'].update(sha256='0'*64),'native_output_identity:')]:
 r=copy.deepcopy(base);mut(r);check(case,lambda r=r:ns['verify_dc'](root,'a',r,goodhash),expected)
check('receipt_changed_during_verify',lambda:ns['verify_dc'](root,'a',base,'0'*64),'DC_receipt_changed_during_verify')
with patch.dict(ns,{'jobs':lambda:[{'pid':99,'comm':'simv'}]}):check('foreign_heavy_rejected',lambda:ns['no_heavy'](),'same_account_heavy_jobs:')
# PT collection can complete with negative timing. Failed tools halt the chain.
prepared=HERE.parents[1]/'pt-recovery-r4'
assert prepared.is_dir(),prepared
class FakeProcess:
 pid=424242;returncode=0
 def poll(self):return self.returncode
 def wait(self,timeout=None):return self.returncode
for case,status,expected in [('PT_negative_timing_collection_allowed','PT_REPORT_COLLECTION_COMPLETE_NOT_QUALIFIED',None),('PT_tool_FAILED_rejected','FAILED','PT_collection_failed:')]:
 out=fixture/case
 def fake_popen(cmd,**kw):
  out.mkdir(mode=0o700)
  req=['baseline-status.txt','pt.log','BASELINE_PT_REPLAY_COMPLETE_NOT_QUALIFIED.txt','reports/coverage.rpt','reports/all_violators.rpt','reports/setup.rpt','reports/hold.rpt','reports/clock_endpoints.tsv']
  for name in req:
   p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('OFFLINE_FIXTURE: slack (VIOLATED) -3.079 ns; timing is NOT PASS\n')
  r={'status':status,'returncode':0,'completion_marker':True,'source_drift':[],'native_tool_errors':[],'tool_timeout_300s':False,'deadline_terminated':False,'prepared_manifest_sha256':ns['PT_MANIFEST_SHA'],'max_cores':2,'source_dc_execution_sha256':sha(root/'execution.json'),'source_dc_manifest_sha256':ns['MANIFESTS']['a'],'timing_verdict':'UNREVIEWED_NOT_A_TIMING_PASS','outputs':{n:{'bytes':(out/n).stat().st_size,'sha256':sha(out/n)} for n in req}}
  dump(out/'execution.json',r);return FakeProcess()
 # Each run_pt writes an exclusive supervisor log outside out; use unique parent.
 container=fixture/(case+'-container');container.mkdir();out=container/'pt-result'
 with patch.dict(ns,{'jobs':lambda:[]}),patch('subprocess.Popen',side_effect=fake_popen),patch('time.time',return_value=1794380000):check(case,lambda:ns['run_pt'](prepared,root,out,'a',lambda *a:None),expected)
# Exact stage ordering and stop-before-dependent launch on each failed gate.
for case,fail in [('sequence_clean',None),('sequence_A_failed','dc-a'),('sequence_A_PT_failed','pt-a'),('sequence_B_failed','dc-b')]:
 calls=[]
 def dc(r,v,event):
  calls.append('dc-'+v)
  if fail=='dc-'+v:raise RuntimeError('fixture_gate_failure:'+fail)
  return {'status':'CLEAN_MAP_IDENTITY_VERIFIED_NOT_TIMING_PASS'}
 def pt(p,r,o,v,event):
  calls.append('pt-'+v)
  if fail=='pt-'+v:raise RuntimeError('fixture_gate_failure:'+fail)
  return {'status':'PT_COLLECTION_VERIFIED_NOT_TIMING_PASS'}
 def lb(*a):calls.append('launch-b');return FakeProcess()
 with patch.dict(ns,{'wait_dc':dc,'run_pt':pt,'launch_b':lb,'wait_child':lambda *a:0}):check(case,lambda:ns['workflow'](scratch,prepared,fixture,lambda *a:None),'fixture_gate_failure:' if fail else None)
 expected={'sequence_clean':['dc-a','pt-a','launch-b','dc-b','pt-b'],'sequence_A_failed':['dc-a'],'sequence_A_PT_failed':['dc-a','pt-a'],'sequence_B_failed':['dc-a','pt-a','launch-b','dc-b']}[case];assert calls==expected,(case,calls);rows[-1]['stage_calls']=calls
result={'status':'PASS_OFFLINE_SERIAL_CHAIN_GATES','scope':'No remote/UI/network/credentials/EDA. Native receipts/reports in this test are explicit synthetic gate fixtures. All process launches mocked. Exact production watcher and embedded B launch source used; this is not measured synthesis/timing.','checks':rows,'watcher_sha256':sha(HERE/'watcher.py'),'installer_sha256':sha(HERE/'install-and-start-chain-r1.sh'),'review_tool_sha256':sha(Path(__file__))}
p=HERE/'offline-review-receipt.json';assert not p.exists();dump(p,result);print(json.dumps({'status':result['status'],'checks':len(rows),'receipt_sha256':sha(p)}))
