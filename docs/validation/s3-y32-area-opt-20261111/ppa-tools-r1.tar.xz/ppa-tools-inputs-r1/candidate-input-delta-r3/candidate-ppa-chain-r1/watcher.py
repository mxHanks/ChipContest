#!/usr/bin/env python3
"""Serial own A -> PT A -> exact reviewed B launch -> B -> PT B. No restart/ECO."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy,subprocess,sys,time
DEADLINE=1794412740
POLL=15
RUNNER_SHA='14be33ffcb8b21ccc3391d34fae7226e4d150115cd093f24fea500d221bc5917'
DC_SHA='23a4101c711fdb4747a57e6f9524d4989eb76a2b3120f0fa9766f4b25ae8e6d2'
PT_MANIFEST_SHA='118b47a446fb6c7c4095664c9cdebfdcf30d07735ff5a5efa5987b9c4a49c448'
PT_INPUTS={'baseline.tcl':'14d5518b98a9cd31a24576361be2c36f8f2947335b0fee96daf05e2b60367434','run_pt.py':'b29cc4b19bb9dde4b81577798d10c56329f77b2f2637b5c26c20c37eda8d678b','verify_mapping.py':'6da9b29efec8678e92a6af4975f52726f7e4daffd3b8780a451a97c2d4cf9660'}
MANIFESTS={'a':'228b0c936d6e23db99d25bbb0c32596a12e8f2f8a9a4606342ec175ca73001c1','b':'a6ac0c36ecf3616cee2aa80b547f187929b48ec01fa1b4df6a50145d81a9cf3c'}
FULL_MANIFESTS={'a':'90119719bd22d48871d559ff9efa199bea465c2ee1a479132dac4bb6a9966502','b':'f174f305c7569f47ec2a39628d88a76f34194684800a5ebc100ec3271ca1ba80'}
LIBS={'standard_cell':'f69c08a0b89c6d747ecb648e8c212a98d2bba6c8b9aeec766e90babc01a64723','sram':'c2cce1cf2bd8f25de5df3fe01e67b0ef40a933c2ec51da156dd47a288866bf0f'}
B_BODY="from pathlib import Path\nimport datetime, hashlib, json, os, runpy, subprocess, time\nV = 'b'\nEXPECTED_MANIFEST = 'a6ac0c36ecf3616cee2aa80b547f187929b48ec01fa1b4df6a50145d81a9cf3c'\nEXPECTED_RUNNER = '14be33ffcb8b21ccc3391d34fae7226e4d150115cd093f24fea500d221bc5917'\ndef need(v,m):\n if not v: raise RuntimeError(m)\ndef sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()\nmatches=[]\nfor entry in Path('/tmp').glob('codex-area-opt-20261111-*'):\n try:\n  if not entry.is_dir() or entry.is_symlink() or entry.stat().st_uid!=os.getuid() or entry.stat().st_mode&0o777!=0o700:continue\n  op=entry/'owner.json'\n  if not op.is_file() or op.is_symlink() or op.stat().st_uid!=os.getuid():continue\n  o=json.loads(op.read_text());created=o.get('created_epoch')\n  if o.get('schema')!='s3-areaopt-owned-scratch-v1' or o.get('uid')!=os.getuid() or o.get('mode')!='0700':continue\n  if o.get('purpose')!='own PT/candidate EDA outputs; preserve existing Desktop evidence':continue\n  if isinstance(created,bool) or not isinstance(created,(int,float)) or not 1794326400<=created<1794412800 or created>time.time()+30:continue\n  matches.append(entry)\n except (OSError,ValueError,TypeError):continue\nneed(len(matches)==1,'owned_scratch_not_unique')\nscratch=matches[0];top=scratch/('candidate-'+V+'-r3');root=top/'candidate'\nneed(top.is_dir() and not top.is_symlink() and root.is_dir() and not root.is_symlink(),'candidate_missing_or_symlink')\nreceipt_path=top/'transport-reconstruction.json'\nneed(receipt_path.is_file() and not receipt_path.is_symlink(),'transport_ready_receipt_missing')\nr=json.loads(receipt_path.read_text())\nneed(r.get('status')=='READY_INPUTS_VERIFIED_NO_COMPILE' and r.get('compile_started') is False,'transport_not_ready')\nneed(r.get('variant')==V and r.get('candidate')==str(root) and r.get('scratch')==str(scratch),'transport_wrong_candidate')\nneed(r.get('scratch_owner_sha256')==sha(scratch/'owner.json') and r.get('scratch_uid_and_mode_verified') is True,'transport_owner_drift')\nneed(r.get('candidate_manifest_sha256')==EXPECTED_MANIFEST and r.get('input_files')==242 and r.get('all242_input_hashes_verified') is True,'transport_identity_incomplete')\nneed(sha(root/'package-files.json')==EXPECTED_MANIFEST,'manifest_identity_changed')\nmanifest=json.loads((root/'package-files.json').read_text());need(len(manifest)==242,'manifest_input_count')\nfiles={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}\nneed(set(files)==set(manifest)|{'package-files.json'},'prelaunch_extra_or_missing_files')\nneed(not any(p.is_symlink() for p in root.rglob('*')),'prelaunch_symlink')\nneed(all(sha(files[n])==h for n,h in manifest.items()),'prelaunch_input_drift')\nneed(sha(root/'run_once.py')==EXPECTED_RUNNER,'runner_identity_changed')\nomissions=json.loads((root/'REMOTE-EVIDENCE-OMISSIONS.json').read_text())\nneed(omissions.get('original_full_manifest_sha256')=='f174f305c7569f47ec2a39628d88a76f34194684800a5ebc100ec3271ca1ba80','original_candidate_identity_drift')\nneed(omissions.get('remote_manifest_input_count_including_this_sidecar')==242 and omissions.get('retained_original_input_count')==241,'omission_count_drift')\nneed({v.get('path') for v in omissions.get('omitted_files',[])}=={'evidence/variant-proof/packaging/concat.xml','evidence/variant-proof/packaging/split.xml'},'unexpected_omission_policy')\n\nneed(time.time()<1794412740,'experiment_deadline_reached')\nfor name in ['launcher.log','launcher-receipt.json']:\n need(not (top/name).exists() and not (top/name).is_symlink(),'refuse_existing_launch_artifact:'+name)\nrunner=runpy.run_path(str(root/'run_once.py'),run_name='__candidate_launch_preflight__')\nbusy=runner['heavy_jobs']();need(not busy,'same_account_heavy_jobs:'+json.dumps(busy,sort_keys=True))\nreview=json.loads(subprocess.check_output(['python3','run_once.py'],cwd=str(root),universal_newlines=True,timeout=30))\nneed(review.get('status')=='INPUT_REVIEW_PASS_NOT_EXECUTED' and review.get('manifest_sha256')==EXPECTED_MANIFEST and review.get('inputs')==242 and review.get('max_cores')==2,'runner_review_failed')\n# Only this new owned candidate's immutable runner may start DC. It rechecks\n# heavy jobs, frozen inputs, tool/libraries and 23:59 cutoff before execution.\nwith (top/'launcher.log').open('x') as log:\n p=subprocess.Popen(['python3','run_once.py','--run'],cwd=str(root),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)\nlaunch={'status':'SUPERVISOR_STARTED_NOT_A_SYNTHESIS_RESULT','variant':V,'candidate':str(root),'supervisor_pid':p.pid,'started_epoch':time.time(),'manifest_sha256':EXPECTED_MANIFEST,'runner_sha256':EXPECTED_RUNNER,'max_cores':2,'prelaunch_observed_heavy_jobs':busy,'transport_receipt_sha256':sha(receipt_path),'timing_qualification':'NOT_QUALIFIED'}\nwith (top/'launcher-receipt.json').open('x') as out:json.dump(launch,out,sort_keys=True,indent=2);out.write('\\n')\nprint('CANDIDATE_SUPERVISOR_STARTED '+json.dumps(launch,sort_keys=True))"
B_BODY_SHA='a44da18a3fc2fe7beb9b3223ec0fc3d92403761c6b08de65c10245cf93d1cffd'
HEAVY={'simv','vcs','vcs1','dc_shell','snps_shell','common_shell_ex','pt_shell','icc2_shell','fm_shell','lc_shell'}
REQUIRED_MAP=['mapped.v','mapped.ddc','mapped.sdc','libraries.tcl','leaf-inventory.tsv','leaf-area-summary.txt','area-components.tsv','area.rpt','references.rpt','qor.rpt','dc-units.rpt','dc-setup.rpt','dc-hold.rpt','dc-violations.rpt','precheck.rpt','postcheck.rpt','clocks.rpt','dc.log','SYNTHESIS_COMPLETE_NOT_QUALIFIED.txt','dc-clock-reports/review_status.txt']
def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def read(p):
 raw=Path(p).read_bytes();return json.loads(raw.decode()),hashlib.sha256(raw).hexdigest()
def safe(n):
 p=Path(n);need(n and not p.is_absolute() and '..' not in p.parts and str(p)==n,'unsafe_record_path:'+str(n));return p
def deadline():need(time.time()<DEADLINE,'experiment_deadline_reached')
def discover():
 matches=[]
 for entry in Path('/tmp').glob('codex-area-opt-20261111-*'):
  try:
   if not entry.is_dir() or entry.is_symlink() or entry.stat().st_uid!=os.getuid() or entry.stat().st_mode&0o777!=0o700:continue
   op=entry/'owner.json'
   if not op.is_file() or op.is_symlink() or op.stat().st_uid!=os.getuid():continue
   o,_=read(op);created=o.get('created_epoch')
   if o.get('schema')!='s3-areaopt-owned-scratch-v1' or o.get('uid')!=os.getuid() or o.get('mode')!='0700':continue
   if o.get('purpose')!='own PT/candidate EDA outputs; preserve existing Desktop evidence':continue
   if isinstance(created,bool) or not isinstance(created,(int,float)) or not 1794326400<=created<1794412800 or created>time.time()+30:continue
   matches.append(entry)
  except (OSError,ValueError,TypeError):continue
 need(len(matches)==1,'owned_scratch_not_unique');return matches[0]
def jobs():
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   comm=(p/'comm').read_text().strip();exe=Path(os.readlink(str(p/'exe'))).name
   if comm in HEAVY or exe in HEAVY:result.append({'pid':int(p.name),'comm':comm,'exe':exe,'pgid':int((p/'stat').read_text().rsplit(')',1)[1].split()[2])})
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 return sorted(result,key=lambda x:x['pid'])
def no_heavy():
 busy=jobs();need(not busy,'same_account_heavy_jobs:'+json.dumps(busy,sort_keys=True))
def pin_inputs(root,v):
 need(root.is_dir() and not root.is_symlink(),'candidate_root_missing_or_symlink')
 m,mh=read(root/'package-files.json');need(mh==MANIFESTS[v] and len(m)==242,'candidate_manifest_identity:'+v)
 for n,h in m.items():
  p=root/safe(n);need(p.is_file() and not p.is_symlink() and sha(p)==h,'candidate_source_drift:'+v+':'+n)
 need(sha(root/'run_once.py')==RUNNER_SHA,'runner_identity')
 side,_=read(root/'REMOTE-EVIDENCE-OMISSIONS.json');need(side.get('original_full_manifest_sha256')==FULL_MANIFESTS[v],'full_candidate_identity')
 rebuilt=dict(m);rebuilt.pop('REMOTE-EVIDENCE-OMISSIONS.json')
 need({x.get('path') for x in side.get('omitted_files',[])}=={'evidence/variant-proof/packaging/concat.xml','evidence/variant-proof/packaging/split.xml'},'unexpected_omission')
 for x in side['omitted_files']:rebuilt[x['path']]=x['sha256']
 need(hashlib.sha256((json.dumps(rebuilt,sort_keys=True,indent=2)+'\n').encode()).hexdigest()==FULL_MANIFESTS[v],'original243_manifest_not_reconstructed')
 r,_=read(root.parent/'transport-reconstruction.json')
 need(r.get('status')=='READY_INPUTS_VERIFIED_NO_COMPILE' and r.get('variant')==v and r.get('candidate')==str(root) and r.get('candidate_manifest_sha256')==MANIFESTS[v] and r.get('input_files')==242 and r.get('all242_input_hashes_verified') is True and r.get('compile_started') is False,'transport_identity:'+v)
 need(r.get('scratch')==str(root.parents[1]) and r.get('scratch_uid_and_mode_verified') is True and r.get('scratch_owner_sha256')==sha(root.parents[1]/'owner.json'),'transport_owner_drift')
 return m
def output_identity(root,records,required):
 need(isinstance(records,dict) and set(required)<=set(records),'missing_required_output_records')
 for n,row in records.items():
  p=root/safe(n);need(p.is_file() and not p.is_symlink() and p.stat().st_size==row.get('bytes') and sha(p)==row.get('sha256'),'native_output_identity:'+n)
 for n in required:need((root/n).stat().st_size>0,'empty_required_output:'+n)
def verify_dc(root,v,r,rh):
 need(r.get('status')=='SYNTHESIS_COMPLETE_NOT_QUALIFIED' and r.get('returncode')==0 and r.get('completion_marker') is True,'DC_not_clean_completed:'+v)
 need(r.get('source_drift')==[] and r.get('native_tool_errors')==[] and r.get('deadline_terminated') is False and r.get('mapping_outputs_complete') is True,'DC_failure_or_drift:'+v)
 need(r.get('manifest_sha256')==MANIFESTS[v] and r.get('inputs')==242 and r.get('max_cores')==2 and r.get('tool',{}).get('sha256')==DC_SHA,'DC_receipt_identity:'+v)
 need({x['role']:x['sha256'] for x in r.get('libraries',[])}==LIBS and len(r.get('libraries',[]))==2,'DC_libraries_drift')
 need(r.get('report_collection_status')=='COLLECTED_REVIEW_REQUIRED','DC_reports_incomplete')
 pin_inputs(root,v);output_identity(root,r.get('outputs'),REQUIRED_MAP)
 log=(root/'dc.log').read_text(errors='replace');need(not re.search(r'^(?:Error:|Fatal:)',log,re.M),'DC_native_log_errors')
 for label,count in [('tile_pes',64),('tile_engines',8),('weights',16),('bias',1),('all_ramsp',337)]:need(log.count('P4K_COUNT %s actual=%d expected=%d'%(label,count,count))==2,'DC_pre_post_geometry:'+label)
 review=(root/'dc-clock-reports/review_status.txt').read_text();need(re.search(r'^REQUIRED_REPORT_FAILURE_COUNT=0$',review,re.M),'DC_required_report_failures')
 need(sha(root/'execution.json')==rh,'DC_receipt_changed_during_verify')
 return {'execution_sha256':rh,'manifest_sha256':MANIFESTS[v],'mapped_v_sha256':sha(root/'mapped.v'),'output_records_verified':len(r['outputs']),'status':'CLEAN_MAP_IDENTITY_VERIFIED_NOT_TIMING_PASS'}
def wait_dc(root,v,event):
 pin_inputs(root,v);identity=None;missing=0
 while True:
  deadline()
  try:r,rh=read(root/'execution.json')
  except (OSError,ValueError):
   missing+=1;need(missing<=4,'DC_receipt_missing_or_unreadable:'+v);time.sleep(POLL);continue
  missing=0
  need(r.get('manifest_sha256')==MANIFESTS[v] and r.get('inputs')==242 and r.get('max_cores')==2,'DC_running_identity:'+v)
  fixed={k:r.get(k) for k in ['started_epoch','pid','manifest_sha256','tool','libraries','max_cores']}
  if identity is None:identity=fixed;event('OBSERVED_DC_'+v,{'execution_sha256':rh,'fixed_identity':fixed})
  need(identity==fixed,'DC_receipt_run_identity_changed:'+v)
  if r.get('status')!='RUNNING':return verify_dc(root,v,r,rh)
  busy=jobs();foreign=[x for x in busy if x['pgid']!=r.get('pid') or x['comm'] not in {'dc_shell','snps_shell','common_shell_ex'}]
  need(not foreign,'new_foreign_heavy_job:'+json.dumps(foreign,sort_keys=True))
  time.sleep(min(POLL,max(0.1,DEADLINE-time.time())))
def pin_pt(prepared):
 need(sha(prepared/'package-files.json')==PT_MANIFEST_SHA,'PT_package_manifest_identity')
 m,_=read(prepared/'package-files.json');need(m==PT_INPUTS,'PT_package_input_set')
 for n,h in PT_INPUTS.items():need((prepared/n).is_file() and not (prepared/n).is_symlink() and sha(prepared/n)==h,'PT_package_script_identity:'+n)
def wait_child(p,label,event):
 while p.poll() is None:
  if time.time()>=DEADLINE:
   event('DEADLINE_CHILD_RUNNER_HANDLES_OWN_TOOL',{'label':label,'supervisor_pid':p.pid})
   try:return p.wait(timeout=20)
   except subprocess.TimeoutExpired:raise RuntimeError('own_supervisor_not_terminal_after_deadline:'+label)
  time.sleep(min(POLL,max(0.1,DEADLINE-time.time())))
 return p.returncode
def run_pt(prepared,root,out,v,event):
 deadline();pin_pt(prepared);no_heavy();need(not out.exists() and not out.is_symlink(),'refuse_existing_PT_output:'+str(out))
 source_hash=sha(root/'execution.json');cmd=['python3',str(prepared/'run_pt.py'),'--run','--source',str(root),'--out',str(out)]
 log=out.parent/('pt-'+v+'-supervisor.log');need(not log.exists(),'refuse_existing_PT_supervisor_log')
 with log.open('x') as f:p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 event('PT_'+v+'_STARTED',{'supervisor_pid':p.pid,'command':cmd,'source_dc_execution_sha256':source_hash})
 code=wait_child(p,'PT_'+v,event);need(code==0,'PT_supervisor_failed:'+v+':'+str(code))
 r,rh=read(out/'execution.json')
 need(r.get('status')=='PT_REPORT_COLLECTION_COMPLETE_NOT_QUALIFIED' and r.get('returncode')==0 and r.get('completion_marker') is True and r.get('source_drift')==[] and r.get('native_tool_errors')==[] and not r.get('tool_timeout_300s') and not r.get('deadline_terminated'),'PT_collection_failed:'+v)
 need(r.get('prepared_manifest_sha256')==PT_MANIFEST_SHA and r.get('max_cores')==2 and r.get('source_dc_execution_sha256')==source_hash==sha(root/'execution.json') and r.get('source_dc_manifest_sha256')==MANIFESTS[v],'PT_source_identity:'+v)
 need(r.get('timing_verdict')=='UNREVIEWED_NOT_A_TIMING_PASS','PT_must_not_invent_timing_PASS')
 output_identity(out,r.get('outputs'),['baseline-status.txt','pt.log','BASELINE_PT_REPLAY_COMPLETE_NOT_QUALIFIED.txt','reports/coverage.rpt','reports/all_violators.rpt','reports/setup.rpt','reports/hold.rpt','reports/clock_endpoints.tsv'])
 need(sha(out/'execution.json')==rh,'PT_receipt_changed_during_verify');pin_pt(prepared);no_heavy()
 return {'status':'PT_COLLECTION_VERIFIED_NOT_TIMING_PASS','execution_sha256':rh,'source_dc_execution_sha256':source_hash,'output_records_verified':len(r['outputs'])}
def launch_b(root,event):
 deadline();no_heavy();pin_inputs(root,'b');need(hashlib.sha256(B_BODY.encode()).hexdigest()==B_BODY_SHA,'exact_reviewed_B_launch_body_drift')
 env={'__name__':'__exact_reviewed_B_r3_launch__'};exec(compile(B_BODY,'exact-reviewed-launch-candidate-b-r3','exec'),env)
 child=env['p'];event('B_REVIEWED_LAUNCH_SUPERVISOR',{'pid':child.pid,'body_sha256':B_BODY_SHA});return child
def workflow(scratch,prepared,top,event):
 a=scratch/'candidate-a-r3/candidate';b=scratch/'candidate-b-r3/candidate'
 event('WAIT_A',{});dc_a=wait_dc(a,'a',event);event('A_MAP_VERIFIED',dc_a)
 pt_a=run_pt(prepared,a,top/'pt-a-r4','a',event);event('A_PT_COLLECTION_VERIFIED',pt_a)
 child=launch_b(b,event);code=wait_child(child,'DC_b',event);need(code==0,'B_supervisor_failed:'+str(code))
 dc_b=wait_dc(b,'b',event);event('B_MAP_VERIFIED',dc_b)
 pt_b=run_pt(prepared,b,top/'pt-b-r4','b',event);event('B_PT_COLLECTION_VERIFIED',pt_b)
 return {'a':{'dc':dc_a,'pt':pt_a},'b':{'dc':dc_b,'pt':pt_b}}
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
 if not args.run:print('PREPARED_SERIAL_COLLECTION_ONLY_NOT_EXECUTED');return 0
 deadline();scratch=discover();top=Path(__file__).resolve().parent;need(top==scratch/'candidate-ppa-chain-r1','watcher_wrong_owned_path')
 prepared=Path.home()/'Desktop/xu-area-opt-20261111-pt-recovery-r4/pt-recovery-r4';pin_pt(prepared)
 rp=top/'execution.json';need(not rp.exists(),'refuse_existing_chain_execution');owner_sha=sha(scratch/'owner.json')
 record={'schema':'s3-areaopt-serial-ppa-chain-v1','status':'RUNNING','started_epoch':time.time(),'supervisor_pid':os.getpid(),'max_cores_per_tool':2,'deadline_utc':'2026-11-11T15:59:00Z','poll_seconds':POLL,'watcher_sha256':sha(Path(__file__)),'scratch_owner_sha256':owner_sha,'events':[],'qualification':'NOT_QUALIFIED','timing_verdict':'UNREVIEWED_NOT_A_TIMING_PASS'}
 def event(label,data):
  need(sha(scratch/'owner.json')==owner_sha,'scratch_owner_changed');record['events'].append({'epoch':time.time(),'label':label,'data':data});tmp=top/'execution.json.next';tmp.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');os.replace(str(tmp),str(rp));print(label+' '+json.dumps(data,sort_keys=True),flush=True)
 try:
  event('CHAIN_STARTED',{'no_restart':True,'no_other_process_signals':True,'PT_collection_with_violations_is_not_timing_PASS':True})
  record['results']=workflow(scratch,prepared,top,event);record['status']='SERIAL_MAPPING_AND_PT_COLLECTIONS_COMPLETE_NOT_QUALIFIED';record['finished_epoch']=time.time();event('CHAIN_COLLECTION_COMPLETE_NOT_TIMING_PASS',{});return 0
 except Exception as exc:
  record['status']='STOPPED_REQUIRES_ROOT_REVIEW';record['reason']=str(exc);record['finished_epoch']=time.time();event('CHAIN_STOPPED_NO_AUTOMATIC_RESTART',{'reason':str(exc)});return 1
if __name__=='__main__':sys.exit(main())
