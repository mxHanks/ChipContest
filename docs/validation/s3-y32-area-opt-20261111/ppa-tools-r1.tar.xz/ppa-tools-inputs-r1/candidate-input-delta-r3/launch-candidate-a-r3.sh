python3 - <<'PY_XU_AREA_CANDIDATE_LAUNCH'
from pathlib import Path
import datetime, hashlib, json, os, runpy, subprocess, time
V = 'a'
EXPECTED_MANIFEST = '228b0c936d6e23db99d25bbb0c32596a12e8f2f8a9a4606342ec175ca73001c1'
EXPECTED_RUNNER = '14be33ffcb8b21ccc3391d34fae7226e4d150115cd093f24fea500d221bc5917'
def need(v,m):
 if not v: raise RuntimeError(m)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
matches=[]
for entry in Path('/tmp').glob('codex-area-opt-20261111-*'):
 try:
  if not entry.is_dir() or entry.is_symlink() or entry.stat().st_uid!=os.getuid() or entry.stat().st_mode&0o777!=0o700:continue
  op=entry/'owner.json'
  if not op.is_file() or op.is_symlink() or op.stat().st_uid!=os.getuid():continue
  o=json.loads(op.read_text());created=o.get('created_epoch')
  if o.get('schema')!='s3-areaopt-owned-scratch-v1' or o.get('uid')!=os.getuid() or o.get('mode')!='0700':continue
  if o.get('purpose')!='own PT/candidate EDA outputs; preserve existing Desktop evidence':continue
  if isinstance(created,bool) or not isinstance(created,(int,float)) or not 1794326400<=created<1794412800 or created>time.time()+30:continue
  matches.append(entry)
 except (OSError,ValueError,TypeError):continue
need(len(matches)==1,'owned_scratch_not_unique')
scratch=matches[0];top=scratch/('candidate-'+V+'-r3');root=top/'candidate'
need(top.is_dir() and not top.is_symlink() and root.is_dir() and not root.is_symlink(),'candidate_missing_or_symlink')
receipt_path=top/'transport-reconstruction.json'
need(receipt_path.is_file() and not receipt_path.is_symlink(),'transport_ready_receipt_missing')
r=json.loads(receipt_path.read_text())
need(r.get('status')=='READY_INPUTS_VERIFIED_NO_COMPILE' and r.get('compile_started') is False,'transport_not_ready')
need(r.get('variant')==V and r.get('candidate')==str(root) and r.get('scratch')==str(scratch),'transport_wrong_candidate')
need(r.get('scratch_owner_sha256')==sha(scratch/'owner.json') and r.get('scratch_uid_and_mode_verified') is True,'transport_owner_drift')
need(r.get('candidate_manifest_sha256')==EXPECTED_MANIFEST and r.get('input_files')==242 and r.get('all242_input_hashes_verified') is True,'transport_identity_incomplete')
need(sha(root/'package-files.json')==EXPECTED_MANIFEST,'manifest_identity_changed')
manifest=json.loads((root/'package-files.json').read_text());need(len(manifest)==242,'manifest_input_count')
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}
need(set(files)==set(manifest)|{'package-files.json'},'prelaunch_extra_or_missing_files')
need(not any(p.is_symlink() for p in root.rglob('*')),'prelaunch_symlink')
need(all(sha(files[n])==h for n,h in manifest.items()),'prelaunch_input_drift')
need(sha(root/'run_once.py')==EXPECTED_RUNNER,'runner_identity_changed')
omissions=json.loads((root/'REMOTE-EVIDENCE-OMISSIONS.json').read_text())
need(omissions.get('original_full_manifest_sha256')=='90119719bd22d48871d559ff9efa199bea465c2ee1a479132dac4bb6a9966502','original_candidate_identity_drift')
need(omissions.get('remote_manifest_input_count_including_this_sidecar')==242 and omissions.get('retained_original_input_count')==241,'omission_count_drift')
need({v.get('path') for v in omissions.get('omitted_files',[])}=={'evidence/variant-proof/packaging/concat.xml','evidence/variant-proof/packaging/split.xml'},'unexpected_omission_policy')

need(time.time()<1794412740,'experiment_deadline_reached')
for name in ['launcher.log','launcher-receipt.json']:
 need(not (top/name).exists() and not (top/name).is_symlink(),'refuse_existing_launch_artifact:'+name)
runner=runpy.run_path(str(root/'run_once.py'),run_name='__candidate_launch_preflight__')
busy=runner['heavy_jobs']();need(not busy,'same_account_heavy_jobs:'+json.dumps(busy,sort_keys=True))
review=json.loads(subprocess.check_output(['python3','run_once.py'],cwd=str(root),universal_newlines=True,timeout=30))
need(review.get('status')=='INPUT_REVIEW_PASS_NOT_EXECUTED' and review.get('manifest_sha256')==EXPECTED_MANIFEST and review.get('inputs')==242 and review.get('max_cores')==2,'runner_review_failed')
# Only this new owned candidate's immutable runner may start DC. It rechecks
# heavy jobs, frozen inputs, tool/libraries and 23:59 cutoff before execution.
with (top/'launcher.log').open('x') as log:
 p=subprocess.Popen(['python3','run_once.py','--run'],cwd=str(root),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
launch={'status':'SUPERVISOR_STARTED_NOT_A_SYNTHESIS_RESULT','variant':V,'candidate':str(root),'supervisor_pid':p.pid,'started_epoch':time.time(),'manifest_sha256':EXPECTED_MANIFEST,'runner_sha256':EXPECTED_RUNNER,'max_cores':2,'prelaunch_observed_heavy_jobs':busy,'transport_receipt_sha256':sha(receipt_path),'timing_qualification':'NOT_QUALIFIED'}
with (top/'launcher-receipt.json').open('x') as out:json.dump(launch,out,sort_keys=True,indent=2);out.write('\n')
print('CANDIDATE_SUPERVISOR_STARTED '+json.dumps(launch,sort_keys=True))
PY_XU_AREA_CANDIDATE_LAUNCH
