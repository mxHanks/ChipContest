#!/usr/bin/env python3
"""Read/hash/parse native R5 read-only PT recovery. Never executes EDA."""
import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

DC_EXEC='29af3d0aa9c13b2c8978ea362a64a571d488e545b579590e9f403aeb1c82621b'
MANIFEST='437ede00614caa3bfc4c16a0c7972f5e16865d0dec420dda00be8f1138563c6f'
SDC='c15ede0fc2c65771f87e2d6aee763b4ea0d53934868ca807b4785c36182fce7c'
COMPAT='404c7de9a4ef56d624e64407a501df63d8040159171ea2a88bfcc70294a3de98'
PT='afdcfa7071f86d229ed3b4481f67adefd1c51bb0288b7e7d370213a43b70c9ef'
DBS={'standard_cell':'f69c08a0b89c6d747ecb648e8c212a98d2bba6c8b9aeec766e90babc01a64723',
     'sram':'c2cce1cf2bd8f25de5df3fe01e67b0ef40a933c2ec51da156dd47a288866bf0f'}
NUM=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'
REQUIRED_REPORTS=['coverage.rpt','check_timing.rpt','clocks.rpt','setup.rpt','hold.rpt','all_violators.rpt',
    'recovery.rpt','removal.rpt','clock_gating_setup.rpt','clock_gating_hold.rpt','min_pulse_width.rpt',
    'exceptions.rpt','case_analysis.rpt','disable_timing.rpt','async_pin_max.rpt','async_pin_min.rpt',
    'clock_endpoints.tsv','native-pin-attributes.rpt','units.rpt']

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    return p.read_text(errors='replace')
def require(v,m):
    if not v:
        raise ValueError(m)
def safe(n):
    p=Path(n); require(not p.is_absolute() and '..' not in p.parts, 'unsafe output path '+n)
    return p
def path_summary(p):
    t=read(p)
    slacks=[Decimal(x) for x in re.findall(r'\bslack\s*\([^\n)]*\)\s*('+NUM+r')',t,re.I)]
    starts=re.findall(r'^\s*Startpoint:\s*(.*)$',t,re.M)
    ends=re.findall(r'^\s*Endpoint:\s*(.*)$',t,re.M)
    return {'reported_paths':len(starts),'first_startpoint':starts[0] if starts else None,
        'first_endpoint':ends[0] if ends else None,'worst_reported_slack_ns':str(min(slacks)) if slacks else None,
        'negative_reported_paths':sum(v<0 for v in slacks),
        'scope':'finite printed paths; not a complete path census or timing pass'}
def coverage_summary(t):
    rows=[]
    pat=r'^\s*(All Checks|[A-Za-z_]+)\s+(\d+)\s+(\d+)\s*\(\s*\d+%\)\s+(\d+)\s*\(\s*\d+%\)\s+(\d+)\s*\(\s*\d+%\)\s*$'
    for m in re.finditer(pat,t,re.M):
        name,total,met,violated,untested=m.groups()
        row=dict(check=name,total=int(total),met=int(met),violated=int(violated),untested=int(untested))
        require(row['total']==row['met']+row['violated']+row['untested'],'coverage subtotal '+name)
        rows.append(row)
    allrows=[r for r in rows if r['check']=='All Checks']
    require(len(allrows)==1,'native complete coverage total missing/duplicate')
    types=[r for r in rows if r['check']!='All Checks']
    require(len({r['check'] for r in types})==len(types),'duplicate coverage check row')
    for key in ['total','met','violated','untested']:
        require(sum(r[key] for r in types)==allrows[0][key],'coverage category sum '+key)
    reasons=Counter(re.findall(r'\buntested\s+([A-Za-z_]+)\s*$',t,re.M))
    return dict(rows=rows,all_checks=allrows[0],printed_untested_reason_counts=dict(reasons))

def audit(root,dc,dc_inputs,prepared,allow_subset):
    require(sha(dc/'execution.json')==DC_EXEC,'exact preserved native DC execution identity')
    old=json.loads(read(dc/'execution.json'))
    require(old['status']=='FAILED' and old['returncode']==1 and not old['completion_marker'],'original failed collector state differs')
    require(sha(dc/'package-files.json')==MANIFEST==old['manifest_sha256'],'original DC input manifest identity')
    require(sha(dc_inputs/'package-files.json')==MANIFEST,'local frozen DC input manifest differs')
    original_sdc=dc_inputs/'source/contracts/reference-full-soc.sdc'
    require(sha(original_sdc)==SDC,'local frozen original SDC differs')
    e=json.loads(read(root/'execution.json'))
    require(e['status']=='PT_REPORT_COLLECTION_COMPLETE_NOT_QUALIFIED' and e['returncode']==0 and e['completion_marker'] is True,'PT native report collection incomplete')
    require(e['source_drift']==[] and e['native_tool_errors']==[] and e['deadline_terminated'] is False and not e.get('tool_timeout_300s',True),'PT native errors/drift/timeout')
    require(e['source_dc_execution_sha256']==DC_EXEC and e['source_dc_manifest_sha256']==MANIFEST and e['source_dc_status']=='FAILED','PT original DC receipt identity/status differs')
    require(e['mapped_v_sha256']==old['outputs']['mapped.v']['sha256'],'PT actual mapped identity differs from frozen DC output inventory')
    require(e['original_sdc_sha256']==SDC,'PT original SDC differs')
    require({x['role']:x['sha256'] for x in e['libraries']}==DBS and len(e['libraries'])==2,'PT DB identity differs')
    require(e['tool']['sha256']==PT and e['max_cores']==2 and e['tool_timeout_seconds']==300,'PT tool/resource policy differs')
    require(e['observed_jobs']==[] and e['resource_policy']=='REFUSE_ALL_SAME_ACCOUNT_HEAVY_JOBS','PT resource conflict evidence differs')
    require(e['prepared_manifest_sha256']==sha(prepared/'package-files.json'),'PT prepared package identity differs')
    require(e['script_sha256']==sha(prepared/'baseline.tcl')==sha(root/'baseline.tcl'),'actual PT collector script differs')
    recovery=json.loads(read(root/'mapping-recovery-receipt.json'))
    require(recovery==e['mapping_recovery'],'PT saved vs execution recovery receipt differs')
    require(recovery['original_execution_sha256']==DC_EXEC and recovery['original_execution_status']=='FAILED' and recovery['original_returncode']==1 and recovery['completion_marker_preserved_false'] is True,'PT recovery relabels original failure')
    require(recovery['owner_termination_sha256']==sha(dc/'owner-collector-stop.json')==e['source_owner_termination_sha256'],'PT owner termination identity differs')
    require(recovery['source_manifest_sha256']==MANIFEST and recovery['sdc_sha256']==SDC,'PT recovery source identity differs')
    for name,record in recovery['mapping_outputs_verified'].items():
        require(old['outputs'].get(name)==record==e['source_dc_outputs'].get(name),'PT mapping output inventory mismatch '+name)
    require(set(recovery['mapping_outputs_verified'])==set(e['source_dc_outputs']),'PT source mapping inventory differs')
    returned={}; missing={}
    for name,record in e['outputs'].items():
        q=root/safe(name)
        if q.is_file():
            require(sha(q)==record['sha256'] and q.stat().st_size==record['bytes'],'returned native PT output identity differs '+name)
            returned[name]=record
        else:
            missing[name]=record
    require(allow_subset or not missing,'native PT output files not all returned: '+str(len(missing)))
    for n in ['baseline.tcl','mapping-recovery-receipt.json','baseline-status.txt','constraints-pt-add.sdc','pt.log','BASELINE_PT_REPLAY_COMPLETE_NOT_QUALIFIED.txt']:
        require(n in returned,'required native PT output not returned '+n)
    for n in REQUIRED_REPORTS:
        require('reports/'+n in returned and (root/'reports'/n).stat().st_size>0,'required native PT report not returned '+n)
    require(sha(root/'constraints-pt-add.sdc')==COMPAT,'PT compatibility SDC differs')
    require((root/'constraints-pt-add.sdc').read_bytes()==original_sdc.read_bytes().replace(b'create_generated_clock -name ',b'create_generated_clock -add -name '),'PT compatibility is not exact three-call portability transform')
    status=dict(line.split('=',1) for line in read(root/'baseline-status.txt').splitlines() if '=' in line)
    require(status['REQUIRED_REPORT_FAILURES']=='','required native report command failures')
    require(status['SRAM_NO_CLOCK_COUNT']=='0' and status['SRAM_COUNT']=='337','native SRAM CLK association incomplete')
    require(status['CLOCK_MODE']=='envelope' and status['PLL_DIV']=='0' and status['PROPAGATED_CLOCKS']=='0','native clock mode differs')
    require(status['MAPPED_V_SHA256']==e['mapped_v_sha256'] and status['ORIGINAL_CONSTRAINTS_SHA256']==SDC and status['PT_ADD_CONSTRAINTS_SHA256']==COMPAT,'native PT status identity differs')
    counts=Counter(); unclocked=[]; names=set(); clocks=Counter(); ram_clk_parents=set()
    with (root/'reports/clock_endpoints.tsv').open() as f:
        reader=csv.DictReader(f,delimiter='\t')
        require(reader.fieldnames==['kind','pin','clock_count','clocks'],'native endpoint table columns differ')
        for row in reader:
            key=(row['kind'],row['pin']);require(key not in names,'duplicate native endpoint '+row['pin']);names.add(key)
            require(row['kind'] in ['register','SRAM'],'unknown endpoint kind')
            count=int(row['clock_count']);require(count>=0,'negative endpoint clock count')
            require(count==len(row['clocks'].split()),'endpoint clocks/count disagree '+row['pin'])
            counts[row['kind']]+=1
            if count==0:unclocked.append(row)
            if row['kind']=='SRAM':
                require(row['pin'].endswith('/CLK'),'explicit macro clock inventory contains non-CLK pin')
                ram_clk_parents.add(row['pin'].rsplit('/',1)[0])
            for clock in row['clocks'].split():clocks[clock]+=1
    require(counts['register']==int(status['REGISTER_CLOCK_PIN_COUNT']) and counts['SRAM']==337,'endpoint table vs status count differs')
    # Native R4 all_registers -clock_pins also enumerates every macro CEN and
    # RET1N pin. Preserve its 674 raw no-clock count; do not pretend it was 0.
    # Reconcile only exact same-parent pairs with the independently explicit
    # 337 SRAM CLK inventory. Any missing macro CLK or other unassociated pin
    # is still an audit failure. This classification changes no STA constraint
    # and does not dispose of any native timing check or coverage violation.
    raw_register_no_clock=sum(row['kind']=='register' for row in unclocked)
    require(raw_register_no_clock==int(status['REGISTER_NO_CLOCK_COUNT']),'native raw no-clock table/count differs')
    aux={}
    for row in unclocked:
        parent,pin=row['pin'].rsplit('/',1)
        require(row['kind']=='register' and parent in ram_clk_parents and pin in {'CEN','RET1N'},'unassociated endpoint outside exact macro auxiliary inventory '+row['pin'])
        aux.setdefault(parent,set()).add(pin)
    require(len(ram_clk_parents)==337 and len(aux)==337 and all(pins=={'CEN','RET1N'} for pins in aux.values()),'native macro auxiliary no-clock inventory is not exactly one CEN/RET1N pair per clocked macro')
    require(set(clocks)=={'xu_hfextclk','xu_lfextclk','xu_jtag_tck','xu_plldiv_envelope'},'native endpoint clock identities differ')
    for n in ['dma-register-setup.rpt','dma-register-hold.rpt']:
        q='reports/'+n+'.unavailable.txt'
        require(q in returned and 'OMITTED_BROAD_SCOPE_QUERY' in read(root/q),'explicit bounded collector gap absent '+n)
    errors=re.findall(r'^(?:Error:|Fatal:).*$',read(root/'pt.log'),re.M)
    require(not errors,'native PT log has errors')
    coverage=coverage_summary(read(root/'reports/coverage.rpt'))
    paths={n:path_summary(root/'reports'/n) for n in ['setup.rpt','hold.rpt','async_pin_max.rpt','async_pin_min.rpt']}
    allv=read(root/'reports/all_violators.rpt')
    native_violated_lines=[line for line in allv.splitlines() if '(VIOLATED)' in line]
    warnings=[line for line in read(root/'pt.log').splitlines() if line.startswith('Warning:')]
    verdict='NOT_CLOSED_NATIVE_VIOLATIONS' if coverage['all_checks']['violated'] or native_violated_lines or any(v['negative_reported_paths'] for v in paths.values()) else 'NOT_CERTIFIED_COVERAGE_AND_ASSUMPTIONS_REQUIRE_REVIEW'
    return dict(status='NATIVE_PT_ALL_RETURNED_OUTPUT_IDENTITIES_VERIFIED' if not missing else 'NATIVE_PT_RETURNED_SUBSET_ONLY_VERIFIED',
        execution_sha256=sha(root/'execution.json'),source_dc_execution_sha256=DC_EXEC,
        original_dc_status_preserved='FAILED return1 completion_marker=false',mapped_v_sha256=e['mapped_v_sha256'],
        mapped_netlist_locally_returned=(dc/'mapped.v').is_file(),
        actual_mapped_identity_scope='PT runner and recovery receipt pin mapped SHA matching native DC inventory. No claim of local netlist-byte verification when not returned.',
        returned_outputs=returned,unreturned_outputs=missing,coverage=coverage,path_summaries=paths,
        clock_association=dict(pin_counts=dict(counts),clock_memberships=dict(clocks),native_raw_register_no_clock_count=raw_register_no_clock,
            native_sram_clk_no_clock_count=0,unassociated_outside_exact_sram_cen_ret1n_pairs=0,
            macro_auxiliary_pair_count=len(aux),macro_auxiliary_pins=sorted(row['pin'] for row in unclocked),
            classification='674 raw all_registers pins are exactly CEN+RET1N on the same 337 macros with associated explicit CLK. This is inventory classification, not a timing waiver.',
            multi_clock_count=int(status['REGISTER_MULTI_CLOCK_COUNT'])),
        native_all_violators_printed_violated_line_count=len(native_violated_lines),native_all_violators_printed_violated_lines=native_violated_lines,
        native_warning_count=len(warnings),native_warning_lines=warnings,timing_verdict=verdict,
        timing_collector_limitations=['No accelerator Cartesian-scope timing query; native unavailable files retained.','No extracted parasitic file or CTS.','Finite worst paths cannot certify closure; full native coverage/violators still require CDC/reset/electrical disposition.'],
        period_and_exception_policy='Exact original SDC with only three PT-required -add substitutions; no timing fixes or constraints relaxed by this audit.')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--native',type=Path,required=True)
    p.add_argument('--dc-mini',type=Path,required=True);p.add_argument('--prepared',type=Path,required=True)
    p.add_argument('--dc-inputs',type=Path,default=Path(__file__).resolve().parents[1]/'baseline-synth-r5/candidate')
    p.add_argument('--allow-subset',action='store_true');p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();require(not a.out.exists(),'refuse receipt overwrite')
    report=dict(schema='s3-area-opt-independent-native-pt-recovery-audit-v1',created_at_utc=datetime.now(timezone.utc).isoformat(),new_measurement=False)
    try:
        report.update(audit(a.native.resolve(),a.dc_mini.resolve(),a.dc_inputs.resolve(),a.prepared.resolve(),a.allow_subset))
        code=0
    except (ValueError,KeyError,OSError,TypeError) as exc:
        report.update(status='FAIL_OR_INCOMPLETE_NATIVE_ARTIFACTS',reason=str(exc),timing_verdict='NOT_CERTIFIED');code=1
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:report.get(k) for k in ['status','timing_verdict','reason']},sort_keys=True));return code
if __name__=='__main__':
    raise SystemExit(main())
