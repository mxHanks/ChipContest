#!/usr/bin/env python3
"""Independently recompute native leaf area; no synthesis, STA or simulation."""
import argparse
import csv
import hashlib
import io
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

BASE_MANIFEST='437ede00614caa3bfc4c16a0c7972f5e16865d0dec420dda00be8f1138563c6f'
BASE_EXEC='29af3d0aa9c13b2c8978ea362a64a571d488e545b579590e9f403aeb1c82621b'
DC_TOOL='23a4101c711fdb4747a57e6f9524d4989eb76a2b3120f0fa9766f4b25ae8e6d2'
SDC='c15ede0fc2c65771f87e2d6aee763b4ea0d53934868ca807b4785c36182fce7c'
DBS={'standard_cell':'f69c08a0b89c6d747ecb648e8c212a98d2bba6c8b9aeec766e90babc01a64723',
     'sram':'c2cce1cf2bd8f25de5df3fe01e67b0ef40a933c2ec51da156dd47a288866bf0f'}
MAIN='u_soc/u_e203_subsys_top/u_e203_subsys_main/'
DMA=MAIN+'u_e203_subsys_perips/u_xu_matrix_dma/'
ARB=MAIN+'u_xu_dma_shared_arb/'
OMIT={'evidence/variant-proof/packaging/concat.xml','evidence/variant-proof/packaging/split.xml'}
SIDECAR='REMOTE-EVIDENCE-OMISSIONS.json'
NUM=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'
GEOMETRY={'cpu':1,'dma64':1,'arbiter64':1,'original_peripheral_fabric':1,'old_accelerator':0,
    'tile_core':1,'tile_engines':8,'tile_pes':64,'endpoint':1,'itcm':32,'dtcm':32,'shared':256,'weights':16,'bias':1,'all_ramsp':337}
REQUIRED=['libraries.tcl','leaf-inventory.tsv','leaf-area-summary.txt','area-components.tsv','area.rpt',
    'references.rpt','qor.rpt','dc-units.rpt','dc-setup.rpt','dc-hold.rpt',
    'precheck.rpt','postcheck.rpt','clocks.rpt','dc.log','mapped.sdc']

def require(value,message):
    if not value:
        raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()
def load(path):
    return json.loads(path.read_text())
def safe(name):
    q=Path(name);require(not q.is_absolute() and '..' not in q.parts,'unsafe native path '+name)
    return q
def verify_inputs(root,manifest):
    for name,h in manifest.items():
        p=root/safe(name)
        require(p.is_file() and sha(p)==h,'local frozen input identity '+name)
def record_file(root,name,record):
    p=root/safe(name)
    require(p.is_file() and p.stat().st_size==record.get('bytes') and sha(p)==record.get('sha256'),'native output identity '+name)
    return record
def scope(instance,classification):
    if instance.startswith(DMA):
        return 'dma'
    if instance.startswith(ARB):
        return 'arbiter'
    if instance.startswith('u_shared/') and classification!='SRAM':
        return 'endpoint_logic'
    return 'none'
def component(instance,charged):
    if charged!='dma':
        return charged
    rel=instance[len(DMA):]
    if rel.startswith('u_core/weights/'):
        return 'weights'
    if rel.startswith('u_core/bias/'):
        return 'bias'
    if re.match(r'u_core/xs_[^/]+/',rel):
        return 'x_double_buffers'
    if re.match(r'u_core/engines_[^/]+/',rel):
        return 'engines_64pe'
    if rel.startswith('u_core/'):
        return 'core_fifo_and_control'
    return 'dma_frontend_and_scheduler'
def macro_group(instance):
    if instance.startswith(DMA+'u_core/weights/'):
        return 'weights'
    if instance.startswith(DMA+'u_core/bias/memory/'):
        return 'bias'
    if instance.startswith('u_shared/banks'):
        return 'shared'
    if instance.startswith(MAIN+'u_e203_cpu_top/u_e203_srams/u_e203_itcm_ram/'):
        return 'itcm'
    if instance.startswith(MAIN+'u_e203_cpu_top/u_e203_srams/u_e203_dtcm_ram/'):
        return 'dtcm'
    return 'UNCLASSIFIED'
def parse_leaves(text):
    reader=csv.DictReader(io.StringIO(text),delimiter='\t')
    require(reader.fieldnames==['instance','reference','area_library_units','classification','charged_scope'],'native leaf header')
    seen=set();counts=Counter();sums=defaultdict(Decimal);scount=Counter();sarea=defaultdict(Decimal)
    ccount=Counter();carea=defaultdict(Decimal);macros=Counter();macroareas=set();refs=set()
    for row in reader:
        name=row['instance'];ref=row['reference'];category=row['classification'];area=Decimal(row['area_library_units'])
        require(name and name not in seen,'duplicate/empty leaf instance '+name);seen.add(name)
        require(area.is_finite() and area>=0,'nonfinite/negative leaf area '+name)
        if ref in {'**logic_0**','**logic_1**'}:
            require(area==0 and category=='native_constant' and row['charged_scope']=='none','native constant classification '+name)
            charged='none'
        else:
            require(area>0 and category==('SRAM' if ref=='RAMSP1024X16' else 'standard_cell'),'mapped leaf classification '+name)
            charged=scope(name,category)
            require(row['charged_scope']==charged,'charged scope differs from independently derived instance scope '+name)
            refs.add(ref)
        counts[category]+=1;sums[category]+=area;scount[charged]+=1;sarea[charged]+=area
        if category=='SRAM':
            macros[macro_group(name)]+=1;macroareas.add(area)
        if charged!='none':
            key=(component(name,charged),category);ccount[key]+=1;carea[key]+=area
    require(dict(macros)==dict(weights=16,bias=1,shared=256,itcm=32,dtcm=32),'native unique SRAM macro scope/count')
    require(counts['SRAM']==337 and len(macroareas)==1,'macro geometry or same-library macro area differs')
    charged=sum((a for s,a in sarea.items() if s!='none'),Decimal(0))
    charged_sram=sum((a for (c,k),a in carea.items() if k=='SRAM'),Decimal(0))
    return dict(leaf_count=len(seen),counts=counts,sums=sums,scope_counts=scount,scope_area=sarea,
        component_counts=ccount,component_area=carea,macro_groups=macros,macro_unit_area=next(iter(macroareas)),
        charged=charged,charged_sram=charged_sram,charged_logic=charged-charged_sram,references=refs)
def check_summaries(root,leaf):
    summary=dict(line.split('=',1) for line in (root/'leaf-area-summary.txt').read_text().splitlines() if '=' in line)
    require(summary['AREA_DIMENSION']=='UNVERIFIED_DO_NOT_DECLARE_MM2_OR_CONTEST_PASS','native unsupported area dimension assertion')
    charged_count=sum(n for s,n in leaf['scope_counts'].items() if s!='none')
    charged_sram_count=sum(n for (c,k),n in leaf['component_counts'].items() if k=='SRAM')
    expected={'STANDARD_CELL_COUNT':leaf['counts']['standard_cell'],'SRAM_COUNT':337,'NATIVE_CONSTANT_COUNT':leaf['counts']['native_constant'],
        'CHARGED_STANDARD_CELL_COUNT':charged_count-charged_sram_count,'CHARGED_SRAM_COUNT':charged_sram_count}
    for key,value in expected.items():
        require(int(summary[key])==value,'leaf vs summary count '+key)
    for key,value in {'STANDARD_CELL_AREA':leaf['sums']['standard_cell'],'SRAM_AREA':leaf['sums']['SRAM'],
        'CHARGED_STANDARD_CELL_AREA':leaf['charged_logic'],'CHARGED_SRAM_AREA':leaf['charged_sram'],
        'CHARGED_TOTAL_AREA_LIBRARY_UNITS':leaf['charged']}.items():
        require(abs(Decimal(summary[key])-value)<=Decimal('0.0001'),'leaf vs native summary area '+key)
    reader=csv.DictReader((root/'area-components.tsv').open(),delimiter='\t');components=list(reader)
    require(reader.fieldnames==['disjoint_component','classification','leaf_count','area_library_units'],'native component header')
    keys=[(r['disjoint_component'],r['classification']) for r in components]
    require(len(keys)==len(set(keys)) and set(keys)==set(leaf['component_counts'])|{('TOTAL_CHARGED','all_charged')},'native component set/duplicates')
    for row in components:
        key=(row['disjoint_component'],row['classification'])
        n=charged_count if key==('TOTAL_CHARGED','all_charged') else leaf['component_counts'][key]
        area=leaf['charged'] if key==('TOTAL_CHARGED','all_charged') else leaf['component_area'][key]
        require(int(row['leaf_count'])==n and abs(Decimal(row['area_library_units'])-area)<=Decimal('0.0001'),'independently derived component differs '+str(key))
    text=(root/'area.rpt').read_text();matches=re.findall(r'^\s*Total cell area:\s*('+NUM+r')\s*$',text,re.M)
    require(matches,'native report_area total missing')
    total=sum(leaf['sums'].values(),Decimal(0));reported=Decimal(matches[-1])
    require(abs(total-reported)<=max(Decimal('.01'),abs(total)*Decimal('1e-7')),'native whole SoC report vs unique leaf sum')
    references=(root/'references.rpt').read_text();tokens=set(re.findall(r'\S+',references))
    require(leaf['references']<=tokens,'mapped leaf references absent from native reference report: '+str(sorted(leaf['references']-tokens)[:5]))
    return summary,components,total
def check_owner(root,e):
    owner=load(root/'owner-collector-stop.json')
    require(e['status']=='FAILED' and e['returncode']==1 and e['completion_marker'] is False,'preserve exact R5 original failed collector state')
    require(e['mapping_outputs_complete'] is True,'native R5 mapping outputs incomplete')
    require(owner['pid']==owner['pgid']==e['pid']==309326 and owner['no_other_jobs_changed'] is True,'R5 owner stop process scope')
    require(owner['reason']=='DMA report_timing broad from/to collector unchanged for >3600s after complete mapping outputs','R5 owner stop reason differs')
    require(e['started_epoch']<owner['request_epoch']<=e['finished_epoch'],'owner signal outside actual DC run')
    terminal={'returncode','finished_epoch','deadline_terminated','source_drift','completion_marker','native_tool_errors','mapping_outputs_complete','report_collection_status','timing_verdict','signoff_report_gaps_count','signoff_report_status','outputs'}
    running={k:v for k,v in e.items() if k not in terminal};running['status']='RUNNING'
    reconstructed=hashlib.sha256((json.dumps(running,indent=2,sort_keys=True)+'\n').encode()).hexdigest()
    require(reconstructed==owner['original_execution_sha256'],'native owner stop not bound to pre-signal running receipt')
    for name,h in owner['native_mapping_output_hashes'].items():
        require(e['outputs'][name]['sha256']==h,'mapped outputs changed after owner stop '+name)
    log=(root/'dc.log').read_text(errors='replace')
    require(log.count('Received Signal 15 from: PID=129231 (UID=14023)')==1 and 'Process terminated by kill.' in log,'full native owner-signal log evidence absent')
    return dict(termination='PRESERVED_NATIVE_FAILED_RETURN1_REPORT_QUERY_OWNER_STOP',owner_sha256=sha(root/'owner-collector-stop.json'),presignal_receipt_sha256=reconstructed)
def check_policy(prepared,baseline,variant,full):
    baseline_manifest=load(baseline/'package-files.json');require(sha(baseline/'package-files.json')==BASE_MANIFEST,'frozen R5 baseline manifest differs')
    verify_inputs(baseline,baseline_manifest)
    manifest=load(prepared/'package-files.json');verify_inputs(prepared,manifest)
    if variant=='baseline':
        require(manifest==baseline_manifest,'baseline native vs frozen prepared inputs differ')
        return dict(status='EXACT_FROZEN_R5_209_INPUTS',input_count=len(manifest))
    require(full is not None,'full local 243-input candidate required')
    full_manifest=load(full/'package-files.json');verify_inputs(full,full_manifest)
    require(len(full_manifest)==243 and len(manifest)==242,'candidate original/transport input count differs')
    side=load(prepared/SIDECAR)
    require(set(manifest)==(set(full_manifest)-OMIT)|{SIDECAR},'remote manifest omission set differs')
    for n,h in full_manifest.items():
        if n not in OMIT:
            require(manifest[n]==h,'retained original input changed '+n)
    require(side['schema']=='s3-areaopt-remote-evidence-omissions-v1' and side['variant']==variant and side['original_full_manifest_sha256']==sha(full/'package-files.json'),'candidate transport sidecar identity')
    omitted={x['path']:x for x in side['omitted_files']};require(set(omitted)==OMIT,'sidecar raw XML omission set')
    for n,r in omitted.items():
        require(r['sha256']==full_manifest[n] and r['bytes']==(full/n).stat().st_size,'omitted raw local proof identity '+n)
    require(side['retained_original_input_count']==241 and side['original_full_input_count']==243 and side['remote_manifest_input_count_including_this_sidecar']==242,'transport identity counts')
    require(set(baseline_manifest)<=set(full_manifest),'candidate removed frozen baseline input')
    actual_rtl=(prepared/'rtl.f').read_text().splitlines();require(len(actual_rtl)==158 and (prepared/'rtl.f').read_bytes()==(baseline/'rtl.f').read_bytes(),'candidate source-filelist geometry changed')
    tile='source/rtl/perips/LinearTileDmaCore.sv';collector='source/contracts/reference-clock-review.tcl'
    source_changes={n for n in baseline_manifest if n.startswith('source/') and full_manifest[n]!=baseline_manifest[n]}
    require(source_changes=={tile,collector},'candidate changes other baseline source/constraints '+str(source_changes))
    for n in ['synth.tcl','area_components.tcl','source/ppa/hierarchy_contract.tcl','source/contracts/reference-full-soc.sdc','rtl.f']:
        require(full_manifest[n]==baseline_manifest[n],'candidate compile/hierarchy/area/SDC policy changed '+n)
    for n in actual_rtl:
        require(n in manifest and n in baseline_manifest,'compiled path missing from pinned source manifest '+n)
        require(n==tile or manifest[n]==baseline_manifest[n],'compiled source changed beyond the single selected tile '+n)
    require(sha(prepared/'source/contracts/reference-full-soc.sdc')==SDC,'candidate original SDC identity')
    return dict(status='REMOTE242_RECONCILED_WITH_FULL_LOCAL243_SAME_COMPILE_POLICY',transport_manifest_sha256=sha(prepared/'package-files.json'),
        original_full_manifest_sha256=sha(full/'package-files.json'),omission_sidecar_sha256=sha(prepared/SIDECAR),
        omitted_local_raw_xml={n:r['sha256'] for n,r in omitted.items()},changed_rtl=[tile],changed_observational_source=[collector],
        scope='Two omitted XMLs are noncompile proof inputs and remain present/verified locally. No simulation/synthesis/STA is performed by this identity audit.')
def audit(a):
    root=a.native.resolve();prepared=a.prepared.resolve();baseline=a.baseline_inputs.resolve();variant=a.variant
    e=load(root/'execution.json');execution_sha=sha(root/'execution.json')
    require(execution_sha==(BASE_EXEC if variant=='baseline' else a.expected_execution_sha),'exact observed native execution SHA differs')
    require(e['source_drift']==[] and e['native_tool_errors']==[] and e['deadline_terminated'] is False,'native source drift/errors/deadline failure')
    require(e['tool']['sha256']==DC_TOOL and e['max_cores']==2,'native tool/resource identity differs')
    require({x['role']:x['sha256'] for x in e['libraries']}==DBS and len(e['libraries'])==2,'native same-library identities differ')
    require(e['resource_policy']=='REFUSE_ALL_SAME_ACCOUNT_HEAVY_JOBS' and not e.get('observed_jobs',[]),'native resource policy/conflict differs')
    require(sha(root/'package-files.json')==e['manifest_sha256']==sha(prepared/'package-files.json'),'native input manifest differs from sealed local remote package')
    require(load(root/'package-files.json')==load(prepared/'package-files.json'),'native input manifest records differ')
    policy=check_policy(prepared,baseline,variant,a.full_prepared.resolve() if a.full_prepared else None)
    verified={};missing={}
    for n,r in e['outputs'].items():
        if (root/safe(n)).is_file():
            verified[n]=record_file(root,n,r)
        else:
            missing[n]=r
    for n in REQUIRED:
        require(n in verified and (root/n).stat().st_size>0,'required native leaf/area identity evidence absent '+n)
    if variant=='baseline':
        require('owner-collector-stop.json' in verified,'missing exact bound R5 owner record')
        run_state=check_owner(root,e)
    else:
        require(e['status']=='SYNTHESIS_COMPLETE_NOT_QUALIFIED' and e['returncode']==0 and e['completion_marker'] is True,'candidate native synthesis collector not complete/clean')
        require('SYNTHESIS_COMPLETE_NOT_QUALIFIED.txt' in verified,'candidate native completion marker bytes absent')
        status='dc-clock-reports/review_status.txt';require(status in verified,'candidate collector review status absent')
        require(re.search(r'^REQUIRED_REPORT_FAILURE_COUNT=0$',(root/status).read_text(),re.M),'candidate required DC report collector failed')
        for n in ['dma-register-setup.rpt','dma-register-hold.rpt']:
            key='dc-clock-reports/'+n+'.unavailable.txt'
            require(key in verified and 'OMITTED_PROVEN_STALLED_BROAD_SCOPE_QUERY' in (root/key).read_text(),'candidate collector omission is not explicit '+n)
        run_state=dict(termination='NATIVE_CLEAN_REPORT_COLLECTION_NOT_TIMING_QUALIFICATION',report_gap='Standalone PT still required; explicit omitted broad local-scope query is retained')
    log=(root/'dc.log').read_text(errors='replace');require(not re.search(r'^(?:Error:|Fatal:)',log,re.M),'full native DC log error')
    for label,n in GEOMETRY.items():
        require(log.count('P4K_COUNT %s actual=%d expected=%d'%(label,n,n))==2,'native pre/post mapped geometry evidence '+label)
    require('xu_soc_dma64_ppa_top' in log,'actual mapped top identity absent')
    leaf=parse_leaves((root/'leaf-inventory.tsv').read_text());summary,components,total=check_summaries(root,leaf)
    return dict(status='NATIVE_RETURNED_LEAF_AREA_INDEPENDENTLY_RECOMPUTED_NOT_QUALIFIED',execution_sha256=execution_sha,
        original_native_status=e['status'],original_native_returncode=e['returncode'],run_state=run_state,policy=policy,
        input_manifest_sha256=e['manifest_sha256'],library_identities=e['libraries'],verified_returned_outputs=verified,
        unreturned_outputs=missing,unreturned_output_count=len(missing),unreturned_output_bytes=sum(r['bytes'] for r in missing.values()),
        locally_verified_mapped_v='mapped.v' in verified,locally_verified_mapped_ddc='mapped.ddc' in verified,
        netlist_limitation='Any missing mapped.v/ddc are only hash-pinned by native execution/owner evidence, not claimed locally byte-verified. Full unique native leaf TSV and all area records are locally verified/recomputed.',
        charged=dict(total_library_units=str(leaf['charged']),standard_cell_library_units=str(leaf['charged_logic']),sram17_library_units=str(leaf['charged_sram']),
            scope_counts=dict(leaf['scope_counts']),scope_area_library_units={k:str(v) for k,v in leaf['scope_area'].items() if k!='none'}),
        whole_soc=dict(total_library_units=str(total),leaf_counts=dict(leaf['counts']),area_by_category={k:str(v) for k,v in leaf['sums'].items()},macro_groups=dict(leaf['macro_groups']),same_library_macro_unit_area=str(leaf['macro_unit_area'])),
        independently_recomputed_components=[dict(component=k[0],classification=k[1],leaf_count=leaf['component_counts'][k],area_library_units=str(v)) for k,v in sorted(leaf['component_area'].items())],
        native_summary=summary,area_dimension='UNVERIFIED_NOT_MM2_NO_CONTEST_AREA_PASS',
        interpretation='Unique leaf classification and reported library area arithmetic verified. No mapped functional equivalence, STA closure, official macro pricing or shared64 interface qualification claim.')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--native',type=Path,required=True)
    p.add_argument('--prepared',type=Path,required=True);p.add_argument('--baseline-inputs',type=Path,required=True)
    p.add_argument('--variant',choices=['baseline','a','b'],required=True);p.add_argument('--full-prepared',type=Path)
    p.add_argument('--expected-execution-sha');p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    require(not a.out.exists(),'refuse immutable audit receipt overwrite')
    report=dict(schema='s3-area-opt-independent-native-leaf-area-v1',created_at_utc=datetime.now(timezone.utc).isoformat(),new_eda_or_simulation=False,variant=a.variant,auditor_sha256=sha(Path(__file__)))
    try:
        report.update(audit(a));code=0
    except (ValueError,KeyError,OSError,TypeError) as exc:
        report.update(status='FAIL_OR_INCOMPLETE_NATIVE_LEAF_EVIDENCE',reason=str(exc));code=1
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:report.get(k) for k in ['status','reason','execution_sha256','charged']},sort_keys=True));return code
if __name__=='__main__':
    raise SystemExit(main())
