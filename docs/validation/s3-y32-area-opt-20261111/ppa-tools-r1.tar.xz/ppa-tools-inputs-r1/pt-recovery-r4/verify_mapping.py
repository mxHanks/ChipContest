#!/usr/bin/env python3
"""Verify native map outputs without rewriting a failed collector receipt."""
from pathlib import Path
import hashlib,json,re
EXPECTED_MANIFEST='437ede00614caa3bfc4c16a0c7972f5e16865d0dec420dda00be8f1138563c6f'
SDC='c15ede0fc2c65771f87e2d6aee763b4ea0d53934868ca807b4785c36182fce7c'
EXPECTED_ACTUAL_EXECUTION_SHA='29af3d0aa9c13b2c8978ea362a64a571d488e545b579590e9f403aeb1c82621b'
DBS={'standard_cell':'f69c08a0b89c6d747ecb648e8c212a98d2bba6c8b9aeec766e90babc01a64723','sram':'c2cce1cf2bd8f25de5df3fe01e67b0ef40a933c2ec51da156dd47a288866bf0f'}
REQUIRED=['mapped.v','mapped.ddc','mapped.sdc','libraries.tcl','leaf-inventory.tsv','leaf-area-summary.txt','area-components.tsv','area.rpt','references.rpt','qor.rpt','dc-units.rpt','dc-setup.rpt','dc-hold.rpt','dc-violations.rpt','precheck.rpt','postcheck.rpt','clocks.rpt','dc.log']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
def verify(root):
 root=Path(root);old=json.loads((root/'execution.json').read_text())
 require(EXPECTED_ACTUAL_EXECUTION_SHA!='PENDING_NATIVE_METADATA' and sha(root/'execution.json')==EXPECTED_ACTUAL_EXECUTION_SHA,'not exact independently returned R5 native execution receipt')
 require(old.get('status')=='FAILED' and old.get('returncode')==1,'recovery requires exact pinned R5 original FAILED returncode1 receipt')
 require(old.get('mapping_outputs_complete') is True,'original receipt must attest map outputs complete')
 require(old.get('completion_marker') is False,'must not invent original completion marker')
 require(old.get('source_drift')==[] and old.get('native_tool_errors')==[] and old.get('deadline_terminated') is False,'native failure/drift/deadline differs')
 require(sha(root/'package-files.json')==EXPECTED_MANIFEST and old.get('manifest_sha256')==EXPECTED_MANIFEST,'not exact frozen R5 DC inputs')
 for n,h in json.loads((root/'package-files.json').read_text()).items():
  p=Path(n);require(not p.is_absolute() and '..' not in p.parts,'unsafe source path')
  require((root/p).is_file() and sha(root/p)==h,'frozen source drift '+n)
 require(sha(root/'source/contracts/reference-full-soc.sdc')==SDC,'SDC drift')
 require({x['role']:x['sha256'] for x in old.get('libraries',[])}==DBS,'library identity differs')
 require(old.get('tool',{}).get('sha256')=='23a4101c711fdb4747a57e6f9524d4989eb76a2b3120f0fa9766f4b25ae8e6d2','DC tool drift')
 outputs=old.get('outputs',{})
 checked={}
 for n in REQUIRED:
  r=outputs.get(n,{})
  require(r.get('sha256') and (root/n).is_file() and sha(root/n)==r['sha256'] and (root/n).stat().st_size==r.get('bytes'),'required map/native report identity '+n)
  require((root/n).stat().st_size>0,'empty required report '+n)
  checked[n]=r
 log=(root/'dc.log').read_text(errors='replace')
 require(not re.search(r'^(?:Error:|Fatal:)',log,re.M),'native DC log errors')
 require(log.count('Received Signal 15 from: PID=129231 (UID=14023)')==1 and 'Process terminated by kill.' in log,'exact native owner-signal termination log evidence absent')
 for label,n in [('tile_pes',64),('tile_engines',8),('weights',16),('bias',1),('all_ramsp',337)]:
  require(log.count('P4K_COUNT %s actual=%d expected=%d'%(label,n,n))==2,'pre/post hierarchy evidence '+label)
 require(not (root/'dc-clock-reports/dma-register-hold.rpt').exists() and not (root/'dc-clock-reports/review_status.txt').exists(),'collector stopped at different point; audit anew')
 require((root/'dc-clock-reports/dma-register-setup.rpt').is_file(),'slow query partial report absent')
 owner=root/'owner-collector-stop.json'
 require(owner.is_file() and sha(owner)==outputs.get('owner-collector-stop.json',{}).get('sha256'),'owner stop not bound to exact pinned original native execution receipt')
 proof=json.loads(owner.read_text())
 require(proof.get('status')=='OWNER_STOP_REQUEST_FOR_STALLED_REPORT_QUERY_ONLY','owner stop status')
 require(proof.get('pid')==309326 and proof.get('pid')==old.get('pid') and proof.get('pgid')==proof.get('pid'),'exact owner DC pid/process group')
 require(proof.get('reason')=='DMA report_timing broad from/to collector unchanged for >3600s after complete mapping outputs' and proof.get('no_other_jobs_changed') is True,'owner termination reason/scope')
 require(old.get('started_epoch') < proof.get('request_epoch',0) <= old.get('finished_epoch',0),'owner stop time not within original run')
 required_owner={'mapped.v','mapped.ddc','mapped.sdc','leaf-inventory.tsv','leaf-area-summary.txt','area-components.tsv','references.rpt','area.rpt','dc-setup.rpt','dc-hold.rpt','qor.rpt','postcheck.rpt'}
 require(set(proof.get('native_mapping_output_hashes',{}))==required_owner,'owner mapping output inventory differs')
 for n,h in proof['native_mapping_output_hashes'].items():require(h==checked[n]['sha256'],'mapping changed after verified stop '+n)
 # Exact reconstruction of the original RUNNING receipt written by pinned
 # R5 run_once.py. No retrospective owner record is created or modified.
 terminal_keys={'returncode','finished_epoch','deadline_terminated','source_drift','completion_marker','native_tool_errors','mapping_outputs_complete','report_collection_status','timing_verdict','signoff_report_gaps_count','signoff_report_status','outputs'}
 running={k:v for k,v in old.items() if k not in terminal_keys};running['status']='RUNNING'
 running_bytes=(json.dumps(running,indent=2,sort_keys=True)+'\n').encode()
 require(hashlib.sha256(running_bytes).hexdigest()==proof.get('original_execution_sha256'),'owner stop record does not bind exact pre-signal native execution receipt')
 require(outputs.get('owner-collector-stop.json',{}).get('sha256')==sha(owner),'original terminal receipt does not bind owner stop record')
 return {'schema':'s3-area-opt-native-map-recovery-v1','status':'MAP_COMPLETE_COLLECTION_OWNER_STOP_RECORD_RETURN1_NOT_QUALIFIED','original_execution_sha256':sha(root/'execution.json'),'original_execution_status':old['status'],'original_returncode':old['returncode'],'completion_marker_preserved_false':True,'mapping_outputs_verified':checked,'owner_termination_sha256':sha(owner),'source_manifest_sha256':EXPECTED_MANIFEST,'sdc_sha256':SDC,'timing_verdict':'UNMEASURED_STANDALONE_PT_REQUIRED','reports_limited_by':'DC_BROAD_DMA_QUERY_OWNER_STOP_RECORD_RETURN1','returncode_interpretation':'Native exit1 preserved; exact native log reports Signal15 and Process terminated by kill; no clean synthesis exit claimed','native_termination_log_evidence':{'signal':15,'signaller_pid':129231,'signaller_uid':14023,'dc_log_sha256':checked['dc.log']['sha256']},'no_compile_or_source_change':True}
