#!/usr/bin/env python3
"""Verified current DC output -> read-only PT reports. No run without --run."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

DEADLINE = datetime.datetime(2026,11,11,15,59,tzinfo=datetime.timezone.utc).timestamp()
PT = '/eda/synopsys/prime/prime_2022.03-SP5-1/bin/pt_shell'
PT_SHA = 'afdcfa7071f86d229ed3b4481f67adefd1c51bb0288b7e7d370213a43b70c9ef'
LC = '/eda/synopsys/lib_compiler/lib_compiler_2022.03-SP5'
LC_SHA = '15bb8615ae34742544f2149daa47c645d41fd0080372b0a453e7bd19ed083166'
SDC_SHA = 'c15ede0fc2c65771f87e2d6aee763b4ea0d53934868ca807b4785c36182fce7c'
LIB_SHA = {'standard_cell':'f69c08a0b89c6d747ecb648e8c212a98d2bba6c8b9aeec766e90babc01a64723',
           'sram':'c2cce1cf2bd8f25de5df3fe01e67b0ef40a933c2ec51da156dd47a288866bf0f'}

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def check(p,expected):
    if not Path(p).is_file() or sha(p)!=expected: raise ValueError('identity mismatch: '+str(p))

def heavy_jobs():
    heavy={'simv','vcs','vcs1','dc_shell','snps_shell','common_shell_ex','pt_shell','icc2_shell','fm_shell','lc_shell'}
    jobs=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            if p.stat().st_uid!=os.getuid():continue
            comm=(p/'comm').read_text().strip(); exe=Path(os.readlink(str(p/'exe'))).name
            if comm in heavy or exe in heavy:
                jobs.append(dict(pid=int(p.name),comm=comm,exe=exe,cwd_basename=Path(os.readlink(str(p/'cwd'))).name))
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
    return sorted(jobs,key=lambda x:x['pid'])

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',action='store_true')
    p.add_argument('--recover-owner-terminated-map',action='store_true')
    p.add_argument('--source',type=Path,default=Path.home()/'Desktop/xu-area-opt-20261111-baseline-r5/candidate')
    p.add_argument('--out',type=Path,default=Path.home()/'Desktop/xu-area-opt-20261111/pt-baseline-recovery-r4')
    a=p.parse_args(); prepared=Path(__file__).resolve().parent
    package=json.loads((prepared/'package-files.json').read_text())
    for name,h in package.items():
        q=Path(name)
        if q.is_absolute() or '..' in q.parts:raise ValueError('unsafe prepared package path')
        check(prepared/q,h)
    review=dict(schema='s3_area_opt_readonly_pt_v1',status='PREPARED_NOT_EXECUTED',run_requested=a.run,
        max_cores=2,tool_timeout_seconds=300,deadline_utc='2026-11-11T15:59:00Z',source=str(a.source),out=str(a.out),
        prepared_manifest_sha256=sha(prepared/'package-files.json'),qualification='NOT_QUALIFIED')
    if not a.run:
        print(json.dumps(review,sort_keys=True));return 0
    if time.time()>=DEADLINE:raise ValueError('experiment deadline reached; refuse new PT run')
    src=a.source.resolve();out=a.out.resolve()
    if out.exists():raise ValueError('refuse restart or output overwrite: '+str(out))
    old=json.loads((src/'execution.json').read_text())
    recovery=None
    if a.recover_owner_terminated_map:
        from verify_mapping import verify
        recovery=verify(src)
    elif old.get('status')!='SYNTHESIS_COMPLETE_NOT_QUALIFIED' or old.get('returncode')!=0 or not old.get('completion_marker') or old.get('source_drift')!=[] or old.get('native_tool_errors')!=[]:
        raise ValueError('current DC receipt is not completed and clean; explicit verified recovery mode required')
    manifest=json.loads((src/'package-files.json').read_text())
    if old.get('manifest_sha256')!=sha(src/'package-files.json'):raise ValueError('current DC input manifest mismatch')
    for name,h in manifest.items():
        q=Path(name)
        if q.is_absolute() or '..' in q.parts:raise ValueError('unsafe DC input manifest path')
        check(src/q,h)
    required_outputs=['mapped.v','mapped.ddc','mapped.sdc','libraries.tcl','leaf-inventory.tsv','leaf-area-summary.txt','area-components.tsv']
    if recovery:
        required_outputs=sorted(recovery['mapping_outputs_verified'])
    for name in required_outputs:
        record=old.get('outputs',{}).get(name,{})
        if not record.get('sha256'):raise ValueError('DC receipt lacks output identity: '+name)
        check(src/name,record['sha256'])
        if (src/name).stat().st_size!=record.get('bytes'):raise ValueError('DC output byte count mismatch: '+name)
    check(src/'source/contracts/reference-full-soc.sdc',SDC_SHA)
    expected_roles=set(LIB_SHA);actual_roles={x['role'] for x in old.get('libraries',[])}
    if actual_roles!=expected_roles or len(old['libraries'])!=2:raise ValueError('DC library roles mismatch')
    for lib in old['libraries']:
        if lib['sha256']!=LIB_SHA[lib['role']]:raise ValueError('DC library differs from same-condition library')
        check(Path(lib['path']),lib['sha256'])
    check(PT,PT_SHA);check(Path(LC)/'bin/lc_shell',LC_SHA)
    busy=heavy_jobs()
    if busy:raise ValueError('uncoordinated same-account heavy jobs: '+json.dumps(busy))
    out.mkdir(parents=True,mode=0o700);shutil.copy2(prepared/'baseline.tcl',out/'baseline.tcl')
    record=dict(review,status='RUNNING',source=str(src),out=str(out),started_epoch=time.time(),
        command=[PT,'-f','baseline.tcl'],tool=dict(path=PT,sha256=PT_SHA),
        script_sha256=sha(out/'baseline.tcl'),source_dc_execution_sha256=sha(src/'execution.json'),
        source_dc_manifest_sha256=sha(src/'package-files.json'),source_dc_status=old['status'],
        source_dc_outputs={name:old['outputs'][name] for name in required_outputs},
        mapped_v_sha256=sha(src/'mapped.v'),original_sdc_sha256=SDC_SHA,libraries=old['libraries'],
        source_sdc=str(src/'source/contracts/reference-full-soc.sdc'),
        library_compiler=dict(root=LC,launcher_sha256=LC_SHA,scope='child process environment only'),
        resource_policy='REFUSE_ALL_SAME_ACCOUNT_HEAVY_JOBS',observed_jobs=busy,
        timing_verdict='UNREVIEWED_NOT_A_TIMING_PASS')
    if recovery:
        record['mapping_recovery']=recovery
        record['source_owner_termination_sha256']=sha(src/'owner-collector-stop.json')
        (out/'mapping-recovery-receipt.json').write_text(json.dumps(recovery,indent=2,sort_keys=True)+'\n')
    rp=out/'execution.json'
    def save():rp.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    env=os.environ.copy();env['SYNOPSYS_LC_ROOT']=LC;env['XU_BASELINE_ROOT']=str(src);env['XU_MAPPED_SHA256']=record['mapped_v_sha256']
    save();timeout=False
    with (out/'pt.log').open('w') as log:
        job=subprocess.Popen(record['command'],cwd=out,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        record['pid']=job.pid;save()
        try:code=job.wait(timeout=min(300,max(1,DEADLINE-time.time())))
        except subprocess.TimeoutExpired:
            timeout=True;os.killpg(job.pid,signal.SIGTERM)
            try:code=job.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(job.pid,signal.SIGKILL);code=job.wait()
    drift=[name for name,h in manifest.items() if not (src/name).is_file() or sha(src/name)!=h]
    drift += [name for name,v in record['source_dc_outputs'].items() if not (src/name).is_file() or sha(src/name)!=v['sha256']]
    if recovery and sha(src/'owner-collector-stop.json')!=record['source_owner_termination_sha256']:drift.append('owner-collector-stop.json')
    if sha(src/'execution.json')!=record['source_dc_execution_sha256']:drift.append('execution.json')
    errors=re.findall(r'^(?:Error:|Fatal:).*$',(out/'pt.log').read_text(errors='replace'),re.MULTILINE)
    complete=(out/'BASELINE_PT_REPLAY_COMPLETE_NOT_QUALIFIED.txt').is_file()
    record.update(returncode=code,finished_epoch=time.time(),deadline_terminated=timeout and time.time()>=DEADLINE,
        tool_timeout_300s=timeout and time.time()<DEADLINE,
        source_drift=drift,native_tool_errors=errors,completion_marker=complete)
    record['status']='PT_REPORT_COLLECTION_COMPLETE_NOT_QUALIFIED' if code==0 and complete and not timeout and not drift and not errors else 'FAILED'
    record['outputs']={f.relative_to(out).as_posix():dict(bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(out.rglob('*')) if f.is_file() and f!=rp}
    save();print(record['status']);return 0 if record['status']=='PT_REPORT_COLLECTION_COMPLETE_NOT_QUALIFIED' else 1
if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,OSError,KeyError,subprocess.SubprocessError) as exc:
        print('FAIL: '+str(exc),file=sys.stderr);sys.exit(1)
