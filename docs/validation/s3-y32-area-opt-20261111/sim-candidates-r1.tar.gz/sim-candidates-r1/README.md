# 64PE 面积候选仿真交付（A/B）

A 只把 ACC 从48缩到41位；B进一步把引擎结果和结果FIFO缩到41位。完整12任务均为304,128个逐位一致输出、428,915拍（含真实清零12,336拍），gap516拍另列，含gap429,431拍。各层周期与发布版完全相同。150MHz假定下换算约4,196.64task/s；实际时序及面积尚未测定，未选定A或B。

本包包含生成器源码与补丁、默认/特化/安装SV、core/DMA/reset原始日志与结果、8次CPU完整原始日志与source manifests/固件、独立完整AST/type及337宏几何证明、严格逐层比较、工具和输入身份。为缩小体积，复用共享CPU RTL、向量和原基线结果；它们来自已发布冻结包，SHA见DELIVERY.json。候选的Verilator中间C++/obj和可执行simulator不重复打包，测量时binary SHA保留在结果中。

## 校验与重建

`python3 REPLAY.py` 只核验本包文件身份，不启动实验。

先取得同仓库 `docs/validation/s3-y32-4k-20261110/frozen-delivery.tar.gz`。下列命令会核验其SHA，把共享源码和向量解到新目录，叠加候选唯一RTL文件以及已审查的runner/checker guard更新，逐文件确认与实测source manifest完全相同，不运行仿真：

```sh
python3 REPLAY.py --baseline-archive /absolute/frozen-delivery.tar.gz --candidate a-acc41 --prepare-only --out /absolute/new-a-source-check
python3 REPLAY.py --baseline-archive /absolute/frozen-delivery.tar.gz --candidate b-raw41 --prepare-only --out /absolute/new-b-source-check
```

在授权的实验时限内，把 `--prepare-only` 改为 `--run` 并选全新out即可用本机Verilator重建并执行真实CPU完整12任务。默认最多2个编译作业；默认时限为2026-11-11 23:59上海时间。时限后的新实验需要重新获得授权并显式指定deadline。本包不会自动启动远端EDA或改写生产/子仓库。

## 生成器复现

例如在 `candidates/a-acc41/chisel` 目录执行原generation-commands.json中的scala-cli命令，把输出路径换为全新目录并传入41 48 48；B传41 41 41。默认48 48 48的11份SV必须与对应default目录逐字节匹配。安装文件等于 generation-result.json 的concat_order四文件以单个换行拼接；其余7个共享leaf保持默认原字节。原始campaign工具按原仓库布局保存，历史绝对路径和命令未改写；跨目录CPU复现使用本包REPLAY.py。

## 判定边界

两候选的名义声明存储节省分别为448位和1,792位，不能据此宣称面积改进。必须在同库同约束下完成候选综合/时序比较后选型。公共48位数值接口、最终Y32/RNE、真实清零、事务计数、旧回退和参数隔离保留。ELF只允许已独立审查的一个非装载FILE符号中6个随机字符变化，全部PT_LOAD及加载image相同；每份原ELF SHA仍保留。说明见CANDIDATE-SCOPE.md。
