#!/usr/bin/env python3
"""Isolated A/B Chisel generation; default bytes must match published64PE."""
import hashlib,json,shutil,subprocess,time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'build/parallel4k-20261110/core-generated-r1'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def replace(p,old,new):
 s=p.read_text();assert s.count(old)==1,(p,old);p.write_text(s.replace(old,new))
def prepare(name,widths):
 out=HERE/name;assert not out.exists();out.mkdir()
 snap=out/'chisel';snap.mkdir();shutil.copytree(ROOT/'src/main/scala',snap/'src/main/scala')
 shutil.copy2(ROOT/'project.scala',snap/'project.scala')
 exp=snap/'experiment';exp.mkdir()
 for n in ['LinearTileDmaCore.scala','GenerateTileCore.scala']:shutil.copy2(ROOT/'experiments/s3-y32-4k/core'/n,exp/n)
 p=snap/'src/main/scala/dotproduct/MacPE.scala'
 replace(p,'class MacPE(accWidth: Int = 48) extends Module {','''class MacPE(accWidth: Int = 48) extends Module {
    override def desiredName: String = if (accWidth == 48) "MacPE" else s"MacPE_Acc${accWidth}"''')
 p=snap/'src/main/scala/dotproduct/MacPEArray.scala'
 replace(p,'class MacPEArray(accWidth: Int = 48) extends Module {','''class MacPEArray(accWidth: Int = 48) extends Module {
    override def desiredName: String = if (accWidth == 48) "MacPEArray" else s"MacPEArray_Acc${accWidth}"''')
 p=snap/'src/main/scala/dotproduct/DotProductEngine.scala'
 replace(p,'class DotProductEngine(accWidth: Int = 48) extends Module {','''class DotProductEngine(accWidth: Int = 48, resultWidth: Int = 48) extends Module {
    require(resultWidth >= 41 && resultWidth <= 48, "Exact bounded completed results require at least41 bits")
    override def desiredName: String = if (accWidth == 48 && resultWidth == 48) "DotProductEngine"
      else s"DotProductEngine_Acc${accWidth}_Result${resultWidth}"''')
 replace(p,'private val resultReg = RegInit(VecInit(Seq.fill(8)(0.S(48.W))))','private val resultReg = RegInit(VecInit(Seq.fill(8)(0.S(resultWidth.W))))')
 replace(p,'resultReg := peArray.io.result','''if (resultWidth == 48) {
            resultReg := peArray.io.result
        } else {
            for (lane <- 0 until 8) {
                val bounded = peArray.io.result(lane)(resultWidth - 1, 0).asSInt
                assert(peArray.io.result(lane) === bounded.pad(48), "Completed result must fit selected signed storage")
                resultReg(lane) := bounded
            }
        }''')
 replace(p,'io.result := resultReg','''if (resultWidth == 48) { io.result := resultReg }
    else { for (lane <- 0 until 8) io.result(lane) := resultReg(lane).pad(48) }''')
 p=exp/'LinearTileDmaCore.scala'
 replace(p,'class LinearTileDmaCore extends Module {','''class LinearTileDmaCore(accWidth: Int = 48, resultWidth: Int = 48, fifoWidth: Int = 48) extends Module { require(accWidth >= 41 && accWidth <= 48); require(resultWidth >= 41 && resultWidth <= 48); require(fifoWidth >= 41 && fifoWidth <= 48)''')
 replace(p,'val results = Reg(Vec(2, Vec(8, Vec(8, SInt(48.W)))))','val results = Reg(Vec(2, Vec(8, Vec(8, SInt(fifoWidth.W)))))')
 replace(p,'Module(new DotProductEngine)','Module(new DotProductEngine(accWidth, resultWidth))')
 replace(p,'for (row <- 0 until 8) results(tail)(row) := engines(row).io.result','''if (fifoWidth == 48) { for (row <- 0 until 8) results(tail)(row) := engines(row).io.result } else { for (row <- 0 until 8; lane <- 0 until 8) { val bounded = engines(row).io.result(lane)(fifoWidth - 1, 0).asSInt; assert(engines(row).io.result(lane) === bounded.pad(48), "FIFO raw result must fit selected signed storage"); results(tail)(row)(lane) := bounded } }''')
 replace(p,'io.outGroup := tags(head); io.outRow := outputRow; io.outResult := results(head)(outputRow)','''io.outGroup := tags(head); io.outRow := outputRow; if (fifoWidth == 48) { io.outResult := results(head)(outputRow) } else { for (lane <- 0 until 8) io.outResult(lane) := results(head)(outputRow)(lane).pad(48) }''')
 p=exp/'GenerateTileCore.scala'
 replace(p,'ChiselStage.emitSystemVerilogFile(new LinearTileDmaCore,','''val widths = args.drop(1).map(_.toInt)
    require(widths.isEmpty || widths.length == 3, "Supply ACC/result/FIFO widths together")
    val selected = if (widths.isEmpty) Seq(48, 48, 48) else widths.toSeq
    ChiselStage.emitSystemVerilogFile(new LinearTileDmaCore(selected(0), selected(1), selected(2)),''')
 records=[]
 for variant,params in [('default',(48,48,48)),('generated',widths)]:
  generated=out/variant
  command=['scala-cli','run','project.scala','src/main/scala','experiment','--server=false','--jvm','system','-M','GenerateTileCore','--',str(generated),*map(str,params)]
  begin=time.monotonic()
  with (out/(variant+'-generation.log')).open('w') as log:r=subprocess.run(command,cwd=snap,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  records.append(dict(command=command,cwd=str(snap),returncode=r.returncode,elapsed_seconds=time.monotonic()-begin))
  dump(out/'generation-commands.json',records)
  if r.returncode:raise RuntimeError(name+' '+variant+' generation failed')
  rtl=sorted(generated.glob('*.sv'));assert len(rtl)==11,(name,variant,len(rtl))
  if variant=='default':
   assert {p.name:sha(p) for p in rtl}=={p.name:sha(p) for p in BASE.glob('*.sv')},'default RTL differs from original published11'
 special=['MacPE_Acc41.sv','MacPEArray_Acc41.sv','DotProductEngine_Acc41_Result%d.sv'%widths[1]]
 generated=out/'generated';install=out/'install';install.mkdir()
 concat='\n'.join((generated/n).read_text() for n in special+['LinearTileDmaCore.sv'])
 (install/'LinearTileDmaCore.sv').write_text(concat)
 # All7 nonspecial leaf files must remain byte-identical to the original.
 unchanged=[p.name for p in generated.glob('*.sv') if p.name not in special+['LinearTileDmaCore.sv']]
 assert len(unchanged)==7
 assert all(sha(generated/n)==sha(BASE/n) for n in unchanged)
 report=dict(status='GENERATED_DEFAULT11_MATCH_AND_ISOLATED_INSTALL',widths=dict(zip(['ACC','resultReg','FIFO'],widths)),
  default11_byte_identical=True,generated_rtl={p.name:sha(p) for p in sorted(generated.glob('*.sv'))},
  unchanged7=unchanged,install_files={'LinearTileDmaCore.sv':sha(install/'LinearTileDmaCore.sv')},
  concat_order=special+['LinearTileDmaCore.sv'],
  snapshot_sources={p.relative_to(snap).as_posix():sha(p) for p in sorted(snap.rglob('*')) if p.is_file() and '.scala-build' not in p.parts and '.bsp' not in p.parts},
  no_production_or_installed_edits=True,scope='Generated RTL only; no numeric/CPU/PPA claim')
 dump(out/'generation-result.json',report)
 print(name,report['status'],install,flush=True)

for name,widths in [('a-acc41',(41,48,48)),('b-raw41',(41,41,41))]:prepare(name,widths)
