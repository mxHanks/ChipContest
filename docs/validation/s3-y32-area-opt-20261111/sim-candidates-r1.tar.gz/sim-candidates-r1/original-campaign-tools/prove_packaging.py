#!/usr/bin/env python3
"""Split11RTL versus one-file install: fulltop normalized AST/type and geometry."""
import argparse,copy,hashlib,json,shutil,subprocess,time
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'build/area-opt-20261111/baseline-synth-r5/candidate'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')

def canonical(xml):
 tree=ET.parse(xml);root=tree.getroot();net=root.find('netlist');types=net.find('typetable')
 table={e.get('id'):e for e in types if e.get('id') is not None};cache={};visiting=set()
 def typeref(i):
  if i in cache:return cache[i]
  if i not in table:raise ValueError('unknown dtype '+i)
  if i in visiting:raise ValueError('recursive dtype requires explicit handling '+i)
  visiting.add(i)
  value=node(table[i],is_type=True)
  visiting.remove(i);cache[i]=hashlib.sha256(json.dumps(value,separators=(',',':')).encode()).hexdigest();return cache[i]
 def node(e,is_type=False):
  attrs={}
  for k,v in sorted(e.attrib.items()):
   if k=='loc' or (is_type and k=='id'):continue
   attrs[k]=typeref(v) if k.endswith('dtype_id') else v
  return [e.tag,attrs,[node(c,is_type=False) for c in e]]
 modules={e.get('name'):node(e) for e in net if e.tag in ('module','interface','package')}
 cells=sorted((c.get('hier'),c.get('submodname')) for c in root.findall('./cells//cell'))
 return dict(modules=modules,type_structures=sorted(set(typeref(i) for i in table)),cells=cells),tree

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('candidate',type=Path);args=p.parse_args()
 cand=args.candidate.resolve();out=cand/'packaging-proof';assert not out.exists();out.mkdir()
 full=out/'fulltop';shutil.copytree(BASE,full)
 original=list((full/'rtl.f').read_text().splitlines());assert len(original)==158,len(original)
 core='source/rtl/perips/LinearTileDmaCore.sv';assert original.count(core)==1
 shutil.copy2(cand/'install/LinearTileDmaCore.sv',full/core)
 split=[]
 for n in original:
  if n==core:
   split += [str((cand/'generated'/x).resolve()) for x in json.loads((cand/'generation-result.json').read_text())['concat_order']]
  else:split.append(n)
 (full/'split.f').write_text('\n'.join(split)+'\n')
 pre=full/'preflight';pre.mkdir(exist_ok=True);shutil.copy2(ROOT/'tools/ppa/generic_ramsp_non_ppa.sv',pre/'generic_ramsp_non_ppa.sv')
 commands=[];trees={};forms={}
 for name,filelist in [('split','split.f'),('concat','rtl.f')]:
  xml=out/(name+'.xml');command=['verilator','--xml-only','--timing','-Wno-fatal','--top-module','xu_soc_dma64_ppa_top','--Mdir',str(out/(name+'-obj')),'--xml-output',str(xml),'-DSYNTHESIS','-DDISABLE_SV_ASSERTION=1','-DXU_MATRIX_DMA','-DXU_MATRIX_DMA64','-Isource/rtl/core','-Isource/rtl/perips','-Isource/rtl/perips/apb_i2c','-f',filelist,'preflight/generic_ramsp_non_ppa.sv']
  begin=time.monotonic()
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=full,stdout=log,stderr=subprocess.STDOUT,timeout=240)
  commands.append(dict(command=command,cwd=str(full),returncode=r.returncode,elapsed_seconds=time.monotonic()-begin))
  dump(out/'commands.json',commands);assert r.returncode==0,name+' elaboration failed'
  forms[name],trees[name]=canonical(xml)
 assert forms['split']==forms['concat'],'normalized moduleAST/type/cell hierarchy mismatch'
 form=forms['concat'];tree=trees['concat'];cells=form['cells'];counts={}
 for _,n in cells:counts[n]=counts.get(n,0)+1
 pe=sum(n for k,n in counts.items() if k.startswith('MacPE_Acc') and not k.startswith('MacPEArray'))
 engine=sum(n for k,n in counts.items() if k.startswith('DotProductEngine_Acc'))
 assert (pe,engine,counts.get('RAMSP1024X16'))==(64,8,337),(pe,engine,counts.get('RAMSP1024X16'))
 # Installed fallback modules are identical and unused by tile candidate.
 for n in ['MacPE.sv','MacPEArray.sv','DotProductEngine.sv']:
  assert sha(full/'source/rtl/perips'/n)==sha(BASE/'source/rtl/perips'/n),n
 changed=[n for n in original if sha(full/n)!=sha(BASE/n)]
 assert changed==[core],changed
 # Multiplier expression and port widths are exactly unchanged from original48.
 baseline=(BASE/'source/rtl/perips/MacPE.sv').read_text();candidate=(cand/'generated/MacPE_Acc41.sv').read_text()
 expression=lambda s:next(line.strip() for line in s.splitlines() if '_ACC_T =' in line)
 assert expression(baseline)==expression(candidate)
 assert 'input  [15:0] io_x,' in candidate and 'input  [39:0] io_bias,' in candidate and 'output [47:0] io_result' in candidate
 canonical_hash=hashlib.sha256(json.dumps(form,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 dump(out/'proof.json',dict(status='PASS_SPLIT_CONCAT_COMPLETE_AST_TYPE_HIERARCHY',
  scope='Local fulltop elaboration/packaging identity only; not CPU/area/STA',
  complete_ast_type_equal=True,canonical_hash=canonical_hash,normalized_only=['source loc annotations','dtype allocation identifiers resolved to complete structural hashes','global module/typetable order'],
  source_count_concat=len(original),source_count_split=len(split),only_original_source_changed=changed,
  fallback3_byte_identical=True,mac_pe=pe,engines=engine,sram_macros=counts['RAMSP1024X16'],active_cells=len(cells),
  multiply_expression_exactly_unchanged=expression(candidate),public_mac_ports_16x16_40bias_48result=True,
  install_sha256=sha(cand/'install/LinearTileDmaCore.sv'),raw_xml={n:sha(out/(n+'.xml')) for n in ['split','concat']}))
 dump(out/'active-hierarchy.json',cells)
 print(cand.name,'PASS_SPLIT_CONCAT_COMPLETE_AST_TYPE_HIERARCHY',flush=True)
if __name__=='__main__':main()
