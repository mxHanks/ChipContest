#!/usr/bin/env python3
"""Actual generated ACC41 prefix regression plus fulltop raw state inventory."""
import hashlib,importlib.util,json,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
OUT=HERE/'bounds-and-state';assert not OUT.exists();OUT.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
# Exact emitted41 logic equals the previously proved body; only module name differs.
a=HERE/'a-acc41/generated/MacPE_Acc41.sv';b=HERE/'b-raw41/generated/MacPE_Acc41.sv'
old=ROOT/'build/last-two-20261109/integrated-acc41-replay-final/chisel/generated/LinearAutoGroupCore41/MacPE.sv'
assert a.read_bytes()==b.read_bytes()
assert a.read_text().replace('module MacPE_Acc41(','module MacPE(',1)==old.read_text()
for width,source,oldname in [('41',a,'MacPE_Acc41'),('48',HERE/'a-acc41/default/MacPE.sv','MacPE'),
 ('40',ROOT/'build/last-two-20261109/integrated-acc41-replay-final/MacPE40.sv','MacPE40')]:
 text=source.read_text()
 if oldname!='MacPE'+width:text=text.replace('module '+oldname+'(','module MacPE'+width+'(',1)
 (OUT/('MacPE'+width+'.sv')).write_text(text)
tb=ROOT/'experiments/s3-y32-last-two/acc41/tb_acc41.sv';shutil.copy2(tb,OUT/tb.name)
commands=[]
for name,command in [('compile',['iverilog','-g2012','-s','tb_acc41','-o',str(OUT/'prefix.vvp'),str(OUT/tb.name),*[str(OUT/('MacPE'+w+'.sv')) for w in ['48','41','40']]]),('run',['vvp',str(OUT/'prefix.vvp')])]:
 start=time.monotonic()
 with (OUT/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 commands.append(dict(name=name,command=command,cwd=str(ROOT),returncode=r.returncode,elapsed_seconds=time.monotonic()-start))
 dump(OUT/'commands.json',commands);assert r.returncode==0
assert 'ACC41_PREFIX_PASS' in (OUT/'run.log').read_text()
intervals=[dict(n=n,lower=-(1<<39)+n*(-1073709056),upper=(1<<39)-1+n*1073741824) for n in range(65)]
assert all(-(1<<40)<=x['lower']<=x['upper']<(1<<40) for x in intervals)
spec=importlib.util.spec_from_file_location('area_state_reader',ROOT/'experiments/s3-y32-4k/inventory/inventory_r2.py')
reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
states={}
for name,expected in [('a-acc41',(2624,3072,6144,30545)),('b-raw41',(2624,2624,5248,29201))]:
 path=HERE/name/'packaging-proof/concat.xml';rows,excluded=reader.xml_inventory(path)
 acc=sum(v['bits'] for r in rows if r['orig_module'].startswith('MacPE_Acc') for v in r['variables'] if v['name']=='ACC')
 result=sum(v['bits'] for r in rows if r['orig_module'].startswith('DotProductEngine_Acc') for v in r['variables'] if v['name'].startswith('resultReg_'))
 fifo=sum(v['bits'] for r in rows if r['orig_module']=='LinearTileDmaCore' for v in r['variables'] if v['name'].startswith('results_'))
 total=sum(r['bits'] for r in rows)
 assert (acc,result,fifo,total)==expected,(name,acc,result,fifo,total)
 assert sum(r['bits'] for r in rows if r['orig_module']=='TileXRowBuffer')==16384
 states[name]=dict(ACC=acc,engine_result=result,FIFO=fifo,total_declared_bits=total,baseline_declared_bits=30993,
  reduction=30993-total,raw_state_instances=rows,macro_exclusions=excluded,xml_sha256=sha(path))
result=dict(status='PASS_ACTUAL_ACC41_PREFIX_AND_RAW_STATE',scope='Generated RTL prefix regression/fulltop raw declared state; no mapped area/CPU/STA claim',
 generated_A_B_MacPE_identical=True,old_proven_MacPE_body_identical_except_module_name=True,
 prefix_bounds=intervals,prefix_log_sha256=sha(OUT/'run.log'),states=states,
 source_sha256={str(p.relative_to(ROOT)):sha(p) for p in [a,b,old,tb,Path(__file__).resolve()]})
dump(OUT/'result.json',result);print(result['status'])
