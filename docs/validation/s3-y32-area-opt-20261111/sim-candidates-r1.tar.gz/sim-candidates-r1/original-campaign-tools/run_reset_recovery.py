#!/usr/bin/env python3
"""Link existing recovery driver to THIS candidate's sealed model, then run3resets."""
import argparse,hashlib,json,shutil,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
DEADLINE=datetime.fromisoformat('2026-11-11T23:59:00+08:00')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def check_time():
 if datetime.now(timezone.utc)>=DEADLINE:raise RuntimeError('authorized deadline reached')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('candidate',type=Path);args=p.parse_args()
 cand=args.candidate.resolve();screen=cand/'dma-screen';parent=json.loads((screen/'receipt.json').read_text())
 assert parent['status']=='PASS';check_time()
 for path,digest in parent['inputs'].items():assert sha(Path(path))==digest,'parent model/input drift '+path
 out=cand/'dma-reset-recovery';assert not out.exists();out.mkdir()
 driver=ROOT/'experiments/s3-y32-4k/dma-test/dma64_reset_recovery.cpp';shutil.copy2(driver,out/driver.name)
 obj=screen/'obj';helper=screen/'source/dma64_test.cpp'
 pins=dict(parent['inputs']);pins.update({str(p):sha(p) for p in [driver,out/driver.name,helper,obj/'Vdma64_test_top__ALL.a',obj/'verilated.o',obj/'verilated_threads.o',obj/'Vdma64_test_top.h',Path(__file__).resolve()]})
 receipt=dict(status='RUNNING',schema='area_candidate_postreset_recovery_v1',candidate=cand.name,inputs=pins,
  parent_receipt_sha256=sha(screen/'receipt.json'),scope='Existing public-interface recovery driver freshly linked to THIS candidate model; not CPU/PPA',
  legacy_driver_scope_label='Driver retains historicalR2 string; actual candidate model identity is pinned here',commands=[])
 def run(name,command):
  check_time();dump(out/'receipt.json',receipt);start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  receipt['commands'].append(dict(name=name,command=command,cwd=str(ROOT),returncode=r.returncode,elapsed_seconds=time.monotonic()-start))
  dump(out/'receipt.json',receipt);assert r.returncode==0,name+' failed'
 try:
  binary=out/'dma64_reset_recovery'
  run('compile-driver-only',['g++','-Os','-std=c++17','-I'+str(obj),'-I/usr/share/verilator/include','-I'+str(screen/'source'),str(out/driver.name),str(obj/'verilated.o'),str(obj/'verilated_threads.o'),str(obj/'Vdma64_test_top__ALL.a'),'-pthread','-lpthread','-latomic','-o',str(binary)])
  vectors=ROOT/'build/parallel4k-20261110/cpu-full12-r2/vectors'
  run('simulation',[str(binary),str(vectors),str(out/'recovery.json')])
  result=json.loads((out/'recovery.json').read_text());assert result['status']=='PASS' and result['exact_postreset_y32']==76032
  assert len(result['cases'])==3
  for i,case in enumerate(result['cases']):
   assert case['phase']==i and case['fresh_layer']==i+1 and case['fresh_exact_y32']==25344
   assert case['fresh_accepted']==20192 and case['fresh_retired']==20192
   assert sha(out/('recovery.json.phase%d.actual-y32.mem'%i))==sha(vectors/('layer_%02d'%(i+1))/'y32.mem')
  assert all(sha(Path(path))==digest for path,digest in pins.items()),'source drift'
  receipt.update(status='PASS',exact_postreset_y32=76032,cases=result['cases'],source_drift=[])
 except Exception as exc:
  receipt.update(status='FAILED',error=str(exc));raise
 finally:
  receipt['outputs']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(out.iterdir()) if p.is_file() and p.name!='receipt.json'}
  dump(out/'receipt.json',receipt)
 print(cand.name,'DMA_RESET_RECOVERY_PASS exact_y32=76032',flush=True)
if __name__=='__main__':main()
