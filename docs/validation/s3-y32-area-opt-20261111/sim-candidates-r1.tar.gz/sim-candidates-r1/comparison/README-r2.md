# Exact firmware identity with GCC temporary FILE metadata

The original `compare.py` and measurements are preserved. Candidate compilation
created a different random assembler temporary object name, `ccXXXXXX.o`, in
one ELF `.strtab` string. The actual loaded image is byte-identical to the
published image. Whole ELF SHA values remain recorded, distinct, and verified.

`firmware_identity.py` parses ELF32/RISC-V headers, section linkage, and symbol
attributes. The sole exception is six alphanumeric characters in exactly one
LOCAL/FILE/ABS symbol. Its string and symbol tables must not be ALLOC, and the
string must not overlap any PT_LOAD segment. The symbol entry, all headers,
all instructions, all other ELF bytes, the whole image, and the receipt SHA
bindings remain exact. Equal images alone are insufficient.

`compare_r2.py` adds this live audit to the original comparison before allowing
that precise ELF difference. Every previous output, source, vector, CPU,
physical-clear, work-counter and per-layer cycle requirement remains active.
Its original native synthesis gate is unchanged; it does not silently accept
a failed DC collector or establish timing qualification.

```sh
python3 -B build/area-opt-20261111/comparison/firmware_identity_selfcheck.py
python3 -B build/area-opt-20261111/comparison/selfcheck_r2.py
python3 -B build/area-opt-20261111/comparison/compare_r2.py \
  --baseline-cpu build/parallel4k-20261110/cpu-full12-r2/result.json \
  --candidate-cpu CANDIDATE/result.json --out NEW-COMPARISON.json
python3 -B build/area-opt-20261111/comparison/firmware_identity.py \
  --baseline-cpu build/parallel4k-20261110/cpu-full12-r2 \
  --candidate-cpu CANDIDATE --out NEW-FIRMWARE-AUDIT.json
```

The firmware auditor accepts CPU directories; the comparison accepts result
paths. Both audit the original files without modifying them. Selfchecks replay
real existing files and single-fault fixtures; they are not new performance
measurements.
