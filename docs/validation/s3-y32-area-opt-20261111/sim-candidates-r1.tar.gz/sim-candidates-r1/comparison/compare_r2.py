#!/usr/bin/env python3
"""Read-only, fail-closed CPU/area comparison. Never launches simulation or EDA."""
from __future__ import annotations
import argparse
from collections import defaultdict
import csv
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

from firmware_identity import audit_firmware

sys.dont_write_bytecode = True
MAIN = 'u_soc/u_e203_subsys_top/u_e203_subsys_main/'
DMA = MAIN + 'u_e203_subsys_perips/u_xu_matrix_dma/'
ARB = MAIN + 'u_xu_dma_shared_arb/'
EXPECTED_WORK = dict(reads=7520, w_reads=4096, bias_reads=256, x_reads=3168,
                     writes=12672, write_responses=12672, requests=20192,
                     responses=20192, pops=3168, macs=26624, mmio_writes=6)
TOTAL_FIELDS = dict(principal_cycles='principal', payload_cycles='payload',
                    clear_cycles='clear', gap_cycles='gap', including_gap_cycles='including_gap')
TRUSTED_PARSER_SHA = 'b485a5f24f70a3973d867af2d8ee5e7f0035330a1b3a06e2b6b0fa82914336d2'
TOOL_PAIRS = {
    ('526faf2dfd4377cd8add9703157a9aea5800272916d713aa0eb10063dcd6af98',
     '392e111b276001998c2f5f822df2eabdd9d34cf02f1f91f0f9765f4964c31633'): 'frozen_full12_R2',
    ('353a96056da7b5bd5218df78778c378a825ef120e1ca3634f082c21e53efc6a0',
     TRUSTED_PARSER_SHA): 'published_guard_strengthening_only',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def require(test, reason):
    if not test:
        raise ValueError(reason)


def write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def tool_audit(data):
    runner, checker = data['source_sha256'].get('run_cpu.py'), data['source_sha256'].get('check_results.py')
    require(data.get('runner_sha256') == runner, 'runner receipt/source hash disagreement')
    require((runner,checker) in TOOL_PAIRS, 'unknown runner/checker identity pair; audit required')
    return {'runner_sha256':runner,'recorded_checker_sha256':checker,
            'approved_revision':TOOL_PAIRS[(runner,checker)],
            'comparison_parser_sha256':TRUSTED_PARSER_SHA,
            'allowed_difference':'Exactly the audited four stronger window guards and replay throttle/simulator guards; no measurement-boundary or output computation change.'}


def cpu_validate(path, parser_path):
    path = Path(path).resolve()
    root, data = path.parent, load(path)
    require(data.get('status') == 'PASS' and not data.get('source_drift'), 'CPU status/drift')
    require(data.get('performance_scope') == 'complete12', 'CPU result is not complete12')
    args = data.get('arguments', {})
    require(args.get('tasks') == 12 and args.get('rows') == 8 and args.get('warmup') is True,
            'CPU tasks/rows/warmup changed')
    require(not args.get('build_only') and not args.get('firmware_only'), 'not runtime evidence')
    require(data.get('outputs') == 304128, 'not all 304128 Y32 outputs')
    manifest = load(root / 'source-manifest.json')['files']
    require(manifest == data.get('source_sha256'), 'source manifest/result disagree')
    actual = {str(p.relative_to(root / 'source')): sha(p)
              for p in (root / 'source').rglob('*') if p.is_file()}
    require(actual == manifest, 'frozen CPU source missing, extra or changed')
    require(sha(parser_path) == TRUSTED_PARSER_SHA, 'untrusted comparison parser')
    tool_audit(data)
    spec = importlib.util.spec_from_file_location('frozen_dma_checker', parser_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    parsed = module.check_log((root / 'simulation.log').read_text(), 12, 8, True)
    for field, value in parsed.items():
        require(data.get(field) == value, 'raw log/result disagree: ' + field)
    for field, layer_field in TOTAL_FIELDS.items():
        require(data[field] == sum(v[layer_field] for v in data['layers']), 'bad total ' + field)
    require(sha(root / 'firmware/dma_day_soc') == data['firmware']['elf_sha256'], 'ELF drift')
    require(sha(root / 'firmware/dma_day_soc.verilog') == data['firmware']['image_sha256'], 'image drift')
    require(len(data['vectors']) == 12, 'vector task count')
    for index, item in enumerate(data['vectors']):
        require(item['layer'] == index and item['outputs'] == 25344, 'vector layer identity')
        for name, digest in item['sha256'].items():
            require(sha(root / 'vectors' / ('layer_%02d' % index) / name) == digest,
                    'vector bytes changed: %d/%s' % (index, name))
    for name, digest in data['vector_export'].items():
        require(sha(root / 'vectors' / name) == digest, 'vector export identity changed')
    require(len([p for p in manifest if p.startswith('rtl/core/')]) == 42, 'CPU core source scope changed')
    return data


def compare_cpu_data(base, cand, firmware_audit=None):
    require(base.get('outputs') == cand.get('outputs') == 304128, 'not all full12 outputs')
    btools, ctools = tool_audit(base), tool_audit(cand)
    for field in ['clock', 'vectors', 'vector_export', 'tools']:
        require(base.get(field) == cand.get(field), 'CPU identity mismatch: ' + field)
    for field in ['image_sha256', 'source_sha256']:
        require(base['firmware'].get(field) == cand['firmware'].get(field), 'firmware identity: ' + field)
    if base['firmware']['elf_sha256'] != cand['firmware']['elf_sha256']:
        require(firmware_audit is not None and firmware_audit.get('status') == 'PASS' and
                firmware_audit.get('baseline_elf_sha256') == base['firmware']['elf_sha256'] and
                firmware_audit.get('candidate_elf_sha256') == cand['firmware']['elf_sha256'] and
                firmware_audit.get('loaded_image_sha256') == base['firmware']['image_sha256'],
                'firmware identity: ELF differs without exact non-ALLOC FILE-symbol audit')
    for field in ['rows', 'tasks', 'warmup', 'throttle', 'first_source_stall', 'sim']:
        require(base['arguments'].get(field) == cand['arguments'].get(field), 'CPU runtime contract: ' + field)
    bsrc, csrc = base['source_sha256'], cand['source_sha256']
    protected = [p for p in bsrc if p.startswith(('rtl/core/', 'tests/'))]
    require({p: bsrc[p] for p in protected} == {p: csrc.get(p) for p in protected},
            'CPU core, firmware, observer, testbench or parser source changed')
    require(len(base['layers']) == len(cand['layers']) == 12, 'not full12')
    per_layer = []
    for index, (b, c) in enumerate(zip(base['layers'], cand['layers'])):
        require(b['layer'] == c['layer'] == index and b['outputs'] == c['outputs'] == 25344,
                'layer/output scope')
        for field in ['principal', 'including_gap', 'firmware_cycles']:
            require(c[field] <= b[field], 'layer %d regressed: %s (%d > %d)' % (index, field, c[field], b[field]))
        for key, expected in EXPECTED_WORK.items():
            require(b['counters'][key] == c['counters'][key] == expected,
                    'layer %d work counter changed: %s' % (index, key))
        require(b['channel']['max_outstanding'] == c['channel']['max_outstanding'] == 1,
                'outstanding contract changed')
        per_layer.append({'layer': index, 'baseline_principal': b['principal'],
                          'candidate_principal': c['principal'], 'delta_principal': c['principal'] - b['principal'],
                          'baseline_clear': b['clear'], 'candidate_clear': c['clear'],
                          'baseline_gap': b['gap'], 'candidate_gap': c['gap'],
                          'baseline_channel': b['channel'], 'candidate_channel': c['channel'],
                          'baseline_mmio_reads': b['counters']['mmio_reads'],
                          'candidate_mmio_reads': c['counters']['mmio_reads']})
    require(cand['principal_cycles'] <= base['principal_cycles'] <= 428915,
            'principal total exceeds frozen 428915 cycle baseline')
    # Width/encoding changes may alter storage bits, but never physical address
    # coverage, zero-state evidence or the observed per-object clear work count.
    clear_keys = ['W', 'BIAS', 'X', 'total16bit_writes', 'X_REGS', 'ACC', 'ENGINE_RESULT',
                  'FIFO', 'BIAS_CACHE', 'DMA_SNAPSHOT', 'all_addresses', 'all_payload_zero']
    require(len(base['physical_clear']) == len(cand['physical_clear']) == 13, 'physical clear task scope')
    for b, c in zip(base['physical_clear'], cand['physical_clear']):
        require({k: b[k] for k in clear_keys} == {k: c[k] for k in clear_keys}, 'physical clear work reduced/changed')
    return {'status': 'CPU_FUNCTIONAL_AND_CYCLE_COMPARISON_PASS',
            'baseline_principal': base['principal_cycles'], 'candidate_principal': cand['principal_cycles'],
            'per_layer': per_layer, 'candidate_source_changes': sorted(p for p in set(bsrc) | set(csrc) if bsrc.get(p) != csrc.get(p)),
            'work_counters_equal': True, 'clear_coverage_equal': True,
            'firmware_exact_metadata_exception_audit': firmware_audit,
            'baseline_tool_guard_audit':btools,'candidate_tool_guard_audit':ctools,
            'tools_identity_limit': 'Historical CPU receipts record executable paths/version strings, not binary executable SHA256s.',
            'frequency_verdict': 'SIMULATION_CYCLES_ONLY_NOT_150MHZ_STA_PASS'}


def compare_cpu(base_path, cand_path):
    parser = Path(__file__).resolve().parent / 'trusted_check_results.py'
    b, c = cpu_validate(base_path, parser), cpu_validate(cand_path, parser)
    firmware_audit = audit_firmware(Path(base_path).parent, Path(cand_path).parent)
    result = compare_cpu_data(b, c, firmware_audit)
    result['input_sha256'] = {'baseline': sha(base_path), 'candidate': sha(cand_path)}
    return result


def parse_references(path):
    """Read native DC reference table. `n` proves noncombinational, not FF."""
    classes, pending, active = {}, [], False

    def finish():
        if not pending:
            return
        tokens = ' '.join(pending).split()
        ref = tokens[0]
        start = 1 if re.fullmatch(r'\d+\.\d+', tokens[1]) else 2
        require(len(tokens) >= start + 3, 'malformed native reference row: ' + ref)
        Decimal(tokens[start]); int(tokens[start+1]); Decimal(tokens[start+2])
        attrs = set(x.strip() for x in ' '.join(tokens[start+3:]).split(',') if x.strip())
        if 'h' in attrs:
            return
        kind = 'noncombinational_kind_unproven' if 'n' in attrs else 'combinational'
        require(ref not in classes or classes[ref] == kind, 'inconsistent reference classification: ' + ref)
        classes[ref] = kind

    for line in Path(path).read_text().splitlines():
        if line.startswith('Reference') and 'Unit Area' in line:
            active, pending = True, []
        elif active and line.startswith('Total '):
            finish(); pending, active = [], False
        elif active and line and not line.startswith('-'):
            if not line[0].isspace():
                finish(); pending = [line]
            elif pending:
                pending.append(line)
    finish()
    require(bool(classes), 'no native reference classifications')
    return classes


def leaf_component(instance, reference):
    if instance.startswith(DMA):
        rel = instance[len(DMA):]
        if rel.startswith('u_core/weights/'): return 'weights', 'owned'
        if rel.startswith('u_core/bias/'): return 'bias', 'owned'
        if re.match(r'u_core/xs_\d+_\d+/', rel): return 'x_double_buffers', 'owned'
        if re.match(r'u_core/engines_\d+/', rel): return 'engines_64pe', 'owned'
        if rel.startswith('u_core/'): return 'core_fifo_and_control', 'owned'
        return 'dma_frontend_and_scheduler', 'owned'
    if instance.startswith(ARB): return 'new_arbiter', 'new_interface'
    if instance.startswith('u_shared/'):
        return ('reused_shared_sram', 'excluded') if reference == 'RAMSP1024X16' else ('changed_endpoint_logic', 'new_interface')
    return 'reused_soc', 'excluded'


def aggregate_area(leaf_path, references_path, require_64_geometry=True):
    classes = parse_references(references_path)
    groups = defaultdict(lambda: {'count': 0, 'area': Decimal(0)})
    macro_groups = defaultdict(int)
    seen = set()
    with Path(leaf_path).open() as f:
        for row in csv.DictReader(f, delimiter='\t'):
            instance, reference = row['instance'], row['reference']
            require(instance not in seen, 'duplicate mapped leaf: ' + instance)
            seen.add(instance)
            area = Decimal(row['area_library_units'])
            require(area.is_finite() and area >= 0, 'invalid leaf area')
            if reference in ['**logic_0**', '**logic_1**']:
                require(area == 0 and row['classification'] == 'native_constant', 'constant area/class')
                continue
            require(area > 0, 'nonpositive mapped area')
            component, charge = leaf_component(instance, reference)
            if reference == 'RAMSP1024X16':
                require(row['classification'] == 'SRAM', 'macro classification mismatch')
                kind = 'sram'
                macro_groups[component] += 1
            else:
                require(row['classification'] == 'standard_cell', 'unknown mapped leaf classification')
                kind = classes.get(reference, 'standard_classification_unproven')
            if row.get('charged_scope') is not None:
                expected_scope = 'dma' if instance.startswith(DMA) else 'arbiter' if instance.startswith(ARB) else 'endpoint_logic' if component == 'changed_endpoint_logic' else 'none'
                require(row['charged_scope'] == expected_scope, 'native/recomputed charged scope disagree: ' + instance)
            group = groups[(component, charge, kind)]
            group['count'] += 1; group['area'] += area
    if require_64_geometry:
        require(macro_groups.get('weights') == 16 and macro_groups.get('bias') == 1,
                'owned macro count differs from16W+1bias')
        require(macro_groups.get('reused_shared_sram') == 256, 'shared macro count differs from256')
        require(sum(macro_groups.values()) == 337, 'whole SoC macro count differs from337')
    records = [dict(component=k[0], charge=k[1], mapped_kind=k[2], count=v['count'], area_library_units=str(v['area']))
               for k, v in sorted(groups.items())]
    charged = [v for k, v in groups.items() if k[1] != 'excluded']
    charged_area = sum((v['area'] for v in charged), Decimal(0))
    owned_sram = sum((v['area'] for k, v in groups.items() if k[1] != 'excluded' and k[2] == 'sram'), Decimal(0))
    seq = sum((v['count'] for k, v in groups.items() if k[1] != 'excluded' and k[2] == 'noncombinational_kind_unproven'), 0)
    seq_area = sum((v['area'] for k, v in groups.items() if k[1] != 'excluded' and k[2] == 'noncombinational_kind_unproven'), Decimal(0))
    comb_count = sum((v['count'] for k, v in groups.items() if k[1] != 'excluded' and k[2] == 'combinational'), 0)
    comb_area = sum((v['area'] for k, v in groups.items() if k[1] != 'excluded' and k[2] == 'combinational'), Decimal(0))
    interface_area = sum((v['area'] for k, v in groups.items() if k[1] == 'new_interface'), Decimal(0))
    shared_area = sum((v['area'] for k, v in groups.items() if k[0] == 'reused_shared_sram'), Decimal(0))
    unknown = sum((v['count'] for k, v in groups.items() if k[1] != 'excluded' and k[2] == 'standard_classification_unproven'), 0)
    return {'charged_total_library_units': str(charged_area), 'charged_sram_area_library_units': str(owned_sram),
            'charged_standard_area_library_units': str(charged_area-owned_sram),
            'macro_counts': dict(macro_groups), 'components': records,
            'charged_mapped_noncombinational_count': seq,
            'charged_mapped_noncombinational_area_library_units': str(seq_area),
            'charged_mapped_combinational_count': comb_count,
            'charged_mapped_combinational_area_library_units': str(comb_area),
            'charged_new_interface_area_library_units': str(interface_area),
            'excluded_reused_shared_sram_area_library_units': str(shared_area),
            'charged_mapped_ff_count': None, 'charged_mapped_ff_area_library_units': None,
            'ff_evidence_status': 'UNPROVEN: native reference n includes FF and latch; no naming heuristic used.',
            'unclassified_standard_count': unknown,
            'area_dimension': 'UNVERIFIED_LIBRARY_UNITS_NOT_MM2',
            'input_sha256': {'leaf': sha(leaf_path), 'reference': sha(references_path)}}


def synth_identity(root):
    root = Path(root)
    execution = load(root / 'execution.json')
    require(execution.get('completion_marker') is True and not execution.get('source_drift')
            and not execution.get('deadline_terminated'), 'mapping completion/source identity missing')
    for name in ['mapped.v', 'mapped.ddc', 'mapped.sdc', 'leaf-inventory.tsv', 'references.rpt', 'area.rpt']:
        expected = execution.get('outputs', {}).get(name, {}).get('sha256')
        require(expected and sha(root / name) == expected, 'native output SHA mismatch/missing: ' + name)
    for name, digest in load(root / 'package-files.json').items():
        require(sha(root / name) == digest, 'synthesis pinned input drift: ' + name)
    log = (root / 'dc.log').read_text()
    for label, count in [('tile_pes',64), ('tile_engines',8), ('weights',16), ('bias',1), ('all_ramsp',337)]:
        marker = 'P4K_COUNT %s actual=%d expected=%d' % (label, count, count)
        require(log.count(marker) == 2, 'pre/post synthesis geometry not proven: ' + label)
    synth = (root / 'synth.tcl').read_text()
    policy = synth.split('  source libraries.tcl\n',1)[1].split('  compile_ultra -no_autoungroup\n',1)[0] + '  compile_ultra -no_autoungroup\n'
    return {'libraries': {v['role']:v['sha256'] for v in execution['libraries']},
            'tool': execution['tool'], 'sdc_sha256':sha(root/'source/contracts/reference-full-soc.sdc'),
            'rtl_f_sha256':sha(root/'rtl.f'),
            'ppa_top_sha256':sha(root/'source/ppa/xu_soc_dma64_ppa_top.sv'),
            'compile_policy_sha256': hashlib.sha256(policy.encode()).hexdigest(),
            'hierarchy_contract_sha256': sha(root/'source/ppa/hierarchy_contract.tcl'),
            'defines':load(root/'defines.json'), 'top':load(root/'manifest.json')['top'],
            'native_execution_status':execution['status'],
            'report_collection_status':execution.get('report_collection_status','UNPROVEN'),
            'signoff_report_status':execution.get('signoff_report_status','UNPROVEN')}


def timing_summary(root):
    result = {'verdict':'UNREVIEWED_NOT_A_TIMING_PASS'}
    for name, report in [('setup','dc-setup.rpt'),('hold','dc-hold.rpt')]:
        path = Path(root)/report
        values = [Decimal(x) for x in re.findall(r'slack\s+\((?:MET|VIOLATED)\)\s+(-?\d+(?:\.\d+)?)',path.read_text())] if path.is_file() else []
        result[name+'_worst_reported_slack_ns'] = str(min(values)) if values else None
        result[name+'_report_sha256'] = sha(path) if path.is_file() else None
    return result


def compare_synth_identity(base, candidate):
    for field in ['libraries','tool','sdc_sha256','rtl_f_sha256','ppa_top_sha256',
                  'compile_policy_sha256','hierarchy_contract_sha256','defines','top']:
        require(base[field] == candidate[field], 'same-condition synthesis identity mismatch: ' + field)


def compare_native(base_root, cand_root, base_cpu_path, cand_cpu_path):
    bi, ci = synth_identity(base_root), synth_identity(cand_root)
    compare_synth_identity(bi, ci)
    for root, cpu in [(Path(base_root),base_cpu_path),(Path(cand_root),cand_cpu_path)]:
        require(sha(root/'evidence/cpu-full12-result.json') == sha(cpu), 'synth CPU result binding mismatch')
        require(load(root/'final-binding.json')['cpu_full12_result_sha256'] == sha(cpu), 'final binding mismatch')
    b = aggregate_area(Path(base_root)/'leaf-inventory.tsv',Path(base_root)/'references.rpt')
    c = aggregate_area(Path(cand_root)/'leaf-inventory.tsv',Path(cand_root)/'references.rpt')
    delta = Decimal(c['charged_total_library_units']) - Decimal(b['charged_total_library_units'])
    return {'status':'SAME_CONDITION_AREA_COMPARISON_RECORDED_NOT_QUALIFIED',
            'baseline_identity':bi,'candidate_identity':ci,'baseline':b,'candidate':c,
            'charged_area_delta_library_units':str(delta),'area_reduced':delta<0,
            'baseline_timing':timing_summary(base_root),'candidate_timing':timing_summary(cand_root),
            'qualification':'NO_ACTUAL_150MHZ_OR_MM2_VERDICT_FROM_THIS_PARSER'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-cpu', type=Path, required=True)
    parser.add_argument('--candidate-cpu', type=Path, required=True)
    parser.add_argument('--baseline-native', type=Path)
    parser.add_argument('--candidate-native', type=Path)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    result = {'schema':'s3-area-opt-comparison-v2-exact-elf-file-symbol-audit','status':'FAIL'}
    try:
        result['cpu'] = compare_cpu(args.baseline_cpu,args.candidate_cpu)
        require(bool(args.baseline_native) == bool(args.candidate_native), 'both native roots required')
        if args.baseline_native:
            result['native'] = compare_native(args.baseline_native,args.candidate_native,args.baseline_cpu,args.candidate_cpu)
        result['status'] = 'COMPARISON_PASS_NOT_FREQUENCY_OR_CONTEST_QUALIFICATION'
    except (ValueError,KeyError,OSError,TypeError) as exc:
        result['error'] = str(exc)
    write(args.out,result)
    print(json.dumps({'status':result['status'],'out':str(args.out),'error':result.get('error')},sort_keys=True))
    return 0 if result['status'].startswith('COMPARISON_PASS') else 1


if __name__ == '__main__':
    sys.exit(main())
