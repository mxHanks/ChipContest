# Strict area/cycle comparison

This directory contains read-only evidence parsers. They never run simulation,
synthesis, STA, or modify source evidence. Full12 comparison first reruns the
published `check_results.py` over each raw simulation log; it also hashes every
frozen source, vector, ELF and image. The result JSON must exactly match its raw
log. Every layer must retain 25,344 exact Y32 comparisons, all work transactions,
physical clearing from nonzero state, warmup and the same timing boundaries.

The same firmware, vectors, clock stimulus, runtime stall/occupancy settings,
tool version/path receipts, 42 CPU core files, and observer/testbench sources are
required. The runner/checker have exactly two audited hash pairs: the frozen R2
pair and the published pair that adds four strict window guards plus replay
throttle/simulator consistency checks. Their exact patches are retained under
`tool-audit/`. Both raw logs are always rechecked with the copied, hash-pinned
published stricter `trusted_check_results.py`. The comparison records both
original tool hashes and the common comparison parser hash. Unknown checker or
runner changes are rejected. New date is passed by the existing `--deadline`
CLI; runner source does not need a date edit.

Simulator executables naturally differ after RTL changes;
each executable is identified in its own original run receipt, while this parser
compares the tool and evidence contract. Historic CPU receipts lack executable
tool binary hashes, so this limitation is reported. No historical tool identity
is invented.

No layer may regress principal, including-gap, or enclosing firmware cycles;
the total principal cap remains 428,915. This prevents faster layers from hiding
a slower layer and prevents moving work outside the main interval. Work-bearing
transaction counters stay exact; CPU poll counts and measured stall lengths
are reported as diagnostics and may change with a faster implementation.
Clear operation counts/coverage remain equal even when a register's safe width
changes. The existing checker verifies every clear address and state is zero.

CPU-only comparison:

```sh
python3 -B build/area-opt-20261111/comparison/compare.py \
  --baseline-cpu build/parallel4k-20261110/cpu-full12-r2/result.json \
  --candidate-cpu CANDIDATE/result.json \
  --out build/area-opt-20261111/comparison/CANDIDATE-cpu.json
```

Add both `--baseline-native DIR` and `--candidate-native DIR` for actual native
area comparison. Each must contain the full synthesis package plus native
outputs/execution receipt. Package and output hashes, 64-PE/eight-engine and
337-macro pre/post mapping count markers, CPU result binding, exact library/tool,
reference SDC, defines, hierarchy contract and compile policy are checked. The
same source-list portability exclusion must be used for selected candidates. The
actual R2-to-R3 file-list hash difference is explicitly rejected by identity
comparison; candidate PPA must use the same R3 exclusion rather than hiding it.

Area is recomputed from unique native leaves, using a single policy: complete
DMA plus its 17 owned SRAM, all new arbiter, and every modified endpoint standard
cell are charged; the256 reused shared macros and unmodified SoC are listed and
excluded. Components separate W, bias, X buffers,64-PE engines, FIFO/control,
DMA front end, arbiter and endpoint. Unit is library area units, never mm².

Mapped combinational versus noncombinational classes use the native DC
reference table's documented `n` attribute. This proves sequential/noncombi-
national logic but does **not** distinguish FF from latch. Exact FF count/area
therefore remain explicitly unknown until native library attributes or an
authoritative library-cell report supplies that distinction. No reference-name
heuristic is used. Unknown standard classifications remain visible.

The parser preserves worst reported setup/hold slack and report statuses. It
does not certify timing coverage, actual150 MHz, valid exceptions, area units,
SRAM organizer prices, or contest eligibility. Synthesis completion with report
gaps is distinguishable from timing closure; no gap is treated as PASS.

Parser verification:

```sh
python3 -B build/area-opt-20261111/comparison/selfcheck.py
```

Checks replay the actual published12-task evidence and historical native
leaf/reference report, then reject single-fault fixtures: hidden per-layer cycle
regression, missing output/response/clear work, changed FW/vector/CPU core,
increased gap/FW interval, edited source boundary, duplicate/NaN leaf area, and
omitted charged scope. Historical16PE replay is explicitly labeled as parser
verification; it is not a current64PE area measurement.
