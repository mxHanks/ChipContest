#!/usr/bin/env python3
"""Independent read-only candidate packaging/CPU identity review; no EDA launch."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
R5=REPO/'build/area-opt-20261111/baseline-synth-r5/candidate'
BASE_CPU=REPO/'build/parallel4k-20261110/cpu-full12-r2'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def check(v,m):
    if not v: raise ValueError(m)
def importer(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def review(candidate,cpu):
    gen=load(candidate/'generation-result.json')
    check(gen['status']=='GENERATED_DEFAULT11_MATCH_AND_ISOLATED_INSTALL','generation status')
    defaults={p.name:sha(p) for p in (candidate/'default').glob('*.sv')}
    published={p.name:sha(p) for p in (REPO/'build/parallel4k-20261110/core-generated-r1').glob('*.sv')}
    check(len(defaults)==11 and defaults==published,'default11 bytes differ')
    check({p.name:sha(p) for p in (candidate/'generated').glob('*.sv')}==gen['generated_rtl'],'generated manifest drift')
    expected='\n'.join((candidate/'generated'/name).read_text() for name in gen['concat_order'])
    installed=candidate/'install/LinearTileDmaCore.sv'
    check(installed.read_text()==expected and sha(installed)==gen['install_files']['LinearTileDmaCore.sv'],'concat bytes/order')
    for name in gen['unchanged7']:
        check(sha(candidate/'generated'/name)==published[name],'shared leaf changed '+name)
    proofroot=candidate/'packaging-proof';proof=load(proofroot/'proof.json')
    commands=load(proofroot/'commands.json')
    check(len(commands)==2 and all(c['returncode']==0 for c in commands),'elaboration did not succeed')
    parser=importer('candidate_complete_ast',candidate.parent/'prove_packaging.py')
    forms=[]
    for name in ['split','concat']:
        xml=proofroot/(name+'.xml')
        check(sha(xml)==proof['raw_xml'][name],'raw XML changed '+name)
        check(not re.search(r'%Error|\bError:',(proofroot/(name+'.log')).read_text()),'elaboration log error')
        root=ET.parse(xml).getroot();net=root.find('netlist')
        check(all(e.tag in {'module','interface','package','typetable'} for e in net),'unreviewed top-level AST tag')
        modules=[e.get('name') for e in net if e.tag in {'module','interface','package'}]
        check(len(modules)==len(set(modules)),'duplicate module names could hide AST')
        ids=[e.get('id') for e in net.find('typetable') if e.get('id')]
        check(len(ids)==len(set(ids)),'duplicate dtype IDs could hide type')
        form,_=parser.canonical(xml);forms.append(form)
    check(forms[0]==forms[1],'complete split/concat AST/type mismatch')
    canonical_sha=hashlib.sha256(json.dumps(forms[0],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    check(canonical_sha==proof['canonical_hash'],'canonical receipt drift')
    counts=Counter(ref for _,ref in forms[1]['cells'])
    pes=sum(n for ref,n in counts.items() if ref.startswith('MacPE_Acc') and not ref.startswith('MacPEArray'))
    engines=sum(n for ref,n in counts.items() if ref.startswith('DotProductEngine_Acc'))
    geometry={'mac_pe':pes,'engines':engines,'sram_macros':counts['RAMSP1024X16']}
    check(geometry=={'mac_pe':64,'engines':8,'sram_macros':337},'candidate geometry')
    check(counts['MacPE']==counts['DotProductEngine']==0,'legacy compute unexpectedly active')
    full=proofroot/'fulltop';listed=(full/'rtl.f').read_text().splitlines()
    check(len(listed)==158 and sha(full/'rtl.f')==sha(R5/'rtl.f'),'same-policy filelist')
    changed=[name for name in listed if sha(full/name)!=sha(R5/name)]
    check(changed==['source/rtl/perips/LinearTileDmaCore.sv'],'unreviewed fulltop source changed')
    check(sha(full/changed[0])==sha(installed),'fulltop source not installed variant')
    for name in ['MacPE.sv','MacPEArray.sv','DotProductEngine.sv']:
        check(sha(full/'source/rtl/perips'/name)==sha(R5/'source/rtl/perips'/name),'fallback changed')
    data=load(cpu/'result.json')
    check(data['status']=='PASS' and data['performance_scope']=='complete12' and data['outputs']==304128,'not complete12 PASS')
    check(sha(cpu/'source/rtl/perips/LinearTileDmaCore.sv')==sha(installed),'CPU source not variant install')
    bsrc=load(BASE_CPU/'source-manifest.json')['files'];csrc=load(cpu/'source-manifest.json')['files']
    changes=sorted(k for k in set(bsrc)|set(csrc) if bsrc.get(k)!=csrc.get(k))
    check(changes==['check_results.py','rtl/perips/LinearTileDmaCore.sv','run_cpu.py'],'unexpected CPU frozen source change')
    compare=importer('area_compare_r2',HERE/'compare_r2.py')
    cpu_comparison=compare.compare_cpu(BASE_CPU/'result.json',cpu/'result.json')
    roles={'generation':candidate/'generation-result.json','packaging_proof':proofroot/'proof.json',
           'raw_split_xml':proofroot/'split.xml','raw_concat_xml':proofroot/'concat.xml',
           'split_log':proofroot/'split.log','concat_log':proofroot/'concat.log',
           'installed_core':installed,'cpu_result':cpu/'result.json',
           'cpu_source_manifest':cpu/'source-manifest.json','cpu_log':cpu/'simulation.log',
           'complete_ast_parser':candidate.parent/'prove_packaging.py',
           'independent_review_tool':Path(__file__),'strict_cpu_comparison_tool':HERE/'compare_r2.py',
           'firmware_audit_tool':HERE/'firmware_identity.py'}
    return {'status':'PASS','same_policy':True,'scope':'Independent local fulltop packaging/identity and complete12 CPU review; no mapping, timing or mm2 qualification',
            'cpu_result_sha256':sha(cpu/'result.json'),'candidate':candidate.name,'geometry':geometry,
            'canonical_ast_sha256':canonical_sha,'rtl_f_sha256':sha(full/'rtl.f'),
            'installed_sha256':sha(installed),'canonical_split_vs_installed_ast_equal':True,
            'default11_byte_identical':True,'fallback3_byte_identical':True,
            'cpu_source_changes':changes,'cpu_principal_cycles':data['principal_cycles'],
            'cpu_comparison':cpu_comparison,'artifacts':{k:{'path':str(p.resolve()),'sha256':sha(p)} for k,p in roles.items()}}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--candidate',required=True,type=Path)
    p.add_argument('--cpu',required=True,type=Path);p.add_argument('--out',required=True,type=Path)
    args=p.parse_args();check(not args.out.exists(),'refuse overwrite')
    result=review(args.candidate.resolve(),args.cpu.resolve());args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'cpu_result_sha256':result['cpu_result_sha256'],'out':str(args.out)}))

if __name__=='__main__':main()
