#!/usr/bin/env python3
"""Replay real ELF metadata exception and reject executable/identity faults."""
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
spec=importlib.util.spec_from_file_location('firmware_identity',HERE/'firmware_identity.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
baseline=REPO/'build/parallel4k-20261110/cpu-full12-r2/firmware/dma_day_soc'
b=baseline.read_bytes()
a=(REPO/'build/area-opt-20261111/cpu/a-task0-r1/firmware/dma_day_soc').read_bytes()
c=(REPO/'build/area-opt-20261111/cpu/b-task0-r1/firmware/dma_day_soc').read_bytes()
checks=[]
for name,value in [('identical',b),('candidate_a',a),('candidate_b',c)]:
    m.audit_elf_bytes(b,value)
    checks.append({'name':name,'expected':'PASS','actual':'PASS'})
fixtures={}
for name,offset in [('changed_text',4096),('changed_header',24),
                    ('changed_non_temp_strtab',5032),('changed_symbol_info',0x12a8+5*16+12),
                    ('changed_temp_prefix',5017),('changed_temp_suffix',5025),
                    ('changed_string_table_flags',0x147c+6*40+8)]:
    value=bytearray(a);value[offset]^=1;fixtures[name]=bytes(value)
fixtures['truncated']=a[:-1]
value=bytearray(a);value[5019]=ord('_');fixtures['invalid_temp_name']=bytes(value)
for name,value in fixtures.items():
    try:m.audit_elf_bytes(b,value)
    except ValueError as error:
        checks.append({'name':name,'expected':'REJECT','actual':'REJECT','reason':str(error)})
    else:raise AssertionError('false acceptance '+name)
result={'status':'PASS','scope':'PARSER_REPLAY_AND_SINGLE_FAULT_FIXTURES_NO_NEW_SIMULATION',
        'checks':checks,'total':len(checks),'tool_sha256':m.digest((HERE/'firmware_identity.py').read_bytes()),
        'selfcheck_sha256':m.digest(Path(__file__).read_bytes()),
        'baseline_elf_sha256':m.digest(b),'no_source_evidence_modified':True}
(HERE/'firmware-identity-selfcheck-r2.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks)}))
