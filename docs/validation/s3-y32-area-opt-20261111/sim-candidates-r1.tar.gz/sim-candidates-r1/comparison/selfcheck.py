#!/usr/bin/env python3
"""Replay old evidence and single-fault fixtures; never run EDA/simulation."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import sys

sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[2]
spec=importlib.util.spec_from_file_location('area_compare',BASE/'compare.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
RESULT=REPO/'build/parallel4k-20261110/cpu-full12-r2/result.json'
PARSER=BASE/'trusted_check_results.py'
checks=[]

def test(name,fn,expect_error=None):
    try:
        fn()
    except ValueError as exc:
        if expect_error is None or expect_error not in str(exc):
            raise
        checks.append({'name':name,'status':'PASS_EXPECTED_REJECTION','reason':str(exc)})
    else:
        if expect_error is not None:raise AssertionError('failed to reject: '+name)
        checks.append({'name':name,'status':'PASS'})

base=c.cpu_validate(RESULT,PARSER)
test('published full12 raw-log/source/vector/FW replay',lambda:c.compare_cpu(RESULT,RESULT))

def fault(mutator):
    candidate=copy.deepcopy(base)
    mutator(candidate)
    c.compare_cpu_data(base,candidate)

def hidden_layer_regression(d):
    d['layers'][0]['principal']+=1
    d['layers'][1]['principal']-=1
test('one layer slower hidden by equal total',lambda:fault(hidden_layer_regression),'layer 0 regressed')
test('one output missing',lambda:fault(lambda d:d.update(outputs=304127)),'full12 outputs')
test('firmware changed',lambda:fault(lambda d:d['firmware'].update(elf_sha256='0'*64)),'firmware identity')
test('layer parameter vector changed',lambda:fault(lambda d:d['vectors'][3]['sha256'].update(w_mem='0'*64)),'identity mismatch: vectors')
test('CPU core changed',lambda:fault(lambda d:d['source_sha256'].update({'rtl/core/e203_lsu.v':'0'*64})),'CPU core')
test('unknown checker change rejected',lambda:fault(lambda d:d['source_sha256'].update({'check_results.py':'0'*64})),'unknown runner/checker')
def published_guard_pair(d):
    runner,checker=next(pair for pair, label in c.TOOL_PAIRS.items() if label=='published_guard_strengthening_only')
    d['runner_sha256']=runner
    d['source_sha256']['run_cpu.py']=runner
    d['source_sha256']['check_results.py']=checker
test('exact audited published guard pair accepted',lambda:fault(published_guard_pair))
test('one required DMA response removed',lambda:fault(lambda d:d['layers'][8]['counters'].update(responses=20191)),'work counter changed')
test('physical FIFO clear work removed',lambda:fault(lambda d:d['physical_clear'][2].update(FIFO=64)),'physical clear work')
test('gap moved out of principal and increased',lambda:fault(lambda d:d['layers'][1].update(including_gap=35787)),'including_gap')
test('firmware enclosing interval increased',lambda:fault(lambda d:d['layers'][4].update(firmware_cycles=35811)),'firmware_cycles')

spec2=importlib.util.spec_from_file_location('original_checker',PARSER)
checker=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(checker)
log=(RESULT.parent/'simulation.log').read_text()
test('raw source boundary edited by one cycle',lambda:checker.check_log(log.replace('first_request=1612224','first_request=1612225',1),12,8,True),'payload boundary')
test('published guard rejects wrong start/done duration',lambda:checker.check_log(log.replace('start_to_done=34717','start_to_done=34718',1),12,8,True),'start/done duration')
test('published guard rejects too-short firmware interval',lambda:checker.check_log(log.replace('firmware_cycles=35810','firmware_cycles=1',1),12,8,True),'firmware duration')
def shift_window(marker,delta):
    import re
    lines=log.splitlines()
    index=next(i for i,line in enumerate(lines) if line.startswith(marker))
    lines[index]=re.sub(r'(first_request|first_accept|last_y_response|clear_request|clear_done|start|done)=(\d+)',
                        lambda m:m.group(1)+'='+str(int(m.group(2))+delta),lines[index])
    return '\n'.join(lines)+'\n'
test('published guard rejects overlapping counted windows',lambda:checker.check_log(shift_window('D4K_WINDOW layer=1 ', -300000),12,8,True),'overlapping/reused')
test('published guard rejects warmup overlap',lambda:checker.check_log(shift_window('D4K_WARMUP_WINDOW layer=0 ',300000),12,8,True),'warmup overlaps')

prepared=REPO/'build/area-opt-20261111/baseline-synth-r3/candidate'
runner_spec=importlib.util.spec_from_file_location('prepared_review_runner',prepared/'run_once.py')
runner=importlib.util.module_from_spec(runner_spec);runner_spec.loader.exec_module(runner)
synth=(prepared/'synth.tcl').read_text()
policy=synth.split('  source libraries.tcl\n',1)[1].split('  compile_ultra -no_autoungroup\n',1)[0]+'  compile_ultra -no_autoungroup\n'
identity=dict(libraries={role:digest for role,path,digest in runner.LIBS},
              tool={'path':runner.DC,'sha256':runner.DC_SHA},
              sdc_sha256=c.sha(prepared/'source/contracts/reference-full-soc.sdc'),
              rtl_f_sha256=c.sha(prepared/'rtl.f'),
              ppa_top_sha256=c.sha(prepared/'source/ppa/xu_soc_dma64_ppa_top.sv'),
              compile_policy_sha256=c.hashlib.sha256(policy.encode()).hexdigest(),
              hierarchy_contract_sha256=c.sha(prepared/'source/ppa/hierarchy_contract.tcl'),
              defines=c.load(prepared/'defines.json'),top=c.load(prepared/'manifest.json')['top'])
test('prepared same-source synthesis identity replay only',lambda:c.compare_synth_identity(identity,identity))
for field in ['libraries','sdc_sha256','compile_policy_sha256','rtl_f_sha256','defines']:
    changed=copy.deepcopy(identity)
    changed[field]='SINGLE_CHANGED_IDENTITY'
    test('changed '+field+' rejected',lambda changed=changed:c.compare_synth_identity(identity,changed),field)
r2identity=copy.deepcopy(identity)
r2identity['rtl_f_sha256']=c.sha(prepared.parent.with_name('baseline-synth-r2')/'candidate/rtl.f')
test('actual R2 to R3 source-list difference is not hidden',lambda:c.compare_synth_identity(identity,r2identity),'rtl_f_sha256')

historical=REPO/'build/server-dma-synth-20261109/native/r3-full/extracted/candidate'
area=c.aggregate_area(historical/'leaf-inventory.tsv',historical/'references.rpt')
test('native old leaf/reference parser complete classification',lambda:c.require(area['unclassified_standard_count']==0,'unclassified refs'))
test('17 owned macros retained',lambda:c.require(area['macro_counts']['weights']==16 and area['macro_counts']['bias']==1,'owned macro count'))
test('256 shared macros excluded',lambda:c.require(area['macro_counts']['reused_shared_sram']==256,'shared macro count'))
test('noncombinational n is never guessed to be FF',lambda:c.require(area['charged_mapped_ff_count'] is None and area['charged_mapped_noncombinational_count']>0,'FF guessing'))
test('uniform new charging includes old changed endpoint logic',lambda:c.require(area['charged_total_library_units']=='268086.326238','charged total'))

with tempfile.TemporaryDirectory(prefix='s3-area-parser-') as tmp:
    path=Path(tmp)/'leaf.tsv'
    header='instance\treference\tarea_library_units\tclassification\tcharged_scope\n'
    name=c.DMA+'test_leaf'
    def rows(text):path.write_text(header+text)
    row=name+'\tAND2V0_12TR40\t1.276800\tstandard_cell\tdma\n'
    rows(row+row)
    test('duplicate native leaf rejected',lambda:c.aggregate_area(path,historical/'references.rpt',False),'duplicate mapped leaf')
    rows(row.replace('1.276800','NaN'))
    test('NaN native area rejected',lambda:c.aggregate_area(path,historical/'references.rpt',False),'invalid leaf area')
    rows(row.replace('\tdma\n','\tnone\n'))
    test('native scope charging omission rejected',lambda:c.aggregate_area(path,historical/'references.rpt',False),'charged scope disagree')

receipt={'status':'PASS','scope':'PARSER_ONLY_NO_NEW_MEASUREMENT','checks':checks,'count':len(checks),
         'comparison_sha256':c.sha(BASE/'compare.py'),'baseline_cpu_result_sha256':c.sha(RESULT),
         'historical_leaf_sha256':c.sha(historical/'leaf-inventory.tsv'),
         'historical_replay':'Historical16PE input only; recomputed using new64PE charge policy, not current64PE area.'}
c.write(BASE/'selfcheck-result.json',receipt)
c.write(BASE/'historical16pe-leaf-replay.json',dict(scope=receipt['historical_replay'],**area))
print(json.dumps({'status':'PASS','count':len(checks),'scope':receipt['scope']},sort_keys=True))
