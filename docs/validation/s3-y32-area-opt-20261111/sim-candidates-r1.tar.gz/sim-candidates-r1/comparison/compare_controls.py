#!/usr/bin/env python3
"""Reparse one-task CPU controls and compare exact work and cycle boundaries."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import compare_r2 as c
from firmware_identity import audit_firmware

def validate(root,rows,stall):
    d=c.load(root/'result.json');a=d['arguments']
    c.require(d['status']=='PASS' and not d.get('source_drift'),'control status/source drift')
    c.require(a['tasks']==1 and a['rows']==rows and a['first_source_stall']==stall and a['warmup'] is True,'control runtime changed')
    c.tool_audit(d)
    actual={str(p.relative_to(root/'source')):c.sha(p) for p in (root/'source').rglob('*') if p.is_file()}
    c.require(actual==d['source_sha256']==c.load(root/'source-manifest.json')['files'],'control source identity')
    spec=importlib.util.spec_from_file_location('control_checker',HERE/'trusted_check_results.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    parsed=module.check_log((root/'simulation.log').read_text(),1,rows,True)
    for field,value in parsed.items():c.require(d[field]==value,'control raw log/receipt mismatch '+field)
    c.require(d['outputs']==25344 and len(d['layers'])==1,'control output scope')
    for item in d['vectors']:
        for name,h in item['sha256'].items():c.require(c.sha(root/'vectors'/('layer_%02d'%item['layer'])/name)==h,'control vectors drift')
    c.require(c.sha(root/'firmware/dma_day_soc')==d['firmware']['elf_sha256'] and c.sha(root/'firmware/dma_day_soc.verilog')==d['firmware']['image_sha256'],'control firmware drift')
    return d

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline',required=True,type=Path);p.add_argument('--candidate',required=True,type=Path)
    p.add_argument('--rows',type=int,required=True);p.add_argument('--first-source-stall',type=int,required=True)
    p.add_argument('--out',required=True,type=Path);args=p.parse_args()
    c.require(not args.out.exists(),'refuse overwrite')
    b,d=[validate(root,args.rows,args.first_source_stall) for root in [args.baseline,args.candidate]]
    for field in ['vectors','vector_export','clock','tools']:
        c.require(b[field]==d[field],'control '+field+' changed')
    protected=[n for n in b['source_sha256'] if n.startswith(('rtl/core/','tests/'))]
    c.require({n:b['source_sha256'][n] for n in protected}=={n:d['source_sha256'].get(n) for n in protected},'control CPU/firmware/observer changed')
    firmware=audit_firmware(args.baseline,args.candidate)
    bl,dl=b['layers'][0],d['layers'][0]
    for field in ['principal','including_gap','firmware_cycles','clear','gap','payload','start_to_done']:
        c.require(bl[field]==dl[field],'control cycle boundary differs: '+field)
    c.require(bl['counters']==dl['counters'] and bl['channel']==dl['channel'],'control work/wait counters differ')
    keys=['W','BIAS','X','total16bit_writes','X_REGS','ACC','ENGINE_RESULT','FIFO','BIAS_CACHE','DMA_SNAPSHOT','all_addresses','all_payload_zero']
    c.require(len(b['physical_clear'])==len(d['physical_clear'])==2,'control clear scope')
    for bc,dc in zip(b['physical_clear'],d['physical_clear']):
        c.require({k:bc[k] for k in keys}=={k:dc[k] for k in keys},'control physical clear work differs')
    result={'status':'PASS','scope':'One-task CPU control, exact output/work/cycle comparison; no hardware frequency claim',
            'rows':args.rows,'first_source_stall':args.first_source_stall,
            'baseline_result_sha256':c.sha(args.baseline/'result.json'),'candidate_result_sha256':c.sha(args.candidate/'result.json'),
            'outputs':d['outputs'],'principal_cycles':d['principal_cycles'],'clear_cycles':d['clear_cycles'],
            'gap_cycles':d['gap_cycles'],'including_gap_cycles':d['including_gap_cycles'],
            'firmware_audit':firmware,'counter_and_wait_fields_equal':True,'physical_clear_coverage_equal':True,
            'tool_sha256':c.sha(Path(__file__))}
    c.write(args.out,result);print(json.dumps({'status':'PASS','out':str(args.out)}))

if __name__=='__main__':main()
