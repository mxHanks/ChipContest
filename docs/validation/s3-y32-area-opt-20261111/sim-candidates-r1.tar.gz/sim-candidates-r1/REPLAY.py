#!/usr/bin/env python3
"""Verify this delta bundle; explicitly rebuild/replay with the frozen baseline."""
from __future__ import annotations
import argparse,datetime,hashlib,importlib.util,json,shutil,subprocess,tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE_SHA='464bea138c254d842b1db656da0e8feb42e04e509f9ab85d92e0cd30736b543f'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def check(v,m):
 if not v:raise ValueError(m)
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def safe_extract(archive,out):
 with tarfile.open(archive) as tf:
  for m in tf.getmembers():
   check(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts and not m.issym() and not m.islnk(),'unsafe archive member')
   check(m.isfile() or m.isdir(),'nonregular archive member')
  tf.extractall(out,filter='data')
def run(cmd,cwd,log):
 with log.open('w') as f:
  f.write(json.dumps({'command':[str(v) for v in cmd],'cwd':str(cwd)})+'\n');f.flush()
  subprocess.run([str(v) for v in cmd],cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
def before_deadline(value):
 check(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(value).astimezone(datetime.timezone.utc),'Experiment deadline reached; verification remains available. A later experiment needs renewed authorization.')

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--baseline-archive',type=Path);p.add_argument('--candidate',choices=['a-acc41','b-raw41'])
 mode=p.add_mutually_exclusive_group();mode.add_argument('--prepare-only',action='store_true');mode.add_argument('--run',action='store_true')
 p.add_argument('--out',type=Path);p.add_argument('--jobs',type=int,default=2)
 p.add_argument('--deadline',default='2026-11-11T23:59:00+08:00')
 a=p.parse_args();manifest=load(ROOT/'SHA256.json')
 for name,h in manifest.items():
  check(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe manifest path')
  check(sha(ROOT/name)==h,'bundle identity mismatch '+name)
 print('DELTA_SEALED_FILES_PASS',len(manifest),flush=True)
 if a.baseline_archive:check(sha(a.baseline_archive)==BASE_SHA,'wrong published baseline archive')
 if not (a.run or a.prepare_only):return
 check(a.baseline_archive and a.candidate and a.out,'--prepare-only/--run require baseline archive, candidate and new output')
 check(a.jobs>=1 and a.jobs<=4,'jobs must be1..4')
 if a.run:before_deadline(a.deadline)
 out=a.out.resolve();check(not out.exists(),'refuse output overwrite');out.mkdir(parents=True)
 safe_extract(a.baseline_archive,out/'baseline')
 baseline=out/'baseline/delivery-final-r2';cand=ROOT/'candidates'/a.candidate
 cpu=ROOT/'cpu'/({'a-acc41':'a-full12-r1','b-raw41':'b-full12-r1'}[a.candidate])
 source=out/'source';shutil.copytree(baseline/'cpu/source',source)
 shutil.copy2(cand/'install/LinearTileDmaCore.sv',source/'rtl/perips/LinearTileDmaCore.sv')
 for name in ['check_results.py','run_cpu.py']:shutil.copy2(ROOT/'common-cpu-source'/name,source/name)
 source_manifest=load(cpu/'source-manifest.json')['files']
 actual={str(f.relative_to(source)):sha(f) for f in source.rglob('*') if f.is_file()}
 check(actual==source_manifest,'reconstructed candidate source is not exact measured source')
 record=load(cpu/'result.json');check(record['status']=='PASS' and record['outputs']==304128,'not terminal full12')
 for name,field in [('dma_day_soc','elf_sha256'),('dma_day_soc.verilog','image_sha256')]:
  check(sha(cpu/'firmware'/name)==record['firmware'][field],'firmware identity drift')
 vectors=baseline/'cpu/vectors'
 for layer in record['vectors']:
  for name,h in layer['sha256'].items():check(sha(vectors/f"layer_{layer['layer']:02d}"/name)==h,'baseline vector drift')
 for name,h in record['vector_export'].items():check(sha(vectors/name)==h,'vector export drift')
 write(out/'preparation.json',{'status':'PASS_RECONSTRUCTED_EXACT_MEASURED_SOURCE','candidate':a.candidate,'baseline_archive_sha256':BASE_SHA,
  'candidate_cpu_result_sha256':sha(cpu/'result.json'),'source_manifest':source_manifest,'new_simulation_started':False})
 print('EXACT_CANDIDATE_SOURCE_AND_VECTORS_PASS',a.candidate,flush=True)
 if a.prepare_only:return
 before_deadline(a.deadline)
 args=record['arguments'];rtl=source/'rtl';filelist=out/'rtl.f'
 filelist.write_text(''.join(str(f)+'\n' for f in sorted(rtl.rglob('*')) if f.suffix in {'.v','.sv'})+str(source/'tests/tb_dma64_soc.sv')+'\n')
 command=['verilator','--binary','--timing','--assert','-CFLAGS','-std=gnu++20','-j',str(a.jobs),'-Wno-fatal','--top-module','tb_dma64_soc',
  '-Mdir',out/'obj','-o','dma_day_soc','-DDISABLE_SV_ASSERTION=1','-DXU_MATRIX_DMA','-DXU_MATRIX_DMA64','-DD4K_THROTTLE='+str(args['throttle']),
  *['-I'+str(f) for f in [rtl/'core',rtl/'perips',rtl/'perips/apb_i2c',source/'tests']],'-f',filelist]
 run(command,out,out/'build.log');before_deadline(a.deadline)
 command=[out/'obj/dma_day_soc','+TESTCASE='+str(cpu/'firmware/dma_day_soc'),'+VECTORS='+str(vectors),'+TASKS=12','+ROWS=8','+WARMUP=1',
  '+THROTTLE='+str(args['throttle']),'+FIRST_SOURCE_STALL='+str(args['first_source_stall']),'+MAX_CYCLES='+str(args['max_cycles']),'+DUMPWAVE=0']
 run(command,out,out/'simulation.log')
 spec=importlib.util.spec_from_file_location('sealed_candidate_checker',source/'check_results.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
 result=checker.check_log((out/'simulation.log').read_text(),12,8,True)
 check(result['outputs']==304128 and result['principal_cycles']<=428915,'full12 output/cycle gate')
 for observed,measured in zip(result['layers'],record['layers']):
  for key in ['principal','including_gap','firmware_cycles']:check(observed[key]<=measured[key],'per-layer cycle regression')
 write(out/'verified-result.json',result)
 print('CANDIDATE_REAL_CPU_REPLAY_PASS',a.candidate,result['outputs'],result['principal_cycles'],flush=True)

if __name__=='__main__':main()
