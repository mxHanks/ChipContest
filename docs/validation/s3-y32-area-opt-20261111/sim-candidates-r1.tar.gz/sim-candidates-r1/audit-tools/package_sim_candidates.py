#!/usr/bin/env python3
"""Create immutable compact A/B simulation delivery; no experiment launch."""
import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'build/area-opt-20261111'
OUT=BASE/'delivery/sim-candidates-r1';ARCHIVE=OUT.with_suffix('.tar.gz')
BASE_ARCHIVE=ROOT/'docs/validation/s3-y32-4k-20261110/frozen-delivery.tar.gz'
BASE_SHA='464bea138c254d842b1db656da0e8feb42e04e509f9ab85d92e0cd30736b543f'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def check(v,m):
 if not v:raise ValueError(m)
def cp(src,dst):
 dst=OUT/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def cp_tree(src,dst,filter_fn=lambda p:True):
 for p in sorted(src.rglob('*')):
  if p.is_file() and not any(x in p.relative_to(src).parts for x in ['obj','.scala-build','.bsp','__pycache__']) and filter_fn(p):cp(p,Path(dst)/p.relative_to(src))

check(not OUT.exists() and not ARCHIVE.exists(),'refuse delivery overwrite');check(sha(BASE_ARCHIVE)==BASE_SHA,'baseline archive drift')
for n in ['a-acc41','b-raw41']:
 review=load(BASE/'audit'/f'{n}-independent-review.json');check(review['status']=='PASS','terminal independent review missing')
 proof=BASE/'candidates'/n/'independent-synth-proof';receipt=load(proof/'proof-receipt.json')
 for p,h in receipt['files'].items():check(sha(proof/p)==h,'proof drift '+p)
OUT.mkdir(parents=True)
cp(BASE/'audit/replay_sim_delivery.py','REPLAY.py');cp(BASE/'audit/candidate-scope-handoff.md','CANDIDATE-SCOPE.md')
for n in ['prepare_candidates.py','prove_packaging.py','check_bounds_and_state.py','run_reset_recovery.py']:
 cp(BASE/'candidates'/n,'original-campaign-tools/'+n)
for n in ['independent_candidate_review.py','independent_candidate_review_v1.py','independent_candidate_review_v2.py','bundle_candidate_proof.py','package_sim_candidates.py']:
 cp(BASE/'audit'/n,'audit-tools/'+n)
for n in ['check_results.py','run_cpu.py']:
 a=BASE/'cpu/a-full12-r1/source'/n;b=BASE/'cpu/b-full12-r1/source'/n;check(sha(a)==sha(b),'shared current CPU checker/runner mismatch');cp(a,'common-cpu-source/'+n)
for name in ['a-acc41','b-raw41']:
 src=BASE/'candidates'/name
 for d in ['generated','install','default','chisel','independent-synth-proof']:
  cp_tree(src/d,'candidates/'+name+'/'+d)
 for n in ['generation-result.json','generation-commands.json','default-generation.log','generated-generation.log','candidate-source.diff']:
  cp(src/n,'candidates/'+name+'/'+n)
 for d in ['core-screen','core-matrix','dma-screen','dma-reset-recovery']:
  check(load(src/d/'receipt.json')['status']=='PASS','campaign not PASS '+name+'/'+d)
  cp_tree(src/d,'candidates/'+name+'/'+d,lambda p:p.suffix in {'.json','.log','.mem','.sv','.v','.cpp','.py'})
for src in sorted((BASE/'cpu').iterdir()):
 if not src.is_dir():continue
 data=load(src/'result.json');check(data['status']=='PASS','CPU pending '+src.name)
 for n in ['result.json','source-manifest.json','simulation.log','rtl.f','simulator-build.log']:
  if (src/n).is_file():cp(src/n,'cpu/'+src.name+'/'+n)
 cp_tree(src/'firmware','cpu/'+src.name+'/firmware')
for n in ['a-acc41-independent-review.json','b-raw41-independent-review.json','a-acc41-static-review.json','b-raw41-static-review.json']:
 cp(BASE/'audit'/n,'reviews/'+n)
cp_tree(BASE/'candidates/bounds-and-state','bounds-and-state',lambda p:p.suffix in {'.json','.log','.sv'})
cp_tree(BASE/'candidates/a-acc41-attempt1-default-assert-lines','rejected/default-assert-line-attempt',lambda p:p.suffix in {'.json','.log','.scala','.sv','.diff'})
for path in sorted((BASE/'comparison').iterdir()):
 if path.is_file() and path.suffix in {'.json','.md','.py'}:cp(path,'comparison/'+path.name)
summary={n:{k:load(BASE/'cpu'/prefix/'result.json')[k] for k in ['status','outputs','principal_cycles','payload_cycles','clear_cycles','gap_cycles','including_gap_cycles','task_per_second_at_assumed_150mhz']} for n,prefix in [('a-acc41','a-full12-r1'),('b-raw41','b-full12-r1')]}
identity={'schema':'s3-area-opt-sim-delta-delivery-v1','status':'SIMULATION_QUALIFIED_AREA_STA_NOT_MEASURED',
 'published_fallback_parent':'d60e0e00d79051747b8adcfa39fca273a6e7e309','published_fallback_child':'a80dd184536e0f2312c62768d5acf4ba1b01c34e',
 'shared_baseline_archive':{'repository_path':'docs/validation/s3-y32-4k-20261110/frozen-delivery.tar.gz','sha256':BASE_SHA,'bytes':BASE_ARCHIVE.stat().st_size},
 'candidate_results':summary,'selected_candidate':None,'production_or_child_modified':False,'new_synthesis_or_simulation_started_by_packager':False,
 'default_experiment_deadline':'2026-11-11T23:59:00+08:00','scope':'CPU and local module/DMA simulation evidence. Declared width savings are not mapped area.150MHz and official2.25mm2 qualification unverified.'}
dump(OUT/'DELIVERY.json',identity)
(OUT/'README.md').write_text('''# 64PE 面积候选仿真交付（A/B）

A 只把 ACC 从48缩到41位；B进一步把引擎结果和结果FIFO缩到41位。完整12任务均为304,128个逐位一致输出、428,915拍（含真实清零12,336拍），gap516拍另列，含gap429,431拍。各层周期与发布版完全相同。150MHz假定下换算约4,196.64task/s；实际时序及面积尚未测定，未选定A或B。

本包包含生成器源码与补丁、默认/特化/安装SV、core/DMA/reset原始日志与结果、8次CPU完整原始日志与source manifests/固件、独立完整AST/type及337宏几何证明、严格逐层比较、工具和输入身份。为缩小体积，复用共享CPU RTL、向量和原基线结果；它们来自已发布冻结包，SHA见DELIVERY.json。候选的Verilator中间C++/obj和可执行simulator不重复打包，测量时binary SHA保留在结果中。

## 校验与重建

`python3 REPLAY.py` 只核验本包文件身份，不启动实验。

先取得同仓库 `docs/validation/s3-y32-4k-20261110/frozen-delivery.tar.gz`。下列命令会核验其SHA，把共享源码和向量解到新目录，叠加候选唯一RTL文件以及已审查的runner/checker guard更新，逐文件确认与实测source manifest完全相同，不运行仿真：

```sh
python3 REPLAY.py --baseline-archive /absolute/frozen-delivery.tar.gz --candidate a-acc41 --prepare-only --out /absolute/new-a-source-check
python3 REPLAY.py --baseline-archive /absolute/frozen-delivery.tar.gz --candidate b-raw41 --prepare-only --out /absolute/new-b-source-check
```

在授权的实验时限内，把 `--prepare-only` 改为 `--run` 并选全新out即可用本机Verilator重建并执行真实CPU完整12任务。默认最多2个编译作业；默认时限为2026-11-11 23:59上海时间。时限后的新实验需要重新获得授权并显式指定deadline。本包不会自动启动远端EDA或改写生产/子仓库。

## 生成器复现

例如在 `candidates/a-acc41/chisel` 目录执行原generation-commands.json中的scala-cli命令，把输出路径换为全新目录并传入41 48 48；B传41 41 41。默认48 48 48的11份SV必须与对应default目录逐字节匹配。安装文件等于 generation-result.json 的concat_order四文件以单个换行拼接；其余7个共享leaf保持默认原字节。原始campaign工具按原仓库布局保存，历史绝对路径和命令未改写；跨目录CPU复现使用本包REPLAY.py。

## 判定边界

两候选的名义声明存储节省分别为448位和1,792位，不能据此宣称面积改进。必须在同库同约束下完成候选综合/时序比较后选型。公共48位数值接口、最终Y32/RNE、真实清零、事务计数、旧回退和参数隔离保留。ELF只允许已独立审查的一个非装载FILE符号中6个随机字符变化，全部PT_LOAD及加载image相同；每份原ELF SHA仍保留。说明见CANDIDATE-SCOPE.md。
''')
manifest={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()};dump(OUT/'SHA256.json',manifest)
with tarfile.open(ARCHIVE,'w:gz') as tf:tf.add(OUT,arcname=OUT.name)
receipt={'status':'SEALED_SIMULATION_CANDIDATES_NOT_AREA_OR_STA_PASS','archive':str(ARCHIVE),'archive_sha256':sha(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,'files':len(manifest),'delivery_identity_sha256':sha(OUT/'DELIVERY.json'),'manifest_sha256':sha(OUT/'SHA256.json')}
dump(BASE/'delivery/sim-candidates-r1.receipt.json',receipt)
print(json.dumps(receipt,sort_keys=True))
