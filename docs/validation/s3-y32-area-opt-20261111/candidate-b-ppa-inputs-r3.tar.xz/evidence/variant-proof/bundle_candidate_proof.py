#!/usr/bin/env python3
"""Package existing independently verified evidence; never simulates or maps."""
import argparse,hashlib,json,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'build/area-opt-20261111'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def check(v,msg):
 if not v:raise ValueError(msg)

def main():
 p=argparse.ArgumentParser();p.add_argument('candidate',choices=['a-acc41','b-raw41']);p.add_argument('--review',required=True,type=Path);args=p.parse_args()
 name=args.candidate;cand=BASE/'candidates'/name;review=load(args.review)
 check(review['status']=='PASS' and review['candidate']==name and review['same_policy'],'independent terminal review required')
 for f,h in review['files'].items():check(sha(ROOT/f)==h,'independent review source/proof drift '+f)
 cpu=BASE/'cpu'/({'a-acc41':'a-full12-r1','b-raw41':'b-full12-r1'}[name]);result=load(cpu/'result.json');cpusha=sha(cpu/'result.json')
 check(result['status']=='PASS' and result['performance_scope']=='complete12' and result['outputs']==304128,'terminal complete12 missing')
 check(review['cpu_result_sha256']==cpusha,'independent review not bound to current full12 result')
 out=cand/'independent-synth-proof';check(not out.exists(),'refuse proof bundle overwrite');out.mkdir()
 def cp(source,target):
  dest=out/target;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
 for name_ in ['split.xml','concat.xml','split.log','concat.log','commands.json','proof.json']:
  cp(cand/'packaging-proof'/name_,'packaging/'+name_)
 for path in sorted((cand/'generated').glob('*.sv')):cp(path,'generated/'+path.name)
 cp(cand/'generation-result.json','generation-result.json')
 cp(cand/'install/LinearTileDmaCore.sv','installed-core.sv')
 cp(BASE/'candidates/bounds-and-state/result.json','bounds-and-state-result.json')
 cp(args.review,'independent-review.json')
 cp(cpu/'source-manifest.json','cpu-source-manifest.json')
 cp(cpu/'result.json','cpu-result.json')
 cp(Path(__file__),'bundle_candidate_proof.py')
 reviewer=BASE/'audit/independent_candidate_review_v2.py'
 check(sha(reviewer)==review['reviewer_script_sha256'],'final reviewer script drift')
 cp(reviewer,'independent_candidate_review_v2.py')
 cp(BASE/'comparison/firmware_identity.py','firmware_identity.py')
 firmware=review['cpu']['firmware_identity'];check(firmware['candidate_result_sha256']==cpusha,'firmware review not terminal-bound')
 dump(out/'firmware-exact-metadata-audit.json',firmware)
 rtl_f=cand/'packaging-proof/fulltop/rtl.f';cp(rtl_f,'rtl.f')
 geometry={'status':'PASS','scope':'Existing local fulltop XML and independent AST/type review; no mapping/STA claim',
  'geometry':review['geometry'],'macro_groups':review['macro_groups'],'active_cells':review['active_cells'],
  'active_specialized_modules':review['active_specialized_modules'],'legacy_compute_instances':0,
  'rtl_f_sha256':sha(rtl_f),'xml_sha256':sha(cand/'packaging-proof/concat.xml'),
  'independent_review_sha256':sha(args.review),'installed_cpu_result_sha256':cpusha}
 dump(out/'geometry-result.json',geometry)
 install={'status':'PASS','installed_cpu_result_sha256':cpusha,'installed_cpu_source_manifest_sha256':sha(cpu/'source-manifest.json'),
  'installed_sha256':sha(cand/'install/LinearTileDmaCore.sv'),'canonical_split_vs_installed_ast_equal':True,
  'complete_ast_type_canonical_sha256':review['independent_ast_type_canonical_sha256'],
  'only_installed_original_source_changed':review['only_installed_original_source_changed'],
  'fallback3_byte_identical':review['fallback3_byte_identical'],'default11_byte_identical':review['default11_byte_identical'],
  'independent_review_sha256':sha(args.review)}
 dump(out/'source-install-manifest.json',install)
 artifacts={'elaborated_xml':'packaging/concat.xml','elaboration_log':'packaging/concat.log',
  'split_elaborated_xml':'packaging/split.xml','split_elaboration_log':'packaging/split.log',
  'geometry_result':'geometry-result.json','source_install_manifest':'source-install-manifest.json',
  'independent_review':'independent-review.json','firmware_identity':'firmware-exact-metadata-audit.json'}
 files={str(f.relative_to(out)):sha(f) for f in sorted(out.rglob('*')) if f.is_file()}
 receipt={'schema':'s3-area-opt-independent-synth-proof-v1','status':'PASS','candidate':name,'cpu_result_sha256':cpusha,
  'files':files,'artifacts':artifacts,'scope':'Frozen existing full12, arithmetic, source, and split/concat proof. Not PPA/STA/official qualification.'}
 dump(out/'proof-receipt.json',receipt)
 print(json.dumps({'status':'PASS','candidate':name,'proof_root':str(out),'cpu_result_sha256':cpusha,'proof_receipt_sha256':sha(out/'proof-receipt.json')},sort_keys=True))

if __name__=='__main__':main()
