#!/usr/bin/env python3
"""Independent read-only A/B arithmetic, source, and packaging evidence audit.

Does not run simulation, technology mapping, or edit production sources.  The
complete-CPU verdict is separate, and cannot become PASS until the result is
terminal, source-bound and matches every published layer's cycle count.
"""
from __future__ import annotations
import argparse, hashlib, json, re, importlib.util
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
CANDS=ROOT/'build/area-opt-20261111/candidates'
TEMPLATE=ROOT/'build/area-opt-20261111/baseline-synth-r5/candidate'
PUBLISHED=ROOT/'build/parallel4k-20261110/core-generated-r1'
BASECPU=ROOT/'build/parallel4k-20261110/cpu-full12-r2'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(v,msg):
 if not v:raise ValueError(msg)

def independently_normalize(xml):
 """Recompute all active expression/process/type and complete cell identities."""
 root=ET.parse(xml).getroot();net=root.find('netlist')
 types={e.attrib['id']:e for e in net.find('typetable') if 'id' in e.attrib}
 done={};visiting=set()
 def type_digest(key):
  if key in done:return done[key]
  check(key not in visiting,'recursive type needs explicit handling')
  visiting.add(key);done[key]=node_digest(types[key],True);visiting.remove(key)
  return done[key]
 def node_digest(node,is_type=False):
  attrs=[]
  for k,v in sorted(node.attrib.items()):
   if k=='loc' or (is_type and k=='id'):continue
   attrs.append((k,type_digest(v) if k.endswith('dtype_id') else v))
  return digest([node.tag,attrs,[node_digest(c) for c in node]])
 modules={e.attrib['name']:node_digest(e) for e in net if e.tag in {'module','package','interface'}}
 cells=sorted((e.attrib['hier'],e.attrib['submodname']) for e in root.findall('./cells//cell'))
 return {'modules':modules,'types':sorted(set(type_digest(k) for k in types)),'cells':cells}

def review(name):
 cand=CANDS/name;gen=load(cand/'generation-result.json');pack=load(cand/'packaging-proof/proof.json')
 width={'a-acc41':(41,48,48),'b-raw41':(41,41,41)}[name]
 check(tuple(gen['widths'][k] for k in ['ACC','resultReg','FIFO'])==width,'wrong candidate width')
 for path,h in gen['snapshot_sources'].items():check(sha(cand/'chisel'/path)==h,'snapshot Chisel source drift '+path)
 expected_scala={'src/main/scala/dotproduct/MacPE.scala','src/main/scala/dotproduct/MacPEArray.scala','src/main/scala/dotproduct/DotProductEngine.scala','experiment/LinearTileDmaCore.scala','experiment/GenerateTileCore.scala'}
 changed_scala=[]
 for path in gen['snapshot_sources']:
  original=ROOT/('experiments/s3-y32-4k/core/'+path.removeprefix('experiment/')) if path.startswith('experiment/') else ROOT/path
  check(original.is_file(),'unknown snapshot source '+path)
  if sha(original)!=sha(cand/'chisel'/path):changed_scala.append(path)
 check(set(changed_scala)==expected_scala,'unexpected Chisel source changes')
 generated={p.name:sha(p) for p in (cand/'generated').glob('*.sv')}
 check(generated==gen['generated_rtl'] and len(generated)==11,'generated RTL drift')
 defaults={p.name:sha(p) for p in (cand/'default').glob('*.sv')}
 check(defaults=={p.name:sha(p) for p in PUBLISHED.glob('*.sv')} and len(defaults)==11,'default48 differs from publication')
 for n in gen['unchanged7']:check(sha(cand/'generated'/n)==sha(PUBLISHED/n),'shared leaf changed '+n)
 install=cand/'install/LinearTileDmaCore.sv'
 expected='\n'.join((cand/'generated'/n).read_text() for n in gen['concat_order'])
 check(install.read_text()==expected and sha(install)==gen['install_files']['LinearTileDmaCore.sv']==pack['install_sha256'],'install not exact concatenation')
 paths=(TEMPLATE/'rtl.f').read_text().splitlines();check(len(paths)==158,'R5 source list count')
 full=cand/'packaging-proof/fulltop'
 changed=[n for n in paths if sha(full/n)!=sha(TEMPLATE/n)]
 check(changed==['source/rtl/perips/LinearTileDmaCore.sv'],'unexpected packaged source delta')
 for n in ['MacPE.sv','MacPEArray.sv','DotProductEngine.sv']:
  check(sha(full/'source/rtl/perips'/n)==sha(TEMPLATE/'source/rtl/perips'/n),'legacy fallback differs')
 check(sha(full/'source/contracts/reference-full-soc.sdc')==sha(TEMPLATE/'source/contracts/reference-full-soc.sdc'),'SDC drift')
 check((full/'rtl.f').read_bytes()==(TEMPLATE/'rtl.f').read_bytes(),'RTL source paths drift')

 # Exact signed product extrema use endpoints and the only integer stationary
 # point zero.  Bilinearity makes endpoint extrema exhaustive.
 signed16=[-(1<<15),0,(1<<15)-1]
 products=[a*b for a in signed16 for b in signed16]
 pmin,pmax=min(products),max(products)
 check((pmin,pmax)==(-1073709056,1073741824),'product range')
 bounds=[{'n':n,'lower':-(1<<39)+n*pmin,'upper':(1<<39)-1+n*pmax} for n in range(65)]
 check(all(-(1<<40)<=v['lower']<=v['upper']<(1<<40) for v in bounds),'41bit prefix overflow')
 check(bounds[-1]['lower']<-(1<<39) and bounds[-1]['upper']>(1<<39)-1,'40bit negative control invalid')
 prior=load(CANDS/'bounds-and-state/result.json')
 check(bounds==prior['prefix_bounds'],'recorded prefix bounds drift')
 pe=(cand/'generated/MacPE_Acc41.sv').read_text()
 for needle in ['reg  [40:0] ACC;',"ACC <= {io_bias[39], io_bias};",'ACC <= ACC + {{9{_ACC_T[31]}}, _ACC_T};','assign io_result = {{7{ACC[40]}}, ACC};']:
  check(needle in pe,'ACC arithmetic sign/width changed: '+needle)
 mul=next(l.strip() for l in pe.splitlines() if '_ACC_T =' in l)
 check(mul==next(l.strip() for l in (PUBLISHED/'MacPE.sv').read_text().splitlines() if '_ACC_T =' in l),'multiplier changed')
 eng=(cand/'generated'/gen['concat_order'][2]).read_text();tile=(cand/'generated/LinearTileDmaCore.sv').read_text()
 regs=re.findall(r'reg\s+\[(\d+):0\] resultReg_\d+;',eng)
 check(regs==[str(width[1]-1)]*8,'engine result storage geometry')
 fifo=re.findall(r'reg\s+\[(\d+):0\] results_\d_\d_\d;',tile)
 check(fifo==[str(width[2]-1)]*128,'FIFO raw geometry')
 if width[1]==41:
  check(len(re.findall(r'assign io_result_\d = \{\{7\{resultReg_\d\[40\]\}\}, resultReg_\d\};',eng))==8,'engine lacks complete sign extension')
  check(len(re.findall(r'resultReg_\d <= _peArray_io_result_\d\[40:0\];',eng))==8,'engine capture not exact low41')
  check(len(re.findall(r'assign io_outResult_\d = \{\{7\{casez_tmp(?:_\d+)?\[40\]\}\}, casez_tmp(?:_\d+)?\};',tile))==8,'FIFO output lacks sign extension')
  check(len(re.findall(r'results_\d_\d_\d <= _engines_\d_io_result_\d\[40:0\];',tile))==128,'FIFO capture not exact low41')
 else:
  normalized=eng.replace('DotProductEngine_Acc41_Result48','DotProductEngine').replace('MacPEArray_Acc41','MacPEArray')
  check(normalized==(PUBLISHED/'DotProductEngine.sv').read_text(),'A engine changes more than names')

 split=independently_normalize(cand/'packaging-proof/split.xml')
 concat=independently_normalize(cand/'packaging-proof/concat.xml')
 check(split==concat,'split and concatenated full active AST/types differ')
 cells=concat['cells'];counts={n:sum(m==n for _,m in cells) for _,n in cells}
 geometry={'mac_pe':sum(v for k,v in counts.items() if k.startswith('MacPE_Acc')),'engines':sum(v for k,v in counts.items() if k.startswith('DotProductEngine_Acc')),'sram_macros':counts.get('RAMSP1024X16')}
 check(geometry=={'mac_pe':64,'engines':8,'sram_macros':337},'fulltop geometry mismatch')
 check(not any(n in {'MacPE','MacPEArray','DotProductEngine'} for _,n in cells),'legacy compute active in variant')
 macros=[p for p,n in cells if n=='RAMSP1024X16']
 groups={k:sum(test(p) for p in macros) for k,test in {'weights':lambda p:'.u_core.weights.' in p,'bias':lambda p:'.u_core.bias.' in p,'shared':lambda p:'.u_shared.' in p,'itcm':lambda p:'itcm' in p,'dtcm':lambda p:'dtcm' in p}.items()}
 check(groups=={'weights':16,'bias':1,'shared':256,'itcm':32,'dtcm':32},'macro grouping mismatch')
 check(len(set(macros))==337,'duplicate macro instance scopes')
 rne_source=full/'source/rtl/perips/xu_matrix_dma64.sv'
 check(sha(rne_source)==sha(TEMPLATE/'source/rtl/perips/xu_matrix_dma64.sv'),'DMA/RNE source changed')
 check("q=$signed(value)>>>9;" in rne_source.read_text() and "if(value[8:0]>256||(value[8:0]==256&&q[0]))q=q+48'sd1;" in rne_source.read_text(),'RNE semantics not original')
 cpu=ROOT/'build/area-opt-20261111/cpu'/({'a-acc41':'a-full12-r1','b-raw41':'b-full12-r1'}[name])
 result=load(cpu/'result.json');base=load(BASECPU/'result.json')
 cpu_state=result.get('status');cpu_summary={'status':cpu_state,'result_path':str(cpu/'result.json'),'result_sha256':sha(cpu/'result.json')}
 if cpu_state=='PASS':
  check(result.get('outputs')==304128 and result.get('performance_scope')=='complete12','not complete full12')
  sources=load(cpu/'source-manifest.json')['files'];check(sources==result['source_sha256'],'CPU source receipt disagreement')
  check(sources['rtl/perips/LinearTileDmaCore.sv']==sha(install),'CPU not same installed tile')
  base_sources=load(BASECPU/'source-manifest.json')['files']
  source_delta=sorted(k for k in sources if sources[k]!=base_sources[k])
  check(source_delta==['check_results.py','rtl/perips/LinearTileDmaCore.sv','run_cpu.py'],'CPU other source delta')
  approved_pairs={('526faf2dfd4377cd8add9703157a9aea5800272916d713aa0eb10063dcd6af98','392e111b276001998c2f5f822df2eabdd9d34cf02f1f91f0f9765f4964c31633'),('353a96056da7b5bd5218df78778c378a825ef120e1ca3634f082c21e53efc6a0','b485a5f24f70a3973d867af2d8ee5e7f0035330a1b3a06e2b6b0fa82914336d2')}
  for data in [base,result]:check((data['source_sha256']['run_cpu.py'],data['source_sha256']['check_results.py']) in approved_pairs,'unreviewed CPU runner/checker pair')
  checker=cpu/'source/check_results.py';check(sha(checker)=='b485a5f24f70a3973d867af2d8ee5e7f0035330a1b3a06e2b6b0fa82914336d2','unreviewed common parser')
  spec=importlib.util.spec_from_file_location('candidate_raw_log_checker',checker);common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
  for directory,data in [(BASECPU,base),(cpu,result)]:
   parsed=common.check_log((directory/'simulation.log').read_text(),12,8,True)
   for field,value in parsed.items():check(data.get(field)==value,'raw simulation log and result disagree '+field)
  cpu_summary['audited_nonrtl_source_deltas']={'check_results.py':'Four stronger duration/nonoverlap guards only; no measurement boundary or output computation change','run_cpu.py':'Replay simulator/throttle guards only; runtime source snapshot unchanged'}
  check(all(sha(cpu/'source'/k)==v for k,v in sources.items()),'sealed CPU source drift')
  check(result['physical_clear'] and not result.get('source_drift'),'CPU clear/source drift')
  check(result['firmware']['image_sha256']==base['firmware']['image_sha256'],'CPU loaded firmware image changed')
  fwtool=ROOT/'build/area-opt-20261111/comparison/firmware_identity.py'
  check(sha(fwtool)=='3e11bb582be4f58937a184a917c9f3bc8f17e59b5eb976f4a90b50a09b111809','unreviewed firmware metadata auditor')
  spec=importlib.util.spec_from_file_location('candidate_firmware_identity',fwtool);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  firmware_audit=mod.audit_firmware(BASECPU,cpu)
  check(firmware_audit['status']=='PASS','CPU firmware executable bytes changed')
  cpu_summary['firmware_identity']=firmware_audit
  check(result['vectors']==base['vectors'] and result['vector_export']==base['vector_export'],'vector identity changed')
  check(len(result['layers'])==12,'missing layer')
  for a,b in zip(result['layers'],base['layers']):
   check(a['layer']==b['layer'] and a['outputs']==b['outputs'],'layer identity/count')
   for key in ['principal','including_gap','firmware_cycles']:check(a[key]<=b[key],'layer cycle regression '+str((a['layer'],key)))
   for key in ['clear','counters']:check(a[key]==b[key],'clear/transactions changed '+str((a['layer'],key)))
  for key in ['principal_cycles','including_gap_cycles']:check(result[key]<=base[key],'aggregate cycle regression')
  cpu_summary.update({k:result[k] for k in ['outputs','principal_cycles','including_gap_cycles','clear_cycles','gap_cycles']})
 files=[cand/'generation-result.json',cand/'packaging-proof/proof.json',cand/'packaging-proof/split.xml',cand/'packaging-proof/concat.xml',install,CANDS/'bounds-and-state/result.json',rne_source]
 files+=sorted((cand/'generated').glob('*.sv'))
 receipt={'schema':'s3-area-opt-independent-candidate-review-v1','status':'PASS' if cpu_state=='PASS' else 'STATIC_PASS_CPU_PENDING','same_policy':True,
  'candidate':name,'widths':dict(zip(['ACC','resultReg','FIFO'],width)),
  'scope':'Independent source/arithmetic/packaging audit plus full12 source and cycle gate when terminal; no mapped equivalence, area or STA claim',
  'cpu_result_sha256':cpu_summary['result_sha256'] if cpu_state=='PASS' else None,'cpu':cpu_summary,
  'geometry':geometry,'macro_groups':groups,'active_cells':len(cells),'active_specialized_modules':len(concat['modules']),
  'independent_ast_type_canonical_sha256':digest(concat),'complete_split_concat_ast_type_equal':True,'default11_byte_identical':True,'fallback3_byte_identical':True,
  'only_installed_original_source_changed':changed,'signed16_product_range':[pmin,pmax],'prefix_bounds':bounds,'signed41_range':[-(1<<40),(1<<40)-1],
  'signed40_negative_control_insufficient':True,'no_intermediate_rounding':True,'public48_sign_extension_before_original_dma_rne':True,
  'nominal_declared_storage_reduction_bits':448 if name=='a-acc41' else 1792,
  'nominal_storage_reduction_is_not_mapped_area_claim':True,
  'files':{str(p.relative_to(ROOT)):sha(p) for p in files},'reviewer_script_sha256':sha(__file__)}
 return receipt

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('candidate',choices=['a-acc41','b-raw41']);ap.add_argument('--out',required=True,type=Path);args=ap.parse_args()
 check(not args.out.exists(),'refuse overwrite receipt')
 result=review(args.candidate);args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'status':result['status'],'candidate':args.candidate,'out':str(args.out),'cpu':result['cpu']},sort_keys=True))
