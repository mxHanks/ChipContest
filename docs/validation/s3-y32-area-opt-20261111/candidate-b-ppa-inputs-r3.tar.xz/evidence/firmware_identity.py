#!/usr/bin/env python3
"""Audit exact ELF identity except one GCC temporary STT_FILE basename.

This does not treat equal images as sufficient: every ELF byte outside the six
random characters of one non-ALLOC LOCAL/FILE/ABS symbol must be identical.
No ELF, firmware, or previous measurement is modified.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def temporary_symbol(data):
    require(len(data) >= 52, 'ELF too short')
    header = struct.unpack_from('<16sHHIIIIIHHHHHH', data, 0)
    ident, typ, machine = header[:3]
    require(ident[:7] == b'\x7fELF\x01\x01\x01', 'not ELF32 little-endian v1')
    require(typ == 2 and machine == 243, 'not RISC-V executable')
    phoff, shoff = header[5:7]
    phsize, phnum, shsize, shnum, shstr = header[9:14]
    require(shsize == 40 and phsize == 32, 'unexpected ELF table sizes')
    require(0 < shnum < 1024 and shstr < shnum, 'unsupported section table')
    require(shoff + shnum * shsize <= len(data), 'truncated section table')
    require(phoff + phnum * phsize <= len(data), 'truncated program table')
    sections = [struct.unpack_from('<10I', data, shoff+i*shsize) for i in range(shnum)]
    def section_bytes(sec):
        require(sec[4] + sec[5] <= len(data), 'truncated section')
        return data[sec[4]:sec[4]+sec[5]]
    shnames = section_bytes(sections[shstr])
    def string(table, off):
        require(0 <= off < len(table), 'string offset out of range')
        end = table.find(b'\0', off)
        require(end >= 0, 'unterminated ELF string')
        return table[off:end]
    names = [string(shnames, s[0]).decode('ascii') for s in sections]
    require(names.count('.symtab') == names.count('.strtab') == 1, 'ambiguous symbol tables')
    si, ti = names.index('.symtab'), names.index('.strtab')
    sym, strs = sections[si], sections[ti]
    require(sym[1] == 2 and sym[9] == 16 and sym[5] % 16 == 0, 'unexpected symbol table')
    require(sym[6] == ti and strs[1] == 3, 'symbol string table linkage')
    require(not (sym[2] & 2) and not (strs[2] & 2), 'symbol metadata is allocated')
    rawsym, rawstr = section_bytes(sym), section_bytes(strs)
    matches = []
    for i in range(sym[5] // 16):
        name, value, size, info, other, ndx = struct.unpack_from('<IIIBBH', rawsym, i*16)
        text = string(rawstr, name)
        if re.fullmatch(rb'cc[A-Za-z0-9]{6}\.o', text):
            require((info, other, ndx, value, size) == (4, 0, 0xfff1, 0, 0),
                    'temporary name is not a LOCAL/FILE/ABS metadata symbol')
            require(i < sym[7], 'temporary file symbol not in local partition')
            offset = strs[4] + name
            require(offset >= strs[4] and offset + 11 <= strs[4]+strs[5], 'temporary string bounds')
            # A PT_LOAD that includes symbol metadata would make this exception unsafe.
            for j in range(phnum):
                p = struct.unpack_from('<8I', data, phoff+j*phsize)
                if p[0] == 1:
                    require(not (max(offset, p[1]) < min(offset+11, p[1]+p[4])),
                            'temporary symbol bytes overlap PT_LOAD')
            matches.append({'symbol_index':i, 'offset':offset, 'name':text.decode('ascii'),
                            'symbol_section':si, 'string_section':ti})
    require(len(matches) == 1, 'expected exactly one GCC temporary FILE symbol')
    return matches[0]


def audit_elf_bytes(base, candidate):
    require(len(base) == len(candidate), 'ELF size differs')
    b, c = temporary_symbol(base), temporary_symbol(candidate)
    require({k:v for k,v in b.items() if k != 'name'} ==
            {k:v for k,v in c.items() if k != 'name'}, 'temporary symbol structure differs')
    start, end = b['offset']+2, b['offset']+8
    require(base[:start] == candidate[:start] and base[end:] == candidate[end:],
            'ELF byte difference outside the six temporary-name characters')
    return {'status':'PASS', 'policy':'EXACT_ELF_EXCEPT_ONE_NONALLOC_LOCAL_FILE_ABS_GCC_TEMP_NAME_6_CHARS',
            'baseline_elf_sha256':digest(base), 'candidate_elf_sha256':digest(candidate),
            'whole_elf_bytes':len(base), 'baseline_temporary_symbol':b,
            'candidate_temporary_symbol':c, 'allowed_byte_offsets':list(range(start,end)),
            'actual_differing_offsets':[i for i,(x,y) in enumerate(zip(base,candidate)) if x != y],
            'all_other_elf_bytes_equal':True, 'all_program_headers_and_PT_LOAD_bytes_equal':True}


def audit_firmware(base_root, candidate_root):
    base_root, candidate_root = Path(base_root), Path(candidate_root)
    b, c = base_root/'firmware/dma_day_soc', candidate_root/'firmware/dma_day_soc'
    result = audit_elf_bytes(b.read_bytes(), c.read_bytes())
    bi, ci = base_root/'firmware/dma_day_soc.verilog', candidate_root/'firmware/dma_day_soc.verilog'
    require(bi.read_bytes() == ci.read_bytes(), 'loaded firmware image differs')
    for root in [base_root, candidate_root]:
        data = json.loads((root/'result.json').read_text())
        require(digest((root/'firmware/dma_day_soc').read_bytes()) == data['firmware']['elf_sha256'], 'recorded ELF SHA drift')
        require(digest((root/'firmware/dma_day_soc.verilog').read_bytes()) == data['firmware']['image_sha256'], 'recorded image SHA drift')
    result.update(baseline_root=str(base_root.resolve()), candidate_root=str(candidate_root.resolve()),
                  baseline_result_sha256=digest((base_root/'result.json').read_bytes()),
                  candidate_result_sha256=digest((candidate_root/'result.json').read_bytes()),
                  loaded_image_sha256=digest(bi.read_bytes()), loaded_image_byte_identical=True,
                  audit_tool_sha256=digest(Path(__file__).read_bytes()))
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline-cpu',required=True,type=Path)
    p.add_argument('--candidate-cpu',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    args=p.parse_args()
    result=audit_firmware(args.baseline_cpu, args.candidate_cpu)
    require(not args.out.exists(), 'refuse audit overwrite')
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'out':str(args.out)}))


if __name__ == '__main__':
    main()
