# Frozen published 64 PE baseline, November 11 synthesis package

Prepared locally only; no remote connection or EDA invocation is performed by
the preparer. Published parent is d60e0e00d79051747b8adcfa39fca273a6e7e309;
child is a80dd184536e0f2312c62768d5acf4ba1b01c34e. The complete CPU result
is 428,915 principal cycles for 12 tasks and 304,128 exact Y32 outputs.
It is not proof of achieved 150 MHz frequency.

Local input review only:

```sh
python3 run_once.py
```

After upload/extraction into a NEW dedicated server directory, explicit run:

```sh
python3 run_once.py --run
```

The runner permits at most two cores, refuses every same-account heavy EDA or
simulation job, refuses overwrite/restart, blocks new experiments after
2026-11-11 23:59 Asia/Shanghai, and terminates only its own process group at
the deadline. There is no exception for the historical simv PID. No credentials
are included. The remote coordinator must verify resource availability before
launch; this package does not inspect or modify another user's work.

The SS/0.99 V/125 C standard-cell and RAMSP1024X16 DB paths and hashes, DC
executable identity, RTL, top, defines, SRAM adapters, compile settings, and
reference SDC are identical to the prior sealed final-r3 package.
`baseline-identity.json` records exact differences: only the deadline/resource
guard and read-only reporting are changed. The SDC remains provisional.

Hierarchy is checked before/after mapping: 64 PE, eight engines, 16 W SRAM,
one bias SRAM, 32 ITCM, 32 DTCM, 256 shared, total 337 macros. The leaf inventory
and area-components.tsv charge the complete DMA, its 17 internal SRAM, new
arbiter, and all modified shared endpoint standard logic. Reused shared SRAM
is listed but excluded from the charged total. Disjoint area components include
weights, bias, X double buffers, 64-PE engines, FIFO/control, DMA scheduler,
arbiter, and endpoint. Raw leaf and hierarchy reports are retained.

The collector preserves setup/hold, all clock groups, accelerator register
paths, gating, recovery/removal, pulse width, DRC, exceptions, and coverage.
Known-incompatible `get_clocks -of_objects` is not invoked. A clock association
query is permitted only if the native pin attribute inventory proves `clocks`
is a collection. Known unsupported DC commands are not invoked again. Their required PT reports
produce `.unavailable.txt` and an explicit
incomplete signoff report status; they cannot turn into a timing PASS. The
DC mapping receipt may complete while these standalone PT reports are still
missing; mapping and timing qualification are separate fields. Mapping outputs
are independently recorded in the execution receipt even if reporting fails.

No new path exceptions, ideal clocks, relaxed IO/gating/hold constraints or
other timing changes are introduced. Synthesis completion is not timing
closure, functional equivalence, achieved 150 MHz, or contest qualification.
Area remains in library units until authoritative area dimension and organizer
SRAM prices are verified; no mm² or 2.25 mm² verdict may be inferred here.

## Unreachable legacy source-list portability fix

R2 native DC failed analysis of the inactive legacy accel_icb_slave module on
forward declarations. This package removes only that file from rtl.f. Its bytes
remain unchanged in source/rtl/perips for the old-interface fallback. No active
RTL is modified. The exact defines select xu_matrix_dma64; full-top Verilator
XML elaboration before and after exclusion has identical active hierarchy,
64 PE, eight engines,337 macros, and zero accel_icb_slave instances. See
evidence/legacy-source-exclusion/proof.json and raw XML. This is an analysis
source-list portability fix; it adds no timing exceptions or functional change.

## R4 inactive source closure

R3 DC next reported forward declarations in inactive16PE xu_matrix_dma.sv.
R4 excludes that source and six other unreachable, preprocessor-side-effect-free
module files from analysis. All source bytes remain in the package. Full-top XML
re-elaboration preserves every one of1409 active cells,64 PE,8 engines,337 macros.
Inactive files with define/undef/include directives remain conservatively in the
list. See evidence/inactive-source-closure/proof.json and raw XML. This proof is
not native DC acceptance; no active source declaration or behavior is modified.

## R5 active-main declaration portability

Native R4 Presto rejected DMA nets declared after their first child-instance
use. R5 moves only the complete unchanged cpu_sysmem/DMA wire declaration
block before that child instance, preserving both64/32-bit preprocessor arms.
No expression, type, width, connection, behavior, SDC or compile setting changes.
Full-top XML active logical/type AST matches after ignoring source locations and
pure declaration order; Yosys independently proves all main/interface matched
bits with child outputs arbitrary. See evidence/main-declaration-portability.
This is neither CPU performance evidence nor mapped functional qualification.
