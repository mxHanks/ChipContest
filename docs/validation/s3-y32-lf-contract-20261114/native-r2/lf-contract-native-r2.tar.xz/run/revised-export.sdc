###############################################################################
#
# Created by PrimeTime write_sdc on Sat Nov 14 11:12:02 2026
#
###############################################################################

set sdc_version 2.1

set_units -time ns -capacitance pF -current mA -voltage V -resistance kOhm
###############################################################################
#  
# Units
# capacitive_load_unit           : 1 pF
# current_unit                   : 0.001 A
# resistance_unit                : 1 kOhm
# time_unit                      : 1 ns
# voltage_unit                   : 1 V
###############################################################################
set_operating_conditions -analysis_type on_chip_variation  -library [get_libs \
 {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db:scc40nll_vhsc40_rvt_ss_v0p99_125c_basic}] 
###############################################################################
# Clock Related Information
###############################################################################
create_clock -name xu_hfextclk -period 6.666667 -waveform { 0 3.333333 } \
 [get_ports {hfextclk}]
set_clock_uncertainty  0.1 [get_clocks {xu_hfextclk}]
set_clock_gating_check -rise -setup  0.1 [get_clocks {xu_hfextclk}]
set_clock_gating_check -fall -setup  0.1 [get_clocks {xu_hfextclk}]
set_clock_gating_check -rise -hold  0.1 [get_clocks {xu_hfextclk}]
set_clock_gating_check -fall -hold  0.1 [get_clocks {xu_hfextclk}]
set_clock_transition -rise -max  0.1 [get_clocks {xu_hfextclk}]
set_clock_transition -fall -max  0.1 [get_clocks {xu_hfextclk}]
set_clock_transition -rise -min  0.1 [get_clocks {xu_hfextclk}]
set_clock_transition -fall -min  0.1 [get_clocks {xu_hfextclk}]
create_clock -name xu_lfextclk -period 30517.578125 -waveform { 0 15258.789062 \
 } [get_ports {lfextclk}]
set_clock_uncertainty  0.1 [get_clocks {xu_lfextclk}]
set_clock_gating_check -rise -setup  0.1 [get_clocks {xu_lfextclk}]
set_clock_gating_check -fall -setup  0.1 [get_clocks {xu_lfextclk}]
set_clock_gating_check -rise -hold  0.1 [get_clocks {xu_lfextclk}]
set_clock_gating_check -fall -hold  0.1 [get_clocks {xu_lfextclk}]
set_clock_transition -rise -max  0.1 [get_clocks {xu_lfextclk}]
set_clock_transition -fall -max  0.1 [get_clocks {xu_lfextclk}]
set_clock_transition -rise -min  0.1 [get_clocks {xu_lfextclk}]
set_clock_transition -fall -min  0.1 [get_clocks {xu_lfextclk}]
create_clock -name xu_jtag_tck -period 100 -waveform { 0 50 } [get_ports \
 {io_pads_jtag_TCK_i_ival}]
set_clock_uncertainty  0.1 [get_clocks {xu_jtag_tck}]
set_clock_gating_check -rise -setup  0.1 [get_clocks {xu_jtag_tck}]
set_clock_gating_check -fall -setup  0.1 [get_clocks {xu_jtag_tck}]
set_clock_gating_check -rise -hold  0.1 [get_clocks {xu_jtag_tck}]
set_clock_gating_check -fall -hold  0.1 [get_clocks {xu_jtag_tck}]
set_clock_transition -rise -max  0.1 [get_clocks {xu_jtag_tck}]
set_clock_transition -fall -max  0.1 [get_clocks {xu_jtag_tck}]
set_clock_transition -rise -min  0.1 [get_clocks {xu_jtag_tck}]
set_clock_transition -fall -min  0.1 [get_clocks {xu_jtag_tck}]
###############################################################################
# Derived Clock related information
###############################################################################
create_generated_clock -name xu_plldiv_envelope -source [get_pins \
 {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_hclkgen/u_e203_subsys_pllclkdiv/clk}] \
  -divide_by 1  -add -master_clock [get_clocks {xu_hfextclk}] [get_pins \
 {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_hclkgen/u_e203_subsys_pllclkdiv/clkout}] 
set_clock_gating_check -rise -setup  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_gating_check -fall -setup  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_gating_check -rise -hold  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_gating_check -fall -hold  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_uncertainty  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_transition -rise -max  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_transition -fall -max  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_transition -rise -min  0.1 [get_clocks {xu_plldiv_envelope}]
set_clock_transition -fall -min  0.1 [get_clocks {xu_plldiv_envelope}]
###############################################################################
# External Delay Information
###############################################################################
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_valid}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_valid}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[31]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[31]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[30]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[30]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[29]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[29]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[28]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[28]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[27]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[27]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[26]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[26]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[25]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[25]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[24]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[24]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[23]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[23]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[22]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[22]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[21]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[21]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[20]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[20]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[19]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[19]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[18]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[18]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[17]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[17]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[16]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[16]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[15]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[15]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[14]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[14]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[13]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[13]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[12]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[12]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[11]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[11]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[10]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[10]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[9]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[9]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[8]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[8]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[7]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[7]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[6]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[6]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[5]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[5]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[4]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[4]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[3]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[3]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[2]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[2]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[1]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[1]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_addr[0]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_addr[0]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_read}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_read}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[31]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[31]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[30]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[30]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[29]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[29]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[28]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[28]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[27]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[27]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[26]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[26]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[25]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[25]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[24]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[24]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[23]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[23]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[22]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[22]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[21]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[21]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[20]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[20]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[19]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[19]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[18]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[18]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[17]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[17]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[16]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[16]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[15]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[15]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[14]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[14]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[13]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[13]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[12]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[12]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[11]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[11]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[10]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[10]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[9]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[9]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[8]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[8]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[7]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[7]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[6]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[6]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[5]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[5]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[4]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[4]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[3]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[3]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[2]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[2]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[1]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[1]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wdata[0]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wdata[0]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wmask[3]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wmask[3]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wmask[2]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wmask[2]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wmask[1]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wmask[1]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_wmask[0]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_wmask[0]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_ready}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_ready}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[31]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[31]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[30]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[30]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[29]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[29]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[28]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[28]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[27]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[27]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[26]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[26]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[25]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[25]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[24]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[24]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[23]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[23]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[22]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[22]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[21]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[21]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[20]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[20]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[19]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[19]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[18]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[18]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[17]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[17]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[16]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[16]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[15]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[15]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[14]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[14]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[13]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[13]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[12]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[12]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[11]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[11]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[10]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[10]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[9]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[9]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[8]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[8]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[7]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[7]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[6]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[6]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[5]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[5]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[4]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[4]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[3]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[3]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[2]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[2]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[1]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[1]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_i_ival[0]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_i_ival[0]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[31]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[31]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[30]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[30]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[29]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[29]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[28]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[28]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[27]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[27]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[26]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[26]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[25]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[25]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[24]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[24]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[23]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[23]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[22]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[22]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[21]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[21]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[20]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[20]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[19]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[19]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[18]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[18]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[17]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[17]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[16]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[16]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[15]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[15]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[14]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[14]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[13]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[13]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[12]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[12]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[11]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[11]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[10]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[10]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[9]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[9]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[8]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[8]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[7]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[7]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[6]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[6]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[5]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[5]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[4]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[4]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[3]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[3]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[2]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[2]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[1]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[1]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_i_ival[0]}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_i_ival[0]}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_0_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_0_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_1_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_1_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_2_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_2_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_3_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_3_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -fall -max [get_ports \
 {io_pads_aon_erst_n_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -fall -min [get_ports \
 {io_pads_aon_erst_n_i_ival}]
set_input_delay  2 -clock [get_clocks {xu_lfextclk}] -clock_fall -rise -max \
 -add_delay [get_ports {io_pads_aon_erst_n_i_ival}]
set_input_delay  1 -clock [get_clocks {xu_lfextclk}] -clock_fall -rise -min \
 -add_delay [get_ports {io_pads_aon_erst_n_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_dbgmode0_n_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_dbgmode0_n_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_dbgmode1_n_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_dbgmode1_n_i_ival}]
set_input_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_dbgmode2_n_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_dbgmode2_n_i_ival}]
set_input_delay  5 -clock [get_clocks {xu_jtag_tck}] -max [get_ports \
 {io_pads_jtag_TMS_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_jtag_tck}] -min [get_ports \
 {io_pads_jtag_TMS_i_ival}]
set_input_delay  5 -clock [get_clocks {xu_jtag_tck}] -max [get_ports \
 {io_pads_jtag_TDI_i_ival}]
set_input_delay  0 -clock [get_clocks {xu_jtag_tck}] -min [get_ports \
 {io_pads_jtag_TDI_i_ival}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_cmd_ready}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_cmd_ready}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_valid}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_valid}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_err}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_err}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[31]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[31]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[30]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[30]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[29]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[29]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[28]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[28]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[27]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[27]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[26]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[26]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[25]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[25]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[24]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[24]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[23]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[23]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[22]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[22]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[21]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[21]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[20]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[20]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[19]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[19]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[18]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[18]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[17]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[17]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[16]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[16]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[15]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[15]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[14]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[14]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[13]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[13]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[12]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[12]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[11]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[11]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[10]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[10]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[9]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[9]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[8]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[8]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[7]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[7]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[6]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[6]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[5]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[5]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[4]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[4]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[3]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[3]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[2]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[2]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[1]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[1]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {sysbus_load_rsp_rdata[0]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {sysbus_load_rsp_rdata[0]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {hfxoscen}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {hfxoscen}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {lfxoscen}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {lfxoscen}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[31]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[31]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[30]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[30]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[29]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[29]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[28]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[28]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[27]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[27]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[26]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[26]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[25]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[25]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[24]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[24]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[23]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[23]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[22]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[22]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[21]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[21]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[20]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[20]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[19]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[19]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[18]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[18]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[17]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[17]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[16]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[16]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[15]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[15]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[14]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[14]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[13]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[13]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[12]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[12]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[11]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[11]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[10]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[10]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[9]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[9]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[8]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[8]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[7]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[7]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[6]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[6]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[5]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[5]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[4]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[4]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[3]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[3]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[2]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[2]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[1]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[1]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oval[0]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oval[0]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[31]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[31]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[30]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[30]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[29]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[29]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[28]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[28]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[27]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[27]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[26]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[26]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[25]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[25]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[24]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[24]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[23]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[23]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[22]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[22]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[21]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[21]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[20]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[20]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[19]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[19]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[18]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[18]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[17]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[17]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[16]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[16]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[15]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[15]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[14]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[14]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[13]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[13]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[12]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[12]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[11]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[11]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[10]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[10]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[9]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[9]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[8]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[8]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[7]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[7]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[6]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[6]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[5]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[5]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[4]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[4]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[3]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[3]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[2]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[2]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[1]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[1]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioA_o_oe[0]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioA_o_oe[0]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[31]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[31]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[30]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[30]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[29]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[29]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[28]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[28]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[27]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[27]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[26]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[26]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[25]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[25]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[24]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[24]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[23]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[23]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[22]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[22]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[21]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[21]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[20]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[20]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[19]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[19]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[18]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[18]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[17]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[17]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[16]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[16]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[15]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[15]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[14]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[14]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[13]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[13]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[12]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[12]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[11]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[11]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[10]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[10]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[9]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[9]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[8]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[8]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[7]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[7]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[6]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[6]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[5]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[5]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[4]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[4]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[3]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[3]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[2]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[2]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[1]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[1]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oval[0]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oval[0]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[31]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[31]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[30]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[30]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[29]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[29]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[28]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[28]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[27]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[27]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[26]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[26]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[25]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[25]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[24]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[24]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[23]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[23]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[22]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[22]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[21]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[21]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[20]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[20]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[19]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[19]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[18]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[18]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[17]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[17]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[16]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[16]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[15]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[15]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[14]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[14]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[13]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[13]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[12]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[12]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[11]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[11]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[10]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[10]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[9]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[9]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[8]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[8]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[7]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[7]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[6]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[6]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[5]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[5]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[4]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[4]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[3]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[3]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[2]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[2]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[1]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[1]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_gpioB_o_oe[0]}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_gpioB_o_oe[0]}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_sck_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_sck_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_cs_0_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_cs_0_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_0_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_0_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_0_o_oe}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_0_o_oe}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_1_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_1_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_1_o_oe}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_1_o_oe}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_2_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_2_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_2_o_oe}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_2_o_oe}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_3_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_3_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_qspi0_dq_3_o_oe}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_qspi0_dq_3_o_oe}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_aon_pmu_padrst_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_aon_pmu_padrst_o_oval}]
set_output_delay  0.5 -clock [get_clocks {xu_hfextclk}] -max [get_ports \
 {io_pads_aon_pmu_vddpaden_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_hfextclk}] -min [get_ports \
 {io_pads_aon_pmu_vddpaden_o_oval}]
set_output_delay  5 -clock [get_clocks {xu_jtag_tck}] -max [get_ports \
 {io_pads_jtag_TDO_o_oval}]
set_output_delay  0 -clock [get_clocks {xu_jtag_tck}] -min [get_ports \
 {io_pads_jtag_TDO_o_oval}]
set_output_delay  5 -clock [get_clocks {xu_jtag_tck}] -max [get_ports \
 {io_pads_jtag_TDO_o_oe}]
set_output_delay  0 -clock [get_clocks {xu_jtag_tck}] -min [get_ports \
 {io_pads_jtag_TDO_o_oe}]
set_input_delay  2 -clock [get_clocks {xu_lfextclk}] -clock_fall -max \
 [get_ports {io_pads_bootrom_n_i_ival}]
set_input_delay  1 -clock [get_clocks {xu_lfextclk}] -clock_fall -min \
 [get_ports {io_pads_bootrom_n_i_ival}]
set_input_delay  2 -clock [get_clocks {xu_lfextclk}] -clock_fall -max \
 [get_ports {io_pads_aon_pmu_dwakeup_n_i_ival}]
set_input_delay  1 -clock [get_clocks {xu_lfextclk}] -clock_fall -min \
 [get_ports {io_pads_aon_pmu_dwakeup_n_i_ival}]
set_load -pin_load  0.01 [get_ports {sysbus_load_cmd_ready}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_valid}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_err}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[31]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[30]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[29]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[28]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[27]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[26]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[25]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[24]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[23]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[22]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[21]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[20]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[19]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[18]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[17]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[16]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[15]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[14]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[13]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[12]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[11]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[10]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[9]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[8]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[7]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[6]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[5]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[4]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[3]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[2]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[1]}]
set_load -pin_load  0.01 [get_ports {sysbus_load_rsp_rdata[0]}]
set_load -pin_load  0.01 [get_ports {hfxoscen}]
set_load -pin_load  0.01 [get_ports {lfxoscen}]
set_load -pin_load  0.01 [get_ports {io_pads_jtag_TDO_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_jtag_TDO_o_oe}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[31]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[30]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[29]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[28]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[27]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[26]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[25]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[24]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[23]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[22]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[21]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[20]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[19]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[18]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[17]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[16]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[15]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[14]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[13]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[12]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[11]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[10]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[9]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[8]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[7]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[6]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[5]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[4]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[3]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[2]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[1]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oval[0]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[31]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[30]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[29]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[28]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[27]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[26]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[25]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[24]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[23]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[22]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[21]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[20]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[19]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[18]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[17]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[16]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[15]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[14]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[13]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[12]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[11]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[10]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[9]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[8]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[7]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[6]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[5]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[4]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[3]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[2]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[1]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioA_o_oe[0]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[31]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[30]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[29]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[28]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[27]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[26]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[25]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[24]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[23]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[22]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[21]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[20]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[19]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[18]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[17]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[16]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[15]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[14]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[13]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[12]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[11]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[10]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[9]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[8]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[7]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[6]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[5]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[4]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[3]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[2]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[1]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oval[0]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[31]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[30]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[29]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[28]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[27]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[26]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[25]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[24]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[23]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[22]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[21]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[20]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[19]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[18]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[17]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[16]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[15]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[14]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[13]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[12]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[11]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[10]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[9]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[8]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[7]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[6]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[5]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[4]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[3]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[2]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[1]}]
set_load -pin_load  0.01 [get_ports {io_pads_gpioB_o_oe[0]}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_sck_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_cs_0_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_0_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_0_o_oe}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_1_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_1_o_oe}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_2_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_2_o_oe}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_3_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_qspi0_dq_3_o_oe}]
set_load -pin_load  0.01 [get_ports {io_pads_aon_pmu_padrst_o_oval}]
set_load -pin_load  0.01 [get_ports {io_pads_aon_pmu_vddpaden_o_oval}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_valid}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_valid}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_valid}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_valid}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[31]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[31]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[31]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[31]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[30]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[30]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[30]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[30]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[29]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[29]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[29]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[29]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[28]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[28]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[28]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[28]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[27]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[27]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[27]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[27]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[26]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[26]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[26]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[26]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[25]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[25]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[25]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[25]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[24]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[24]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[24]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[24]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[23]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[23]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[23]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[23]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[22]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[22]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[22]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[22]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[21]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[21]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[21]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[21]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[20]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[20]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[20]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[20]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[19]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[19]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[19]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[19]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[18]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[18]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[18]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[18]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[17]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[17]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[17]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[17]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[16]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[16]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[16]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[16]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[15]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[15]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[15]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[15]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[14]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[14]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[14]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[14]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[13]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[13]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[13]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[13]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[12]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[12]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[12]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[12]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[11]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[11]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[11]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[11]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[10]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[10]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[10]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[10]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[9]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[9]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[9]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[9]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[8]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[8]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[8]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[8]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[7]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[7]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[7]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[7]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[6]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[6]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[6]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[6]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[5]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[5]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[5]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[5]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[4]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[4]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[4]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[4]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[3]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[3]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[3]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[3]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[2]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[2]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[2]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[2]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[1]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[1]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[1]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[1]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_addr[0]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_addr[0]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_addr[0]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_addr[0]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_read}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_read}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_read}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_read}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[31]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[31]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[31]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[31]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[30]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[30]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[30]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[30]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[29]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[29]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[29]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[29]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[28]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[28]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[28]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[28]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[27]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[27]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[27]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[27]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[26]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[26]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[26]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[26]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[25]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[25]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[25]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[25]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[24]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[24]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[24]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[24]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[23]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[23]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[23]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[23]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[22]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[22]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[22]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[22]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[21]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[21]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[21]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[21]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[20]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[20]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[20]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[20]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[19]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[19]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[19]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[19]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[18]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[18]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[18]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[18]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[17]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[17]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[17]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[17]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[16]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[16]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[16]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[16]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[15]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[15]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[15]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[15]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[14]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[14]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[14]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[14]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[13]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[13]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[13]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[13]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[12]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[12]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[12]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[12]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[11]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[11]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[11]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[11]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[10]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[10]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[10]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[10]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[9]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[9]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[9]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[9]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[8]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[8]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[8]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[8]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[7]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[7]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[7]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[7]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[6]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[6]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[6]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[6]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[5]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[5]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[5]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[5]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[4]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[4]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[4]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[4]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[3]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[3]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[3]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[3]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[2]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[2]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[2]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[2]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[1]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[1]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[1]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[1]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wdata[0]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wdata[0]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wdata[0]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wdata[0]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wmask[3]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wmask[3]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wmask[3]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wmask[3]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wmask[2]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wmask[2]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wmask[2]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wmask[2]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wmask[1]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wmask[1]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wmask[1]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wmask[1]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_cmd_wmask[0]}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_cmd_wmask[0]}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_cmd_wmask[0]}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_cmd_wmask[0]}]
set_input_transition -rise -min  0.1 [get_ports {sysbus_load_rsp_ready}]
set_input_transition -fall -min  0.1 [get_ports {sysbus_load_rsp_ready}]
set_input_transition -rise -max  0.1 [get_ports {sysbus_load_rsp_ready}]
set_input_transition -fall -max  0.1 [get_ports {sysbus_load_rsp_ready}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_jtag_TMS_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_jtag_TMS_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_jtag_TMS_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_jtag_TMS_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_jtag_TDI_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_jtag_TDI_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_jtag_TDI_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_jtag_TDI_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[31]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[31]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[31]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[31]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[30]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[30]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[30]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[30]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[29]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[29]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[29]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[29]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[28]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[28]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[28]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[28]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[27]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[27]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[27]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[27]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[26]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[26]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[26]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[26]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[25]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[25]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[25]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[25]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[24]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[24]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[24]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[24]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[23]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[23]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[23]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[23]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[22]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[22]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[22]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[22]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[21]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[21]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[21]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[21]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[20]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[20]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[20]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[20]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[19]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[19]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[19]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[19]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[18]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[18]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[18]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[18]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[17]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[17]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[17]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[17]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[16]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[16]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[16]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[16]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[15]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[15]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[15]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[15]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[14]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[14]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[14]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[14]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[13]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[13]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[13]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[13]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[12]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[12]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[12]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[12]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[11]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[11]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[11]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[11]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[10]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[10]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[10]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[10]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[9]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[9]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[9]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[9]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[8]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[8]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[8]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[8]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[7]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[7]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[7]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[7]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[6]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[6]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[6]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[6]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[5]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[5]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[5]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[5]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[4]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[4]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[4]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[4]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[3]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[3]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[3]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[3]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[2]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[2]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[2]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[2]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[1]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[1]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[1]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[1]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioA_i_ival[0]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioA_i_ival[0]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioA_i_ival[0]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioA_i_ival[0]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[31]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[31]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[31]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[31]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[30]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[30]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[30]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[30]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[29]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[29]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[29]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[29]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[28]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[28]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[28]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[28]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[27]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[27]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[27]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[27]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[26]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[26]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[26]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[26]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[25]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[25]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[25]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[25]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[24]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[24]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[24]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[24]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[23]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[23]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[23]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[23]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[22]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[22]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[22]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[22]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[21]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[21]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[21]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[21]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[20]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[20]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[20]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[20]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[19]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[19]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[19]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[19]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[18]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[18]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[18]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[18]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[17]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[17]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[17]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[17]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[16]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[16]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[16]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[16]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[15]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[15]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[15]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[15]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[14]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[14]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[14]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[14]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[13]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[13]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[13]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[13]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[12]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[12]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[12]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[12]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[11]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[11]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[11]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[11]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[10]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[10]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[10]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[10]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[9]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[9]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[9]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[9]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[8]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[8]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[8]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[8]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[7]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[7]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[7]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[7]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[6]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[6]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[6]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[6]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[5]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[5]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[5]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[5]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[4]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[4]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[4]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[4]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[3]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[3]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[3]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[3]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[2]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[2]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[2]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[2]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[1]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[1]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[1]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[1]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_gpioB_i_ival[0]}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_gpioB_i_ival[0]}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_gpioB_i_ival[0]}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_gpioB_i_ival[0]}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_qspi0_dq_0_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_qspi0_dq_0_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_qspi0_dq_0_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_qspi0_dq_0_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_qspi0_dq_1_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_qspi0_dq_1_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_qspi0_dq_1_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_qspi0_dq_1_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_qspi0_dq_2_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_qspi0_dq_2_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_qspi0_dq_2_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_qspi0_dq_2_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_qspi0_dq_3_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_qspi0_dq_3_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_qspi0_dq_3_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_qspi0_dq_3_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_aon_erst_n_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_aon_erst_n_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_aon_erst_n_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_aon_erst_n_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_dbgmode0_n_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_dbgmode0_n_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_dbgmode0_n_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_dbgmode0_n_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_dbgmode1_n_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_dbgmode1_n_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_dbgmode1_n_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_dbgmode1_n_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_dbgmode2_n_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_dbgmode2_n_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_dbgmode2_n_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_dbgmode2_n_i_ival}]
set_input_transition -rise -min  0.1 [get_ports {io_pads_bootrom_n_i_ival}]
set_input_transition -fall -min  0.1 [get_ports {io_pads_bootrom_n_i_ival}]
set_input_transition -rise -max  0.1 [get_ports {io_pads_bootrom_n_i_ival}]
set_input_transition -fall -max  0.1 [get_ports {io_pads_bootrom_n_i_ival}]
set_input_transition -rise -min  0.1 [get_ports \
 {io_pads_aon_pmu_dwakeup_n_i_ival}]
set_input_transition -fall -min  0.1 [get_ports \
 {io_pads_aon_pmu_dwakeup_n_i_ival}]
set_input_transition -rise -max  0.1 [get_ports \
 {io_pads_aon_pmu_dwakeup_n_i_ival}]
set_input_transition -fall -max  0.1 [get_ports \
 {io_pads_aon_pmu_dwakeup_n_i_ival}]
###############################################################################
# POCV Information
###############################################################################
