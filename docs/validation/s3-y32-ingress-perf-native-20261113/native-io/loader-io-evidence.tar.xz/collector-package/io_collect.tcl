# Read-only new SYSBUS32 PrimeTime collection using old B native-proven commands.
# Original mapped netlist/library/SDC untouched. No compile or ECO.
# Only a new output-local SDC copy adds PT-required -add to generated-clock calls.
# Root runs this in a NEW output directory via the authorized server runner.
# A completed collection is not timing closure or formal qualification.
set xu_failures {}
set xu_required_failures {}
set xu_required_reports {}
set xu_out [pwd]
set xu_reports [file join $xu_out reports]
file mkdir $xu_reports
proc xu_sha256 {path expected} {
  if {![file isfile $path]} {error "missing pinned input: $path"}
  set got [lindex [exec sha256sum -- $path] 0]
  if {$got ne $expected} {error "input SHA256 drift: $path expected=$expected got=$got"}
  return $got
}
proc xu_capture {name command required} {
  global xu_reports xu_failures xu_required_failures xu_required_reports
  if {$required} {lappend xu_required_reports $name}
  set path [file join $xu_reports $name]
  if {[catch {redirect -file $path $command} reason options]} {
    set f [open ${path}.unavailable.txt w]
    puts $f "COMMAND=$command\nREQUIRED=$required\nERROR=$reason"
    if {[dict exists $options -errorinfo]} {puts $f [dict get $options -errorinfo]}
    close $f
    lappend xu_failures [list $name $required $reason]
    if {$required} {lappend xu_required_failures $name}
    return 0
  }
  return 1
}
set xu_error [catch {
  if {![info exists ::env(XU_BASELINE_ROOT)] || ![info exists ::env(XU_MAPPED_SHA256)]} {
    error {runner must provide verified current DC root and mapped.v output SHA256}
  }
  set xu_root [file normalize $::env(XU_BASELINE_ROOT)]
  set_host_options -max_cores 8
  set xu_mapped_sha [xu_sha256 [file join $xu_root mapped.v] $::env(XU_MAPPED_SHA256)]
  set xu_sdc_sha [xu_sha256 [file join $xu_root source contracts reference-full-soc.sdc] c15ede0fc2c65771f87e2d6aee763b4ea0d53934868ca807b4785c36182fce7c]
  # libraries.tcl is a DC-generated two-list file. Read it through an isolated
  # loader: do not ask PT to execute DC-only target_library/set_app_var settings.
  set xu_loader [interp create -safe]
  interp eval $xu_loader {
    set xu_library_lists [dict create]
    proc set_app_var {name value} {
      if {$name ni {target_library link_library}} {error "unexpected library variable: $name"}
      dict set ::xu_library_lists $name $value
    }
  }
  set xu_f [open [file join $xu_root libraries.tcl] r]
  set xu_library_text [read $xu_f]; close $xu_f
  interp eval $xu_loader $xu_library_text
  set xu_lists [interp eval $xu_loader {set xu_library_lists}]
  interp delete $xu_loader
  set xu_link [dict get $xu_lists link_library]
  set xu_targets [dict get $xu_lists target_library]
  if {[llength $xu_link] != 3 || [lindex $xu_link 0] ne "*" || [llength $xu_targets] != 1 || [lindex $xu_link 1] ne [lindex $xu_targets 0]} {
    error {original library lists have unexpected shape}
  }
  set xu_std [lindex $xu_link 1]
  set xu_ram [lindex $xu_link 2]
  xu_sha256 $xu_std f69c08a0b89c6d747ecb648e8c212a98d2bba6c8b9aeec766e90babc01a64723
  xu_sha256 $xu_ram c2cce1cf2bd8f25de5df3fe01e67b0ef40a933c2ec51da156dd47a288866bf0f
  set_app_var link_path $xu_link
  read_verilog [file join $xu_root mapped.v]
  current_design xu_soc_sysbus32_ppa_top
  if {![link_design xu_soc_sysbus32_ppa_top]} {error {baseline PT link failed}}
  if {[sizeof_collection [current_design]] != 1} {error {missing linked baseline design}}
  source [file join $xu_root source ppa hierarchy_contract.tcl]
  sysbus32_check_hierarchy
  set xu_ram_cells [get_cells -quiet -hierarchical -filter {ref_name == RAMSP1024X16}]
  if {[sizeof_collection $xu_ram_cells] != $sysbus32_expected_total_macros} {error {PT SRAM count does not match sealed profile}}
  # Original constraints, same default envelope, no added timing exceptions.
  set XU_CLOCK_MODE envelope
  set XU_PLL_DIV 0
  set XU_PROPAGATE_CLOCKS 0
  # Native R1 failed CMD-003: PT requires -add when -master_clock is given.
  # Fresh replay has no prior explicitly created clocks. This is the first
  # generated-clock declaration; -add changes no source/master/period/edge.
  # Original SDC stays byte-identical. Only this output-local copy is sourced.
  if {[sizeof_collection [get_clocks -quiet *]] != 0} {error {unexpected clocks before original-SDC replay}}
  set xu_f [open [file join $xu_root source contracts reference-full-soc.sdc] rb]
  set xu_sdc_original [read $xu_f]; close $xu_f
  set xu_sdc_from {create_generated_clock -name }
  set xu_sdc_to {create_generated_clock -add -name }
  if {[regexp -all {create_generated_clock -name } $xu_sdc_original] != 3} {error {unexpected original generated-clock declaration count}}
  set xu_sdc_compat [string map [list $xu_sdc_from $xu_sdc_to] $xu_sdc_original]
  set xu_sdc_compat_path [file join $xu_out constraints-pt-add.sdc]
  set xu_f [open $xu_sdc_compat_path {WRONLY CREAT EXCL}]
  fconfigure $xu_f -translation binary
  puts -nonewline $xu_f $xu_sdc_compat
  close $xu_f
  set xu_sdc_compat_sha [xu_sha256 $xu_sdc_compat_path 404c7de9a4ef56d624e64407a501df63d8040159171ea2a88bfcc70294a3de98]
  set xu_f [open [file join $xu_out sdc-portability-receipt.txt] {WRONLY CREAT EXCL}]
  puts $xu_f "ORIGINAL_SDC_SHA256=$xu_sdc_sha\nCOMPAT_SDC_SHA256=$xu_sdc_compat_sha"
  puts $xu_f {TRANSFORM=exact three occurrences: create_generated_clock -name -> create_generated_clock -add -name}
  puts $xu_f {NATIVE_R1_ERROR=Cannot specify -master_clock without -add (CMD-003)}
  puts $xu_f {FIRST_DECLARATION=No clocks exist before sourcing the new SDC copy; this is not a replacement/relaxation of an existing generated clock.}
  puts $xu_f {NO_PERIOD_EDGE_SOURCE_MASTER_IO_UNCERTAINTY_OR_PATH_EXCEPTION_CHANGE=1}
  puts $xu_f {STATUS=COMMAND_PORTABILITY_ONLY_NOT_TIMING_FIX}
  close $xu_f
  source $xu_sdc_compat_path
  if {[sizeof_collection [get_clocks -quiet *]] != 4} {error {unexpected clock count after original-SDC compatibility replay}}
  foreach xu_pair {{xu_hfextclk 6.666666667} {xu_lfextclk 30517.578125} {xu_jtag_tck 100.0}} {
    set xu_clock [get_clocks -quiet [lindex $xu_pair 0]]
    if {[sizeof_collection $xu_clock] != 1} {error "missing primary clock: $xu_pair"}
    if {abs([get_attribute $xu_clock period]-[lindex $xu_pair 1])>0.000001} {error "wrong primary period: $xu_pair"}
  }
  if {[sizeof_collection [get_clocks -quiet xu_plldiv_envelope]] != 1} {error {missing baseline divider envelope}}
  update_timing -full
  # Appended after the byte-identical, native-proven fixed collector load prefix.
  # Bounded observations only: max_paths1/nworst1 per bit and delay type.
  # A tool may return one path per group; keep all headers and the minimum slack.
  # No get_timing_paths or timing_path/port attribute assumptions are needed.
  set io_expected {}
  foreach {name width direction} {
    sysbus_load_cmd_valid 1 input
    sysbus_load_cmd_ready 1 output
    sysbus_load_cmd_addr 32 input
    sysbus_load_cmd_read 1 input
    sysbus_load_cmd_wdata 32 input
    sysbus_load_cmd_wmask 4 input
    sysbus_load_rsp_valid 1 output
    sysbus_load_rsp_ready 1 input
    sysbus_load_rsp_err 1 output
    sysbus_load_rsp_rdata 32 output
  } {
    for {set bit 0} {$bit < $width} {incr bit} {
      set port_name [expr {$width == 1 ? $name : [format {%s[%d]} $name $bit]}]
      dict set io_expected $port_name $direction
    }
  }
  set io_ports [get_ports -quiet sysbus_load*]
  if {[sizeof_collection $io_ports] != 106 ||
      [lsort [get_object_name $io_ports]] ne [lsort [dict keys $io_expected]]} {
    error {actual sysbus_load* port set is not exactly the106 declared loader bits}
  }
  set io_inputs [all_inputs]
  set io_outputs [all_outputs]
  set io_in 0
  set io_out 0
  set io_no_path 0
  set io_numeric 0
  set io_without_slack 0
  set io_unparsed 0
  set io_catalog [open [file join $xu_out required-reports.list] w]
  set io_summary [open [file join $xu_out loader-io-observations.tsv] w]
  puts $io_summary "port\tdirection\tdelay_type\tstatus\treported_path_headers\tnumeric_slack_count\tworst_numeric_slack\tslack_state\tworst_startpoint_header\tworst_endpoint_header\tworst_path_group\tworst_path_type\tinput_external_delay_seen\toutput_external_delay_seen\treport"
  xu_capture host-usage.rpt {report_host_usage -verbose} 1
  xu_capture clocks.rpt {report_clock -attributes} 1
  xu_capture check_timing.rpt {check_timing -verbose} 1
  foreach io_name [lsort [dict keys $io_expected]] {
    set io_port [get_ports -quiet [list $io_name]]
    if {[sizeof_collection $io_port] != 1} {error "loader bit not unique: $io_name"}
    set io_direction [dict get $io_expected $io_name]
    set io_is_in [expr {[sizeof_collection [remove_from_collection $io_port $io_inputs]] == 0}]
    set io_is_out [expr {[sizeof_collection [remove_from_collection $io_port $io_outputs]] == 0}]
    if {$io_direction eq "input" && $io_is_in && !$io_is_out} {
      incr io_in
      set io_selector -from
    } elseif {$io_direction eq "output" && $io_is_out && !$io_is_in} {
      incr io_out
      set io_selector -to
    } else {error "actual port direction differs from sealed top: $io_name"}
    set io_safe [string map {\[ _ \] _} $io_name]
    foreach io_delay {max min} {
      set io_file ${io_safe}-${io_delay}.rpt
      set io_command [list report_timing $io_selector $io_port -delay_type $io_delay \
        -slack_lesser_than 1000000000 -max_paths 1 -nworst 1 \
        -path_type full_clock_expanded -significant_digits 8 -nets -input_pins \
        -transition_time -capacitance]
      if {![xu_capture $io_file $io_command 1]} {error "loader timing report failed: $io_name $io_delay"}
      puts $io_catalog reports/$io_file
      set io_f [open [file join $xu_reports $io_file] r]
      set io_text [read $io_f]; close $io_f
      if {[regexp {(^|\n)[ \t]*(Error:|Fatal:)} $io_text]} {error "native error in loader report: $io_file"}
      set io_count 0
      set io_slack_count 0
      set io_slack {}
      set io_slack_state {}
      set io_start {}
      set io_end {}
      set io_group {}
      set io_type {}
      set io_current_start {}
      set io_current_end {}
      set io_current_group {}
      set io_current_type {}
      foreach io_line [split $io_text \n] {
        if {[regexp {^[ \t]*Startpoint:[ \t]*(.*)$} $io_line -> value]} {
          incr io_count; set io_current_start $value
          set io_current_end {}; set io_current_group {}; set io_current_type {}
        }
        if {[regexp {^[ \t]*Endpoint:[ \t]*(.*)$} $io_line -> value]} {set io_current_end $value}
        if {[regexp {^[ \t]*Path Group:[ \t]*(.*)$} $io_line -> value]} {set io_current_group $value}
        if {[regexp {^[ \t]*Path Type:[ \t]*(.*)$} $io_line -> value]} {set io_current_type $value}
        if {[regexp {^[ \t]*slack[ \t]+\((MET|VIOLATED)\)[ \t]+([-+0-9.eE]+)[ \t]*$} $io_line -> state value]} {
          if {![string is double -strict $value]} {error "invalid slack number: $io_file"}
          incr io_slack_count
          if {$io_slack eq "" || $value < $io_slack} {
            set io_slack $value; set io_slack_state $state
            set io_start $io_current_start; set io_end $io_current_end
            set io_group $io_current_group; set io_type $io_current_type
          }
        }
      }
      if {$io_count > 0 && $io_slack ne ""} {
        set io_status REPORTED_PATHS_WITH_NUMERIC_SLACK; incr io_numeric
        if {$io_slack_count != $io_count} {set io_status PARTIAL_NUMERIC_SLACK_CONTEXTS_REVIEW_REQUIRED}
      } elseif {$io_count > 0} {
        set io_status REPORTED_PATH_WITHOUT_NUMERIC_SLACK; incr io_without_slack
      } elseif {[regexp -nocase {No paths[.]} $io_text]} {
        set io_status NO_PATH_REPORTED; incr io_no_path
      } else {
        set io_status UNPARSED_REPORT_REVIEW_REQUIRED; incr io_unparsed
      }
      foreach value [list $io_start $io_end $io_group $io_type] {
        if {[regexp {[\t\r]} $value]} {error "unexpected tab/CR in path header: $io_file"}
      }
      puts $io_summary [join [list $io_name $io_direction $io_delay $io_status $io_count \
        $io_slack_count $io_slack $io_slack_state $io_start $io_end $io_group $io_type \
        [regexp {input external delay} $io_text] [regexp {output external delay} $io_text] reports/$io_file] \t]
    }
  }
  close $io_catalog
  close $io_summary
  if {$io_in != 71 || $io_out != 35} {error "actual loader direction totals differ: in=$io_in out=$io_out"}
  if {[llength $xu_required_failures]} {error "required observation report commands failed: $xu_required_failures"}
  set io_f [open [file join $xu_out io-status.txt] w]
  puts $io_f "INPUT_BITS=$io_in\nOUTPUT_BITS=$io_out\nPORT_BITS=106\nBOUNDED_REPORTS=212"
  puts $io_f "NUMERIC_SLACK_REPORTS=$io_numeric\nNO_PATH_REPORTS=$io_no_path\nPATH_WITHOUT_NUMERIC_SLACK=$io_without_slack\nUNPARSED_REPORTS=$io_unparsed"
  puts $io_f "MAPPED_V_SHA256=$xu_mapped_sha\nORIGINAL_SDC_SHA256=$xu_sdc_sha\nPT_COMPAT_SDC_SHA256=$xu_sdc_compat_sha"
  puts $io_f {LIMIT=Bounded max_paths1/nworst1 per port/delay; tool may return a path per group. TSV records actual header/numeric counts and minimum returned slack. No all-context, transition-polarity, exception, CDC or complete IO qualification is established. NO_PATH is not a timing pass.}
  puts $io_f {STATUS=READ_ONLY_LOADER_IO_OBSERVATIONS_REVIEW_REQUIRED_NOT_QUALIFIED}
  close $io_f
  set io_f [open [file join $xu_out LOADER_IO_OBSERVATION_COMPLETE_NOT_QUALIFIED.txt] w]
  puts $io_f {Read-only106-bit loader IO report collection completed. This is not STA closure or complete IO/CDC qualification.}
  close $io_f
} xu_reason xu_options]
if {$xu_error} {
  set io_f [open [file join $xu_out LOADER_IO_OBSERVATION_FAILED.txt] w]
  puts $io_f $xu_reason
  if {[dict exists $xu_options -errorinfo]} {puts $io_f [dict get $xu_options -errorinfo]}
  close $io_f
  puts stderr "LOADER_IO_OBSERVATION_FAILED: $xu_reason"
  exit 1
}
puts {LOADER_IO_OBSERVATION_COMPLETE_NOT_QUALIFIED}
exit 0
