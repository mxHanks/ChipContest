from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent
candidate=root/'candidate'
expected='96fbf8088cb2b94cc5bd682e09b9ec126762bd6c2dd54aad32caea854fb416ed'
assert hashlib.sha256((candidate/'package-files.json').read_bytes()).hexdigest()==expected
note='User selected original1064 N3 development candidate and authorized cap8; one own EDA stage at a time, preexisting jobs untouched.'
state=dict(schema='ingress1064-n3-sequential-driver-v1',pid=os.getpid(),manifest_sha256=expected,started_epoch=time.time(),stage='PRECHECK',user_authorized_cap=8)
def save(): (root/'driver.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for stage in ['dc','pt']:
 state.update(stage=stage,status='RUNNING');save()
 cmd=['python3','-B','run_once.py','--stage',stage,'--run','--allow-coordinated-busy-jobs','--coordination-note',note]
 rc=subprocess.call(cmd,cwd=str(candidate))
 path=candidate/('execution.json' if stage=='dc' else 'pt/execution.json')
 receipt=json.loads(path.read_text()) if path.is_file() else {}
 state[stage]=dict(driver_rc=rc,receipt_status=receipt.get('status'),pid=receipt.get('pid'),finished_epoch=time.time())
 save()
 if rc: state.update(status='FAILED',finished_epoch=time.time());save();raise SystemExit(rc)
state.update(stage='DONE',status='COMPLETE_NOT_QUALIFIED',finished_epoch=time.time());save()
