from pathlib import Path
import json,os,subprocess,time,hashlib
b=Path(__file__).resolve().parent;api=Path('/tmp/codex-ingress1064-pt-host-api-20261113-r1');env=os.environ.copy();env['XU_RECOLLECT_BASELINE']='/tmp/codex-ingress1064-n3-20261113-r2/candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(schema='ingress1064-report-only-pt-recollect-driver-v1',status='RUNNING',started_epoch=time.time(),pid=os.getpid(),repair_catalog_sha256=sha(b/'candidate/package-files.json'),native_host_api=dict(receipt_sha256=sha(api/'execution.json'),native_log_sha256=sha(api/'native.log'),probe_sha256=sha(api/'probe.tcl')))
def save():(b/'driver.json').write_text(json.dumps(r,indent=2)+'\n')
save()
cmd=['python3','-B','run.py','--stage','pt','--run','--allow-coordinated-busy-jobs','--coordination-note','User authorized cap8. Read-only same-map PT recollection changes only unsupported host report API; original design/library/SDC/failed receipts retained.']
rc=subprocess.call(cmd,cwd=b/'candidate',env=env);r.update(status='COMPLETE_NOT_QUALIFIED' if rc==0 else 'FAILED',returncode=rc,finished_epoch=time.time());save()
