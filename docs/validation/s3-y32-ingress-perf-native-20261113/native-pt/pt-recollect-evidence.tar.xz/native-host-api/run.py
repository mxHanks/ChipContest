from pathlib import Path
import hashlib,json,os,subprocess,time,re
b=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool=Path('/eda/synopsys/prime/prime_2022.03-SP5-1/bin/pt_shell')
assert sha(tool)=='afdcfa7071f86d229ed3b4481f67adefd1c51bb0288b7e7d370213a43b70c9ef'
a=sorted(os.sched_getaffinity(0));assert len(a)>=10;os.sched_setaffinity(0,a[:8])
r=dict(schema='ingress1064-native-pt-host-api-v1',status='RUNNING_DOCUMENTATION_ONLY',tool=str(tool),tool_resolved=str(tool.resolve()),tool_sha256=sha(tool),script_sha256=sha(b/'probe.tcl'),affinity=a[:8],max_cores=8,started_epoch=time.time(),design_or_library_read=False)
def save():(b/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
env=os.environ.copy();env['SYNOPSYS_LC_ROOT']='/eda/synopsys/lib_compiler/lib_compiler_2022.03-SP5'
with (b/'native.log').open('w') as log:
 p=subprocess.Popen([str(tool),'-f','probe.tcl'],cwd=b,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=p.pid;save();code=p.wait(timeout=120)
s=(b/'native.log').read_text(errors='replace');r.update(status='DOCUMENTATION_COLLECTED_REVIEW_REQUIRED',returncode=code,finished_epoch=time.time(),log_sha256=sha(b/'native.log'),source_drift=[] if sha(b/'probe.tcl')==r['script_sha256'] else ['probe.tcl'],native_errors=re.findall(r'^Error:.*$',s,re.M));save()
