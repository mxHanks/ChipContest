set_host_options -max_cores 8
puts "PT_HOST_COMMANDS_BEGIN"
puts [lsort [info commands *host*]]
puts "PT_HOST_COMMANDS_END"
foreach c {set_host_options report_host_usage get_host_options report_host_options} {
 if {[llength [info commands $c]]} {
  puts "PT_HOST_HELP_BEGIN=$c"
  catch {help -verbose $c} r
  puts "PT_HOST_HELP_END=$c"
  puts "PT_HOST_MAN_BEGIN=$c"
  catch {man $c} r
  puts "PT_HOST_MAN_END=$c"
 }
}
exit 0
