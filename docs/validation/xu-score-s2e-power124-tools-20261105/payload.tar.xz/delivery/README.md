# xu S2e124 独立全SoC功耗诊断流程

本目录只是已准备、经host验证的测量工具，**尚未执行服务器PT，不能报告S2e能耗合格或评分**。不修改Chisel、RTL、MMIO、数值格式、向量、原网表、工艺DB或SDC。

输入必须同时是冻结S2e源main `5bf123b` / child `a0767db`、原S2e89 own mapped `0cfac0b…c09d0` / own SVF / own109原生Formality证明，以及actual120真正完成的12任务活动。活动为每层868,343 elapsed周期、5,788,953,333,333fs；12层elapsed总10,420,116，不能使用开发窗口10,420,140代替。每个任务的33,697次CPU清零写在SAIF窗口之外。

流程先重新核对原109工具checkout `2c791bc`、候选全部源字节、原89/109证据及120运行依赖，再从immutable raw SAIF重做全部12任务normalization并逐bit核对。随后在自己的S2e89网表上实际执行一次独立PT inventory，要求相同SS STD/SRAM两DB、原SDC、336个宏及每宏67个pin；不能复用S2c20 inventory。只有完整inventory与精确macro双射通过，才为12任务分别生成mapped SAIF和PT脚本。12个PT进程各自独立，原始before/after pin属性、source/file/default/propagated、unannotated、toggle coverage、SRAM power/Liberty arcs及功耗报告全部保留。未知TX/TZ/TB不置零，不补造门级初态，不驱动Q。

仅复用冻结common的`generate_tcl`、`execute`、`checked_reports`等函数。S2e自身validator检查actual120的schema、源/工具/own映射、完整生成TB/RTL列表、固件clear wrapper、编译选项、实际原日志/边界/清零/上传/结果退休、fixture及归一化。没有调用baseline `checked_activity`，也没有补造它要求的S2c字段。私有bridge组合经原guard验证的S2e alias API；原baseline文件与模块不变。

PT使用原有propagated pre-CTS时钟及envelope场景。own89尚未完整150MHz合格，full-SoC annotation及conditional SRAM功耗语义仍待审查。原生`x_probability=0`不能证明Q物理已知；`before`仅表示显式`update_power`之前，getter可触发lazy propagation/power。报告中的W乘实际窗口仅为诊断能量。全部状态明确为`NOT_QUALIFIED`；成功返回、覆盖报告或唯一marker都不授予正式能量或比赛资格。

## 服务器启动

仅上传以下两份原字节至Desktop即可，原109工具checkout保持清洁：

```text
xu_s2e_full_soc_power124.py
launch_s2e_power124.py
```

`launch_s2e_power124.py`核对driver SHA后复制到新的launch目录，并以detached进程执行完整campaign。实际输出为`~/Desktop/xu-score-optimization-20261102/s2e-full-soc-power12-20261105-124`，launch/state/log为同父目录下`s2e-full-soc-power-launch-20261105-124`。输出或launch已经存在时拒绝再次启动。观察超时须检查同一PID及原state，不能重启。调用命令兼容服务器csh：

```bash
python3 "$HOME/Desktop/launch_s2e_power124.py"
```

也可在新的编号目录手动分阶段准备和执行（prepare包括真实PT inventory）：

```bash
B="$HOME/Desktop/xu-score-optimization-20261102"
python3 "$HOME/Desktop/xu_s2e_full_soc_power124.py" prepare \
  --activity "$B/s2e-formal-activity12-20261105-120/result.json" \
  --source-root "$B/ChipContest-s2e-74" \
  --tool-root "$B/ChipContest-s2e-activity-tools-109" \
  --ppa-root "$B/s2e-ppa-campaign-20261104-89" \
  --formality-root "$B/s2e-own-formality-audit-20261104-109" \
  --out "$B/s2e-full-soc-power12-new"
python3 "$HOME/Desktop/xu_s2e_full_soc_power124.py" run \
  --out "$B/s2e-full-soc-power12-new" --timeout 21600
```

手动示例的`B=...`为bash写法；直接从csh终端操作时使用launcher，或显式展开完整路径。PT版本固定`T-2022.03-SP5-1`，LC root为`/eda/synopsys/lib_compiler/lib_compiler_2022.03-SP5`。生产收据保存实际命令、全部依赖SHA、同一输入before/after及逐任务脚本/SAIF/原始日志SHA。完整原生pin报告可能约20GB，应留在服务器并随后流式审计，不能因未回传正文而声称本地重放了它们。

## 已完成的本地验证

`host-check124.json`及`host-check124.log`保存23项聚焦验证：Python3.6语法；原109 clean模块和本地冻结S2e源码guard；actual120完整任务元数据；actual57原日志和功耗解析；actual120 task00 SAIF22,512pin输入布局与未知dwell保持；冻结common Tcl所保留的scope/coverage/pin/Liberty报告；完整336×67合成TSV布局。负例覆盖running/partial/缺task/重复task、非零返回、仅marker回显、重复marker、rc0原生错误、W→mW、wrapper报告、unknown dwell、重复/缺失pin。

其中合成DB/TSV只用于host生成器或parser测试，没有运行EDA，没有冒充实际工艺库或S2e mapped inventory。host使用的S2c57原报告只测试parser，不与S2e活动拼接为能耗测量。测试没有执行服务器own89/109/runtime完整文件重哈希或PT。

```bash
python3 build/xu-s2e-power124/check_power124.py
```

本地测试使用本目录下独立只读原109工具clone `frozen-tools109`，因为另一个并行归档正在原本地activity worktree写入untracked证据；没有绕过原tool clean guard。该clone不需要上传。
