#!/usr/bin/env python3
"""Read-only124 delivery or prepared-campaign audit; never runs EDA.

Campaign mode independently reconstructs generated Tcl and measured macro pin
bindings. It does not resolve native unknown-state conversion or qualify energy.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

DRIVER_SHA = '2349b11ec32e63c71ff70497c8d6d124ec99024bec73b75239944993bd58bc58'
LAUNCHER_SHA = '282b56f60cbbca2e1b94578b664f9245e73af7feb4e25e287460095edff81f20'
NETLIST = '0cfac0b5e99ec05301ec8c0efde38ef2c96790dd1243e84727687b15b25c09d0'
SDC = '404c7de9a4ef56d624e64407a501df63d8040159171ea2a88bfcc70294a3de98'
STRIP = 'tb_xu_soc_ppa/dut'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def identity(path):
    path = Path(path).absolute()
    need(path.is_file() and not path.is_symlink(), 'regular file required: ' + str(path))
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def checked_identity(record):
    actual = identity(record['path'])
    need(actual['sha256'] == record['sha256'] and ('bytes' not in record or actual['bytes'] == record['bytes']),
         'actual identity differs: ' + record['path'])
    return actual


def driver_module(directory):
    path = Path(directory).resolve() / 'xu_s2e_full_soc_power124.py'
    need(sha(path) == DRIVER_SHA, 'frozen2349 driver differs')
    spec = importlib.util.spec_from_file_location('xu_readonly124_frozen_driver', str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def python36_syntax(source):
    try:
        return ast.parse(source, feature_version=(3, 6))
    except TypeError:
        # Python3.6 has no feature_version keyword; its native parser is the
        # required grammar. No production code is changed by this check.
        return ast.parse(source)


def delivery(directory):
    directory = Path(directory).resolve()
    manifest = read(directory / 'handoff124-manifest.json')
    files = {}
    for name, row in manifest['files'].items():
        need(Path(name).name == name, 'unsafe delivery path')
        files[name] = identity(directory / name)
        need(files[name]['sha256'] == row['sha256'] and files[name]['bytes'] == row['bytes'], 'delivery file differs: ' + name)
    need(files['xu_s2e_full_soc_power124.py']['sha256'] == DRIVER_SHA and
         files['launch_s2e_power124.py']['sha256'] == LAUNCHER_SHA, 'driver/launcher original bytes differ')
    launcher = python36_syntax((directory / 'launch_s2e_power124.py').read_text())
    constants = {}
    for node in launcher.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, (ast.Str, ast.Num)):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    constants[target.id] = getattr(node.value, 's', getattr(node.value, 'n', None))
    need(constants['PRODUCER_SHA'] == DRIVER_SHA, 'launcher pins a different producer')
    host = read(directory / 'host-check124.json')
    need(host['total'] == len(host['checks']) == 23 and all(row['status'] == 'PASS' for row in host['checks']) and
         host['producer']['sha256'] == DRIVER_SHA, 'focused host receipt differs')
    need((directory / 'host-check124.log').read_text().splitlines() == ['PASS ' + row['name'] for row in host['checks']],
         'host log/receipt names or order differ')
    for name in ('xu_s2e_full_soc_power124.py', 'launch_s2e_power124.py', 'check_power124.py'):
        python36_syntax((directory / name).read_text())
    return dict(status='DELIVERY_BYTES_AND_FOCUSED_HOST_RECEIPTS_VERIFIED_NOT_SERVER_EXECUTION', files=files,
                host_check_count=23, qualification='NOT_QUALIFIED')


def campaign(directory, out, terminal=False):
    driver = driver_module(directory)
    out = Path(out).resolve()
    prepared_path = out / 'prepared.json'
    prepared_before = identity(prepared_path)
    prepared = read(prepared_path)
    need(prepared.get('schema') == 'xu-s2e-full-soc-power124-prepared-v1' and
         prepared.get('qualification') == 'NOT_QUALIFIED' and prepared.get('status') == 'PREPARED_REVIEW_PENDING' and
         prepared.get('requested_task_ids') == list(range(12)) and prepared.get('taskset_complete') is True and
         [row.get('task_id') for row in prepared.get('tasks', [])] == list(range(12)), 'complete prepared124 set required')
    modules = driver.Modules(prepared['tool_root'])
    # The original source/mapped guards are reused; this checker does not call
    # the production prepare/verify_prepared/run validators or execute EDA.
    ctx = modules.ctx(prepared['source_root'])
    mapped = modules.context.checked_mapped_context(ctx.root, prepared['ppa_root'], prepared['formality_root'])
    need(mapped == prepared['mapped_context'] and mapped['netlist']['sha256'] == NETLIST and mapped['constraints']['sha256'] == SDC,
         'actual own89/109/source proof differs')
    need(prepared['source_context'] == ctx.source and prepared['original_capture_tool_context'] == ctx.tool,
         'actual source/capture tool context differs')
    need(prepared['strip_path'] == STRIP and prepared['netlist'] == identity(mapped['netlist']['path']) and
         prepared['analysis_sdc'] == identity(mapped['constraints']['path']), 'exact own netlist/SDC path or bytes differ')
    impl = read(Path(prepared['ppa_root']) / 'ppa/prepared.json')['implementation']
    need(prepared['implementation_controls'] == impl, 'Tcl implementation must equal original own89 implementation')
    for path, digest in prepared['input_sha256'].items():
        need(Path(path).is_absolute() and identity(path)['sha256'] == digest, 'actual frozen preparation input differs')
    need(checked_identity(prepared['producer'])['sha256'] == DRIVER_SHA, 'actual executed producer differs')
    report = read(prepared['activity']['path'])
    checked_identity(prepared['activity'])
    need(report.get('schema') == 'xu-s2e-isolated-task-activity-v1' and
         report.get('status') == 'COLLECTED_12_TASKS_REVIEW_PENDING' and report.get('taskset_complete') is True and
         report.get('requested_task_ids') == list(range(12)) and [r.get('task_id') for r in report['tasks']] == list(range(12)),
         'actual complete120 activity required')
    config = report['configuration']
    need(config['mapped_context'] == mapped and config['source_context'] == ctx.source and config['tool_context'] == ctx.tool and
         config['simulator_defines'] == ['ARM_UD_MODEL', 'DISABLE_SV_ASSERTION=1'] and
         config['nominal_hz'] == 150000000 and config['lf_hz'] == 32768 and config['precision_fs'] == 1,
         'activity own mapping/source/format/clock/no-initialization binding differs')
    need(report['configuration_sha256'] == modules.context.canonical(config) == prepared['original_capture_configuration_sha256'],
         'actual configuration hash differs')
    inventory_path = Path(prepared['mapped_sram_inventory']['path'])
    checked_identity(prepared['mapped_sram_inventory'])
    bridge = modules.bridge(config['sram_alias_mapping']['path'])
    inventory, actual, comparison = bridge.inventory_macros(inventory_path)
    need(inventory['netlist'] == prepared['netlist'] and inventory['constraints'] == prepared['analysis_sdc'] and
         len(inventory['libraries']) == len(impl['libraries']) == 2 and
         {row['sha256'] for row in inventory['libraries']} == {row['sha256'] for row in impl['libraries']},
         'own actual inventory netlist/SDC/two-library binding differs')
    need(inventory['macros'] == driver.inventory_rows(inventory['provenance']['raw_tsv']['path']), 'raw inventory TSV/JSON differs')
    for key in ('raw_tsv', 'pt_log', 'script', 'tool_version', 'tool'):
        checked_identity(inventory['provenance'][key])
    need(inventory['provenance']['input_sha256_before'] == inventory['provenance']['input_sha256_after'],
         'inventory original input freeze differs')
    mapping, pairs = modules.alias.validate_mapping(config['sram_alias_mapping']['path'])
    need(mapping == config['sram_alias'] and len(pairs) == 22512, 'complete source-guarded alias mapping differs')
    _, canonical_macros = bridge.mapping_macros(config['sram_alias_mapping']['path'], STRIP)
    need(set(canonical_macros) == set(comparison), 'actual mapped/canonical macro bijection differs')
    summaries = []
    for task in prepared['tasks']:
        task_id = task['task_id']
        source = report['tasks'][task_id]
        directory = out / ('task_%02d' % task_id)
        need(task['directory'] == directory.name and task['macro_names'] == sorted(actual) and
             task['activity_window'] == source['activity_window'], 'task/window/actual macro names differ')
        need(task['saif']['path'] == str(directory / 'task-mapped.saif') and
             task['script']['path'] == str(directory / 'power.tcl') and
             task['canonical_saif'] == identity(source['saif']['path']), 'task canonical/mapped paths differ')
        for key in ('script', 'saif', 'mapped_macro_bridge', 'measured_sram_pin_states'):
            checked_identity(task[key])
        need(re.fullmatch('XU_S2E124_FULL_SOC_POWER_TASK_%02d_[0-9a-f]{32}' % task_id, task['completion_marker']) is not None,
             'unique task completion marker format differs')
        # Reconstruct from the actual own89 implementation and actual own netlist,
        # not a caller-supplied unvalidated implementation or stored Tcl digest.
        expected = modules.common.generate_tcl(impl, prepared['netlist'], prepared['analysis_sdc'], task, task['completion_marker'])
        need(expected.count('\nupdate_power\n') == 1, 'frozen common update_power differs')
        expected = expected.replace('\nupdate_power\n', '\nredirect -file update-power.rpt {update_power}\n')
        needle = '\nputs ' + modules.ppa.tcl(task['completion_marker'])
        need(expected.count(needle) == 1, 'unique expected native completion marker missing')
        expected = expected.replace(needle, '\nif {![file isfile update-power.rpt]} {error {missing update-power.rpt}}\n' + needle)
        need(Path(task['script']['path']).read_text() == expected, 'actual Tcl differs from independently reconstructed own-context script')
        need(task['expected_reports'] == modules.common.report_names() + ['update-power.rpt'], 'required native reports changed')
        mapped_saif = modules.alias.activity_module().read_saif(task['saif']['path'])
        canonical_saif = modules.alias.activity_module().read_saif(source['saif']['path'])
        mapped_by_path, canonical_by_path = {}, {}
        for reader, by_path in ((mapped_saif, mapped_by_path), (canonical_saif, canonical_by_path)):
            for row in reader['signals']:
                by_path.setdefault(row['path'], []).append(row)
        measured = read(task['measured_sram_pin_states']['path'])
        measured_by_name = {row['mapped_path']: row for row in measured['pins']}
        need(len(measured_by_name) == len(measured['pins']) == 22512, 'all unique measured pin states required')
        unknown = 0
        for key, relative in comparison.items():
            for pin in actual[relative]['pins']:
                name = pin['name']
                original = canonical_by_path.get(canonical_macros[key] + '/' + name, [])
                target = mapped_by_path.get(STRIP + '/' + pin['full_name'], [])
                saved = measured_by_name.get(pin['full_name'])
                need(original and target and saved, 'canonical/mapped/measured pin missing')
                stats = modules.alias.stats(original[0])
                need(all(modules.alias.stats(row) == stats for row in original + target + [saved]),
                     'canonical/mapped/measured TX/TZ/TB/dwell/TC attributes differ')
                unknown += sum(stats.get(k, 0) for k in ('TX', 'TZ', 'TB'))
        need(unknown == source['normalization']['alias_unknown_bit_ticks'] == measured['alias_unknown_bit_ticks'] and
             mapped_saif['duration_ticks'] == canonical_saif['duration_ticks'] == task['activity_window']['duration_ticks'] and
             mapped_saif['timescale_seconds'] == canonical_saif['timescale_seconds'] == '1E-15',
             'unknown dwell or physical window/timebase changed')
        summaries.append(dict(task_id=task_id, script=identity(task['script']['path']),
            mapped_saif=identity(task['saif']['path']), pins_verified=22512, unknown_bit_ticks=unknown,
            status='TCL_AND_MEASURED_INPUT_BINDINGS_VERIFIED_NOT_NATIVE_PT_OR_ENERGY_QUALIFIED'))
    execution = None
    if (out / 'execution.json').is_file():
        execution = read(out / 'execution.json')
        need(execution['prepared'] == prepared_before and execution['qualification'] == 'NOT_QUALIFIED', 'actual execution/prepared identity differs')
    if terminal:
        need(execution and execution['status'] == 'EXECUTED_12_TASKS_DIAGNOSTIC_REVIEW_PENDING' and
             execution['taskset_complete'] is True and len(execution['tasks']) == 12 and
             execution['input_sha256_before'] == execution['input_sha256_after'], 'complete immutable execution terminal required')
        for task, entry in zip(prepared['tasks'], execution['tasks']):
            need(entry['task_id'] == task['task_id'] and entry['status'] == 'EXECUTED_DIAGNOSTIC_REVIEW_PENDING', 'terminal task incomplete')
            driver.checked_native_log(out / task['directory'] / 'pt.log', task['completion_marker'], entry['execution']['returncode'])
            need(entry['reports'] == modules.common.checked_reports(out / task['directory'], task), 'native report identities differ')
    ctx.recheck()
    need(identity(prepared_path) == prepared_before, 'prepared manifest changed during read-only audit')
    return dict(status='PREPARED_CONTEXT_TCL_AND_MEASURED_INPUTS_VERIFIED_NOT_ENERGY_QUALIFIED',
        prepared=prepared_before, tasks=summaries, total_pins_verified=270144, qualification='NOT_QUALIFIED',
        execution_status=None if execution is None else execution['status'], terminal_reports_rehashed=terminal,
        limitations=['Does not interpret native X/SP/TR getter semantics or SRAM conditional power; no full150MHz or contest energy qualification.',
                     'Raw-to-normalized120 capture proof remains a separate original collection/archive audit; this checks normalized-to-mapped measured stats.',
                     'Live execution status is only a snapshot; source/Tcl/input audit is not a live process check.'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--delivery-dir', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--campaign', type=Path)
    parser.add_argument('--terminal', action='store_true')
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    result = delivery(args.delivery_dir)
    if args.campaign:
        result['campaign'] = campaign(args.delivery_dir, args.campaign, args.terminal)
    need(not args.terminal or args.campaign is not None, '--terminal requires campaign')
    if args.receipt:
        with args.receipt.open('x') as stream:
            stream.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError) as error:
        print('FAIL: ' + str(error), file=sys.stderr)
        sys.exit(1)
