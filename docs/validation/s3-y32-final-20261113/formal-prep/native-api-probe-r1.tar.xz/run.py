from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path(__file__).resolve().parent
tool=Path('/eda/synopsys/fm/fm_2020.09-SP5/bin/fm_shell')
assert tool.is_file() and hashlib.sha256(tool.read_bytes()).hexdigest()=='4c502a4490b6eb1e27c9196732db1bc4f12488297bfa458f1e00e70c971e6e48'
allowed=sorted(os.sched_getaffinity(0));chosen=allowed[:2];assert chosen;os.sched_setaffinity(0,chosen)
record=dict(status='RUNNING_API_DOCUMENTATION_ONLY',started_epoch=time.time(),max_cpus=2,affinity=chosen,tool=str(tool),resolved=str(tool.resolve()),tool_sha256=hashlib.sha256(tool.read_bytes()).hexdigest(),probe_sha256=hashlib.sha256((base/'api_probe.tcl').read_bytes()).hexdigest())
def save():(base/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
save()
with (base/'native.log').open('w') as out:
 job=subprocess.Popen([str(tool),'-f','api_probe.tcl'],cwd=base,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT);record['pid']=job.pid;save();code=job.wait(timeout=180)
record.update(status='API_COLLECTION_COMPLETE_NOT_EQUIVALENCE',returncode=code,finished_epoch=time.time(),log_sha256=hashlib.sha256((base/'native.log').read_bytes()).hexdigest());save()
