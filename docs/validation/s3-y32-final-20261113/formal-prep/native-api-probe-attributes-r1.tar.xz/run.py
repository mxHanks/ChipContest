from pathlib import Path
import hashlib,json,os,subprocess,time,signal,re
base=Path(__file__).resolve().parent
tool=Path('/eda/synopsys/fm/fm_2020.09-SP5/bin/fm_shell')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert tool.is_file() and sha(tool)=='4c502a4490b6eb1e27c9196732db1bc4f12488297bfa458f1e00e70c971e6e48'
assert sha(base/'api_probe_attributes.tcl')=='1902ff35578275c48c8660d5045e0a93c79c082d910ca557eaae7de8779e835f'
allowed=sorted(os.sched_getaffinity(0));chosen=allowed[:2];assert chosen;os.sched_setaffinity(0,chosen)
record=dict(schema='final374-fm-native-attribute-definitions-probe-v1',status='RUNNING_API_DOCUMENTATION_ONLY',started_epoch=time.time(),max_cpus=2,affinity=chosen,tool=str(tool),resolved=str(tool.resolve()),tool_sha256=sha(tool),probe_sha256=sha(base/'api_probe_attributes.tcl'),synthesis_or_design_verification=False)
def save():(base/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
save();timeout=False
with (base/'native.log').open('w') as log:
 job=subprocess.Popen([str(tool),'-f','api_probe_attributes.tcl'],cwd=base,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['pid']=job.pid;save()
 try:code=job.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(job.pid,signal.SIGTERM)
  try:code=job.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(job.pid,signal.SIGKILL);code=job.wait()
text=(base/'native.log').read_text(errors='replace')
record.update(status='API_COLLECTION_COMPLETE_REVIEW_REQUIRED_NOT_EQUIVALENCE' if code==0 and not timeout else 'API_COLLECTION_FAILED',returncode=code,tool_timed_out=timeout,finished_epoch=time.time(),log_sha256=sha(base/'native.log'),native_report_error_lines=re.findall(r'^(?:Error:|Fatal:).*$',text,re.M),source_drift=[] if sha(base/'api_probe_attributes.tcl')==record['probe_sha256'] else ['api_probe_attributes.tcl'])
save()
