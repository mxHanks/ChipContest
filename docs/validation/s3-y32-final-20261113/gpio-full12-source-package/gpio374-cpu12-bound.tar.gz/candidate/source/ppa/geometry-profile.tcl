# Final exact DMA4/storage21 profile. Original constraints unchanged.
set sysbus32_hardware_profile {sysbus32-dma4-storage-sram-374-final}
set sysbus32_production_defines [list SYNTHESIS DISABLE_SV_ASSERTION=1 XU_MATRIX_DMA XU_MATRIX_DMA_SYSBUS32 XU_MATRIX_X_SRAM XU_MATRIX_STORAGE_SRAM]
set sysbus32_expected_total_macros 374
set sysbus32_expected_x_macros 16
set sysbus32_expected_internal_macros 54
set sysbus32_expected_result_macros 21
