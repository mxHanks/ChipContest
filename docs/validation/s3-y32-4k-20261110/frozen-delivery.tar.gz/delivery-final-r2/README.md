This is local functional/cycle evidence, not achieved150MHz, area or official qualification.
Run python3 REPLAY.py to verify identities without simulation.
Explicit --run --out NEW_DIR replays the exact sealed simulator; --rebuild also recompiles frozen RTL.
Later experiments require renewed deadline authorization. Do not mistake fixture transfer time for payload.
