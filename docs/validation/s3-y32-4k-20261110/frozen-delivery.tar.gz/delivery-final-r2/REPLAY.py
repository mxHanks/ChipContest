#!/usr/bin/env python3
import argparse,datetime,hashlib,importlib.util,json,pathlib,subprocess,sys
sys.dont_write_bytecode=True
root=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser(description='Default: verify sealed files; --run explicitly starts local simulation')
p.add_argument('--run',action='store_true');p.add_argument('--rebuild',action='store_true');p.add_argument('--out',type=pathlib.Path)
p.add_argument('--deadline',default='2026-11-10T23:59:00+08:00',help='A later deadline needs renewed user authorization')
a=p.parse_args()
if a.rebuild and not a.run:p.error('--rebuild requires --run')
manifest=json.loads((root/'SHA256.json').read_text())
for path,digest in manifest.items():
    item=root/path
    if not item.is_file() or hashlib.sha256(item.read_bytes()).hexdigest()!=digest:raise SystemExit('File identity mismatch: '+path)
print('SEALED_FILES_PASS',len(manifest),flush=True)
if not a.run:raise SystemExit(0)
if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(a.deadline).astimezone(datetime.timezone.utc):p.error('Experiment deadline reached; verify-only remains available')
if a.out is None:p.error('--run requires a new --out directory')
out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
record=json.loads((root/'cpu/result.json').read_text());args=record['arguments'];binary=root/'cpu/simulator/dma_day_soc'
if a.rebuild:
    source=root/'cpu/source';rtl=source/'rtl'
    filelist=out/'rtl.f';filelist.write_text(''.join(str(x)+'\n' for x in sorted(rtl.rglob('*')) if x.suffix in ('.v','.sv'))+str(source/'tests/tb_dma64_soc.sv')+'\n')
    command=['verilator','--binary','--timing','--assert','-CFLAGS','-std=gnu++20','-Wno-fatal','-j','2','--top-module','tb_dma64_soc','-Mdir',str(out/'obj'),'-o','dma_day_soc','-DDISABLE_SV_ASSERTION=1','-DXU_MATRIX_DMA','-DXU_MATRIX_DMA64','-DD4K_THROTTLE='+str(args['throttle']),*['-I'+str(x) for x in (rtl/'core',rtl/'perips',rtl/'perips/apb_i2c',source/'tests')],'-f',str(filelist)]
    (out/'build-command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (out/'build.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    binary=out/'obj/dma_day_soc'
if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(a.deadline).astimezone(datetime.timezone.utc):p.error('Experiment deadline reached before simulation')
command=[str(binary),'+TESTCASE='+str(root/'cpu/firmware/dma_day_soc'),'+VECTORS='+str(root/'cpu/vectors'),'+TASKS='+str(args['tasks']),'+ROWS='+str(args['rows']),'+WARMUP='+str(int(args['warmup'])),'+MAX_CYCLES='+str(args['max_cycles']),'+FIRST_SOURCE_STALL='+str(args['first_source_stall'])]
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'simulation.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
checker=root/'cpu/source/check_results.py';spec=importlib.util.spec_from_file_location('sealed_checker',checker);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.check_log((out/'simulation.log').read_text(),args['tasks'],args['rows'],args['warmup'])
(out/'verified-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('REAL_CPU_REPLAY_PASS',result['outputs'],result['principal_cycles'],flush=True)
