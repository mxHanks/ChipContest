import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/home/mxhanks/Projects/ChipContest-xu-optimize-hw')
sys.path.insert(0, str(root/'tools/scripts'))
import e203_soc as soc
import xu_hw_experiments as hw

out = root/'build/xu-hw-local-97b3542'
out.mkdir(exist_ok=False)
identity = hw.source_identity()
report = dict(status='RUNNING', scope='local GCC14/Verilator screening, no server performance claim',
              source=identity, runs=[])
def save():
    (out/'local-check.json').write_text(json.dumps(report,indent=2)+'\n')
save()
cases = [('B0','bias-dtcm','real',1),
         ('H1','bias-hw','synthetic',2),('H1','bias-hw','real',1),
         ('H2','bias-dtcm-window','synthetic',2),('H2','bias-dtcm-window','real',1),
         ('H1H2','bias-hw-window','synthetic',2),('H1H2','bias-hw-window','real',1)]
try:
    for name,schedule,mode,tasks in cases:
        if hw.source_identity()!=identity:
            raise RuntimeError('source changed during local screening')
        label='{}-{}{}'.format(name,mode,tasks)
        target=out/label
        command=[sys.executable,str(root/'tools/scripts/e203_soc.py'),'--mode',mode,
                 '--tasks',str(tasks),'--sim','verilator','--firmware-schedule',schedule,
                 '--firmware-opt=-O2','--firmware-experiment','both-unroll-no-masks','--out',str(target)]
        print('START '+label,flush=True)
        record=dict(name=label,command=command,status='RUNNING')
        report['runs'].append(record); save()
        with (out/(label+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=str(root),stdout=log,stderr=subprocess.STDOUT,timeout=7200)
        data=json.loads((target/'result.json').read_text())
        if result.returncode or data['status']!='PASS':
            raise RuntimeError('failed '+label+': '+str(data.get('error')))
        record.update(status='PASS',cycles=[r['cycles'] for r in data['layers']],
                      result_sha256=soc.sha(target/'result.json'),
                      log_sha256=data['log_sha256'],firmware_image_sha256=data['firmware_image_sha256'])
        if name=='B0' and data['firmware_image_sha256']!='1e038157321ac5891329762064d7da77125fbf0134dfe29600e94105b5acefd8':
            raise RuntimeError('B0 local image differs from separately rebuilt old source')
        save(); print('PASS '+label+' '+str(record['cycles']),flush=True)
    report['status']='PASS'
except Exception as exc:
    report.update(status='FAIL',error=str(exc))
    raise
finally:
    save()
