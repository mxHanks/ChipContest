# Exact three-receiver, read-only propagation API collection.
# Unconstrained arrivals and aggregate pin attributes never establish timing Met.
source [file join $::env(XU_ECO_PACKAGE) common.tcl]

proc catch_probe_attribute {object attribute} {
  if {[catch {get_attribute $object $attribute} value]} {
    return [list UNAVAILABLE [string map [list "\t" { } "\n" { }] $value]]
  }
  if {$value eq {}} {return [list EMPTY {}]}
  return [list NATIVE_VALUE [string map [list "\t" { } "\n" { }] $value]]
}

set failed [catch {
  eco_config
  eco_load_pt $::eco_mapped
  # Collect documentation before using any additional timing-arc APIs.
  # No get_timing_arcs or report_delay_calculation invocation is guessed here.
  eco_capture native-get-timing-arcs-man.rpt {man get_timing_arcs}
  eco_capture native-report-delay-calculation-man.rpt {man report_delay_calculation}
  eco_capture native-timing-arc-attributes.rpt {list_attributes -application -class timing_arc}
  eco_capture native-unconstrained-report-before.rpt {printvar timing_report_unconstrained_paths}

  set source [get_ports -quiet io_pads_aon_erst_n_i_ival]
  eco_require [expr {[sizeof_collection $source] == 1 && [get_object_name $source] eq {io_pads_aon_erst_n_i_ival}}] {exact external ERST input missing}
  set old [get_app_var timing_report_unconstrained_paths]
  eco_require [expr {$old in {true false 0 1}}] {report-only unconstrained switch is not Boolean}
  set paths_log [eco_open exact-external-max-paths.tsv]
  puts $paths_log "endpoint\ttransition\tpath_index\tpath_count\tstartpoint\tactual_arrival_state\tactual_arrival_ns\trequired_state\trequired_ns\tslack_state\tslack_ns\tqualification"
  set attrs_log [eco_open aggregate-pin-attributes.tsv]
  puts $attrs_log "endpoint\tattribute\tstate\tnative_value\tqualification"
  set query_log [eco_open exact-query-counts.tsv]
  puts $query_log "endpoint\ttransition\tpath_count\tquery_limit\tcompleteness"

  set_app_var timing_report_unconstrained_paths true
  set query_failed [catch {
    foreach index {0 1 2} {
      set name u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_${index}/q_reg/RDN
      set pin [eco_pin $name]
      foreach attribute {max_rise_arrival max_fall_arrival} {
        lassign [catch_probe_attribute $pin $attribute] state value
        puts $attrs_log "$name\t$attribute\t$state\t$value\tAGGREGATE_ONLY_NOT_EXTERNAL_SOURCE_PROOF"
      }
      foreach edge {rise fall} {
        set command [list get_timing_paths -from $source -${edge}_to $pin -delay_type max -nworst 8 -max_paths 8]
        set paths [eval $command]
        set count [sizeof_collection $paths]
        set completeness COMPLETE_WITHIN_QUERY
        if {$count == 0} {set completeness NO_PATH_NO_MAX_PROPAGATION_PROOF}
        if {$count >= 8} {set completeness CAPPED_NOT_COMPLETE}
        puts $query_log "$name\t$edge\t$count\t8\t$completeness"
        set number 0
        foreach_in_collection path $paths {
          incr number
          eco_require [expr {[get_object_name [get_attribute $path startpoint]] eq {io_pads_aon_erst_n_i_ival} && [get_object_name [get_attribute $path endpoint]] eq $name}] {path escaped exact external source or exact RDN endpoint}
          lassign [catch_probe_attribute $path arrival] arrival_state arrival
          lassign [catch_probe_attribute $path required] required_state required
          lassign [catch_probe_attribute $path slack] slack_state slack
          puts $paths_log "$name\t$edge\t$number\t$count\tio_pads_aon_erst_n_i_ival\t$arrival_state\t$arrival\t$required_state\t$required\t$slack_state\t$slack\tREAD_ONLY_NO_UNKNOWN_PROMOTION"
        }
      }
    }
  } query_reason query_options]
  set_app_var timing_report_unconstrained_paths $old
  close $paths_log
  close $attrs_log
  close $query_log
  if {$query_failed} {return -options $query_options $query_reason}
  eco_capture native-unconstrained-report-restored.rpt {printvar timing_report_unconstrained_paths}
  eco_finish CATCH_PROPAGATION_API_READ_ONLY_COMPLETE.txt
} reason options]
if {$failed} {eco_failure $reason $options}
exit
