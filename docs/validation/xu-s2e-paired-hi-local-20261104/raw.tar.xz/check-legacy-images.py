from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tools/scripts'))
import e203_soc as soc
out=Path(__file__).resolve().parent/'legacy-images'
out.mkdir(exist_ok=False)
oldtests=out/'frozen-tests'
(oldtests/'firmware').mkdir(parents=True)
for name in ['accel.c','accel.h','start.S','main.c','link.ld']:
    data=subprocess.check_output(['git','show','d276b55:tests/e203/firmware/'+name],cwd=str(root))
    (oldtests/'firmware'/name).write_bytes(data)
newtests=soc.TESTS
records=[]
for schedule in soc.contract.SCHEDULES:
    if schedule==soc.contract.PAIRED_HI_SCHEDULE: continue
    for optimization,experiment in [('-Os','none'),('-O2','both-unroll-no-masks'),('-O3','both-unroll-no-masks')]:
        name=schedule+'-'+optimization[1:]+'-'+experiment
        pair=[]
        for kind,tests in [('frozen',oldtests),('new',newtests)]:
            destination=out/name/kind
            destination.mkdir(parents=True)
            soc.TESTS=tests
            soc.compile_firmware(destination,'riscv64-unknown-elf-',schedule,optimization,experiment)
            data=(destination/'accel_soc.verilog').read_bytes()
            pair.append(dict(kind=kind,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
        assert pair[0]['sha256']==pair[1]['sha256'],name
        records.append(dict(schedule=schedule,optimization=optimization,experiment=experiment,images=pair,equal=True))
soc.TESTS=newtests
(out/'image-equality.json').write_text(json.dumps(dict(status='PASS',scope='Local GCC14.2 RV32 load image equality for all 8 old schedules x 3 compiler profiles; no server toolchain claim',records=records),indent=2)+'\n')
print('PASS legacy schedule/profile load images',len(records))
