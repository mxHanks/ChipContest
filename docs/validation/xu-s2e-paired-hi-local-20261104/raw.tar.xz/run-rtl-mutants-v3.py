#!/usr/bin/env python3
"""Local Icarus mutation screening using the actual direct paired-HI TB."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent/'rtl-mutants-v3'
OUT.mkdir(exist_ok=False)
PERIPS=ROOT/'third-party/e203_hbirdv2/rtl/e203/perips'
WRAPPER=PERIPS/'accel_icb_slave.v'
ORIGINAL=WRAPPER.read_text()
SOURCES=['BiasBankCache.sv','LinearAutoGroupCore.sv','LinearCachedCore.sv','LinearComputeCore.sv',
         'DotProductEngine.sv','MacController.sv','MacPEArray.sv','MacPE.sv','XRowBuffer.sv',
         'WeightBankArray.sv','WeightBank.sv','Sram1024x16.sv','mem_1024x16.sv']
MUTANTS=[
 ('swap-lane-hi-halves',"row_result[{cmd_addr[3:2],1'b1}][47:32],\n                            row_result[{cmd_addr[3:2],1'b0}][47:32]",
   "row_result[{cmd_addr[3:2],1'b0}][47:32],\n                            row_result[{cmd_addr[3:2],1'b1}][47:32]"),
 ('zero-odd-lane-hi',"row_result[{cmd_addr[3:2],1'b1}][47:32],","16'b0,"),
 ('accept-unaligned-read','if (!cmd_read || cmd_addr[1:0] != 0 ||','if (!cmd_read ||'),
 ('accept-packed-write','if (!cmd_read || cmd_addr[1:0] != 0 ||','if (cmd_addr[1:0] != 0 ||'),
]
records=[]
for name,old,new in [('original-positive-control','','')]+MUTANTS:
 directory=OUT/name
 directory.mkdir()
 body=ORIGINAL
 if old:
  assert ORIGINAL.count(old)==1,(name,ORIGINAL.count(old))
  body=ORIGINAL.replace(old,new)
 source=directory/'accel_icb_slave.v'
 source.write_text(body)
 binary=directory/'sim.vvp'
 inputs=[ROOT/'tests/e203/tb_xu_paired_hi_wrapper.sv']+[PERIPS/p for p in SOURCES]+[source]
 command=['iverilog','-g2012','-s','tb_xu_paired_hi_wrapper','-o',str(binary)]+list(map(str,inputs))
 with (directory/'compile.log').open('wb') as stream:
  stream.write((json.dumps(command)+'\n').encode());stream.flush()
  compiled=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
 assert compiled.returncode==0,(name,'compile failed, not a detected behavioral mutant')
 command=['vvp',str(binary)]
 with (directory/'simulation.log').open('wb') as stream:
  stream.write((json.dumps(command)+'\n').encode());stream.flush()
  actual=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
 log=(directory/'simulation.log').read_text()
 passed=actual.returncode==0 and 'XU_PAIRED_HI_WRAPPER_PASS' in log
 if name=='original-positive-control': assert passed,(name,log)
 else: assert not passed and actual.returncode!=0 and 'FATAL:' in log,(name,log)
 records.append(dict(name=name,compile_exit=compiled.returncode,simulation_exit=actual.returncode,
                     source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                     simulation_log_sha256=hashlib.sha256((directory/'simulation.log').read_bytes()).hexdigest(),
                     expected_behavior='PASS' if name=='original-positive-control' else 'BEHAVIORAL_MUTANT_REJECTED'))
assert WRAPPER.read_text()==ORIGINAL
(OUT/'summary.json').write_text(json.dumps(dict(status='PASS',scope='Local Icarus direct-TB mutation screening; not server VCS qualification',records=records),indent=2)+'\n')
print('XU_S2E_MUTANTS_PASS original=1 rejected=4')
