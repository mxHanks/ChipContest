from pathlib import Path
import csv
import hashlib
import io
import json
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[2]
BUILD=Path(__file__).resolve().parent
DEST=ROOT/'docs/validation/xu-s2e-paired-hi-local-20261104'
DEST.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(ROOT/'tools/scripts'))
import e203_soc as soc
import xu_s2e_server_accept as entry
def sha(data): return hashlib.sha256(data).hexdigest()
paired=json.loads((BUILD/'paired-real12/result.json').read_text())
control=json.loads((BUILD/'control-real12-fresh-v3/result.json').read_text())
same=['e203_commit','source_sha256','runner_sha256','contract_sha256','versions','tools','vectors','fixture','simulator_sha256']
for name in same: assert paired[name]==control[name],name
for result in [paired,control]:
 assert result['status']=='PASS' and result['tasks']==12 and result['simulator']=='verilator'
 assert result['outputs']==304128 and result['write_words']==608256
 for name,digest in result['source_sha256'].items(): assert soc.sha(ROOT/name)==digest,name
 assert soc.sha(ROOT/'tools/scripts/e203_soc.py')==result['runner_sha256']
 assert soc.sha(ROOT/'tools/scripts/xu_firmware_contract.py')==result['contract_sha256']
rows=[]
for a,b,pa,ca in zip(paired['layers'],control['layers'],paired['result_activity'],control['result_activity']):
 rows.append(dict(layer=a['layer'],paired_cycles=a['cycles'],control_cycles=b['cycles'],delta_cycles=a['cycles']-b['cycles'],
                  paired_result_reads=pa['legacy_words']+pa['packed_words'],control_result_reads=ca['legacy_words']+ca['packed_words']))
with (DEST/'per-layer-comparison.csv').open('w',newline='') as stream:
 writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
pt=sum(r['paired_cycles'] for r in rows);ct=sum(r['control_cycles'] for r in rows)
summary=dict(status='LOCAL_SCREENING_PASS_NOT_SERVER_QUALIFIED',paired_cycles=pt,control_cycles=ct,delta_cycles=pt-ct,
             cycle_reduction_percent=100.0*(ct-pt)/ct,paired_main=paired['main_commit'],control_main=control['main_commit'],
             common_e203=paired['e203_commit'],identical_measured_inputs=same,
             main_metadata_difference='b01a895 to a544664 adds only strict server helper, its host tests and documentation; measured RTL/runner/contract/simulator identities are byte-identical. Server entry still requires identical full main commits.',
             limits='Local GCC14.2/Verilator and Icarus screening; not server GCC10.2/VCS, nominal150MHz, clear/activity, mapped equivalence, area, whole-SoC energy, official accuracy or retention.',
             chisel_changed=False,generated_compute_sv_changed=False,
             current_source_sha256={str(p.relative_to(ROOT)):soc.sha(p) for p in [ROOT/'tools/scripts/xu_s2e_server_accept.py',ROOT/'tests/e203/test_s2e_server.py',ROOT/'third-party/e203_hbirdv2/rtl/e203/perips/accel_icb_slave.v']})
(DEST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(BUILD/'runtime-freeze-smoke-v4.json').write_text(json.dumps(entry.freeze_runtime(),indent=2)+'\n')
selected={}
def addtree(base,label,skip=()):
 for p in sorted(base.rglob('*')):
  if p.is_file() and not p.is_symlink() and not any(part in skip for part in p.relative_to(base).parts):
   selected[label+'/'+p.relative_to(base).as_posix()]=p
for name in ['paired-real12','control-real12-fresh-v3']:
 addtree(BUILD/name,name,('vectors',))
for name in ['legacy-full-domain-v4','direct-paired-hi-v4','direct-legacy-v4']:
 addtree(BUILD/name,name)
addtree(BUILD/'rtl-mutants-v3','rtl-mutants-v3')
selected={k:v for k,v in selected.items() if not k.endswith('sim.vvp')}
for name in ['paired-driver.log','control-driver.log','control-driver-v3.log','numeric.log','host-final.log','host-v3.log','host-v4.log',
             'legacy-images.log','legacy-full-domain-v4.log','server-helper-host.log','server-helper-host-v2.log','server-helper-v4.log',
             'runtime-freeze-smoke-v2.json','runtime-freeze-smoke-v3.json','runtime-freeze-smoke-v4.json',
             'check-legacy-images.py','run-rtl-mutants-v3.py','rtl-mutants-v3-driver.log','archive-local-v4.py']:
 selected[name]=BUILD/name
selected['legacy-images-24-profiles/image-equality.json']=BUILD/'legacy-images/image-equality.json'
for name in ['xu-s2e-entry-independent-review-01','xu-s2e-entry-independent-review-02','xu-s2e-entry-independent-review-04','xu-paired-hi-independent-review-01']:
 addtree(ROOT/'build'/name,name)
records={}
with tarfile.open(str(DEST/'raw.tar.xz'),'w:xz') as tar:
 for name,path in sorted(selected.items()):
  data=path.read_bytes()
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  tar.addfile(info,io.BytesIO(data))
  records[name]=dict(bytes=len(data),sha256=sha(data),original_path=str(path))
manifest=dict(schema='xu-raw-byte-manifest-v1',scope=summary['limits'],archive_sha256=soc.sha(DEST/'raw.tar.xz'),
              files=len(records),bytes=sum(r['bytes'] for r in records.values()),records=records)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(files=manifest['files'],raw_bytes=manifest['bytes'],archive_bytes=(DEST/'raw.tar.xz').stat().st_size,
                      archive_sha256=manifest['archive_sha256'],summary=summary),indent=2))
