
proc sizeof_collection {x} {return [llength $x]}
proc get_object_name {x} {return $x}
proc get_pins {args} {if {[lsearch -exact $args -of_objects]>=0} {return comb/Z};return [lindex $args end]}
proc get_nets {args} {set p [lindex $args end];if {$p eq "first/Q"} {return n0};if {$p eq "comb/Z"} {return n1};error BADNET}
proc all_connected {args} {set n [lindex $args end];if {$n eq "n0"} {return {first/Q comb/A}};if {$n eq "n1"} {return {comb/Z second/D}};error BADCON}
proc get_cells {args} {if {[lindex $args end] eq "comb/A"} {return comb};return second}
proc get_attribute {object attribute} {
 if {$attribute eq "object_class"} {return pin}
 if {$attribute eq "direction"} {if {$object in {first/Q comb/Z}} {return out};return in}
 if {$attribute eq "is_hierarchical"} {return false}
 if {$attribute eq "is_sequential"} {if {$object eq "comb"} {return UNKNOWN};return true}
 if {$attribute eq "ref_name"} {return $object}
 error BADATTR
}
proc foreach_in_collection {variable collection body} {upvar 1 $variable v;foreach v $collection {uplevel 1 $body}}

proc xu_row {f values} {
 set clean {}
 foreach value $values {lappend clean [string map [list "\\" "\\\\" "\t" "\\t" "\r" "\\r" "\n" "\\n"] $value]}
 puts $f [join $clean "\t"]
}
set xu_unknown [open {/home/mxhanks/Projects/ChipContest-xu-score-opt/build/xu-timing-coverage126/local-check-03/mock-unknown.tsv} w]
xu_row $xu_unknown {scope field status detail}
proc xu_attr {object attribute collection} {
 global xu_unknown
 if {[catch {get_attribute -quiet $object $attribute} value]} {
  xu_row $xu_unknown [list [get_object_name $object] $attribute QUERY_ERROR $value]
  return QUERY_ERROR
 }
 if {$collection} {
  if {[catch {get_object_name $value} names]} {
   xu_row $xu_unknown [list [get_object_name $object] $attribute COLLECTION_NAME_ERROR $names]
   return COLLECTION_NAME_ERROR
  }
  return $names
 }
 return $value
}
proc xu_capture {name command} {
 global xu_unknown
 if {[catch {redirect -file $name {uplevel #0 $command}} message]} {
  xu_row $xu_unknown [list $name command QUERY_ERROR $message]
  set f [open ${name}.unavailable.txt w]; puts $f $message; close $f
 }
}
proc xu_pin {name} {
 set p [get_pins -quiet $name]
 if {[sizeof_collection $p]!=1 || [get_object_name $p] ne $name} {error "exact pin identity missing: $name"}
 return $p
}
proc xu_arcs {f owner arcs fromfield tofield attributes} {
 set index 0
 foreach_in_collection arc $arcs {
  set values [list $owner $index]; incr index
  foreach field $attributes {
   set collection [expr {$field eq $fromfield || $field eq $tofield}]
   lappend values [xu_attr $arc $field $collection]
  }
  xu_row $f $values
 }
}
proc xu_connections {f tag pin} {
 set ns [get_nets -of_objects $pin]
 foreach_in_collection net $ns {
  foreach_in_collection object [all_connected -leaf $net] {
   xu_row $f [list $tag [get_object_name $pin] [get_object_name $net] [get_object_name $object] [get_attribute $object object_class] [get_attribute $object direction]]
  }
 }
}
proc xu_fanin {pin} {
 puts [get_object_name [all_fanin -flat -startpoints_only -to $pin]]
}
proc xu_structural_consumers {f tag start} {
 # Structural all_connected traversal; never stops at timing-disabled arcs.
 # Sequential cells terminate the trace; every combination output is followed.
 set front [list [get_object_name $start]]; set visited [dict create]; set count 0
 while {[llength $front]>0} {
  set next {}
  foreach name $front {
   if {[dict exists $visited $name]} {continue}
   dict set visited $name 1
   incr count
   if {$count>4096} {error {bounded reset consumer traversal exceeded4096 outputs}}
   set p [xu_pin $name]
   foreach_in_collection net [get_nets -of_objects $p] {
    foreach_in_collection object [all_connected -leaf $net] {
     set on [get_object_name $object]; set class [get_attribute $object object_class]
     set direction [get_attribute $object direction]
     if {$on eq $name} {continue}
     if {$class eq "port"} {xu_row $f [list $tag $name [get_object_name $net] $on $class $direction PORT_ENDPOINT]; continue}
     if {$class ne "pin" || $direction ne "in"} {error {unexpected reset Q leaf connection}}
     set c [get_cells -of_objects $object]
     if {[sizeof_collection $c]!=1 || [get_attribute $c is_hierarchical]} {error {reset Q consumer is not exact leaf}}
     set sequential [get_attribute $c is_sequential]
     if {![string is boolean -strict $sequential]} {error {reset Q consumer sequential classification unknown}}
     xu_row $f [list $tag $name [get_object_name $net] $on [get_attribute $c ref_name] $direction $sequential]
     if {!$sequential} {
      foreach_in_collection op [get_pins -of_objects $c -filter {direction == out}] {lappend next [get_object_name $op]}
     }
    }
   }
  }
  set front $next
 }
}

set f [open {/home/mxhanks/Projects/ChipContest-xu-score-opt/build/xu-timing-coverage126/local-check-03/structural.tsv} w]
xu_structural_consumers $f 0 first/Q
close $f
