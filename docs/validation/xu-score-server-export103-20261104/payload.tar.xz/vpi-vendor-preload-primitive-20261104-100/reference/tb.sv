`timescale 1ns/1fs
module tb_xu_vpi_preload100;
  reg clk=0,cen=1,gwen=1,ret=1;
  reg [15:0] wen=16'hffff,d=0;
  reg [9:0] a=0;
  wire [15:0] q0,q1;
  RAMSP1024X16 ordinary(.Q(q0),.CLK(clk),.CEN(cen),.WEN(wen),.A(a),.D(d),.EMA(3'd2),.EMAW(2'd0),.GWEN(gwen),.RET1N(ret));
  RAMSP1024X16 \macro_storage.depth_bank[0].width_lane[0].macro (.Q(q1),.CLK(clk),.CEN(cen),.WEN(wen),.A(a),.D(d),.EMA(3'd2),.EMAW(2'd0),.GWEN(gwen),.RET1N(ret));
  function automatic [15:0] expected0(input integer col);
    case(col) 0:expected0=16'h1234;1:expected0=16'h8001;2:expected0=16'h55aa;3:expected0=16'hf00d;default:expected0=16'hxxxx;endcase
  endfunction
  function automatic [15:0] expected1(input integer col);
    case(col) 0:expected1=16'h2468;1:expected1=16'h1002;2:expected1=16'haa55;3:expected1=16'h0ff0;default:expected1=16'hxxxx;endcase
  endfunction
  integer column;
  initial begin
    // Settle the native LAST_CLK using disabled real clock edges, leaving Q unknown.
    #2;clk=1;#2;clk=0;#6;
    $xu_preload100();
    #1;
    if(q0!==16'hxxxx || q1!==16'hxxxx) $fatal(1,"XU_PRIMITIVE100_ERROR Q_preload_became_known");
    for(column=0;column<4;column=column+1) begin
      clk=0;cen=0;gwen=1;wen=16'hffff;a=12+column;
      #5;clk=1;#5;
      if(q0!==expected0(column) || q1!==expected1(column)) $fatal(1,"XU_PRIMITIVE100_ERROR physical_port_tag_or_readback");
      $xu_expect100(column);
      clk=0;#5;
    end
    // Normal disabled clocks/address/data changes must hold Q; no Q force.
    cen=1;gwen=1;a=10'd31;d=16'hdead;
    #5;clk=1;#5;$xu_hold100();clk=0;
    a=10'd255;d=16'hbeef;
    #5;clk=1;#5;$xu_hold100();clk=0;
    $xu_done100();
    #1;$finish;
  end
  initial begin #1000;$fatal(1,"XU_PRIMITIVE100_ERROR timeout");end
endmodule
