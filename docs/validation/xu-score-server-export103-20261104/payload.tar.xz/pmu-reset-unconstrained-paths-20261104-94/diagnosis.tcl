if {[catch {
set_app_var link_path [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db}]
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-reset-buffer-20261104-61-from50-n4/mapped.v}
if {![link_design xu_soc_ppa_top]} {error {exact actual61 link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
set rows [open paths.tsv w]
puts $rows "source_kind\tindex\tcheck\tcatch_rc\tcount\tworst_slack\tstatus"
set attrs [open clock-properties.tsv w]
puts $attrs "clock\tattribute\tcatch_rc\tvalue"
set calls [open tagged-net-queries.tsv w]
puts $calls "pin\tcatch_rc\tcount\tnames_or_error"
set hf [get_ports -quiet {io_pads_aon_erst_n_i_ival}]
set lf [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/wdog/AsyncResetRegVec_6_1/reg_0/q_reg/Q}]
if {[sizeof_collection $hf]!=1 || [sizeof_collection $lf]!=1} {error {source identity missing}}
redirect -file {loaded-defaults-00.txt} {printvar {*expand*}}
redirect -file {loaded-defaults-01.txt} {printvar {*waveform*}}
redirect -file {loaded-defaults-02.txt} {printvar {*base_period*}}
redirect -file {loaded-defaults-03.txt} {printvar {*repeat*}}
redirect -file {loaded-defaults-04.txt} {printvar {*clock*}}
redirect -file {loaded-defaults-05.txt} {printvar {*unconstrained*}}
redirect -file {loaded-defaults-06.txt} {printvar {*recovery*}}
redirect -file clocks.rpt {report_clock -attributes}
set c [get_clocks -quiet {xu_hfextclk}]
if {[sizeof_collection $c]!=1} {error {clock identity missing}}
set rc [catch {get_attribute -quiet $c {is_generated}} value]
puts $attrs [join [list {xu_hfextclk} {is_generated} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {is_generated_from_lib_cell}} value]
puts $attrs [join [list {xu_hfextclk} {is_generated_from_lib_cell} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {master_clock}} value]
puts $attrs [join [list {xu_hfextclk} {master_clock} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {period}} value]
puts $attrs [join [list {xu_hfextclk} {period} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {sources}} value]
puts $attrs [join [list {xu_hfextclk} {sources} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {waveform}} value]
puts $attrs [join [list {xu_hfextclk} {waveform} $rc $value] "\t"]
set c [get_clocks -quiet {xu_lfextclk}]
if {[sizeof_collection $c]!=1} {error {clock identity missing}}
set rc [catch {get_attribute -quiet $c {is_generated}} value]
puts $attrs [join [list {xu_lfextclk} {is_generated} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {is_generated_from_lib_cell}} value]
puts $attrs [join [list {xu_lfextclk} {is_generated_from_lib_cell} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {master_clock}} value]
puts $attrs [join [list {xu_lfextclk} {master_clock} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {period}} value]
puts $attrs [join [list {xu_lfextclk} {period} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {sources}} value]
puts $attrs [join [list {xu_lfextclk} {sources} $rc $value] "\t"]
set rc [catch {get_attribute -quiet $c {waveform}} value]
puts $attrs [join [list {xu_lfextclk} {waveform} $rc $value] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DSNQV0_12TR40}} {error {endpoint identity differs}}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]
if {[sizeof_collection $p]!=1} {error {reset endpoint missing}}
puts {XU_PATH_QUERY_BEGIN hf_reset-0-recovery.rpt}
redirect -file {hf_reset-0-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 0 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-0-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN hf_reset-0-removal.rpt}
redirect -file {hf_reset-0-removal.rpt} {report_timing -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 0 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-0-removal.rpt}
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DSNQNV0_12TR40}} {error {endpoint identity differs}}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]
if {[sizeof_collection $p]!=1} {error {reset endpoint missing}}
puts {XU_PATH_QUERY_BEGIN hf_reset-1-recovery.rpt}
redirect -file {hf_reset-1-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 1 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-1-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN hf_reset-1-removal.rpt}
redirect -file {hf_reset-1-removal.rpt} {report_timing -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 1 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-1-removal.rpt}
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DRNQV0_12TR40}} {error {endpoint identity differs}}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN}]
if {[sizeof_collection $p]!=1} {error {reset endpoint missing}}
puts {XU_PATH_QUERY_BEGIN hf_reset-2-recovery.rpt}
redirect -file {hf_reset-2-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 2 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-2-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN hf_reset-2-removal.rpt}
redirect -file {hf_reset-2-removal.rpt} {report_timing -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 2 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-2-removal.rpt}
puts {XU_PATH_QUERY_BEGIN lf_watchdog-2-recovery.rpt}
redirect -file {lf_watchdog-2-recovery.rpt} {report_timing -delay_type max -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {LF_WATCHDOG} 2 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END lf_watchdog-2-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN lf_watchdog-2-removal.rpt}
redirect -file {lf_watchdog-2-removal.rpt} {report_timing -delay_type min -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {LF_WATCHDOG} 2 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END lf_watchdog-2-removal.rpt}
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DRNQV0_12TR40}} {error {endpoint identity differs}}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN}]
if {[sizeof_collection $p]!=1} {error {reset endpoint missing}}
puts {XU_PATH_QUERY_BEGIN hf_reset-3-recovery.rpt}
redirect -file {hf_reset-3-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 3 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-3-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN hf_reset-3-removal.rpt}
redirect -file {hf_reset-3-removal.rpt} {report_timing -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 3 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-3-removal.rpt}
puts {XU_PATH_QUERY_BEGIN lf_watchdog-3-recovery.rpt}
redirect -file {lf_watchdog-3-recovery.rpt} {report_timing -delay_type max -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {LF_WATCHDOG} 3 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END lf_watchdog-3-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN lf_watchdog-3-removal.rpt}
redirect -file {lf_watchdog-3-removal.rpt} {report_timing -delay_type min -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {LF_WATCHDOG} 3 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END lf_watchdog-3-removal.rpt}
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {DRNQV0_12TR40}} {error {endpoint identity differs}}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN}]
if {[sizeof_collection $p]!=1} {error {reset endpoint missing}}
puts {XU_PATH_QUERY_BEGIN hf_reset-4-recovery.rpt}
redirect -file {hf_reset-4-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 4 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-4-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN hf_reset-4-removal.rpt}
redirect -file {hf_reset-4-removal.rpt} {report_timing -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $hf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {HF_RESET} 4 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END hf_reset-4-removal.rpt}
puts {XU_PATH_QUERY_BEGIN lf_watchdog-4-recovery.rpt}
redirect -file {lf_watchdog-4-recovery.rpt} {report_timing -delay_type max -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type max -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {LF_WATCHDOG} 4 {recovery} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END lf_watchdog-4-recovery.rpt}
puts {XU_PATH_QUERY_BEGIN lf_watchdog-4-removal.rpt}
redirect -file {lf_watchdog-4-removal.rpt} {report_timing -delay_type min -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10 -significant_digits 8 -path_type full_clock_expanded}
set rc [catch {get_timing_paths -delay_type min -from $lf -to $p -slack_lesser_than 1000000 -max_paths 10} paths]
set n UNKNOWN
set slack UNKNOWN
set status QUERY_ERROR_NOT_PASS
if {!$rc} {set n [sizeof_collection $paths];set status NO_PATH_UNKNOWN;if {$n>0} {set slack [get_attribute [index_collection $paths 0] slack];set status PATHS_PRESENT_DIAGNOSTIC_ONLY}}
puts $rows [join [list {LF_WATCHDOG} 4 {removal} $rc $n $slack $status] "\t"]
puts {XU_PATH_QUERY_END lf_watchdog-4-removal.rpt}
set report_before [get_app_var timing_report_unconstrained_paths]
puts [list XU_REPORT_ONLY_SWITCH_BEFORE $report_before]
set_app_var timing_report_unconstrained_paths true
puts [list XU_REPORT_ONLY_SWITCH_AFTER [get_app_var timing_report_unconstrained_paths]]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-0-recovery.rpt}
redirect -file {reported-unconstrained-hf-0-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-0-recovery.rpt}
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-0-removal.rpt}
redirect -file {reported-unconstrained-hf-0-removal.rpt} {report_timing -delay_type min -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-0-removal.rpt}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-1-recovery.rpt}
redirect -file {reported-unconstrained-hf-1-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-1-recovery.rpt}
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-1-removal.rpt}
redirect -file {reported-unconstrained-hf-1-removal.rpt} {report_timing -delay_type min -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-1-removal.rpt}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_0/q_reg/RDN}]
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-2-recovery.rpt}
redirect -file {reported-unconstrained-hf-2-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-2-recovery.rpt}
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-2-removal.rpt}
redirect -file {reported-unconstrained-hf-2-removal.rpt} {report_timing -delay_type min -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-2-removal.rpt}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_1/q_reg/RDN}]
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-3-recovery.rpt}
redirect -file {reported-unconstrained-hf-3-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-3-recovery.rpt}
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-3-removal.rpt}
redirect -file {reported-unconstrained-hf-3-removal.rpt} {report_timing -delay_type min -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-3-removal.rpt}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/RDN}]
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-4-recovery.rpt}
redirect -file {reported-unconstrained-hf-4-recovery.rpt} {report_timing -delay_type max -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-4-recovery.rpt}
puts {XU_UNCONSTRAINED_REPORT_BEGIN reported-unconstrained-hf-4-removal.rpt}
redirect -file {reported-unconstrained-hf-4-removal.rpt} {report_timing -delay_type min -from $hf -to $p -max_paths 10 -significant_digits 10 -path_type full_clock_expanded}
puts {XU_UNCONSTRAINED_REPORT_END reported-unconstrained-hf-4-removal.rpt}
set_app_var timing_report_unconstrained_paths $report_before
puts [list XU_REPORT_ONLY_SWITCH_RESTORED [get_app_var timing_report_unconstrained_paths]]
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/D}]
if {[sizeof_collection $p]!=1} {error {tagged pin identity missing}}
puts {XU_NET_QUERY_BEGIN u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/D}
set rc [catch {get_nets -of_objects $p} nets]
set n QUERY_ERROR
set names $nets
if {!$rc} {set n [sizeof_collection $nets];set names {};if {$n>0} {set names [get_object_name $nets]}}
puts $calls [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/D} $rc $n $names] "\t"]
puts {XU_NET_QUERY_END u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/D}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/D}]
if {[sizeof_collection $p]!=1} {error {tagged pin identity missing}}
puts {XU_NET_QUERY_BEGIN u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/D}
set rc [catch {get_nets -of_objects $p} nets]
set n QUERY_ERROR
set names $nets
if {!$rc} {set n [sizeof_collection $nets];set names {};if {$n>0} {set names [get_object_name $nets]}}
puts $calls [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/D} $rc $n $names] "\t"]
puts {XU_NET_QUERY_END u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/aonrst_catch/reset_n_catch_reg/reg_2/q_reg/D}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}]
if {[sizeof_collection $p]!=1} {error {tagged pin identity missing}}
puts {XU_NET_QUERY_BEGIN u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}
set rc [catch {get_nets -of_objects $p} nets]
set n QUERY_ERROR
set names $nets
if {!$rc} {set n [sizeof_collection $nets];set names {};if {$n>0} {set names [get_object_name $nets]}}
puts $calls [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN} $rc $n $names] "\t"]
puts {XU_NET_QUERY_END u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_reg/SDN}
set p [get_pins -quiet {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}]
if {[sizeof_collection $p]!=1} {error {tagged pin identity missing}}
puts {XU_NET_QUERY_BEGIN u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}
set rc [catch {get_nets -of_objects $p} nets]
set n QUERY_ERROR
set names $nets
if {!$rc} {set n [sizeof_collection $nets];set names {};if {$n>0} {set names [get_object_name $nets]}}
puts $calls [join [list {u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN} $rc $n $names] "\t"]
puts {XU_NET_QUERY_END u_soc/u_e203_subsys_top/u_sirv_aon_top/u_sirv_aon_wrapper/u_sirv_aon/u_sirv_pmu/erst_reset_r_r_reg/SDN}
redirect -file analysis-coverage.rpt {report_analysis_coverage -status_details untested}
close $rows
close $attrs
close $calls

} xu_error xu_options]} {
 puts stderr "XU_FATAL: $xu_error"
 if {[dict exists $xu_options -errorinfo]} {puts stderr [dict get $xu_options -errorinfo]}
 exit 1
}
puts {XU_RESET94_READ_ONLY_CLOCK_DIAGNOSIS_DONE_NOT_QUALIFIED}
exit 0
