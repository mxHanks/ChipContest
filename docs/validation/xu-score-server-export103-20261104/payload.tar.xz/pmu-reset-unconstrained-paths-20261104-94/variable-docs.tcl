if {[catch {
set f [open variable-doc-index.tsv w]
puts $f "variable\tcatch_rc\tmessage"
set rc [catch {redirect -file {man-var-delay_calc_enhanced_ccsn_waveform_analysis.txt} {man delay_calc_enhanced_ccsn_waveform_analysis}} msg]
puts $f [join [list {delay_calc_enhanced_ccsn_waveform_analysis} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-delay_calc_waveform_analysis_constraint_arcs_compatibility.txt} {man delay_calc_waveform_analysis_constraint_arcs_compatibility}} msg]
puts $f [join [list {delay_calc_waveform_analysis_constraint_arcs_compatibility} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-delay_calc_waveform_analysis_mode.txt} {man delay_calc_waveform_analysis_mode}} msg]
puts $f [join [list {delay_calc_waveform_analysis_mode} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-hier_clock_mapping_period_percent_tolerance.txt} {man hier_clock_mapping_period_percent_tolerance}} msg]
puts $f [join [list {hier_clock_mapping_period_percent_tolerance} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-power_dump_multi_rail_total_waveform.txt} {man power_dump_multi_rail_total_waveform}} msg]
puts $f [join [list {power_dump_multi_rail_total_waveform} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-power_enable_write_clock_activity_in_power_waveform.txt} {man power_enable_write_clock_activity_in_power_waveform}} msg]
puts $f [join [list {power_enable_write_clock_activity_in_power_waveform} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-ps_cell_robustness_clock_period_ratio.txt} {man ps_cell_robustness_clock_period_ratio}} msg]
puts $f [join [list {ps_cell_robustness_clock_period_ratio} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-timing_enable_min_pulse_width_waveform_adjustment.txt} {man timing_enable_min_pulse_width_waveform_adjustment}} msg]
puts $f [join [list {timing_enable_min_pulse_width_waveform_adjustment} $rc $msg] "\t"]
set rc [catch {redirect -file {man-var-timing_keep_waveform_on_points.txt} {man timing_keep_waveform_on_points}} msg]
puts $f [join [list {timing_keep_waveform_on_points} $rc $msg] "\t"]
close $f

} xu_error xu_options]} {
 puts stderr "XU_FATAL: $xu_error"
 if {[dict exists $xu_options -errorinfo]} {puts stderr [dict get $xu_options -errorinfo]}
 exit 1
}
puts {XU_RESET94_VARIABLE_DOCS_DONE_NOT_QUALIFIED}
exit 0
