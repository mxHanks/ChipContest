#!/usr/bin/env python3
"""Install independent S2e104 producer; no VCS, network, credentials, or source edits.

Own mapped/full-FM activity gate is separate. This bootstrap never runs a task.
Python3.6 and Git1.8 compatible.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
META = {'tool_commit': 'ab241e356360a4ec1ab8764a89732eef34fe6707', 'base_tool_commit': '554267f0d34de30289ddd43babeb450da0d1dfc9', 'source_main': '5bf123bfead8f2a37f97f3234d4e40ce8201aae9', 'source_e203': 'a0767db69628ef30e53de2d1e93dd0360c0ccf76', 'bundle_name': 'xu-s2e-activity-tools104.bundle', 'bundle_bytes': 41331, 'bundle_sha256': '4a126e833a2253b217979235b4cd1177d51b9fb020bdde5e5c401ecd0d443dd8'}
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--base',type=Path,default=Path.home()/'Desktop/xu-score-optimization-20261102')
args=parser.parse_args();B=args.base.resolve()
ORIGINAL=B/'ChipContest-s2e-ppa-tools-89'
TOOLS=B/'ChipContest-s2e-activity-tools-104'
SOURCE=B/'ChipContest-s2e-74'
DEPLOY=B/'s2e-activity-deploy-20261104-104'
DEPLOY.mkdir(parents=True,exist_ok=False)
state=dict(status='PREPARING_NOT_QUALIFIED',pid=os.getpid(),started_epoch=time.time(),meta=META,tools=str(TOOLS),source=str(SOURCE))
def need(ok,message):
 if not ok:raise ValueError(message)
def save():
 p=DEPLOY/'state.json';t=DEPLOY/'state.json.tmp';t.write_text(json.dumps(state,sort_keys=True,indent=2)+'\n');os.replace(str(t),str(p))
def git(cwd,argv):
 command=['git','--no-replace-objects']+argv
 with (DEPLOY/'prepare.log').open('ab') as stream:
  stream.write((json.dumps(dict(cwd=str(cwd),command=command))+'\n').encode());stream.flush()
  result=subprocess.run(command,cwd=str(cwd),stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
 need(result.returncode==0,'Git preparation failed: '+repr(command))
def head(path):
 return subprocess.check_output(['git','--no-replace-objects','rev-parse','HEAD'],cwd=str(path),universal_newlines=True).strip()
save()
try:
 bundle=B/META['bundle_name'];data=bundle.read_bytes()
 need(len(data)==META['bundle_bytes'] and hashlib.sha256(data).hexdigest()==META['bundle_sha256'],'exact104 tools bundle required')
 need(head(ORIGINAL)==META['base_tool_commit'],'original89 producer prerequisite differs')
 need(head(SOURCE)==META['source_main'] and head(SOURCE/'third-party/e203_hbirdv2')==META['source_e203'],'accepted frozen S2e source differs')
 need(not TOOLS.exists(),'fresh independent tools104 checkout required')
 git(B,['clone','--shared','--no-checkout',str(ORIGINAL),str(TOOLS)])
 git(TOOLS,['bundle','verify',str(bundle)])
 git(TOOLS,['fetch',str(bundle),'refs/heads/codex/xu-s2e-activity'])
 git(TOOLS,['checkout','--detach',META['tool_commit']])
 need(head(TOOLS)==META['tool_commit'],'new104 producer commit differs')
 sys.path.insert(0,str(TOOLS/'tools/ppa'))
 import xu_s2e_activity_context as context
 ctx=context.Context(SOURCE)
 state.update(status='TOOLS_READY_ACTIVITY_NOT_RUN',source_context=ctx.source,tool_context=ctx.tool,
  task00_command=[sys.executable,str(TOOLS/'tools/ppa/xu_s2e_activity_server.py'),'task00','--source-root',str(SOURCE),
                  '--ppa-root',str(B/'s2e-ppa-campaign-20261104-89'),'--out',str(B/'s2e-formal-activity-task00-20261104-104')],
  limitation='No activity run. Actual own full-SoC FM gate must pass; failed89 is immutable. Replace ppa-root only with a newly completed actual own-DC/full-FM campaign, never S2c.')
except BaseException as error:state.update(status='FAIL',error=type(error).__name__+': '+str(error))
finally:state['finished_epoch']=time.time();save()
print('XU_S2E_ACTIVITY104_TOOLS',json.dumps(state,sort_keys=True),flush=True)
sys.exit(0 if state['status']=='TOOLS_READY_ACTIVITY_NOT_RUN' else 1)
