if {[catch {
set_host_options -max_cores 2
set_app_var target_library [list {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db}]
set_app_var link_library [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db}]
set_svf repair.svf
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-gating-margin-repair-20261103-09/mapped.v}
current_design xu_soc_ppa_top
if {![link]} {error {DC link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
set_dont_touch [get_cells -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}] true

proc xu_lib_logic_signature {c} {
 set signature {}
 foreach_in_collection p [get_lib_pins -of_objects $c] {
  set function [get_attribute -quiet $p function]
  lappend signature [list [lindex [split [get_object_name $p] /] end] [get_attribute $p direction] $function]
 }
 return [lsort $signature]
}
set f [open sized-cells.tsv w]
puts $f "cell\tbefore_ref\tafter_ref\tnew_max_capacitance"
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/U42}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.055427148} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {CLKINV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {CLKINV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/U43}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.055427148} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {CLKINV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {CLKINV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/U44}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.055427148} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {CLKINV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {CLKINV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/U46}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.055427148} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {CLKINV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {CLKINV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/U45}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0554266335} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {CLKINV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {CLKINV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/U48}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0554245755} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/CLKINV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {CLKINV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {CLKINV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U33}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV0_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV1_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV1_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV1_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0287350245} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV1_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV1_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV0_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_rxfifo/U29}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_rxfifo/U31}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_txfifo/U32}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi1/u_txfifo/U33}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_rxfifo/U30}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_rxfifo/U32}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_txfifo/U30}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_perips_apb_spi2/u_txfifo/U31}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV1_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV1_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0254083305} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR3CV2_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR3CV2_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR3CV1_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_csr/U5}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_csr/U6}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U29}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U30}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U31}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U32}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U33}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U34}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U35}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U36}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U37}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U38}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U39}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U40}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U41}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U42}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U43}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U44}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U45}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U46}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U47}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U48}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U49}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U50}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U51}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U52}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U53}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U54}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U55}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U56}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U57}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U58}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_regfile/U59}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050513547000000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_shared/storage/U60}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.049763154000000004} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_shared/storage/U126}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.049763154000000004} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_shared/storage/U90}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.0497559195} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/U12}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.050392660500000006} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_shared/storage/U87}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.049741440000000005} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_shared/storage/U88}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.049741440000000005} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_shared/storage/U89}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.049712502} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/NOR2CV3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {NOR2CV3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {NOR2CV2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_csr/U7}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V2_12TR40}} {error {source driver identity changed}}
set old [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/OAI21V2_12TR40}]
set new [get_lib_cells -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/OAI21V3_12TR40}]
if {[sizeof_collection $old]!=1 || [sizeof_collection $new]!=1 || [xu_lib_logic_signature $old] ne [xu_lib_logic_signature $new]} {error {runtime library pin/function mismatch}}
set allowed [get_alternative_lib_cells -quiet $c]
if {[lsearch -exact [get_object_name $allowed] {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/OAI21V3_12TR40}]<0} {error {DC native logical/pin-number compatibility rejected candidate}}
set lp [get_lib_pins -quiet {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/OAI21V3_12TR40/ZN}]
if {[sizeof_collection $lp]!=1 || [get_attribute $lp max_capacitance]<0.049285131} {error {runtime library maxcap insufficient}}
set sized [size_cell $c {scc40nll_vhsc40_rvt_ss_v0p99_125c_basic/OAI21V3_12TR40}]
if {[sizeof_collection $sized]!=1 || [get_object_name $sized] ne [get_object_name $c] || [get_attribute $c ref_name] ne {OAI21V3_12TR40}} {error {size_cell did not apply exact candidate}}
puts $f [join [list [get_object_name $c] {OAI21V2_12TR40} [get_attribute $c ref_name] [get_attribute $lp max_capacitance]] "\t"]
close $f
# Exact post-elaboration macro groups; overlapping matches and missing/extra cells fail.
set xu_seen [dict create]
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_itcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: itcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP itcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_dtcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: dtcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP dtcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_shared/storage/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 256} {error {wrong macro count: shared}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP shared count=256 macro_ref=RAMSP1024X16 logical_bits=4194304 physical_bits=4194304 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 16} {error {wrong macro count: accelerator_weights}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP accelerator_weights count=16 macro_ref=RAMSP1024X16 logical_bits=262144 physical_bits=262144 padding_bits=0"
# RAMSP is the explicit technology SRAM namespace; reject every extra leaf/reference.
set xu_allowed_refs [list {RAMSP1024X16}]
set xu_all_macros [get_cells -quiet -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}]
if {[sizeof_collection $xu_all_macros] != 336 || [dict size $xu_seen] != 336} {error {full-SoC SRAM total must be exactly 336}}
foreach_in_collection xu_c $xu_all_macros {
  if {[lsearch -exact $xu_allowed_refs [get_attribute $xu_c ref_name]] < 0} {error {unexpected SRAM reference}}
  if {![dict exists $xu_seen [get_object_name $xu_c]]} {error {ungrouped/unaccounted SRAM macro}}
}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave && ref_name =~ accel_icb_slave*}]] != 1} {error {missing/wrong accelerator}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top && ref_name =~ e203_cpu_top*}]] != 1} {error {missing/wrong cpu}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab && ref_name =~ sirv_icb1to16_bus*}]] != 1} {error {missing/wrong interconnect}}
report_constraint -all_violators -verbose > dc-all-constraints.rpt
report_units > dc-units.rpt
report_area -hierarchy > area.rpt
report_qor > qor.rpt
report_timing -delay_type max -max_paths 50 > dc-setup.rpt
report_timing -delay_type min -max_paths 50 > dc-hold.rpt
report_constraint -all_violators > dc-violations.rpt
write -format verilog -hierarchy -output mapped.v
write -format ddc -hierarchy -output mapped.ddc
write_sdc mapped.sdc

puts {XU_FULL_SOC_CAP_SIZE_REPAIR_DC_DONE_NOT_QUALIFIED}
} xu_error]} {
  puts stderr "XU_FATAL: $xu_error"
  exit 1
}
exit 0
