from pathlib import Path
import os,json,subprocess,hashlib,time,signal,re
b=Path(__file__).resolve().parent
base=Path('/tmp/codex-ingress1064-n3-20261113-r2/candidate')
chain=json.loads((base/'toolchain.json').read_text())
tool=chain['pt'];exe=Path(tool['path'])
assert hashlib.sha256(exe.read_bytes()).hexdigest()==tool['sha256']
heavy=[]
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  try:
   if p.stat().st_uid==os.getuid() and (p/'comm').read_text().strip() in ['pt_shell','dc_shell','fm_shell','vcs','simv']:heavy.append(int(p.name))
  except (OSError,IOError):pass
assert not heavy, 'Other native job is running; refusing discovery'
allowed=sorted(os.sched_getaffinity(0));assert len(allowed)>=4
os.sched_setaffinity(0,allowed[:2])
lc=chain['library_compiler'];lc_exe=Path(lc['root'])/'bin/lc_shell'
assert hashlib.sha256(lc_exe.read_bytes()).hexdigest()==lc['launcher_sha256']
env=os.environ.copy();env['SYNOPSYS_LC_ROOT']=lc['root']
script=b/'probe.tcl'
r=dict(schema='unknown4-native-empty-design-discovery-v1',status='RUNNING',command=[str(exe),'-f',str(script)],tool_sha256=tool['sha256'],script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),max_cores=2,affinity=allowed[:2],started_epoch=time.time(),loads_design=False,modifies_constraints=False,qualification=False)
def save():(b/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
with (b/'native.log').open('w') as log:
 p=subprocess.Popen(r['command'],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 r['pid']=p.pid;save()
 try:rc=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);rc=p.wait(timeout=10);r['timed_out']=True
r['native_tool_errors']=re.findall(r'^(?:Error:|Fatal:).*$',(b/'native.log').read_text(errors='replace'),re.M)
r.update(returncode=rc,status='READ_ONLY_DISCOVERY_COMPLETE' if rc==0 and not r['native_tool_errors'] and (b/'UNKNOWN4_DISCOVERY_COMPLETE.txt').is_file() else 'FAILED',finished_epoch=time.time())
r['outputs']={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(b.iterdir())if p.is_file() and p.name not in ['execution.json','driver.log','driver.py']}
save()
print('UNKNOWN4_DISCOVERY',r['status'],r['returncode'],flush=True)
