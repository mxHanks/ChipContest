"""Private read-only UART Boolean-cone proof; no timing/metastability claim."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
source = json.loads((out / 'uart-proc.json').read_text())
module = source['modules']['apb_uart_sv']
latches = [c for c in module['cells'].values() if c['type'] == '$dlatch']
assert len(latches) == 1
latch = latches[0]
assert int(latch['parameters']['WIDTH'], 2) == 8
assert latch['connections']['D'] == module['netnames']['PWDATA']['bits'][:8]
assert latch['connections']['Q'] == module['netnames']['fifo_tx_data']['bits']
assert latch['connections']['EN'] and len(latch['connections']['EN']) == 1
valid = module['netnames']['fifo_tx_valid']['bits']
assert len(valid) == 1

drivers = {}
for name, cell in module['cells'].items():
    for port, bits in cell['connections'].items():
        if cell['port_directions'][port] == 'output':
            for bit in bits:
                if type(bit) is int:
                    assert bit not in drivers
                    drivers[bit] = name

allowed = {'$logic_not', '$logic_and', '$logic_or', '$not', '$and', '$or',
           '$eq', '$ne', '$reduce_or', '$reduce_and', '$reduce_bool', '$mux', '$pmux'}
selected, boundaries, seen = {}, set(), set()

def visit(bit):
    if type(bit) is not int or bit in seen:
        return
    seen.add(bit)
    name = drivers.get(bit)
    if name is None:
        boundaries.add(bit)
        return
    cell = module['cells'][name]
    # Current state of registers is an unrestricted primary input. This proves
    # the enable relation for every state, without a reset/APB assumption.
    if cell['type'] in {'$adff', '$adffe', '$aldff', '$aldffe', '$dff', '$dffe', '$dlatch'}:
        boundaries.add(bit)
        return
    assert cell['type'] in allowed, (name, cell['type'])
    selected[name] = copy.deepcopy(cell)
    for port, bits in cell['connections'].items():
        if cell['port_directions'][port] == 'input':
            for predecessor in bits:
                visit(predecessor)

for bit in latch['connections']['EN'] + valid:
    visit(bit)

next_bit = max(b for cell in module['cells'].values() for bits in cell['connections'].values()
               for b in bits if type(b) is int) + 1
active = latch['connections']['EN'][0]
if int(latch['parameters']['EN_POLARITY'], 2) == 0:
    selected['xu_active_enable'] = dict(hide_name=0, type='$not',
        parameters=dict(A_SIGNED='0', A_WIDTH='1', Y_WIDTH='1'),
        attributes={}, port_directions=dict(A='input', Y='output'),
        connections=dict(A=[active], Y=[next_bit]))
    active = next_bit
    next_bit += 1
selected['xu_property_compare'] = dict(hide_name=0, type='$eq',
    parameters=dict(A_SIGNED='0', B_SIGNED='0', A_WIDTH='1', B_WIDTH='1', Y_WIDTH='1'),
    attributes={}, port_directions=dict(A='input', B='input', Y='output'),
    connections=dict(A=[active], B=valid, Y=[next_bit]))
ports = {('boundary_%d' % b): dict(direction='input', bits=[b]) for b in sorted(boundaries)}
ports['xu_enable_equals_valid'] = dict(direction='output', bits=[next_bit])
cone = dict(creator='xu extraction of original Yosys proc output; no source rewrite',
    modules=dict(xu_uart_enable_cone=dict(attributes={}, parameter_default_values={},
        ports=ports, cells=selected, netnames={name: dict(hide_name=0, bits=p['bits'], attributes={})
            for name, p in ports.items()})))
(out / 'enable-cone.json').write_text(json.dumps(cone, indent=2, sort_keys=True) + '\n')
script = 'read_json ' + str(out / 'enable-cone.json') + '\nhierarchy -check -top xu_uart_enable_cone\ncheck -assert\nsat -verify -prove xu_enable_equals_valid 1 -show-inputs\n'
(out / 'prove-enable.ys').write_text(script)
with (out / 'prove-enable.log').open('x') as log:
    run = subprocess.run(['yosys', '-s', str(out / 'prove-enable.ys')],
        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=60)
text = (out / 'prove-enable.log').read_text()
assert run.returncode == 0 and 'SAT proof finished - no model found: SUCCESS!' in text
result = dict(status='BOOLEAN_ENABLE_RELATION_PROVED_NOT_TIMING_QUALIFIED',
    statement='actual UART latch transparency enable iff fifo_tx_valid, for arbitrary current register state and all two-state APB inputs; D is PWDATA[7:0]',
    limitations='No analog delay, APB setup/hold, metastability, mapped-latch timing or full-SoC qualification; this proves one Boolean relation only',
    boundary_bits=sorted(boundaries), copied_combinational_cell_count=len(selected) - 2,
    latch_enable_polarity=int(latch['parameters']['EN_POLARITY'], 2),
    returncode=run.returncode,
    sha256={name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in
        ['uart-proc.json', 'enable-cone.json', 'prove-enable.py', 'prove-enable.ys', 'prove-enable.log']})
(out / 'enable-proof.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(result))
