"""Read-only small raw receipt snapshot, independent of final171/191 names."""
import hashlib,importlib.util
from pathlib import Path
D=Path.home()/'Desktop';B=D/'xu-score-optimization-20261102'
p=D/'exporter171.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='9c72cfa8ef45b0b2cfba865af1914728077e63a4fb62c940ad7dacaa81300263'
spec=importlib.util.spec_from_file_location('xu199_frozen171',str(p));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
J=['s2e_final155_power12_166','two_candidate_autopack173','s2c_readonly177','s2e_coverage186','s2c_common_preflight190','s2c_common_full12_190','two_candidate_finalpack191']
def select(s):
 c=B/'unified-experiment-control-20261105-150'
 s.names(c,c.name,['state.json','events.jsonl','SUMMARY.md'])
 for j in J:
  s.add(c/'registrations'/(j+'.json'),c.name+'/registrations/'+j+'.json')
  s.tree(c/'runs'/j,c.name+'/runs/'+j,{'.json','.log','.txt'})
 for n in ['two-candidate-followup-registration-20261105-198.json','followup198-install.json','followup192-install.json']:
  s.add(B/n,n)
 for n in ['register198.py','frozen-jobs198.json']:
  s.add(D/'xu-two-candidate-control198'/n,'desktop/xu-two-candidate-control198/'+n,D)
 for r in ['s2e-final155-power12-20261105-166','s2c-own9c16-readonly-20261105-177','s2e-own155-coverage-readonly-20261105-186','s2c-common-scope-preflight-20261105-190','s2c-common-scope-power12-20261105-190','two-candidate-autopack-20261105-173']:
  s.names(B/r,r,['state.json','result.json','execution.json','summary.json','output-manifest177.json','output-manifest186.json'])
 s.add(Path(__file__).resolve(),'desktop/export199.py',D)
m.select=select;m.JOBS=J
m.export(B,D,B/'xu-server-two-candidate-followup-20261105-199.tar.xz',16*1024*1024)
