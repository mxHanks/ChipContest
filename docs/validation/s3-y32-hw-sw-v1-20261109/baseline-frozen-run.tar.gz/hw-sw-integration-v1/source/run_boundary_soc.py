#!/usr/bin/env python3
"""Real CPU check of frozen boundary-repair-A with a matched endpoint model.

Only source snapshot collection is replaced. The original runner retains its
firmware build, independent integer oracle, CPU protocol and physical-clear
checks, source/ELF/image/simulator pins and measured HF cycle boundaries.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
DEFAULT_CANDIDATE=ROOT/'build/timing-opt-20261109/boundary-repair-A'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def replace_once(text,before,after):
    if text.count(before)!=1:raise ValueError(f'adapter seam count {text.count(before)} for {before!r}')
    return text.replace(before,after)

def adapt_tb(text):
    text=replace_once(text,'  reg rsp_valid=0;\n  reg [31:0] rsp_rdata=0;',
        '  wire shared_mem_clk,shared_mem_rst_n;\n  wire rsp_valid,rsp_err;\n  wire [31:0] rsp_rdata;\n  wire [16:0] storage_read_addr,storage_write_addr;\n  wire storage_write;\n  wire [31:0] storage_write_data;\n  wire [3:0] storage_write_mask;')
    text=replace_once(text,'  assign cmd_ready=(!rsp_valid || rsp_ready) && (throttle==0 || cycles%throttle!=0) && !initial_block;',
        '''  // Actual endpoint controller phase is relative to shared fabric reset,
  // not wall-clock cycles. FIRST_SOURCE_STALL must be0 in this adapter.
  boundary_tb_shared_endpoint #(.THROTTLE_RESET_PHASE(2)) endpoint (
    .clk(shared_mem_clk),.rst_n(shared_mem_rst_n),
    .cmd_valid(cmd_valid),.cmd_ready(cmd_ready),.cmd_addr(cmd_addr),.cmd_read(cmd_read),
    .cmd_wdata(cmd_wdata),.cmd_wmask(cmd_wmask),
    .rsp_valid(rsp_valid),.rsp_ready(rsp_ready),.rsp_err(rsp_err),.rsp_rdata(rsp_rdata),
    .storage_read_data(ram[storage_read_addr]),.storage_read_addr(storage_read_addr),
    .storage_write(storage_write),.storage_write_addr(storage_write_addr),
    .storage_write_data(storage_write_data),.storage_write_mask(storage_write_mask)
  );
  always @(posedge shared_mem_clk)begin
    for(integer byte_lane=0;byte_lane<4;byte_lane=byte_lane+1)
      if(storage_write&&storage_write_mask[byte_lane])
        ram[storage_write_addr][8*byte_lane+:8]<=storage_write_data[8*byte_lane+:8];
  end
  // Principal timing stays on the original external HF wall clock.
  always @(posedge clk)cycles<=startup_complete?cycles+1:0;''')
    text=replace_once(text,'  e203_soc_top #(.EXTERNAL_SYSMEM(1)) dut (',
        '  e203_soc_top #(.EXTERNAL_SYSMEM(1)) dut (\n    .shared_mem_clk(shared_mem_clk),.shared_mem_rst_n(shared_mem_rst_n),')
    text=replace_once(text,"    .ext_sysmem_rsp_err(1'b0),.ext_sysmem_rsp_rdata(rsp_rdata),",
        '    .ext_sysmem_rsp_err(rsp_err),.ext_sysmem_rsp_rdata(rsp_rdata),')
    text=replace_once(text,'  always @(posedge clk) begin : monitor_and_memory',
        '  always @(posedge shared_mem_clk) begin : monitor_and_memory')
    text=replace_once(text,'    cycles<=startup_complete ? cycles+1 : 0;\n','')
    text=replace_once(text,'    if(startup_complete && rst_n) begin',
        '    if(startup_complete && shared_mem_rst_n) begin')
    text=replace_once(text,'        rsp_valid<=0;\n','')
    text=replace_once(text,'        rsp_valid<=cmd_valid;\n','')
    text=replace_once(text,'            rsp_rdata<=ram[index];\n','')
    text=replace_once(text,"              y_seen[index]=1;ram[offset/4]=cmd_wdata;writes=writes+1;pending_kind=4;",
        '              y_seen[index]=1;writes=writes+1;pending_kind=4;')
    text=replace_once(text,'    if(throttle<0 || throttle==1 || first_source_stall<0 || first_source_stall>1000) $fatal(1,"invalid channel settings");',
        '    if(throttle!=7 || first_source_stall!=0) $fatal(1,"boundary endpoint adapter requires real throttle7 and no extra first-source gating");')
    text=replace_once(text,'    startup_complete=1;rst_n=1;',
        '    startup_complete=1;rst_n=1;\n    $display("BOUNDARY_ENDPOINT real_phase_reset=2 throttle=7 transaction_clock=fabric timing_clock=HF source_preload=existing_TB_contract");')
    return text

def main():
    parser=argparse.ArgumentParser(description=__doc__,add_help=False)
    parser.add_argument('--candidate',type=Path,default=DEFAULT_CANDIDATE)
    parser.add_argument('--endpoint-proof',type=Path,required=True)
    known,rest=parser.parse_known_args()
    if any(x in rest for x in ['--replay-from','--generated-dir','--extra-source','--observer']):
        raise SystemExit('boundary adapter owns exact frozen source/observer collection')
    candidate=known.candidate.resolve();source=candidate/'source'
    ident=json.loads((candidate/'source-identity.json').read_text())
    actual={str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file()}
    if actual!=ident['files']:raise ValueError('candidate source identity drift')
    proof=json.loads(known.endpoint_proof.read_text())
    if proof.get('status')!='PASS':raise ValueError('endpoint public-interface equivalence gate is not PASS')
    model=HERE/'boundary_tb_shared_endpoint.sv'
    if proof['model_sha256']!=sha(model):raise ValueError('endpoint proof/model drift')
    spec=importlib.util.spec_from_file_location('original_dma_cpu_runner',ROOT/'experiments/s3-y32-dma-day/run_soc.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    def snapshot(out,generated,extras,observer):
        if generated or extras or observer:raise ValueError('unexpected source override')
        dst=out/'source';shutil.copytree(source,dst)
        tb=dst/'tests/tb_dma_day_soc.sv';original_tb=tb.read_text();tb.write_text(adapt_tb(original_tb))
        mon=dst/'tests/dma_physical_observer.svh'
        mon.write_text(replace_once(mon.read_text(),'always @(posedge clk) begin : dma_physical_clear_observation',
            'always @(posedge shared_mem_clk) begin : dma_physical_clear_observation'))
        shutil.copy2(model,dst/'rtl/perips'/model.name)
        shutil.copy2(Path(__file__),dst/'run_boundary_soc.py')
        shutil.copy2(known.endpoint_proof,dst/'endpoint-equivalence.json')
        (out/'adapter.json').write_text(json.dumps(dict(candidate=str(candidate),candidate_identity_sha256=sha(candidate/'source-identity.json'),
            original_runner_sha256=sha(ROOT/'experiments/s3-y32-dma-day/run_soc.py'),adapter_sha256=sha(Path(__file__)),
            endpoint_model_sha256=sha(model),endpoint_proof_sha256=sha(known.endpoint_proof),
            tb_before_sha256=hashlib.sha256(original_tb.encode()).hexdigest(),tb_after_sha256=sha(tb),
            transaction_clock='exported shared_mem_clk',physical_observer_clock='exported shared_mem_clk',
            timing_cycles='original HF wall clock',endpoint_phase='reset2 then modulo7 at everyfabric edge independently of wallclock/startup',
            no_new_dut_backdoor=True,scope='realCPUboundaryrepair single-layer; not throughput optimization or complete12 proof'),indent=2)+'\n')
        manifest={str(p.relative_to(dst)):sha(p) for p in sorted(dst.rglob('*')) if p.is_file()}
        runner.write_json(out/'source-manifest.json',dict(files=manifest,adapter='run_boundary_soc.py',candidate=str(candidate)))
        return dst,manifest
    runner.snapshot_sources=snapshot
    return runner.main(rest)

if __name__=='__main__':sys.exit(main())
