// Generated read-only physical-clear monitor. No hierarchical writes.
  wire [16:0] dma_phys_en = {`CORE.bias.memory.mem_ext.RW0_en, `CORE.weights.banks_7.sram1.mem_ext.RW0_en, `CORE.weights.banks_7.sram0.mem_ext.RW0_en, `CORE.weights.banks_6.sram1.mem_ext.RW0_en, `CORE.weights.banks_6.sram0.mem_ext.RW0_en, `CORE.weights.banks_5.sram1.mem_ext.RW0_en, `CORE.weights.banks_5.sram0.mem_ext.RW0_en, `CORE.weights.banks_4.sram1.mem_ext.RW0_en, `CORE.weights.banks_4.sram0.mem_ext.RW0_en, `CORE.weights.banks_3.sram1.mem_ext.RW0_en, `CORE.weights.banks_3.sram0.mem_ext.RW0_en, `CORE.weights.banks_2.sram1.mem_ext.RW0_en, `CORE.weights.banks_2.sram0.mem_ext.RW0_en, `CORE.weights.banks_1.sram1.mem_ext.RW0_en, `CORE.weights.banks_1.sram0.mem_ext.RW0_en, `CORE.weights.banks_0.sram1.mem_ext.RW0_en, `CORE.weights.banks_0.sram0.mem_ext.RW0_en};
  wire [16:0] dma_phys_write = {`CORE.bias.memory.mem_ext.RW0_wmode, `CORE.weights.banks_7.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_7.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_6.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_6.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_5.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_5.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_4.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_4.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_3.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_3.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_2.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_2.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_1.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_1.sram0.mem_ext.RW0_wmode, `CORE.weights.banks_0.sram1.mem_ext.RW0_wmode, `CORE.weights.banks_0.sram0.mem_ext.RW0_wmode};
  wire [169:0] dma_phys_addr = {`CORE.bias.memory.mem_ext.RW0_addr, `CORE.weights.banks_7.sram1.mem_ext.RW0_addr, `CORE.weights.banks_7.sram0.mem_ext.RW0_addr, `CORE.weights.banks_6.sram1.mem_ext.RW0_addr, `CORE.weights.banks_6.sram0.mem_ext.RW0_addr, `CORE.weights.banks_5.sram1.mem_ext.RW0_addr, `CORE.weights.banks_5.sram0.mem_ext.RW0_addr, `CORE.weights.banks_4.sram1.mem_ext.RW0_addr, `CORE.weights.banks_4.sram0.mem_ext.RW0_addr, `CORE.weights.banks_3.sram1.mem_ext.RW0_addr, `CORE.weights.banks_3.sram0.mem_ext.RW0_addr, `CORE.weights.banks_2.sram1.mem_ext.RW0_addr, `CORE.weights.banks_2.sram0.mem_ext.RW0_addr, `CORE.weights.banks_1.sram1.mem_ext.RW0_addr, `CORE.weights.banks_1.sram0.mem_ext.RW0_addr, `CORE.weights.banks_0.sram1.mem_ext.RW0_addr, `CORE.weights.banks_0.sram0.mem_ext.RW0_addr};
  wire [271:0] dma_phys_data = {`CORE.bias.memory.mem_ext.RW0_wdata, `CORE.weights.banks_7.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_7.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_6.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_6.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_5.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_5.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_4.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_4.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_3.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_3.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_2.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_2.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_1.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_1.sram0.mem_ext.RW0_wdata, `CORE.weights.banks_0.sram1.mem_ext.RW0_wdata, `CORE.weights.banks_0.sram0.mem_ext.RW0_wdata};
  wire [3:0] dma_phys_x_en = {`CORE.xs_1_1.io_wen, `CORE.xs_1_0.io_wen, `CORE.xs_0_1.io_wen, `CORE.xs_0_0.io_wen};
  wire [23:0] dma_phys_x_addr = {`CORE.xs_1_1.io_waddr, `CORE.xs_1_0.io_waddr, `CORE.xs_0_1.io_waddr, `CORE.xs_0_0.io_waddr};
  wire [63:0] dma_phys_x_data = {`CORE.xs_1_1.io_wdata, `CORE.xs_1_0.io_wdata, `CORE.xs_0_1.io_wdata, `CORE.xs_0_0.io_wdata};
  wire dma_phys_payload_zero = (`CORE.xs_0_0.data_0 === 0) &&
    (`CORE.xs_0_0.data_1 === 0) &&
    (`CORE.xs_0_0.data_2 === 0) &&
    (`CORE.xs_0_0.data_3 === 0) &&
    (`CORE.xs_0_0.data_4 === 0) &&
    (`CORE.xs_0_0.data_5 === 0) &&
    (`CORE.xs_0_0.data_6 === 0) &&
    (`CORE.xs_0_0.data_7 === 0) &&
    (`CORE.xs_0_0.data_8 === 0) &&
    (`CORE.xs_0_0.data_9 === 0) &&
    (`CORE.xs_0_0.data_10 === 0) &&
    (`CORE.xs_0_0.data_11 === 0) &&
    (`CORE.xs_0_0.data_12 === 0) &&
    (`CORE.xs_0_0.data_13 === 0) &&
    (`CORE.xs_0_0.data_14 === 0) &&
    (`CORE.xs_0_0.data_15 === 0) &&
    (`CORE.xs_0_0.data_16 === 0) &&
    (`CORE.xs_0_0.data_17 === 0) &&
    (`CORE.xs_0_0.data_18 === 0) &&
    (`CORE.xs_0_0.data_19 === 0) &&
    (`CORE.xs_0_0.data_20 === 0) &&
    (`CORE.xs_0_0.data_21 === 0) &&
    (`CORE.xs_0_0.data_22 === 0) &&
    (`CORE.xs_0_0.data_23 === 0) &&
    (`CORE.xs_0_0.data_24 === 0) &&
    (`CORE.xs_0_0.data_25 === 0) &&
    (`CORE.xs_0_0.data_26 === 0) &&
    (`CORE.xs_0_0.data_27 === 0) &&
    (`CORE.xs_0_0.data_28 === 0) &&
    (`CORE.xs_0_0.data_29 === 0) &&
    (`CORE.xs_0_0.data_30 === 0) &&
    (`CORE.xs_0_0.data_31 === 0) &&
    (`CORE.xs_0_0.data_32 === 0) &&
    (`CORE.xs_0_0.data_33 === 0) &&
    (`CORE.xs_0_0.data_34 === 0) &&
    (`CORE.xs_0_0.data_35 === 0) &&
    (`CORE.xs_0_0.data_36 === 0) &&
    (`CORE.xs_0_0.data_37 === 0) &&
    (`CORE.xs_0_0.data_38 === 0) &&
    (`CORE.xs_0_0.data_39 === 0) &&
    (`CORE.xs_0_0.data_40 === 0) &&
    (`CORE.xs_0_0.data_41 === 0) &&
    (`CORE.xs_0_0.data_42 === 0) &&
    (`CORE.xs_0_0.data_43 === 0) &&
    (`CORE.xs_0_0.data_44 === 0) &&
    (`CORE.xs_0_0.data_45 === 0) &&
    (`CORE.xs_0_0.data_46 === 0) &&
    (`CORE.xs_0_0.data_47 === 0) &&
    (`CORE.xs_0_0.data_48 === 0) &&
    (`CORE.xs_0_0.data_49 === 0) &&
    (`CORE.xs_0_0.data_50 === 0) &&
    (`CORE.xs_0_0.data_51 === 0) &&
    (`CORE.xs_0_0.data_52 === 0) &&
    (`CORE.xs_0_0.data_53 === 0) &&
    (`CORE.xs_0_0.data_54 === 0) &&
    (`CORE.xs_0_0.data_55 === 0) &&
    (`CORE.xs_0_0.data_56 === 0) &&
    (`CORE.xs_0_0.data_57 === 0) &&
    (`CORE.xs_0_0.data_58 === 0) &&
    (`CORE.xs_0_0.data_59 === 0) &&
    (`CORE.xs_0_0.data_60 === 0) &&
    (`CORE.xs_0_0.data_61 === 0) &&
    (`CORE.xs_0_0.data_62 === 0) &&
    (`CORE.xs_0_0.data_63 === 0) &&
    (`CORE.xs_0_1.data_0 === 0) &&
    (`CORE.xs_0_1.data_1 === 0) &&
    (`CORE.xs_0_1.data_2 === 0) &&
    (`CORE.xs_0_1.data_3 === 0) &&
    (`CORE.xs_0_1.data_4 === 0) &&
    (`CORE.xs_0_1.data_5 === 0) &&
    (`CORE.xs_0_1.data_6 === 0) &&
    (`CORE.xs_0_1.data_7 === 0) &&
    (`CORE.xs_0_1.data_8 === 0) &&
    (`CORE.xs_0_1.data_9 === 0) &&
    (`CORE.xs_0_1.data_10 === 0) &&
    (`CORE.xs_0_1.data_11 === 0) &&
    (`CORE.xs_0_1.data_12 === 0) &&
    (`CORE.xs_0_1.data_13 === 0) &&
    (`CORE.xs_0_1.data_14 === 0) &&
    (`CORE.xs_0_1.data_15 === 0) &&
    (`CORE.xs_0_1.data_16 === 0) &&
    (`CORE.xs_0_1.data_17 === 0) &&
    (`CORE.xs_0_1.data_18 === 0) &&
    (`CORE.xs_0_1.data_19 === 0) &&
    (`CORE.xs_0_1.data_20 === 0) &&
    (`CORE.xs_0_1.data_21 === 0) &&
    (`CORE.xs_0_1.data_22 === 0) &&
    (`CORE.xs_0_1.data_23 === 0) &&
    (`CORE.xs_0_1.data_24 === 0) &&
    (`CORE.xs_0_1.data_25 === 0) &&
    (`CORE.xs_0_1.data_26 === 0) &&
    (`CORE.xs_0_1.data_27 === 0) &&
    (`CORE.xs_0_1.data_28 === 0) &&
    (`CORE.xs_0_1.data_29 === 0) &&
    (`CORE.xs_0_1.data_30 === 0) &&
    (`CORE.xs_0_1.data_31 === 0) &&
    (`CORE.xs_0_1.data_32 === 0) &&
    (`CORE.xs_0_1.data_33 === 0) &&
    (`CORE.xs_0_1.data_34 === 0) &&
    (`CORE.xs_0_1.data_35 === 0) &&
    (`CORE.xs_0_1.data_36 === 0) &&
    (`CORE.xs_0_1.data_37 === 0) &&
    (`CORE.xs_0_1.data_38 === 0) &&
    (`CORE.xs_0_1.data_39 === 0) &&
    (`CORE.xs_0_1.data_40 === 0) &&
    (`CORE.xs_0_1.data_41 === 0) &&
    (`CORE.xs_0_1.data_42 === 0) &&
    (`CORE.xs_0_1.data_43 === 0) &&
    (`CORE.xs_0_1.data_44 === 0) &&
    (`CORE.xs_0_1.data_45 === 0) &&
    (`CORE.xs_0_1.data_46 === 0) &&
    (`CORE.xs_0_1.data_47 === 0) &&
    (`CORE.xs_0_1.data_48 === 0) &&
    (`CORE.xs_0_1.data_49 === 0) &&
    (`CORE.xs_0_1.data_50 === 0) &&
    (`CORE.xs_0_1.data_51 === 0) &&
    (`CORE.xs_0_1.data_52 === 0) &&
    (`CORE.xs_0_1.data_53 === 0) &&
    (`CORE.xs_0_1.data_54 === 0) &&
    (`CORE.xs_0_1.data_55 === 0) &&
    (`CORE.xs_0_1.data_56 === 0) &&
    (`CORE.xs_0_1.data_57 === 0) &&
    (`CORE.xs_0_1.data_58 === 0) &&
    (`CORE.xs_0_1.data_59 === 0) &&
    (`CORE.xs_0_1.data_60 === 0) &&
    (`CORE.xs_0_1.data_61 === 0) &&
    (`CORE.xs_0_1.data_62 === 0) &&
    (`CORE.xs_0_1.data_63 === 0) &&
    (`CORE.xs_1_0.data_0 === 0) &&
    (`CORE.xs_1_0.data_1 === 0) &&
    (`CORE.xs_1_0.data_2 === 0) &&
    (`CORE.xs_1_0.data_3 === 0) &&
    (`CORE.xs_1_0.data_4 === 0) &&
    (`CORE.xs_1_0.data_5 === 0) &&
    (`CORE.xs_1_0.data_6 === 0) &&
    (`CORE.xs_1_0.data_7 === 0) &&
    (`CORE.xs_1_0.data_8 === 0) &&
    (`CORE.xs_1_0.data_9 === 0) &&
    (`CORE.xs_1_0.data_10 === 0) &&
    (`CORE.xs_1_0.data_11 === 0) &&
    (`CORE.xs_1_0.data_12 === 0) &&
    (`CORE.xs_1_0.data_13 === 0) &&
    (`CORE.xs_1_0.data_14 === 0) &&
    (`CORE.xs_1_0.data_15 === 0) &&
    (`CORE.xs_1_0.data_16 === 0) &&
    (`CORE.xs_1_0.data_17 === 0) &&
    (`CORE.xs_1_0.data_18 === 0) &&
    (`CORE.xs_1_0.data_19 === 0) &&
    (`CORE.xs_1_0.data_20 === 0) &&
    (`CORE.xs_1_0.data_21 === 0) &&
    (`CORE.xs_1_0.data_22 === 0) &&
    (`CORE.xs_1_0.data_23 === 0) &&
    (`CORE.xs_1_0.data_24 === 0) &&
    (`CORE.xs_1_0.data_25 === 0) &&
    (`CORE.xs_1_0.data_26 === 0) &&
    (`CORE.xs_1_0.data_27 === 0) &&
    (`CORE.xs_1_0.data_28 === 0) &&
    (`CORE.xs_1_0.data_29 === 0) &&
    (`CORE.xs_1_0.data_30 === 0) &&
    (`CORE.xs_1_0.data_31 === 0) &&
    (`CORE.xs_1_0.data_32 === 0) &&
    (`CORE.xs_1_0.data_33 === 0) &&
    (`CORE.xs_1_0.data_34 === 0) &&
    (`CORE.xs_1_0.data_35 === 0) &&
    (`CORE.xs_1_0.data_36 === 0) &&
    (`CORE.xs_1_0.data_37 === 0) &&
    (`CORE.xs_1_0.data_38 === 0) &&
    (`CORE.xs_1_0.data_39 === 0) &&
    (`CORE.xs_1_0.data_40 === 0) &&
    (`CORE.xs_1_0.data_41 === 0) &&
    (`CORE.xs_1_0.data_42 === 0) &&
    (`CORE.xs_1_0.data_43 === 0) &&
    (`CORE.xs_1_0.data_44 === 0) &&
    (`CORE.xs_1_0.data_45 === 0) &&
    (`CORE.xs_1_0.data_46 === 0) &&
    (`CORE.xs_1_0.data_47 === 0) &&
    (`CORE.xs_1_0.data_48 === 0) &&
    (`CORE.xs_1_0.data_49 === 0) &&
    (`CORE.xs_1_0.data_50 === 0) &&
    (`CORE.xs_1_0.data_51 === 0) &&
    (`CORE.xs_1_0.data_52 === 0) &&
    (`CORE.xs_1_0.data_53 === 0) &&
    (`CORE.xs_1_0.data_54 === 0) &&
    (`CORE.xs_1_0.data_55 === 0) &&
    (`CORE.xs_1_0.data_56 === 0) &&
    (`CORE.xs_1_0.data_57 === 0) &&
    (`CORE.xs_1_0.data_58 === 0) &&
    (`CORE.xs_1_0.data_59 === 0) &&
    (`CORE.xs_1_0.data_60 === 0) &&
    (`CORE.xs_1_0.data_61 === 0) &&
    (`CORE.xs_1_0.data_62 === 0) &&
    (`CORE.xs_1_0.data_63 === 0) &&
    (`CORE.xs_1_1.data_0 === 0) &&
    (`CORE.xs_1_1.data_1 === 0) &&
    (`CORE.xs_1_1.data_2 === 0) &&
    (`CORE.xs_1_1.data_3 === 0) &&
    (`CORE.xs_1_1.data_4 === 0) &&
    (`CORE.xs_1_1.data_5 === 0) &&
    (`CORE.xs_1_1.data_6 === 0) &&
    (`CORE.xs_1_1.data_7 === 0) &&
    (`CORE.xs_1_1.data_8 === 0) &&
    (`CORE.xs_1_1.data_9 === 0) &&
    (`CORE.xs_1_1.data_10 === 0) &&
    (`CORE.xs_1_1.data_11 === 0) &&
    (`CORE.xs_1_1.data_12 === 0) &&
    (`CORE.xs_1_1.data_13 === 0) &&
    (`CORE.xs_1_1.data_14 === 0) &&
    (`CORE.xs_1_1.data_15 === 0) &&
    (`CORE.xs_1_1.data_16 === 0) &&
    (`CORE.xs_1_1.data_17 === 0) &&
    (`CORE.xs_1_1.data_18 === 0) &&
    (`CORE.xs_1_1.data_19 === 0) &&
    (`CORE.xs_1_1.data_20 === 0) &&
    (`CORE.xs_1_1.data_21 === 0) &&
    (`CORE.xs_1_1.data_22 === 0) &&
    (`CORE.xs_1_1.data_23 === 0) &&
    (`CORE.xs_1_1.data_24 === 0) &&
    (`CORE.xs_1_1.data_25 === 0) &&
    (`CORE.xs_1_1.data_26 === 0) &&
    (`CORE.xs_1_1.data_27 === 0) &&
    (`CORE.xs_1_1.data_28 === 0) &&
    (`CORE.xs_1_1.data_29 === 0) &&
    (`CORE.xs_1_1.data_30 === 0) &&
    (`CORE.xs_1_1.data_31 === 0) &&
    (`CORE.xs_1_1.data_32 === 0) &&
    (`CORE.xs_1_1.data_33 === 0) &&
    (`CORE.xs_1_1.data_34 === 0) &&
    (`CORE.xs_1_1.data_35 === 0) &&
    (`CORE.xs_1_1.data_36 === 0) &&
    (`CORE.xs_1_1.data_37 === 0) &&
    (`CORE.xs_1_1.data_38 === 0) &&
    (`CORE.xs_1_1.data_39 === 0) &&
    (`CORE.xs_1_1.data_40 === 0) &&
    (`CORE.xs_1_1.data_41 === 0) &&
    (`CORE.xs_1_1.data_42 === 0) &&
    (`CORE.xs_1_1.data_43 === 0) &&
    (`CORE.xs_1_1.data_44 === 0) &&
    (`CORE.xs_1_1.data_45 === 0) &&
    (`CORE.xs_1_1.data_46 === 0) &&
    (`CORE.xs_1_1.data_47 === 0) &&
    (`CORE.xs_1_1.data_48 === 0) &&
    (`CORE.xs_1_1.data_49 === 0) &&
    (`CORE.xs_1_1.data_50 === 0) &&
    (`CORE.xs_1_1.data_51 === 0) &&
    (`CORE.xs_1_1.data_52 === 0) &&
    (`CORE.xs_1_1.data_53 === 0) &&
    (`CORE.xs_1_1.data_54 === 0) &&
    (`CORE.xs_1_1.data_55 === 0) &&
    (`CORE.xs_1_1.data_56 === 0) &&
    (`CORE.xs_1_1.data_57 === 0) &&
    (`CORE.xs_1_1.data_58 === 0) &&
    (`CORE.xs_1_1.data_59 === 0) &&
    (`CORE.xs_1_1.data_60 === 0) &&
    (`CORE.xs_1_1.data_61 === 0) &&
    (`CORE.xs_1_1.data_62 === 0) &&
    (`CORE.xs_1_1.data_63 === 0) &&
    (`CORE.engines_0.peArray.pes_0.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_1.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_2.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_3.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_4.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_5.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_6.ACC === 0) &&
    (`CORE.engines_0.peArray.pes_7.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_0.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_1.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_2.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_3.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_4.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_5.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_6.ACC === 0) &&
    (`CORE.engines_1.peArray.pes_7.ACC === 0) &&
    (`CORE.engines_0.resultReg_0 === 0) &&
    (`CORE.engines_0.resultReg_1 === 0) &&
    (`CORE.engines_0.resultReg_2 === 0) &&
    (`CORE.engines_0.resultReg_3 === 0) &&
    (`CORE.engines_0.resultReg_4 === 0) &&
    (`CORE.engines_0.resultReg_5 === 0) &&
    (`CORE.engines_0.resultReg_6 === 0) &&
    (`CORE.engines_0.resultReg_7 === 0) &&
    (`CORE.engines_1.resultReg_0 === 0) &&
    (`CORE.engines_1.resultReg_1 === 0) &&
    (`CORE.engines_1.resultReg_2 === 0) &&
    (`CORE.engines_1.resultReg_3 === 0) &&
    (`CORE.engines_1.resultReg_4 === 0) &&
    (`CORE.engines_1.resultReg_5 === 0) &&
    (`CORE.engines_1.resultReg_6 === 0) &&
    (`CORE.engines_1.resultReg_7 === 0) &&
    (`CORE.results_0_0_0 === 0) &&
    (`CORE.results_0_0_1 === 0) &&
    (`CORE.results_0_0_2 === 0) &&
    (`CORE.results_0_0_3 === 0) &&
    (`CORE.results_0_0_4 === 0) &&
    (`CORE.results_0_0_5 === 0) &&
    (`CORE.results_0_0_6 === 0) &&
    (`CORE.results_0_0_7 === 0) &&
    (`CORE.results_0_1_0 === 0) &&
    (`CORE.results_0_1_1 === 0) &&
    (`CORE.results_0_1_2 === 0) &&
    (`CORE.results_0_1_3 === 0) &&
    (`CORE.results_0_1_4 === 0) &&
    (`CORE.results_0_1_5 === 0) &&
    (`CORE.results_0_1_6 === 0) &&
    (`CORE.results_0_1_7 === 0) &&
    (`CORE.results_1_0_0 === 0) &&
    (`CORE.results_1_0_1 === 0) &&
    (`CORE.results_1_0_2 === 0) &&
    (`CORE.results_1_0_3 === 0) &&
    (`CORE.results_1_0_4 === 0) &&
    (`CORE.results_1_0_5 === 0) &&
    (`CORE.results_1_0_6 === 0) &&
    (`CORE.results_1_0_7 === 0) &&
    (`CORE.results_1_1_0 === 0) &&
    (`CORE.results_1_1_1 === 0) &&
    (`CORE.results_1_1_2 === 0) &&
    (`CORE.results_1_1_3 === 0) &&
    (`CORE.results_1_1_4 === 0) &&
    (`CORE.results_1_1_5 === 0) &&
    (`CORE.results_1_1_6 === 0) &&
    (`CORE.results_1_1_7 === 0) &&
    (`CORE.bias.slotData_0_0 === 0) &&
    (`CORE.bias.slotData_0_1 === 0) &&
    (`CORE.bias.slotData_0_2 === 0) &&
    (`CORE.bias.slotData_0_3 === 0) &&
    (`CORE.bias.slotData_0_4 === 0) &&
    (`CORE.bias.slotData_0_5 === 0) &&
    (`CORE.bias.slotData_0_6 === 0) &&
    (`CORE.bias.slotData_0_7 === 0) &&
    (`CORE.bias.slotData_1_0 === 0) &&
    (`CORE.bias.slotData_1_1 === 0) &&
    (`CORE.bias.slotData_1_2 === 0) &&
    (`CORE.bias.slotData_1_3 === 0) &&
    (`CORE.bias.slotData_1_4 === 0) &&
    (`CORE.bias.slotData_1_5 === 0) &&
    (`CORE.bias.slotData_1_6 === 0) &&
    (`CORE.bias.slotData_1_7 === 0);
  reg dma_phys_observing=0;
  integer dma_phys_clears=0,dma_phys_writes_w=0,dma_phys_writes_b=0,dma_phys_writes_x=0;
  integer dma_phys_cycles=0,dma_phys_w_dirty_before=0,dma_phys_b_dirty_before=0,dma_phys_x_dirty_before=0;
  reg [1023:0] dma_phys_seen_w[0:15],dma_phys_dirty_w[0:15];
  reg [767:0] dma_phys_seen_b=0,dma_phys_dirty_b=0;
  reg [63:0] dma_phys_seen_x[0:3],dma_phys_dirty_x[0:3];
  integer dma_phys_i,dma_phys_j,dma_phys_address;
  initial begin
    for(integer i=0;i<16;i=i+1)begin dma_phys_seen_w[i]=0;dma_phys_dirty_w[i]=0;end
    for(integer i=0;i<4;i=i+1)begin dma_phys_seen_x[i]=0;dma_phys_dirty_x[i]=0;end
  end
  always @(posedge shared_mem_clk) begin : dma_physical_clear_observation
    if(`CORE.reset !== 1'b0)begin
      dma_phys_observing=0;dma_phys_clears=0;
      dma_phys_seen_b=0;dma_phys_dirty_b=0;
      for(dma_phys_i=0;dma_phys_i<16;dma_phys_i=dma_phys_i+1)begin
        dma_phys_seen_w[dma_phys_i]=0;dma_phys_dirty_w[dma_phys_i]=0;
      end
      for(dma_phys_i=0;dma_phys_i<4;dma_phys_i=dma_phys_i+1)begin
        dma_phys_seen_x[dma_phys_i]=0;dma_phys_dirty_x[dma_phys_i]=0;
      end
    end else begin
      if(`CORE.io_abort)begin
        // An abort invalidates this observation; it never makes a completed
        // physical-clear claim. A subsequent clear starts fresh coverage.
        dma_phys_observing=0;
      end
      if(`CORE.io_clearValid && `CORE.io_clearReady)begin
        if(dma_phys_observing) $fatal(1,"physical clear overlaps a prior clear");
        if(`DMA.pending || `DMA.locked || `CORE.io_active || `CORE.io_outValid)
          $fatal(1,"physical clear started before owners drained");
        dma_phys_observing=1;dma_phys_cycles=0;
        dma_phys_writes_w=0;dma_phys_writes_b=0;dma_phys_writes_x=0;
        dma_phys_w_dirty_before=0;dma_phys_b_dirty_before=0;dma_phys_x_dirty_before=0;
        for(dma_phys_i=0;dma_phys_i<16;dma_phys_i=dma_phys_i+1)begin
          dma_phys_seen_w[dma_phys_i]=0;
          for(dma_phys_j=0;dma_phys_j<1024;dma_phys_j=dma_phys_j+1)
            dma_phys_w_dirty_before=dma_phys_w_dirty_before+dma_phys_dirty_w[dma_phys_i][dma_phys_j];
        end
        dma_phys_seen_b=0;
        for(dma_phys_j=0;dma_phys_j<768;dma_phys_j=dma_phys_j+1)
          dma_phys_b_dirty_before=dma_phys_b_dirty_before+dma_phys_dirty_b[dma_phys_j];
        for(dma_phys_i=0;dma_phys_i<4;dma_phys_i=dma_phys_i+1)begin
          dma_phys_seen_x[dma_phys_i]=0;
          for(dma_phys_j=0;dma_phys_j<64;dma_phys_j=dma_phys_j+1)
            dma_phys_x_dirty_before=dma_phys_x_dirty_before+dma_phys_dirty_x[dma_phys_i][dma_phys_j];
        end
        if(!warmup_active && dma_phys_clears>0 &&
          (dma_phys_w_dirty_before==0 || dma_phys_b_dirty_before==0 || dma_phys_x_dirty_before==0))
          $fatal(1,"counted task clear lacks prior public nonzero W/bias/X writes");
        $display("DMA_PHYSICAL_CLEAR_BEGIN call=%0d warmup=%0d nonzero_W=%0d nonzero_BIAS=%0d nonzero_X=%0d observed_last_public_writes=1",
          dma_phys_clears+1,warmup_active,dma_phys_w_dirty_before,dma_phys_b_dirty_before,dma_phys_x_dirty_before);
      end
      if(dma_phys_observing)dma_phys_cycles=dma_phys_cycles+1;
      for(dma_phys_i=0;dma_phys_i<17;dma_phys_i=dma_phys_i+1)begin
        if(dma_phys_en[dma_phys_i] && !dma_phys_write[dma_phys_i] && dma_phys_observing)
          $fatal(1,"physical SRAM read during exclusive clear");
        if(dma_phys_en[dma_phys_i] && dma_phys_write[dma_phys_i])begin
          dma_phys_address=dma_phys_addr[10*dma_phys_i+:10];
          if(dma_phys_i<16)
            dma_phys_dirty_w[dma_phys_i][dma_phys_address]=(dma_phys_data[16*dma_phys_i+:16]!==16'b0);
          else begin
            if(dma_phys_address>=768) $fatal(1,"physical bias address outside 768-word aperture");
            dma_phys_dirty_b[dma_phys_address]=(dma_phys_data[16*dma_phys_i+:16]!==16'b0);
          end
          if(dma_phys_observing)begin
            if(dma_phys_data[16*dma_phys_i+:16]!==16'b0) $fatal(1,"nonzero physical SRAM clear data");
            if(dma_phys_i<16)begin
              if(dma_phys_seen_w[dma_phys_i][dma_phys_address]) $fatal(1,"duplicate physical W clear address");
              dma_phys_seen_w[dma_phys_i][dma_phys_address]=1;
              dma_phys_writes_w=dma_phys_writes_w+1;
            end else begin
              if(dma_phys_seen_b[dma_phys_address]) $fatal(1,"duplicate physical bias clear address");
              dma_phys_seen_b[dma_phys_address]=1;dma_phys_writes_b=dma_phys_writes_b+1;
            end
          end
        end
      end
      for(dma_phys_i=0;dma_phys_i<4;dma_phys_i=dma_phys_i+1)if(dma_phys_x_en[dma_phys_i])begin
        dma_phys_address=dma_phys_x_addr[6*dma_phys_i+:6];
        dma_phys_dirty_x[dma_phys_i][dma_phys_address]=(dma_phys_x_data[16*dma_phys_i+:16]!==16'b0);
        if(dma_phys_observing)begin
          if(dma_phys_x_data[16*dma_phys_i+:16]!==16'b0 || dma_phys_seen_x[dma_phys_i][dma_phys_address])
            $fatal(1,"bad or duplicate physical X clear write");
          dma_phys_seen_x[dma_phys_i][dma_phys_address]=1;dma_phys_writes_x=dma_phys_writes_x+1;
        end
      end
      if(`CORE.io_clearDone)begin
        if(!dma_phys_observing || dma_phys_writes_w!=16384 || dma_phys_writes_b!=768 || dma_phys_writes_x!=256)
          $fatal(1,"incomplete physical clear totals W=%0d B=%0d X=%0d",dma_phys_writes_w,dma_phys_writes_b,dma_phys_writes_x);
        for(dma_phys_i=0;dma_phys_i<16;dma_phys_i=dma_phys_i+1)
          if((&dma_phys_seen_w[dma_phys_i])!==1'b1) $fatal(1,"physical W address coverage hole");
        if((&dma_phys_seen_b)!==1'b1) $fatal(1,"physical bias address coverage hole");
        for(dma_phys_i=0;dma_phys_i<4;dma_phys_i=dma_phys_i+1)
          if((&dma_phys_seen_x[dma_phys_i])!==1'b1) $fatal(1,"physical X address coverage hole");
        if(!dma_phys_payload_zero) $fatal(1,"physical X/ACC/result/FIFO/bias-cache payload not zero at clear_done");
        if(`DMA.y_payload!==256'b0 || `DMA.b_low!==32'b0 || `DMA.b_high!==8'b0)
          $fatal(1,"DMA snapshot/bias assembly payload not zero at clear_done");
        if(`DMA.pending || `DMA.locked || `CORE.io_active || `CORE.io_outValid)
          $fatal(1,"physical clear done with outstanding owners");
        dma_phys_clears=dma_phys_clears+1;dma_phys_observing=0;
        $display("DMA_PHYSICAL_CLEAR_PASS call=%0d warmup=%0d W=16384 BIAS=768 X=256 total16bit_writes=17408 physical_cycles=%0d X_REGS=256 ACC=16 ENGINE_RESULT=16 FIFO=32 BIAS_CACHE=16 DMA_SNAPSHOT=1 all_addresses=1 all_payload_zero=1",
          dma_phys_clears,warmup_active,dma_phys_cycles);
      end
    end
  end
