// Testbench endpoint control matching the real xu_shared_icb_sram exactly.
// Storage is external testbench state so the established input-fixture preload
// remains outside the DUT. All DUT reads/writes still use public ICB signals.
module boundary_tb_shared_endpoint #(
  parameter THROTTLE_RESET_PHASE=2
)(
  input wire clk,rst_n,
  input wire cmd_valid,
  output wire cmd_ready,
  input wire [31:0] cmd_addr,
  input wire cmd_read,
  input wire [31:0] cmd_wdata,
  input wire [3:0] cmd_wmask,
  output reg rsp_valid,
  input wire rsp_ready,
  output reg rsp_err,
  output wire [31:0] rsp_rdata,
  input wire [31:0] storage_read_data,
  output reg [16:0] storage_read_addr,
  output wire storage_write,
  output wire [16:0] storage_write_addr,
  output wire [31:0] storage_write_data,
  output wire [3:0] storage_write_mask
);
  reg [2:0] phase;
  wire accept=cmd_valid&&cmd_ready;
  wire in_range=cmd_addr>=32'ha0000000&&cmd_addr<32'ha0080000&&cmd_addr[1:0]==0;
  assign cmd_ready=(~rsp_valid||rsp_ready)&&phase!=0;
  assign rsp_rdata=rsp_err?32'b0:storage_read_data;
  assign storage_write=accept&&in_range&&!cmd_read;
  assign storage_write_addr=cmd_addr[18:2];
  assign storage_write_data=cmd_wdata;
  assign storage_write_mask=cmd_wmask;
  always @(posedge clk) if(accept&&in_range&&cmd_read)
    storage_read_addr<=cmd_addr[18:2];
  always @(posedge clk) begin
    if(!rst_n)begin phase<=THROTTLE_RESET_PHASE;rsp_valid<=0;rsp_err<=0;end
    else begin
      phase<=phase==6?0:phase+1'b1;
      if(rsp_valid&&rsp_ready)rsp_valid<=0;
      if(accept)begin rsp_valid<=1;rsp_err<=~in_range;end
    end
  end
endmodule
