# 软硬件联调冻结候选 v1（2026-11-09）

建议统一联调 **16 PE（两行×八列）＋共享 W/bias＋独立外围 DMA＋共享端点共同 clock/reset 修复 A**。软件可见接口按本文冻结。它是完整 CPU 功能验证通过的联调候选；尚未完成最终时序、新面积或正式平台资格验收。

## 已实现的硬件优化

| 改动 | 实际行为与收益 |
| --- | --- |
| 两行×八列 16 PE | 两个 8 PE 引擎同时处理两行；第 99 行只启用第一路。相同搬运路径下，完整任务吞吐由约 640.60 提高到 1,188.72 task/s。 |
| 共享权重与 bias | 两路使用同一套 16 个 W SRAM 宏和 1 个 bias 宏；没有复制第二套权重存储。每个任务重新装载自己的参数。 |
| 独立外围 DMA | CPU 提交四个地址并启动；硬件经实际仲裁和共享存储接口装载、计算和写回。每任务 40,384 笔请求/响应；不经 NICE 串行 LSU。CPU 每任务 6 次 MMIO 写。 |
| packed W 与计算搬运重叠 | 一个 32 位 W 源字同拍装入两个 INT16 bank；512 B X 双缓冲装载下一对行，224 B 结果缓冲承接写回。 |
| 硬件并行物理清零 | 每任务从 66,802 拍降到 2,052 拍；实际清零 17,408 个物理地址，并清空累加器、缓存和控制状态。 |
| 共同 clock/reset 修复 A | 共享端点接已有 fabric clock/reset，修复分频或单独复位导致的事务丢失；CPU、LSU、BIU 及原在途配置的 42 个文件不变。 |

所有吞吐数字按 150 MHz 换算；目前不代表已通过该频率的时序验收。当前联调候选仍使用已验证的 48 位累加路径；41 位累加、更多 PE、通用多在途 DMA 及失败的时钟树试验不在本候选内。

## 当前已核实结果

修复 A 的 CPU 完整 12 层于本轮实际执行通过：304,128 个计量 Y32 输出逐位一致，另一个预热任务的 25,344 个输出也检查。每层独立输入/参数身份、事务计数、payload、真实 clear 和 gap 均与原 full12 基线逐层相同。

| 方案 | 完整 12 任务主周期（含真实 clear） | 150 MHz 换算吞吐 |
| --- | ---: | ---: |
| 原 8 PE | 5,874,840 | 306.39 task/s |
| 新 DMA 单行 | 2,809,873 | 640.60 task/s |
| 新 DMA 双行＋修复 A | 1,514,236 | 1,188.72 task/s |

新候选 payload 1,489,612 拍、真实 clear 24,624 拍；clear 后 gap 492 拍另列。包含 gap 合计 1,514,728 拍，约 1,188.33 task/s。源码漂移为零，42 份 CPU 文件逐字节不变；固件装载 image 与原 full12 相同。ELF 非装载 `.strtab` 中的临时对象名差异已有独立记录。

原件：`build/timing-opt-20261109/boundary-repair-A/cpu-full12-r1/` 的 `result.json`、`simulation.log`、`integration-audit.json` 与 `per-layer.csv`。单层、28 项协议对照、实际 20 级 resetcatch 停钟测试和端点模型逐拍对照均保留在 `boundary-repair-A/`。

## 软件侧冻结接口

- 编译打开 `XU_MATRIX_DMA`；不打开时保留旧加速器/NICE 回退构建。
- MMIO 基址 `0x10042300`，ID 寄存器返回 `0x444d4131`。采用 32 位对齐整字访问。
- `+0x04`：写 `1` 真实清零，写 `0x102` 启动双行模式；`2` 为同硬件单行对照模式。
- `+0x08`：busy bit0、done bit1、error bit2、clear_done bit3；`+0x0c` 读取首个错误码。
- `+0x10/+0x14/+0x18/+0x1c`：X/W/bias/Y 起始地址。START 时冻结四个地址；busy 时配置写入报错。
- 共享地址范围 `0xa0000000..0xa0080000`，Y 不得与输入或参数重叠。当前验证布局 X=`0xa0000000`、W=`0xa0008000`、bias=`0xa0018000`、Y=`0xa0020000`。
- 固定任务为 99×64 的 X 乘 64×256 的 W；输入/权重 INT16，bias signed40，内部累加 48 位，按既有 RNE 除以 512 得到 Y32。W 每个源 32 位字打包两个相邻 INT16；bias 每项两个 32 位字；X 每个源 32 位字放一个 INT16。
- 顺序：准备输入/参数 → fence → CLEAR → 检查 clear_done/error → 写四个地址 → fence → START → 优先检查 error、等待 done 且 busy=0 → fence → 读取 Y。首次错误中止，不直接重试已部分写回的任务；新任务必须重新 clear。
- DONE 仅在全部 Y 写响应退休且内部在途请求排空后可见。保留原错误处理、fence 和输出数值检查。

可复用驱动示例为 `tests/e203/dma_day_main.c`；其中 HOST 握手为验证环境使用，软件集成到实际应用时应保留 DMA 提交和完成语义，替换测试台任务管理部分。完整寄存器表见 `experiments/s3-y32-dma-day/README.md`。

## 精确版本与交付口径

本地父仓库基准提交 `1800a0767f1df5f0af483d546b24edcf84a7b857`，E203 子仓库基准提交 `79c8af1cd92589ddeb3f49edb5b9e4454fcf8efa`。修复 A 补丁和生成 RTL 尚未作为完整候选提交到父/子仓库；不能只 checkout 这两个提交便宣称得到当前实测版本。

权威联调源码为 `build/timing-opt-20261109/boundary-repair-A/cpu-full12-r1/source/`，168 项文件受清单固定。其中必须包含以下三份生成覆盖：

| 文件 | SHA256 |
| --- | --- |
| `rtl/perips/LinearRowPairDmaCore.sv` | `1abfa51ee7d2a00412a1d9e8a9246f3a58c5d5844ffdbcc88dd464c95d5b388e` |
| `rtl/perips/DmaWeightBankArray.sv` | `3fcd0cd40b24d71e2de38560ad23e1b0fc750f174fa0444ad4fdb7306070a003` |
| `rtl/perips/BiasSramPrefetch.sv` | `9cc633caaac00015177ab022f18507108615589321d8b37c0a457e92f5b33749` |

修复 A 的四文件补丁为 `build/timing-opt-20261109/boundary-repair-A/repair-A.patch`。生产顶层应采用该候选 `source/ppa/xu_soc_ppa_top.sv` 的共同 clock/reset 接线；测试专用 `boundary_tb_shared_endpoint.sv` 不是生产 SRAM 或正式宏替代品。

固件 ELF SHA256=`18a2ebaebe071e4602590dfdd5c179b1af7d24f19c85f8ab77b2ab8a6f3c13f5`；image SHA256=`7f20af91d64efad7267b1badd5aad3473d070e3f151dff9268242c8d89840370`。本地交接包位于 `build/timing-opt-20261109/hw-sw-integration-v1/`，以其 manifest 和包 receipt 为准。

## GitHub 与剩余工作

本轮未推送、未发 PR，遵守此前明确的“不推送”要求。2026-11-09 本轮直接查询 GitHub 远端：父/子仓库均没有本次 `codex/s3-y32-dma-day` 或 `codex/s3-y32-timing-opt` 分支。远端已有较早的 `s3-y32-development` 快照（父仓库 `680be46`），不能当作本轮 16 PE DMA 修复版。

当前可冻结软件 ABI 并开展联调；最终参赛版本仍需同一个冻结候选的完整时序、新面积、SRAM 模式/复位电气合同及正式接口资格验证。旧综合基准存在 setup/hold/DRC 违例，修复 A 不能借用旧面积或旧 STA 作为通过证据。面积硬上限保持 328,309.34679750 同库面积单位（当前基准的 1.25 倍）；本文件不宣称目标已完成。
