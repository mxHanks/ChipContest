#!/usr/bin/env python3
"""Restore frozen S2c and require direct VCS, eight-step acceptance and full12 packed control."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
MAIN = 'd276b55ffecbe8d620f9a361bf5d0859299ba7b5'
CHILD = '49a9436e01ea8ceeead94242e4a99c16e31a0865'
BRANCH = 'codex/xu-s2c-autogroup'
SCHEDULE = 'bias-hw-autogroup-window'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True, type=Path, help='new isolated source directory')
parser.add_argument('--out', required=True, type=Path, help='new evidence output directory')
parser.add_argument('--cross-prefix', default='/storage2/2026contest/server4/s4_23usr/Desktop/xu-platform-eval-20261101-codex/sifive-rv32-c/bin/riscv64-unknown-elf-')
parser.add_argument('--prepare-only', action='store_true', help='restore/verify source without EDA execution')
args = parser.parse_args()
source, out = args.source.resolve(), args.out.resolve()
if sys.version_info < (3, 6):
    parser.error('Python 3.6 or newer is required')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def run(command, cwd, logfile, timeout=10800):
    with logfile.open('w') as log:
        log.write(json.dumps(dict(argv=[str(x) for x in command], cwd=str(cwd))) + '\n')
        log.flush()
        result = subprocess.run([str(x) for x in command], cwd=str(cwd),
                                env=dict(os.environ, PWD=str(cwd)),
                                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                timeout=timeout)
    require(result.returncode == 0, 'command exit ' + str(result.returncode) + ': ' + str(logfile))
    return logfile.read_text(errors='replace').split('\n', 1)[1]


def git(command, cwd):
    return subprocess.check_output(['git'] + command, cwd=str(cwd), universal_newlines=True).strip()


def save():
    state['updated_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')


out.mkdir(parents=True, exist_ok=False)
state = dict(status='STARTED', main_commit=MAIN, e203_commit=CHILD,
             scope='VCS development acceptance; default Icarus helper tests identified separately; no S0/PPA/power/retention claim',
             steps=[], source=str(source), package_sha256={}, direct_vcs={})
try:
    manifest = json.loads((HERE / 'package-files.json').read_text())
    for name, record in manifest.items():
        require(sha(HERE / name) == record['sha256'], 'deployment file hash mismatch: ' + name)
        state['package_sha256'][name] = record['sha256']
    require(not source.exists(), 'source directory must not exist')
    previous = Path.home() / 'Desktop/xu-score-optimization-20261102/ChipContest-s2c-01'
    run(['git','clone','--no-hardlinks',str(previous),str(source)],HERE,out/'main-clone.log',300)
    run(['git','fetch',str(HERE/'xu-s2c-main.bundle'),BRANCH],source,out/'main-fetch.log',300)
    run(['git','checkout','--detach',MAIN],source,out/'main-checkout.log',120)
    child = source/'third-party/e203_hbirdv2'
    child.rmdir()
    run(['git','clone','--no-hardlinks',str(previous/'third-party/e203_hbirdv2'),str(child)],source,out/'child-clone.log',300)
    run(['git','fetch',str(HERE/'xu-s2c-child.bundle'),BRANCH],child,out/'child-fetch.log',300)
    run(['git','checkout','--detach',CHILD],child,out/'child-checkout.log',120)
    require(git(['rev-parse', 'HEAD'], source) == MAIN and git(['rev-parse', 'HEAD'], child) == CHILD,
            'restored commit identity differs')
    require(git(['ls-tree', 'HEAD', 'third-party/e203_hbirdv2'], source).split()[2] == CHILD,
            'main gitlink differs')
    frozen = json.loads((HERE / 'source-files.json').read_text())
    for name, digest in frozen.items():
        require(sha(source / name) == digest, 'restored source hash mismatch: ' + name)
    require(not git(['status', '--porcelain'], source) and not git(['status', '--porcelain'], child),
            'restored source is dirty')
    state.update(status='PREPARED', verified_source_paths=len(frozen))
    save()
    if args.prepare_only:
        print('PREPARED: ' + str(source), flush=True)
        sys.exit(0)

    tools = ['git', 'make', 'vcs', 'gcc', 'g++', args.cross_prefix + 'gcc',
             args.cross_prefix + 'objcopy', args.cross_prefix + 'objdump']
    state['tools'] = {name: shutil.which(name) for name in tools}
    require(all(state['tools'].values()), 'missing required tool: ' +
            ', '.join(name for name in tools if state['tools'][name] is None))
    gcc = run([args.cross_prefix + 'gcc', '--version'], source, out / 'sifive-version.log', 60)
    require(gcc.splitlines()[0] == 'riscv64-unknown-elf-gcc (SiFive GCC-Metal 10.2.0-2020.12.8) 10.2.0',
            'expected frozen SiFive GCC 10.2.0-2020.12.8')
    vcs = run(['vcs', '-ID'], source, out / 'vcs-version.log', 60)
    require('Q-2020.03' in vcs, 'expected server VCS Q-2020.03')
    sys.path.insert(0, str(source / 'tools/scripts'))
    import e203_soc as soc
    import server_accept as accept

    # Every direct supplement is actual VCS, required even when Icarus helpers
    # in host unittest skip. The frozen cached helper is selected by env below.
    modules = ['BiasBankCache.sv', 'LinearAutoGroupCore.sv', 'LinearCachedCore.sv',
               'LinearComputeCore.sv', 'DotProductEngine.sv', 'MacController.sv',
               'MacPEArray.sv', 'MacPE.sv', 'XRowBuffer.sv', 'WeightBankArray.sv',
               'WeightBank.sv', 'Sram1024x16.sv', 'mem_1024x16.sv', 'accel_icb_slave.v']
    perips = child / 'rtl/e203/perips'
    for kind, marker in [('autogroup', 'XU_AUTOGROUP_WRAPPER_PASS'),
                         ('packed', 'XU_PACKED_WRAPPER_PASS'), ('stream', 'XU_STREAM_WRAPPER_PASS')]:
        state.update(status='RUNNING', stage='direct-' + kind + '-vcs'); save()
        directory = out / ('direct-' + kind + '-vcs')
        directory.mkdir()
        binary = directory / 'simv'
        tb = source / ('tests/e203/tb_xu_' + kind + '_wrapper.sv')
        inputs = [tb] + [perips / name for name in modules]
        command = ['vcs', '-full64', '-sverilog', '-timescale=1ns/10ps',
                   '-top', 'tb_xu_' + kind + '_wrapper', '+define+DISABLE_SV_ASSERTION=1',
                   '-Mdir=' + str(directory / 'csrc'), '-o', str(binary)] + inputs
        run(command, directory, directory / 'compile.log', 600)
        log = run([binary], directory, directory / 'simulation.log', 180)
        if kind == 'autogroup':
            pattern = marker + r' rows=(\d+) groups=(\d+) lanes=(\d+) overlap=(\d+) launches=(\d+) dones=(\d+) accepted=(\d+) retired=(\d+)'
            matches = re.findall(pattern, log)
            require(len(matches) == 1, 'direct autogroup VCS marker missing/duplicate')
            counts = list(map(int, matches[0]))
            require(counts[:3] == [2, 64, 512] and counts[3] > 0 and
                    counts[4:] == [99, 99, 11719, 11719], 'autogroup VCS FIFO/numeric/retirement counts differ')
        else:
            matches = re.findall(marker + r' accepted=(\d+) retired=(\d+) writes=(\d+) W=(\d+) X=(\d+) starts=(\d+)', log)
            require(len(matches) == 1, 'direct ' + kind + ' VCS marker missing/duplicate')
            counts = list(map(int, matches[0]))
            expected = [9653, 9653, 16457, 16390, 67, 33] if kind == 'packed' else [17828, 17828, 16454, 16387, 67, 33]
            require(counts == expected, 'direct ' + kind + ' VCS work counts differ')
        require(not re.search(r'\b(?:FATAL|FAIL(?:ED|URE)?)\b', log, re.I), 'direct VCS reported failure')
        state['direct_vcs'][kind] = dict(status='PASS', backend='vcs', counts=counts,
            source_sha256={str(p.relative_to(source)):sha(p) for p in inputs},
            binary_sha256=sha(binary), log_sha256={p.name:sha(p) for p in directory.glob('*.log')})
        save()

    acceptance_out = out / 'acceptance'
    acceptance_out.mkdir()
    steps = accept.acceptance_steps(acceptance_out, args.cross_prefix, 'vcs', False, False,
                                    SCHEDULE, '-O2', 'both-unroll-no-masks')
    require(steps[0][0] == 'host' and steps[0][1][:2] == ['env', 'XU_WRAPPER_SIM=vcs'],
            'cached host wrapper must be selected to actual VCS')

    def checked_run_result(directory, schedule, tasks):
        result = json.loads((directory / 'result.json').read_text())
        text = (directory / 'simulation.log').read_text().split('\n', 1)[1]
        layers = soc.check_log(text, tasks)
        counters = soc.check_performance(text, layers, schedule)
        for layer, counter in zip(layers, counters): layer['performance'] = counter
        require(result['status'] == 'PASS' and result['tasks'] == tasks and result['layers'] == layers and
                result['main_commit'] == MAIN and result['e203_commit'] == CHILD and
                result['firmware_schedule'] == schedule and result['simulator'] == 'vcs',
                'strict actual result identity mismatch')
        return result

    for name, command, timeout in steps:
        record = dict(name=name, command=command, status='RUNNING')
        state['steps'].append(record); state['stage'] = name; save()
        print('Starting ' + name, flush=True)
        log = run(command, source, acceptance_out / (name + '.log'), timeout)
        if name == 'host':
            match = re.search(r'Ran (\d+) tests in [^\n]+\n\nOK(?: \(skipped=(\d+)\))?\s*$', log)
            require(match and int(match.group(1)) == 57, 'host57 completion missing')
            record.update(tests=57, skipped=int(match.group(2) or 0), helper_backends=dict(
                cached='vcs via XU_WRAPPER_SIM=vcs',
                packed_stream_autogroup='Icarus if installed; else skip; mandatory VCS supplements above'))
        if name == 'numeric':
            require(re.search(r'Ran 42 tests in [^\n]+\n\nOK\s*$', log), 'numeric42 completion missing')
        if name in ['vectors', 'doctor', 'baseline']:
            result = json.loads((acceptance_out / name / 'result.json').read_text())
            require(result['status'] == 'PASS' and result['main_commit'] == MAIN and
                    result['firmware_schedule'] == SCHEDULE, 'preflight/baseline result identity differs')
            if name != 'vectors':
                require(result['e203_commit'] == CHILD, 'preflight child identity differs')
            if name == 'vectors':
                require(result['outputs'] == 12 * 25344 and len(result['layers']) == 12,
                        'full12 vector check incomplete')
            if name == 'baseline':
                require(result['tests'] == ['rv32ui-p-add', 'accel_mmio', 'accel_compute',
                                             'accel_multigroup', 'accel_repeat_x'], 'legacy five cases incomplete')
        if name in ['synthetic1', 'synthetic2', 'real12']:
            result = checked_run_result(acceptance_out / name, SCHEDULE,
                                        {'synthetic1':1, 'synthetic2':2, 'real12':12}[name])
            record['total_cycles'] = sum(layer['cycles'] for layer in result['layers'])
        record['status'] = 'PASS'; save()

    # Mandatory same-RTL full12 S2b control isolates the row scheduler from the
    # additive wrapper itself. Never substitute an older candidate's result.
    control = acceptance_out / 'packed-control-real12'
    command = [sys.executable, str(source / 'tools/scripts/e203_soc.py'),
               '--mode', 'real', '--tasks', '12', '--sim', 'vcs', '--cross-prefix', args.cross_prefix,
               '--out', str(control), '--firmware-schedule', 'bias-hw-pack32-window',
               '--firmware-opt=-O2', '--firmware-experiment', 'both-unroll-no-masks']
    record = dict(name='packed-control-real12', command=command, status='RUNNING')
    state['steps'].append(record); state['stage'] = 'packed-control-real12'; save()
    print('Starting packed-control-real12', flush=True)
    run(command, source, acceptance_out / 'packed-control-real12.log', 10800)
    packed = checked_run_result(control, 'bias-hw-pack32-window', 12)
    auto = checked_run_result(acceptance_out / 'real12', SCHEDULE, 12)
    common = ['main_commit', 'e203_commit', 'source_sha256', 'runner_sha256', 'contract_sha256',
              'versions', 'tools', 'vectors', 'fixture', 'firmware_sha256', 'simulator_sha256',
              'firmware_opt', 'firmware_experiment']
    for field in common:
        require(auto[field] == packed[field], 'full12 common identity differs: ' + field)
    activity = soc.check_autogroup_activity((acceptance_out / 'real12/simulation.log').read_text().split('\n', 1)[1],
                                          auto['layers'], SCHEDULE)
    require(activity == auto['autogroup_activity'], 'full12 POP retirement/overlap records differ')
    rows = [dict(layer=a['layer'], packed_cycles=p['cycles'], autogroup_cycles=a['cycles'],
                 autogroup_minus_packed=a['cycles']-p['cycles']) for a, p in zip(auto['layers'], packed['layers'])]
    packed_total = sum(p['cycles'] for p in packed['layers'])
    auto_total = sum(a['cycles'] for a in auto['layers'])
    comparison = dict(status='PASS', scope='same-RTL full12 VCS development comparison; no PPA or retention claim',
        identities_identical=common, rows=rows, packed_total_cycles=packed_total,
        autogroup_total_cycles=auto_total, autogroup_minus_packed=auto_total-packed_total,
        autogroup_cycle_reduction_percent=100.0*(packed_total-auto_total)/packed_total,
        auto_result_sha256=sha(acceptance_out / 'real12/result.json'),
        packed_result_sha256=sha(control / 'result.json'))
    (out / 'full12-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
    record.update(status='PASS', total_cycles=packed_total); save()
    state.update(status='VCS_ACCEPTED_NOT_RETAINED', acceptance_status='PASS',
                 not_run=['candidate formal clear/request window', 'Chisel', 'candidate PPA/power/retention'])
    (acceptance_out / 'acceptance.json').write_text(json.dumps(dict(status='PASS',
        scope=state['scope'], profile='vcs-s2c-autogroup-with-direct-vcs-and-packed-control',
        steps=state['steps'], direct_vcs=state['direct_vcs'], not_run=state['not_run'],
        firmware_configuration=dict(schedule=SCHEDULE, optimization='-O2', experiment='both-unroll-no-masks')),
        indent=2) + '\n')
except Exception as error:
    if state['steps'] and state['steps'][-1]['status'] == 'RUNNING':
        state['steps'][-1]['status'] = 'FAIL'
    state.update(status='FAIL', error=str(error))
    save()
    (out / 'failure.json').write_text(json.dumps(state, indent=2) + '\n')
    print('FAIL: ' + str(error), flush=True)
    sys.exit(1)
save()
print('S2C_DONE VCS_ACCEPTED_NOT_RETAINED ' + str(out), flush=True)
