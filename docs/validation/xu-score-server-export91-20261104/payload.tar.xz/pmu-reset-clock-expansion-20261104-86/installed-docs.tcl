if {[catch {
set f [open docs-index.tsv w]
puts $f "kind\tname\tcatch_rc\tmessage"
set rc [catch {redirect -file {help-report_clock.txt} {help report_clock}} msg]
puts $f [join [list {help} {report_clock} $rc $msg] "\t"]
set rc [catch {redirect -file {man-report_clock.txt} {man report_clock}} msg]
puts $f [join [list {man} {report_clock} $rc $msg] "\t"]
set rc [catch {redirect -file {help-report_clock_timing.txt} {help report_clock_timing}} msg]
puts $f [join [list {help} {report_clock_timing} $rc $msg] "\t"]
set rc [catch {redirect -file {man-report_clock_timing.txt} {man report_clock_timing}} msg]
puts $f [join [list {man} {report_clock_timing} $rc $msg] "\t"]
set rc [catch {redirect -file {help-get_clocks.txt} {help get_clocks}} msg]
puts $f [join [list {help} {get_clocks} $rc $msg] "\t"]
set rc [catch {redirect -file {man-get_clocks.txt} {man get_clocks}} msg]
puts $f [join [list {man} {get_clocks} $rc $msg] "\t"]
set rc [catch {redirect -file {help-get_timing_paths.txt} {help get_timing_paths}} msg]
puts $f [join [list {help} {get_timing_paths} $rc $msg] "\t"]
set rc [catch {redirect -file {man-get_timing_paths.txt} {man get_timing_paths}} msg]
puts $f [join [list {man} {get_timing_paths} $rc $msg] "\t"]
set rc [catch {redirect -file {help-report_timing.txt} {help report_timing}} msg]
puts $f [join [list {help} {report_timing} $rc $msg] "\t"]
set rc [catch {redirect -file {man-report_timing.txt} {man report_timing}} msg]
puts $f [join [list {man} {report_timing} $rc $msg] "\t"]
set rc [catch {redirect -file {help-printvar.txt} {help printvar}} msg]
puts $f [join [list {help} {printvar} $rc $msg] "\t"]
set rc [catch {redirect -file {man-printvar.txt} {man printvar}} msg]
puts $f [join [list {man} {printvar} $rc $msg] "\t"]
set rc [catch {redirect -file {help-report_analysis_coverage.txt} {help report_analysis_coverage}} msg]
puts $f [join [list {help} {report_analysis_coverage} $rc $msg] "\t"]
set rc [catch {redirect -file {man-report_analysis_coverage.txt} {man report_analysis_coverage}} msg]
puts $f [join [list {man} {report_analysis_coverage} $rc $msg] "\t"]
set rc [catch {redirect -file {help-get_nets.txt} {help get_nets}} msg]
puts $f [join [list {help} {get_nets} $rc $msg] "\t"]
set rc [catch {redirect -file {man-get_nets.txt} {man get_nets}} msg]
puts $f [join [list {man} {get_nets} $rc $msg] "\t"]
set rc [catch {redirect -file {help-get_attribute.txt} {help get_attribute}} msg]
puts $f [join [list {help} {get_attribute} $rc $msg] "\t"]
set rc [catch {redirect -file {man-get_attribute.txt} {man get_attribute}} msg]
puts $f [join [list {man} {get_attribute} $rc $msg] "\t"]
set rc [catch {redirect -file {help-PTE-052.txt} {help PTE-052}} msg]
puts $f [join [list {help} {PTE-052} $rc $msg] "\t"]
set rc [catch {redirect -file {man-PTE-052.txt} {man PTE-052}} msg]
puts $f [join [list {man} {PTE-052} $rc $msg] "\t"]
close $f
redirect -file attributes-clock.txt {list_attributes -application -class clock}
redirect -file {defaults-00.txt} {printvar {*expand*}}
redirect -file {defaults-01.txt} {printvar {*waveform*}}
redirect -file {defaults-02.txt} {printvar {*base_period*}}
redirect -file {defaults-03.txt} {printvar {*repeat*}}
redirect -file {defaults-04.txt} {printvar {*clock*}}
redirect -file {defaults-05.txt} {printvar {*unconstrained*}}
redirect -file {defaults-06.txt} {printvar {*recovery*}}

} xu_error xu_options]} {
 puts stderr "XU_FATAL: $xu_error"
 if {[dict exists $xu_options -errorinfo]} {puts stderr [dict get $xu_options -errorinfo]}
 exit 1
}
puts {XU_RESET86_INSTALLED_DOCS_DONE_NOT_QUALIFIED}
exit 0
