/* xu147: native read-only observations; writes only TB regs and original mem. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "vpi_user.h"
#include "xu_mapped_expected111.h"
#include "xu_private147_bindings.h"
static vpiHandle macro_mod[336], macro_mem[336], macro_words[336][256];
static unsigned macro_seen[336], initialized, preload_calls[3];
static int failed;
static vpiHandle inputs[XU147_BINDINGS][48], outputs[XU147_BINDINGS];
static unsigned bound[XU147_BINDINGS];
static unsigned long long sample_counts[3];
static void reject(const char *why,const char *name) {failed=1;vpi_printf("XU_PRIVATE147_ADAPTER_REJECT reason=%s object=%s\n",why,name?name:"<null>");vpi_control(vpiFinish,1);}
static void canonical(const char *in,char *out,size_t size) {size_t n=0;while(*in){unsigned char c=(unsigned char)*in++;if(c=='\\'||isspace(c))continue;if(n+1>=size){reject("overlong_inventory_name",in);break;}out[n++]=(char)c;}out[n]='\0';}

static int geometry(unsigned tag) {
 unsigned r,j,reg_words=0,memory_words=0,index_present=0,parent_present=0,scope_present=0;
 char modname[8192],memname[8192],want[8224],full[8192];const char *text;vpiHandle parent,scope;
 text=vpi_get_str(vpiFullName,macro_mod[tag]);canonical(text?text:"",modname,sizeof(modname));
 text=macro_mem[tag]?vpi_get_str(vpiFullName,macro_mem[tag]):NULL;canonical(text?text:"",memname,sizeof(memname));
 snprintf(want,sizeof(want),"%s.mem",modname);
 if(!macro_mem[tag]||strcmp(modname,xu_expected111[tag].name)!=0||strcmp(want,memname)!=0||vpi_get(vpiSize,macro_mem[tag])!=256||(vpi_get(vpiType,macro_mem[tag])!=vpiMemory&&vpi_get(vpiType,macro_mem[tag])!=vpiRegArray)) {reject("owning_memory_name_type_or_256_rows",modname);return 0;}
 parent=vpi_handle(vpiParent,macro_mem[tag]);scope=vpi_handle(vpiScope,macro_mem[tag]);
 if((parent&&!vpi_compare_objects(parent,macro_mod[tag]))||(scope&&!vpi_compare_objects(scope,macro_mod[tag]))) {reject("owning_memory_parent_or_scope_disagrees",modname);return 0;}
 for(j=0;j<tag;++j)if(macro_mem[j]&&vpi_compare_objects(macro_mem[tag],macro_mem[j])) {reject("macro_memories_alias",modname);return 0;}
 for(r=0;r<256;++r) {
  vpiHandle again,ix;int type;s_vpi_value iv;
  macro_words[tag][r]=vpi_handle_by_index(macro_mem[tag],(PLI_INT32)r);
  if(!macro_words[tag][r]) {reject("indexed_word_missing",modname);return 0;}
  type=vpi_get(vpiType,macro_words[tag][r]);
  if((type!=vpiMemoryWord&&type!=vpiReg)||vpi_get(vpiSize,macro_words[tag][r])!=64) {reject("indexed_word_native_type_or_64_bits",modname);return 0;}
  if(type==vpiReg)++reg_words;else ++memory_words;
  text=vpi_get_str(vpiFullName,macro_words[tag][r]);canonical(text?text:"",full,sizeof(full));snprintf(want,sizeof(want),"%s[%u]",memname,r);
  if(strcmp(full,want)!=0) {reject("indexed_word_not_in_exact_owning_memory",modname);return 0;}
  again=vpi_handle_by_index(macro_mem[tag],(PLI_INT32)r);
  if(!again||!vpi_compare_objects(macro_words[tag][r],again)) {reject("indexed_word_identity_not_repeatable",modname);return 0;}
  for(j=0;j<r;++j)if(vpi_compare_objects(macro_words[tag][r],macro_words[tag][j])) {reject("indexed_word_aliases_another_row",modname);return 0;}
  parent=vpi_handle(vpiParent,macro_words[tag][r]);scope=vpi_handle(vpiScope,macro_words[tag][r]);
  if(parent) {++parent_present;if(!vpi_compare_objects(parent,macro_mem[tag])&&!vpi_compare_objects(parent,macro_mod[tag])) {reject("native_word_parent_disagrees",modname);return 0;}}
  if(scope) {++scope_present;if(!vpi_compare_objects(scope,macro_mod[tag])&&!vpi_compare_objects(scope,macro_mem[tag])) {reject("native_word_scope_disagrees",modname);return 0;}}
  ix=vpi_handle(vpiIndex,macro_words[tag][r]);if(ix) {++index_present;memset(&iv,0,sizeof(iv));iv.format=vpiIntVal;vpi_get_value(ix,&iv);if(iv.value.integer!=(PLI_INT32)r) {reject("native_word_index_disagrees",modname);return 0;}}
 }
 vpi_printf("XU_MAPPED111_GEOMETRY tag=%u role=%d status=PASS rows=256 row_bits=64 unique=256 memory_type=%d reg_words=%u memoryword_words=%u parent_present=%u scope_present=%u index_present=%u name=%s\n",tag,xu_expected111[tag].role,vpi_get(vpiType,macro_mem[tag]),reg_words,memory_words,parent_present,scope_present,index_present,modname);
 return 1;
}



static void bind_observation(unsigned index,vpiHandle mod) {
 const struct xu_binding147_t *s=&xu_binding147[index];unsigned bit,j;char full[8192],wanted[8192];
 vpiHandle tb,parent,array;const char *raw;
 if(bound[index]++){reject("duplicate_native_source_scope",s->scope);return;}
 for(bit=0;bit<s->parts;++bit){
  inputs[index][bit]=vpi_handle_by_name((PLI_BYTE8 *)s->names[bit],mod);
  if(!inputs[index][bit]||vpi_get(vpiSize,inputs[index][bit])!=(int)(s->parts==1?s->width:1u)){
   reject("native_source_absent_or_wrong_width",s->names[bit]);return;
  }
  if(vpi_get(vpiType,inputs[index][bit])!=vpiNet&&vpi_get(vpiType,inputs[index][bit])!=vpiReg&&
     vpi_get(vpiType,inputs[index][bit])!=vpiPort){reject("native_source_not_net_reg_or_port",s->names[bit]);return;}
  raw=vpi_get_str(vpiFullName,inputs[index][bit]);canonical(raw?raw:"",full,sizeof(full));
  snprintf(wanted,sizeof(wanted),"%s.%s",s->scope,s->names[bit]);
  if(strcmp(full,wanted)){reject("native_source_fullname_disagrees",full);return;}
 }
 tb=vpi_handle_by_name((PLI_BYTE8 *)"tb_xu_soc_ppa",NULL);
 parent=vpi_handle_by_name((PLI_BYTE8 *)s->target,tb);
 array=parent;
 outputs[index]=s->lane<0?parent:vpi_handle_by_index(array,s->lane);
 if(!outputs[index]||vpi_get(vpiSize,outputs[index])!=(int)s->width||
    (vpi_get(vpiType,outputs[index])!=vpiReg&&vpi_get(vpiType,outputs[index])!=vpiMemoryWord)){
  reject("observation_destination_not_exact_TB_reg",s->target);return;
 }
 raw=vpi_get_str(vpiFullName,outputs[index]);canonical(raw?raw:"",full,sizeof(full));
 if(s->lane<0)snprintf(wanted,sizeof(wanted),"tb_xu_soc_ppa.%s",s->target);
 else snprintf(wanted,sizeof(wanted),"tb_xu_soc_ppa.%s[%d]",s->target,s->lane);
 if(strncmp(s->target,"xu147_o_",8)||strcmp(full,wanted)){
  reject("destination_outside_TB_observation_allowlist",full);return;
 }
 for(j=0;j<index;++j)if(outputs[j]&&vpi_compare_objects(outputs[index],outputs[j])){
  reject("TB_observation_destinations_alias",full);return;
 }
 vpi_printf("XU_PRIVATE147_BIND tag=%u logical=%s lane=%d width=%u sources=%u phase_mask=%u source=%s.%s target=%s source_type=%d\n",
  index,s->logical,s->lane,s->width,s->parts,s->phases,s->scope,s->names[0],full,vpi_get(vpiType,inputs[index][0]));
}

static void walk(vpiHandle mod) {
 const char *raw=vpi_get_str(vpiFullName,mod);char *name=raw?strdup(raw):NULL;
 const char *definition=vpi_get_str(vpiDefName,mod);char *def=definition?strdup(definition):NULL;
 char full[8192];vpiHandle it,child;unsigned i;canonical(name?name:"",full,sizeof(full));
 if(def&&!strcmp(def,"RAMSP1024X16")){
  unsigned found=0;
  for(i=0;i<336;++i)if(!strcmp(full,xu_expected111[i].name)){
   ++found;++macro_seen[i];macro_mod[i]=mod;macro_mem[i]=vpi_handle_by_name((PLI_BYTE8 *)"mem",mod);
  }
  if(found!=1)reject("inventory_macro_bijection",full);
 }
 for(i=0;i<XU147_BINDINGS;++i)if(!strcmp(full,xu_binding147[i].scope)){
  if(!def||strcmp(def,xu_binding147[i].definition))reject("source_module_definition_disagrees",full);
  else bind_observation(i,mod);
 }
 it=vpi_iterate(vpiModule,mod);if(it)while((child=vpi_scan(it))!=NULL)walk(child);
 free(name);free(def);
}

static PLI_INT32 prepare147(PLI_BYTE8 *unused) {
 vpiHandle root;unsigned i;(void)unused;
 if(initialized++){reject("duplicate_prepare","");return 0;}
 root=vpi_handle_by_name((PLI_BYTE8 *)"tb_xu_soc_ppa.dut",NULL);
 if(!root){reject("mapped_root_absent","");return 0;}walk(root);
 for(i=0;i<336;++i){if(macro_seen[i]!=1)reject("missing_inventory_macro",xu_expected111[i].name);else if(!geometry(i))return 0;}
 for(i=0;i<XU147_BINDINGS;++i)if(bound[i]!=1||!outputs[i])reject("native_binding_missing",xu_binding147[i].logical);
 if(!failed)vpi_printf("XU_PRIVATE147_ADAPTER_READY logical_references=72 private_references=60 native_bindings=%u original_preload_macros=288 Q_WRITES=0 OTHER_DUT_FF_WRITES=0\n",(unsigned)XU147_BINDINGS);
 return 0;
}

static void copy_observation(unsigned i) {
 const struct xu_binding147_t *s=&xu_binding147[i];s_vpi_value v;
 s_vpi_vecval packed[2]={{0,0},{0,0}};unsigned bit;
 if(s->parts==1){memset(&v,0,sizeof(v));v.format=vpiVectorVal;vpi_get_value(inputs[i][0],&v);
  if(!v.value.vector){reject("native_source_vector_absent",s->logical);return;}
 }
 else{
  for(bit=0;bit<s->parts;++bit){unsigned dest=s->width-1u-bit,word=dest/32u,shift=dest%32u;
   memset(&v,0,sizeof(v));v.format=vpiVectorVal;vpi_get_value(inputs[i][bit],&v);
   if(!v.value.vector){reject("native_source_vector_absent",s->logical);return;}
   if((uint32_t)v.value.vector[0].aval&1u)packed[word].aval|=(PLI_INT32)(UINT32_C(1)<<shift);
   if((uint32_t)v.value.vector[0].bval&1u)packed[word].bval|=(PLI_INT32)(UINT32_C(1)<<shift);
  }
  memset(&v,0,sizeof(v));v.format=vpiVectorVal;v.value.vector=packed;
 }
 /* outputs[] are bound and fullname/type checked TB observation regs only. */
 vpi_put_value(outputs[i],&v,NULL,vpiNoDelay);
}

static PLI_INT32 sample147(PLI_BYTE8 *unused) {
 vpiHandle call,it,arg,extra;s_vpi_value value;unsigned phase,i;(void)unused;
 if(initialized!=1||failed){reject("sample_before_valid_prepare","");return 0;}
 call=vpi_handle(vpiSysTfCall,NULL);it=vpi_iterate(vpiArgument,call);arg=it?vpi_scan(it):NULL;
 extra=it?vpi_scan(it):NULL;
 if(!arg||extra){reject("exact_sampling_context_argument_required","");return 0;}
 memset(&value,0,sizeof(value));value.format=vpiIntVal;vpi_get_value(arg,&value);phase=(unsigned)value.value.integer;
 if(phase>2){reject("unknown_sampling_context","");return 0;}
 for(i=0;i<XU147_BINDINGS&&!failed;++i)if(xu_binding147[i].phases&(1u<<phase))copy_observation(i);
 ++sample_counts[phase];return 0;
}

static PLI_INT32 preload_role(unsigned role) {vpiHandle words,ram;unsigned i,r,k,b,count=0;if(initialized!=1||failed||preload_calls[role]++){reject("invalid_or_duplicate_preload","");return 0;}words=vpi_handle_by_name((PLI_BYTE8 *)"tb_xu_soc_ppa.xu_program_words",NULL);ram=vpi_handle_by_name((PLI_BYTE8 *)"tb_xu_soc_ppa.ram",NULL);if(!words||!ram){reject("original_TB_memories_absent","");return 0;}for(i=0;i<336;++i)if((unsigned)xu_expected111[i].role==role){++count;for(r=0;r<256;++r){s_vpi_vecval out[2]={{0,0},{0,0}};s_vpi_value value;for(k=0;k<4;++k){unsigned address=(unsigned)xu_expected111[i].bank*1024+4*r+k;vpiHandle word=vpi_handle_by_index(xu_expected111[i].role==1?words:ram,(PLI_INT32)address);if(!word){reject("original_TB_word_absent",xu_expected111[i].name);return 0;}memset(&value,0,sizeof(value));value.format=vpiVectorVal;vpi_get_value(word,&value);for(b=0;b<16;++b){unsigned source_bit=(unsigned)xu_expected111[i].lane*16+b,output_bit=4*b+k,si=source_bit/32,oi=output_bit/32,sp=source_bit%32,op=output_bit%32;if(((uint32_t)value.value.vector[si].aval>>sp)&1u)out[oi].aval|=(PLI_INT32)(UINT32_C(1)<<op);if(((uint32_t)value.value.vector[si].bval>>sp)&1u)out[oi].bval|=(PLI_INT32)(UINT32_C(1)<<op);}}memset(&value,0,sizeof(value));value.format=vpiVectorVal;value.value.vector=out;{vpiHandle destination=vpi_handle_by_index(macro_mem[i],(PLI_INT32)r);s_vpi_value check;unsigned half;if(!destination||!vpi_compare_objects(destination,macro_words[i][r])){reject("native_preload_word_missing",xu_expected111[i].name);return 0;}vpi_put_value(destination,&value,NULL,vpiNoDelay);memset(&check,0,sizeof(check));check.format=vpiVectorVal;vpi_get_value(destination,&check);for(half=0;half<2;++half)if(check.value.vector[half].aval!=out[half].aval||check.value.vector[half].bval!=out[half].bval){reject("native_preload_4state_readback_mismatch",xu_expected111[i].name);return 0;}}}}if(count!=(role==1?32u:256u))reject("original_preload_macro_count","");vpi_printf("XU_PRIVATE147_PRELOAD_ROLE_DONE role=%u macros=%u rows=256 bits=64 arbitrary_XZ_preserved=1 Q_WRITES=0\n",role,count);return 0;}

static PLI_INT32 itcm147(PLI_BYTE8 *unused){(void)unused;return preload_role(1);}
static PLI_INT32 shared147(PLI_BYTE8 *unused){(void)unused;return preload_role(2);}
static PLI_INT32 gate147(PLI_BYTE8 *unused){
 (void)unused;
 if(failed||initialized!=1||preload_calls[1]!=1||preload_calls[2]!=1||
    !sample_counts[0]||!sample_counts[1]||!sample_counts[2]){
  reject("incomplete_native_observation_or_preload_contexts","");return 0;
 }
 vpi_printf("XU_PRIVATE147_ORIGINAL_EXU_HALT_REACHED logical=72 private=60 bindings=%u pll_samples=%llu reset_samples=%llu main_samples=%llu Q_WRITES=0 OTHER_DUT_FF_WRITES=0 QUALIFICATION_PENDING=1\n",
  (unsigned)XU147_BINDINGS,sample_counts[0],sample_counts[1],sample_counts[2]);return 0;
}
/* xu167 independent passive observations. No VPI writes, force, delay or timing control. */
#define XU167_LIMIT 256
#define XU167_START UINT64_C(9359300000000)
#define XU167_STOP UINT64_C(9359500000000)
static vpiHandle xu167_nodes[XU167_LIMIT];
static char *xu167_names[XU167_LIMIT], *xu167_roles[XU167_LIMIT];
static s_cb_data xu167_callbacks[XU167_LIMIT];
static s_vpi_time xu167_times[XU167_LIMIT];
static s_vpi_value xu167_values[XU167_LIMIT];
static unsigned xu167_count, xu167_failed, xu167_ready, xu167_scope_counts[4], xu167_window_seen;
static uint64_t xu167_serial;
static const char *xu167_scopes[]={
 "tb_xu_soc_ppa.dut.u_soc.u_e203_subsys_top.u_e203_subsys_main.u_e203_subsys_perips.u_accel_icb_slave.u_linear_compute_core",
 "tb_xu_soc_ppa.dut.u_soc.u_e203_subsys_top.u_e203_subsys_main.u_e203_subsys_mems.u_sirv_mem_fab.u_sirv_gnrl_icb_buffer.u_sirv_gnrl_rsp_fifo",
 "tb_xu_soc_ppa.dut.u_soc.u_e203_subsys_top.u_e203_subsys_main.u_e203_subsys_mems.u_sirv_mem_fab.u_sirv_gnrl_icb_buffer.u_sirv_gnrl_rsp_fifo.dp_gt0.vec_31_dfflr.qout_r_reg[0]",
 "tb_xu_soc_ppa.dut.u_shared"};
static const char *xu167_eight_native[]={"io_wLoadWen","io_xLoadWen","io_cacheWriteEnable","io_rowActive","io_rowCount","io_rowRunning","io_rowProduced","io_rowRetired"};
static const char *xu167_eight_tb[]={"xu147_o_048","xu147_o_051","xu147_o_043","xu147_o_016","xu147_o_017","xu147_o_023","xu147_o_020","xu147_o_022"};
static const unsigned xu167_eight_width[]={1,1,1,1,2,1,6,6};
static const char *xu167_eight_logical[]={"w_commit","x_commit","bias_commit","row_active","row_count","row_running","row_produced","row_retired"};
static uint64_t xu167_tick(void){s_vpi_time t;memset(&t,0,sizeof(t));t.type=vpiSimTime;vpi_get_time(NULL,&t);return((uint64_t)t.high<<32)|(uint32_t)t.low;}
static void xu167_snapshot(unsigned i,const char *why){
 s_vpi_value v;unsigned width=(unsigned)vpi_get(vpiSize,xu167_nodes[i]);uint32_t a0,b0,a1=0,b1=0;
 memset(&v,0,sizeof(v));v.format=vpiVectorVal;vpi_get_value(xu167_nodes[i],&v);
 if(!v.value.vector||width<1||width>64){++xu167_failed;vpi_printf("XU_UNKNOWN167_READ_REJECT role=%s name=%s\n",xu167_roles[i],xu167_names[i]);return;}
 a0=(uint32_t)v.value.vector[0].aval;b0=(uint32_t)v.value.vector[0].bval;
 if(width>32){a1=(uint32_t)v.value.vector[1].aval;b1=(uint32_t)v.value.vector[1].bval;}
 vpi_printf("XU_UNKNOWN167_EVENT serial=%llu tick_fs=%llu reason=%s role=%s bits=%u aval=%08x%08x bval=%08x%08x name=%s\n",(unsigned long long)++xu167_serial,(unsigned long long)xu167_tick(),why,xu167_roles[i],width,a1,a0,b1,b0,xu167_names[i]);
}
static PLI_INT32 xu167_changed(p_cb_data cb){unsigned j,i=(unsigned)(uintptr_t)cb->user_data;uint64_t t=xu167_tick();if(i>=xu167_count){++xu167_failed;vpi_printf("XU_UNKNOWN167_CALLBACK_REJECT index=%u\n",i);return 0;}if(t>=XU167_START&&t<=XU167_STOP){if(!xu167_window_seen){xu167_window_seen=1;for(j=0;j<xu167_count;++j)xu167_snapshot(j,"first_observed_window_event");}xu167_snapshot(i,"value_change");}return 0;}
static void xu167_bind(vpiHandle h,const char *role,unsigned expected_width){
 unsigned i;const char *raw;char full[8192];
 if(!h||vpi_get(vpiSize,h)<1||vpi_get(vpiSize,h)>64||(expected_width&&vpi_get(vpiSize,h)!=(int)expected_width)){++xu167_failed;vpi_printf("XU_UNKNOWN167_BIND_REJECT role=%s reason=missing_or_width\n",role);return;}
 raw=vpi_get_str(vpiFullName,h);canonical(raw?raw:"",full,sizeof(full));
 /* Preserve distinct named native aliases; only the exact same fullname is
    skipped when the generic inventory encounters an explicitly bound pin. */
 for(i=0;i<xu167_count;++i)if(!strcmp(full,xu167_names[i]))return;
 if(xu167_count>=XU167_LIMIT){++xu167_failed;return;}i=xu167_count++;xu167_nodes[i]=h;
 xu167_names[i]=strdup(full);xu167_roles[i]=strdup(role);
 memset(&xu167_callbacks[i],0,sizeof(xu167_callbacks[i]));memset(&xu167_times[i],0,sizeof(xu167_times[i]));memset(&xu167_values[i],0,sizeof(xu167_values[i]));
 xu167_times[i].type=vpiSuppressTime;xu167_values[i].format=vpiSuppressVal;xu167_callbacks[i].reason=cbValueChange;xu167_callbacks[i].cb_rtn=xu167_changed;xu167_callbacks[i].obj=h;xu167_callbacks[i].time=&xu167_times[i];xu167_callbacks[i].value=&xu167_values[i];xu167_callbacks[i].user_data=(PLI_BYTE8 *)(uintptr_t)i;
 if(!vpi_register_cb(&xu167_callbacks[i]))++xu167_failed;
 vpi_printf("XU_UNKNOWN167_BIND role=%s bits=%d type=%d name=%s\n",role,vpi_get(vpiSize,h),vpi_get(vpiType,h),full);
}
static void xu167_bind_exact(vpiHandle mod,const char *name,const char *role,unsigned width){
 const char *raw;char actual[8192],want[8192],scope[8192];vpiHandle h=vpi_handle_by_name((PLI_BYTE8 *)name,mod);
 raw=vpi_get_str(vpiFullName,mod);canonical(raw?raw:"",scope,sizeof(scope));
 if(strlen(scope)+strlen(name)+2>sizeof(want)){++xu167_failed;return;}
 strcpy(want,scope);strcat(want,".");strcat(want,name);
 if(!h){++xu167_failed;vpi_printf("XU_UNKNOWN167_BIND_REJECT role=%s reason=missing name=%s\n",role,want);return;}
 raw=vpi_get_str(vpiFullName,h);canonical(raw?raw:"",actual,sizeof(actual));
 if(strcmp(actual,want)){++xu167_failed;vpi_printf("XU_UNKNOWN167_BIND_REJECT role=%s reason=fullname name=%s\n",role,actual);return;}
 xu167_bind(h,role,width);
}
static void xu167_walk(vpiHandle mod){
 const char *raw=vpi_get_str(vpiFullName,mod);char full[8192];vpiHandle it,h;unsigned scope,i;canonical(raw?raw:"",full,sizeof(full));
 for(scope=0;scope<4;++scope)if(!strcmp(full,xu167_scopes[scope])){
  ++xu167_scope_counts[scope];
  raw=vpi_get_str(vpiDefName,mod);vpi_printf("XU_UNKNOWN167_SCOPE index=%u definition=%s name=%s\n",scope,raw?raw:"ABSENT",full);
  if(scope==0){for(i=0;i<8;++i)xu167_bind_exact(mod,xu167_eight_native[i],xu167_eight_logical[i],xu167_eight_width[i]);}
  else if(scope==3){static const char *n[]={"clk","rst_n","cmd_valid","cmd_ready","cmd_read","cmd_addr","cmd_wdata","cmd_wmask","rsp_valid","rsp_ready","rsp_rdata","rsp_err"};for(i=0;i<12;++i)xu167_bind_exact(mod,n[i],"shared_port",0);}
  else{
   if(scope==2){static const char *n[]={"CK","D","Q","NOTIFIER"};static const char *r[]={"fifo_CK","fifo_D","fifo_Q","fifo_NOTIFIER"};for(i=0;i<4;++i)xu167_bind_exact(mod,n[i],r[i],1);}
   it=vpi_iterate(vpiNet,mod);if(it)while((h=vpi_scan(it))!=NULL)if(vpi_get(vpiSize,h)>=1&&vpi_get(vpiSize,h)<=64)xu167_bind(h,scope==1?"fifo_net":"target_net",0);
   it=vpi_iterate(vpiReg,mod);if(it)while((h=vpi_scan(it))!=NULL)if(vpi_get(vpiSize,h)>=1&&vpi_get(vpiSize,h)<=64)xu167_bind(h,scope==1?"fifo_reg":"target_reg",0);
  }
 }
 it=vpi_iterate(vpiModule,mod);if(it)while((h=vpi_scan(it))!=NULL)xu167_walk(h);
}
static PLI_INT32 xu167_prepare_task(PLI_BYTE8 *unused){
 vpiHandle root,tb;unsigned i;(void)unused;
 if(xu167_ready++){++xu167_failed;return 0;}
 root=vpi_handle_by_name((PLI_BYTE8 *)"tb_xu_soc_ppa.dut",NULL);tb=vpi_handle_by_name((PLI_BYTE8 *)"tb_xu_soc_ppa",NULL);
 if(root&&tb){xu167_walk(root);for(i=0;i<8;++i)xu167_bind_exact(tb,xu167_eight_tb[i],"tb_fatal_operand",xu167_eight_width[i]);}else ++xu167_failed;
 for(i=0;i<4;++i)if(xu167_scope_counts[i]!=1)++xu167_failed;
 vpi_printf("XU_UNKNOWN167_READY native_operands=8 tb_operands=8 scopes=%u,%u,%u,%u observed_nodes=%u failed=%u start_fs=%llu stop_fs=%llu new_DUT_writes=0 new_TB_writes=0 forces=0 timing_controls_changed=0 NOT_QUALIFIED\n",xu167_scope_counts[0],xu167_scope_counts[1],xu167_scope_counts[2],xu167_scope_counts[3],xu167_count,xu167_failed,(unsigned long long)XU167_START,(unsigned long long)XU167_STOP);
 return 0;
}
static PLI_INT32 xu167_fatal_snapshot_task(PLI_BYTE8 *unused){unsigned i;(void)unused;for(i=0;i<xu167_count;++i)xu167_snapshot(i,"before_original_unknown_fatal");vpi_printf("XU_UNKNOWN167_SNAPSHOT_DONE nodes=%u failed=%u tick_fs=%llu original_fatal_retained=1 NOT_QUALIFIED\n",xu167_count,xu167_failed,(unsigned long long)xu167_tick());return 0;}
static void xu167_register(void){
 s_vpi_systf_data d;memset(&d,0,sizeof(d));d.type=vpiSysTask;d.tfname=(PLI_BYTE8 *)"$xu_unknown167_prepare";d.calltf=xu167_prepare_task;vpi_register_systf(&d);
 memset(&d,0,sizeof(d));d.type=vpiSysTask;d.tfname=(PLI_BYTE8 *)"$xu_unknown167_snapshot";d.calltf=xu167_fatal_snapshot_task;vpi_register_systf(&d);
}

void xu_private147_register(void){
 xu167_register();
 static const char *names[]={"$xu_private147_prepare","$xu_private147_sample","$xu_private147_itcm","$xu_private147_shared","$xu_private147_gate"};
 PLI_INT32(*calls[])(PLI_BYTE8 *)={prepare147,sample147,itcm147,shared147,gate147};unsigned i;
 for(i=0;i<5;++i){s_vpi_systf_data d;memset(&d,0,sizeof(d));d.type=vpiSysTask;d.tfname=(PLI_BYTE8 *)names[i];d.calltf=calls[i];vpi_register_systf(&d);}
}
void(*vlog_startup_routines[])(void)={xu_private147_register,NULL};
