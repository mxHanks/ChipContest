// Generated from original TB SHA256 b80fa66842a4d7bed21b264ac30e0e561bc5b53ad3f0b71ed2337dfa1ddc76d2
`timescale 1ns/1fs
module tb_xu_soc_ppa;
  reg [2:0] xu147_o_000;
  reg [39:0] xu147_o_001 [0:7];
  reg [7:0] xu147_o_003;
  reg [0:0] xu147_o_004;
  reg [0:0] xu147_o_005;
  reg [31:0] xu147_o_006;
  reg [0:0] xu147_o_007;
  reg [0:0] xu147_o_008;
  reg [0:0] xu147_o_009;
  reg [31:0] xu147_o_010;
  reg [3:0] xu147_o_011;
  reg [0:0] xu147_o_012;
  reg [0:0] xu147_o_013;
  reg [0:0] xu147_o_014;
  reg [0:0] xu147_o_015;
  reg [0:0] xu147_o_016;
  reg [1:0] xu147_o_017;
  reg [4:0] xu147_o_018;
  reg [0:0] xu147_o_019;
  reg [5:0] xu147_o_020;
  reg [47:0] xu147_o_021 [0:7];
  reg [5:0] xu147_o_022;
  reg [0:0] xu147_o_023;
  reg [0:0] xu147_o_024;
  reg [0:0] xu147_o_026;
  reg [0:0] xu147_o_027;
  reg [31:0] xu147_o_028;
  reg [0:0] xu147_o_029;
  reg [0:0] xu147_o_030;
  reg [0:0] xu147_o_031;
  reg [14:0] xu147_o_032;
  reg [0:0] xu147_o_033;
  reg [0:0] xu147_o_034;
  reg [0:0] xu147_o_035;
  reg [0:0] xu147_o_036;
  reg [0:0] xu147_o_037;
  reg [0:0] xu147_o_038;
  reg [4:0] xu147_o_039;
  reg [0:0] xu147_o_040;
  reg [7:0] xu147_o_041;
  reg [39:0] xu147_o_042;
  reg [0:0] xu147_o_043;
  reg [4:0] xu147_o_044;
  reg [10:0] xu147_o_045;
  reg [2:0] xu147_o_046;
  reg [15:0] xu147_o_047;
  reg [0:0] xu147_o_048;
  reg [5:0] xu147_o_049;
  reg [15:0] xu147_o_050;
  reg [0:0] xu147_o_051;
  reg [0:0] xu147_o_052;
  reg [10:0] xu147_o_053;
  reg [2:0] xu147_o_054;
  reg [14:0] xu147_o_055;
  reg [0:0] xu147_o_056;
  reg [5:0] xu147_o_057;
  reg [6:0] xu147_o_058;
  reg [0:0] xu147_o_059;
  reg [31:0] xu147_o_060;
  reg [0:0] xu147_o_061;
  reg [31:0] xu147_o_062;
  reg [0:0] xu147_o_063;
  reg [7:0] xu147_o_064;
  reg [4:0] xu147_o_065;
  reg [1:0] xu147_o_066;
  reg [0:0] xu147_o_067;
  reg [0:0] xu147_o_068;
  reg [5:0] xu147_o_069;
  reg [0:0] xu147_o_070;
  reg [0:0] xu147_o_071;
  reg clk = 0, lfclk = 0, rst_n = 0;
  integer xu_half_index=0, xu_reset_edges=0, xu_static_checks=0;
  real xu_target_ns;
  always @(posedge clk) begin
    $xu_private147_sample(0);
    if (!rst_n) xu_reset_edges=xu_reset_edges+1;
    else begin
      if ({xu147_o_071,xu147_o_068,xu147_o_070,
           xu147_o_069,xu147_o_067,xu147_o_063,
           xu147_o_066,xu147_o_064,xu147_o_065} !==
          {1'b0,1'b1,1'b1,6'b0,1'b0,1'b0,2'd2,8'd50,5'd2})
        $fatal(1,"nominal150 clock controls departed from static reset bypass/divby1 mode");
      xu_static_checks=xu_static_checks+1;
    end
  end

  initial forever begin
    xu_half_index=xu_half_index+1;
    xu_target_ns=xu_half_index*(10.0/3.0);
    #(xu_target_ns-$realtime);
    clk=~clk;
  end
  integer xu_lf_half_index=0, xu_lf_static_checks=0;
  real xu_lf_target_ns, xu_lf_phase_error_fs;
  initial forever begin
    xu_lf_half_index=xu_lf_half_index+1;
    xu_lf_target_ns=xu_lf_half_index*15258.7890625;
    #(xu_lf_target_ns-$realtime);
    xu_lf_phase_error_fs=($realtime-xu_lf_target_ns)*1000000.0;
    if (xu_lf_phase_error_fs>1.01 || xu_lf_phase_error_fs< -1.01)
      $fatal(1,"nominal32768 LF absolute phase drift exceeded 1fs");
    xu_lf_static_checks=xu_lf_static_checks+1;
    lfclk=~lfclk;
  end
  wire cmd_valid, cmd_read, cmd_ready, rsp_ready;
  wire [31:0] cmd_addr, cmd_wdata;
  wire [3:0] cmd_wmask;
  wire rsp_valid;
  wire [31:0] rsp_rdata;
  wire rsp_err;
  reg [31:0] ram [0:131071]; // Development shared SRAM: exactly 512 KiB.
  reg [15:0] x [0:6335], w [0:16383];
  reg [39:0] bias [0:255];
  reg [47:0] golden [0:25343];
  reg [7:0] program_bytes [0:65535];
  reg [63:0] xu_program_words [0:8191];
  string testcase, vectors;
  integer tasks, layer = 0, completed = 0, writes = 0;
  integer cycles = 0, first_cycle = -1, last_cycle = 0;
  integer max_cycles, firmware_cycles = 0;
  integer outstanding = 0;
  reg final_write_pending = 0;
  integer dumpwave;
  localparam BASE = 32'ha0000000, YOFF = 32'h20000, HOST = 32'h7f000;

  // Backpressure exercises CPU/bus waits; responses remain stable until accepted.
  assign cmd_ready=dut.ext_sysmem_cmd_ready;
  assign cmd_valid=dut.ext_sysmem_cmd_valid;
  assign cmd_read=dut.ext_sysmem_cmd_read;
  assign cmd_addr=dut.ext_sysmem_cmd_addr;
  assign cmd_wdata=dut.ext_sysmem_cmd_wdata;
  assign cmd_wmask=dut.ext_sysmem_cmd_wmask;
  assign rsp_ready=dut.ext_sysmem_rsp_ready;
  assign rsp_valid=dut.ext_sysmem_rsp_valid;
  assign rsp_rdata=dut.ext_sysmem_rsp_rdata;
  assign rsp_err=dut.ext_sysmem_rsp_err;

  // xu passive S2c observer. Reads actual core inputs at their sampling edge.
  integer xu_global_task, xu_saif_started=0, xu_saif_stopped=0;
  integer xu_w_count=0, xu_x_count=0, xu_bias_count=0, xu_rows=0;
  integer xu_starts=0, xu_dones=0, xu_pops=0, xu_w_pairs=0, xu_x_pairs=0;
  integer xu_clear_w_commits=0, xu_clear_x_commits=0, xu_clear_bias_commits=0;
  reg [16383:0] xu_clear_w_committed=0, xu_w_seen=0;
  reg [63:0] xu_clear_x_committed=0, xu_x_seen=0;
  reg [4:0] xu_bias_seen [0:255];
  reg [4:0] xu_clear_bias_committed [0:255];
  reg [15:0] xu_result_words=0;
  integer xu_reset_checked=0;
  integer xu_w_cursor_setups=0, xu_x_cursor_setups=0, xu_cache_mode_writes=0;
  reg xu_result_response_pending=0;
  reg [31:0] xu_result_response_word=0;
  integer xu_accel_reset_clock_edges=0, xu_accel_startup_observer_edges=0;
  reg xu_accel_reset_seen=0, xu_accel_observation_ready=0;
  real xu_accel_reset_first_tick=-1.0, xu_accel_reset_last_tick=-1.0;

  // The SoC accelerator uses bus_rst_n, released by its own synchronous
  // reset chain; TB rst_n is not that pin. In particular the synchronous
  // Chisel FIFO may remain X while its actual clock has not yet run in reset.
  // Count actual reset-sampling edges without changing any reset or DUT pin.
  always @(posedge dut.u_soc.u_e203_subsys_top.u_e203_subsys_main.u_e203_subsys_perips.u_accel_icb_slave.clk) begin
    $xu_private147_sample(1);
    if (xu147_o_031===1'b0) begin
      if (xu_accel_observation_ready || xu_saif_started)
        $fatal(1,"XU_CANDIDATE_RESET_REJECT accelerator reset reasserted after observation ready");
      if (!xu_accel_reset_seen) xu_accel_reset_first_tick=$realtime*1000000.0;
      xu_accel_reset_seen=1;
      xu_accel_reset_clock_edges=xu_accel_reset_clock_edges+1;
      xu_accel_reset_last_tick=$realtime*1000000.0;
    end else if (xu147_o_031!==1'b1 && xu_accel_reset_seen)
      $fatal(1,"XU_CANDIDATE_RESET_REJECT accelerator reset unknown after known assertion");
  end

  task xu_observe_candidate_reset_window;
    reg source_request;
    begin
      source_request=cmd_valid && cmd_read && cmd_addr>=BASE && cmd_addr<BASE+'h18800;
      if (xu147_o_031===1'b1) begin
        if (!xu_accel_reset_seen || xu_accel_reset_clock_edges<=0)
          $fatal(1,"XU_CANDIDATE_RESET_REJECT no actual accelerator clock sampled asserted reset");
        if (!xu_accel_observation_ready) begin
          xu_accel_observation_ready=1;
          // This still checks every original known-commit/FIFO/clear assertion.
          xu_observe_clear_window();
          $display("XU_CANDIDATE_RESET_READY task=%0d actual_reset_clock_edges=%0d startup_observer_edges=%0d first_reset_tick=%0.0f last_reset_tick=%0.0f first_ready_cycle=%0d first_ready_tick=%0.0f actual_rst_n=1 checked_empty_fifo=1",xu_global_task,xu_accel_reset_clock_edges,xu_accel_startup_observer_edges,xu_accel_reset_first_tick,xu_accel_reset_last_tick,cycles,$realtime*1000000.0);
        end else xu_observe_clear_window();
      end else begin
        if (xu_accel_observation_ready || xu_saif_started)
          $fatal(1,"XU_CANDIDATE_RESET_REJECT reset reasserted/unknown after observation ready");
        if (xu147_o_009===1'b1 || source_request===1'b1)
          $fatal(1,"XU_CANDIDATE_RESET_REJECT accelerator/source request before actual reset ready");
        if (xu147_o_031!==1'b0 && xu_accel_reset_seen)
          $fatal(1,"XU_CANDIDATE_RESET_REJECT reset unknown after known assertion");
        xu_accel_startup_observer_edges=xu_accel_startup_observer_edges+1;
      end
    end
  endtask

  task xu_observe_candidate;
    integer a, logical_index, lane, bit_index, b;
    reg [4:0] old_mask, new_mask;
    reg w_commit, x_commit, bias_commit;
    begin
      w_commit=xu147_o_048;
      x_commit=xu147_o_051;
      bias_commit=xu147_o_043;
      if ((^{w_commit,x_commit,bias_commit,xu147_o_016,xu147_o_017,
              xu147_o_023,xu147_o_020,xu147_o_022})===1'bx)
begin
        $display("XU_UNKNOWN167_TRIGGER tick_fs=%0.0f w_commit=%b x_commit=%b bias_commit=%b row_active=%b row_count=%b row_running=%b row_produced=%b row_retired=%b",$realtime*1000000.0,w_commit,x_commit,bias_commit,xu147_o_016,xu147_o_017,xu147_o_023,xu147_o_020,xu147_o_022);
        $xu_unknown167_snapshot();
        $fatal(1,"XU_CANDIDATE_REJECT unknown commit/FIFO ownership state");
      end
      if (!xu_reset_checked) begin
        if ({xu147_o_016,xu147_o_023,xu147_o_017,
             xu147_o_020,xu147_o_022,
             xu147_o_040,xu147_o_052}!==0)
          $fatal(1,"XU_CANDIDATE_REJECT FIFO logical ownership was not reset");
        xu_reset_checked=1;
      end
      if (xu147_o_017>2 || xu147_o_020<xu147_o_022 ||
          xu147_o_020-xu147_o_022!=xu147_o_017)
        $fatal(1,"XU_CANDIDATE_REJECT FIFO conservation");
      if ((xu147_o_016 || xu147_o_024) && (w_commit || x_commit || bias_commit))
        $fatal(1,"XU_CANDIDATE_REJECT operand commit while row owns storage");
      if (xu_result_response_pending) begin
        if (!xu147_o_030 || xu147_o_028!==xu_result_response_word)
          $fatal(1,"XU_CANDIDATE_REJECT result response absent/changed before retirement");
        if (xu147_o_029) xu_result_response_pending=0;
      end
      if (xu147_o_030 && xu147_o_027)
        $fatal(1,"XU_CANDIDATE_REJECT accelerator error response");
      if (w_commit) begin
        if ((^{xu147_o_046,
               xu147_o_045,
               xu147_o_047})===1'bx)
          $fatal(1,"XU_CANDIDATE_REJECT unknown W commit");
        a=xu147_o_046*2048+
          xu147_o_045;
        logical_index=(xu147_o_045%64)*256+
          (xu147_o_045/64)*8+
          xu147_o_046;
        if (!xu_saif_started) begin
          if (xu_clear_w_committed[a] || xu147_o_047!==16'b0)
            $fatal(1,"XU_CANDIDATE_REJECT duplicate/nonzero actual W clear commit");
          xu_clear_w_committed[a]=1; xu_clear_w_commits=xu_clear_w_commits+1;
        end else begin
          if (xu_saif_stopped || xu_w_seen[a] ||
              xu147_o_047!==w[logical_index])
            $fatal(1,"XU_CANDIDATE_REJECT outside/duplicate/fixture-mismatched actual W commit");
          if (!xu147_o_036 || !xu147_o_034 || !xu147_o_035 ||
              xu147_o_032!==2*(xu_w_count/2) ||
              xu147_o_037!==(xu_w_count%2!=0))
            $fatal(1,"XU_CANDIDATE_REJECT W PACK32 first/second commit order");
          xu_w_seen[a]=1; xu_w_count=xu_w_count+1;
        end
      end
      if (x_commit) begin
        if ((^{xu147_o_049,
               xu147_o_050})===1'bx)
          $fatal(1,"XU_CANDIDATE_REJECT unknown X commit");
        a=xu147_o_049;
        if (!xu_saif_started) begin
          if (xu_clear_x_committed[a] || xu147_o_050!==16'b0)
            $fatal(1,"XU_CANDIDATE_REJECT duplicate/nonzero actual X clear commit");
          xu_clear_x_committed[a]=1; xu_clear_x_commits=xu_clear_x_commits+1;
        end else begin
          if (xu_saif_stopped || xu_rows>=99 || xu_x_seen[a] ||
              xu147_o_050!==x[xu_rows*64+a])
            $fatal(1,"XU_CANDIDATE_REJECT outside/duplicate/fixture-mismatched actual X commit");
          if (!xu147_o_036 || xu147_o_034 || !xu147_o_035 ||
              xu147_o_032!==2*((xu_x_count%64)/2) ||
              xu147_o_037!==(xu_x_count%2!=0))
            $fatal(1,"XU_CANDIDATE_REJECT X PACK32 first/second commit order");
          xu_x_seen[a]=1; xu_x_count=xu_x_count+1;
        end
      end
      if (bias_commit) begin
        a=xu147_o_041;
        if ((^{a,xu147_o_042,
               xu147_o_044})===1'bx || xu147_o_004)
          $fatal(1,"XU_CANDIDATE_REJECT unknown/enabled-cache bias commit");
        old_mask=xu_saif_started ? xu_bias_seen[a] : xu_clear_bias_committed[a];
        new_mask=xu147_o_044;
        if (new_mask!==5'b01111 && new_mask!==5'b10000)
          $fatal(1,"XU_CANDIDATE_REJECT incomplete bias commit mask");
        if ((new_mask & old_mask)!=0 || xu_saif_stopped)
          $fatal(1,"XU_CANDIDATE_REJECT duplicate/outside bias commit");
        for (b=0;b<5;b=b+1) if (new_mask[b] &&
            xu147_o_042[8*b+:8] !==
            (xu_saif_started ? bias[a][8*b+:8] : 8'b0))
          $fatal(1,"XU_CANDIDATE_REJECT incorrect actual bias byte");
        if (xu_saif_started) xu_bias_seen[a]=old_mask|new_mask;
        else xu_clear_bias_committed[a]=old_mask|new_mask;
        if ((old_mask|new_mask)==31) begin
          if (xu_saif_started) xu_bias_count=xu_bias_count+1;
          else xu_clear_bias_commits=xu_clear_bias_commits+1;
        end
      end
      if (xu147_o_009 && xu147_o_008 && !xu147_o_007 && xu_saif_started) begin
        if (xu_saif_stopped) $fatal(1,"XU_CANDIDATE_REJECT task write after final Y retirement");
        case (xu147_o_006[11:0])
          12'h054: begin
            if (xu147_o_011!==15 || xu147_o_010!==0 || xu_w_count!=0 || xu_w_cursor_setups!=0)
              $fatal(1,"XU_CANDIDATE_REJECT W cursor setup");
            xu_w_cursor_setups=xu_w_cursor_setups+1;
          end
          12'h060: begin
            if (xu147_o_011!==15 || xu147_o_010!==0 || xu_x_count!=xu_rows*64 ||
                xu_x_cursor_setups!=xu_rows || xu_rows>=99)
              $fatal(1,"XU_CANDIDATE_REJECT X cursor setup");
            xu_x_cursor_setups=xu_x_cursor_setups+1;
          end
          12'h040: begin
            if (xu147_o_011!==15 || xu_w_count!=16384 || xu_cache_mode_writes>=2 ||
                xu147_o_010!==xu_cache_mode_writes ||
                xu_bias_count!=(xu_cache_mode_writes==0 ? 0 : 256))
              $fatal(1,"XU_CANDIDATE_REJECT cache mode setup order/count");
            xu_cache_mode_writes=xu_cache_mode_writes+1;
          end
          12'h05c: begin
            if (xu147_o_011!==15) $fatal(1,"XU_CANDIDATE_REJECT W PACK32 mask");
            xu_w_pairs=xu_w_pairs+1;
          end
          12'h068: begin
            if (xu147_o_011!==15) $fatal(1,"XU_CANDIDATE_REJECT X PACK32 mask");
            xu_x_pairs=xu_x_pairs+1;
          end
          12'h044,12'h048,12'h04c,12'h0c0,12'h0c8: begin end
          default: $fatal(1,"XU_CANDIDATE_REJECT unexpected payload MMIO write");
        endcase
      end
      if ((xu147_o_009 && xu147_o_008 && !xu147_o_007 &&
        xu147_o_006[11:0] == 12'h0c0 && xu147_o_011 == 4'hf &&
        xu147_o_010 == 32'd1 && xu147_o_004 && !((xu147_o_015 || xu147_o_016 || xu147_o_024)) && !xu147_o_024 &&
        !xu147_o_014 && !xu147_o_059 && !xu147_o_056 && xu147_o_017 == 0)) begin
        if (!xu_saif_started || xu_saif_stopped || xu_rows>=99 ||
            xu_w_count!=16384 || xu_bias_count!=256 || xu_x_seen!==64'hffffffffffffffff ||
            xu147_o_004!==1 || xu147_o_036 ||
            xu147_o_048 || xu147_o_051 ||
            xu147_o_016 || xu147_o_017!=0 || xu_pops!=xu_rows*32 ||
            xu_starts!=xu_rows*32 || xu_dones!=xu_rows*32 || xu_result_words!=0)
          $fatal(1,"XU_CANDIDATE_REJECT STARTROW before fresh complete/drained operands/FIFO");
        xu_rows=xu_rows+1; xu_x_seen=0;
      end
      if (xu147_o_016 && xu147_o_012) begin
        if (!xu_saif_started || xu_saif_stopped ||
            xu147_o_039!==xu_starts%32)
          $fatal(1,"XU_CANDIDATE_REJECT autonomous group start order/window");
        xu_starts=xu_starts+1;
      end
      if (xu147_o_013) begin
        if (!xu_saif_started || xu_saif_stopped || xu_dones>=xu_starts)
          $fatal(1,"XU_CANDIDATE_REJECT unexpected done");
        xu_dones=xu_dones+1;
      end
      if (xu147_o_009 && xu147_o_008 && xu147_o_007 &&
          xu147_o_006[11:0]>=12'h100 && xu147_o_006[11:0]<=12'h13c) begin
        lane=xu147_o_006[5:3]; bit_index=xu147_o_006[5:2];
        if (!xu_saif_started || xu_saif_stopped || !xu147_o_026 ||
            xu147_o_018!==xu_pops%32 || xu_result_words[bit_index] ||
            xu147_o_021[lane]!==golden[(xu_rows-1)*256+(xu_pops%32)*8+lane])
          $fatal(1,"XU_CANDIDATE_REJECT incomplete/duplicate/incorrect owned FIFO result");
        if (xu_result_response_pending)
          $fatal(1,"XU_CANDIDATE_REJECT result response overlap without retirement");
        xu_result_response_pending=1;
        xu_result_response_word=bit_index%2 ? {16'b0,xu147_o_021[lane][47:32]} :
                                                           xu147_o_021[lane][31:0];
        xu_result_words[bit_index]=1;
      end
      if (xu147_o_019) begin
        if (!xu_saif_started || xu_saif_stopped || !xu147_o_016 ||
            !xu147_o_026 || xu147_o_018!==xu_pops%32 ||
            xu_result_words!==16'hffff || xu_pops>=xu_rows*32)
          $fatal(1,"XU_CANDIDATE_REJECT POP before all owned words read / wrong group");
        xu_pops=xu_pops+1; xu_result_words=0;
      end
    end
  endtask

  // xu passive clear observer: no force, no DUT assignment, no task payload.
  integer xu_clear_writes=0, xu_clear_w_count=0, xu_clear_bias_count=0;
  integer xu_clear_legacy_count=0, xu_clear_x_count=0, xu_clear_disable_count=0;
  reg [16383:0] xu_clear_w_seen=0;
  reg [63:0] xu_clear_x_seen=0;
  reg [4:0] xu_clear_bias_seen [0:255];
  reg [4:0] xu_clear_legacy_seen [0:7];
  reg xu_clear_complete=0;
  integer xu_clear_init;
  initial begin
    for (xu_clear_init=0;xu_clear_init<256;xu_clear_init=xu_clear_init+1)
      xu_clear_bias_seen[xu_clear_init]=0;
    for (xu_clear_init=0;xu_clear_init<8;xu_clear_init=xu_clear_init+1)
      xu_clear_legacy_seen[xu_clear_init]=0;
  end

  task xu_observe_task_clear;
    input source_request;
    output payload_phase;
    integer a;
    reg [4:0] old_mask, new_mask;
    begin
      if (!xu_clear_complete) begin
        if (xu147_o_004!==1'b0 || (xu147_o_015 || xu147_o_016 || xu147_o_024)!==1'b0 ||
            xu147_o_014!==1'b0)
          $fatal(1,"XU_CLEAR_REJECT non-idle/enabled clear phase");
        if (source_request) begin
          if (xu_clear_writes!=33697 || xu_clear_disable_count!=1 ||
              xu_clear_w_count!=16384 || xu_clear_bias_count!=256 ||
              xu_clear_legacy_count!=8 || xu_clear_x_count!=64)
            $fatal(1,"XU_CLEAR_REJECT incomplete clear before first source request");
          // W/X stores are committed one clock after MMIO acceptance.
          if (xu147_o_056!==1'b0 || xu147_o_059!==1'b0 || xu147_o_036!==1'b0 || xu147_o_030!==1'b0)
            $fatal(1,"XU_CLEAR_REJECT undrained W/X clear strobe");
          if (xu_clear_w_commits!=16384 || xu_clear_x_commits!=64 ||
              xu_clear_bias_commits!=256 || xu_clear_w_committed!=={16384{1'b1}} ||
              xu_clear_x_committed!==64'hffffffffffffffff || !xu_reset_checked ||
              xu147_o_016 || xu147_o_023 || xu147_o_017!=0 ||
              xu147_o_020!=0 || xu147_o_022!=0 ||
              xu147_o_040!==0 || xu147_o_052!==0 ||
              xu147_o_033 || xu147_o_055!=0 || xu147_o_058!=0)
            $fatal(1,"XU_CLEAR_REJECT incomplete actual zero commits or nonempty FIFO/stream ownership");
          for (a=0;a<8;a=a+1) if (xu147_o_001[a]!==40'b0)
            $fatal(1,"XU_CLEAR_REJECT actual legacy bias did not clear");
          xu_clear_complete=1;
          $display("XU_TASK_CLEAR_OBSERVED writes=33697 w=16384 bias=256 legacy_bias=8 x=64 drained=1 cache_enable=0 idle=1 source_request=1 task_setup_writes=0 actual_commits=1 fifo_reset_empty=1");
        end else if (xu147_o_009 && xu147_o_008) begin
          if (xu147_o_007) begin
            if (xu147_o_006[11:0]!=12'h000 &&
                xu147_o_006[11:0]!=12'h00c &&
                xu147_o_006[11:0]!=12'h050 && xu147_o_006[11:0]!=12'h070 &&
                xu147_o_006[11:0]!=12'h074 && xu147_o_006[11:0]!=12'h078)
              $fatal(1,"XU_CLEAR_REJECT unexpected pretask MMIO read");
          end else begin
            if (xu_clear_writes==33697)
              $fatal(1,"XU_CLEAR_REJECT candidate setup/data write before first source request");
            if (xu147_o_011!==4'hf ||
                (^xu147_o_010)===1'bx)
              $fatal(1,"XU_CLEAR_REJECT incomplete/unknown clear word");
            xu_clear_writes=xu_clear_writes+1;
            case (xu147_o_006[11:0])
              12'h040: begin
                if (xu147_o_010!==32'b0 || xu_clear_disable_count!=0)
                  $fatal(1,"XU_CLEAR_REJECT cache disable");
                xu_clear_disable_count=xu_clear_disable_count+1;
              end
              12'h01c: if (xu147_o_010>7)
                $fatal(1,"XU_CLEAR_REJECT W bank");
              12'h020: if (xu147_o_010>2047)
                $fatal(1,"XU_CLEAR_REJECT W address");
              12'h044: if (xu147_o_010>255)
                $fatal(1,"XU_CLEAR_REJECT bias address");
              12'h028: if (xu147_o_010>7)
                $fatal(1,"XU_CLEAR_REJECT legacy bias address");
              12'h014: if (xu147_o_010>63)
                $fatal(1,"XU_CLEAR_REJECT X address");
              12'h024: begin
                if ((^{xu147_o_054,xu147_o_053})===1'bx)
                  $fatal(1,"XU_CLEAR_REJECT unknown W destination");
                a=xu147_o_054*2048+xu147_o_053;
                if (xu147_o_010!==32'b0 || xu_clear_w_seen[a])
                  $fatal(1,"XU_CLEAR_REJECT nonzero/duplicate W clear");
                xu_clear_w_seen[a]=1;
                xu_clear_w_count=xu_clear_w_count+1;
              end
              12'h018: begin
                if ((^xu147_o_057)===1'bx)
                  $fatal(1,"XU_CLEAR_REJECT unknown X destination");
                a=xu147_o_057;
                if (xu147_o_010!==32'b0 || xu_clear_x_seen[a])
                  $fatal(1,"XU_CLEAR_REJECT nonzero/duplicate X clear");
                xu_clear_x_seen[a]=1;
                xu_clear_x_count=xu_clear_x_count+1;
              end
              12'h048,12'h04c,12'h02c,12'h030: begin
                if (xu147_o_010!==32'b0)
                  $fatal(1,"XU_CLEAR_REJECT nonzero bias clear");
                if (xu147_o_006[11:0]==12'h048 ||
                    xu147_o_006[11:0]==12'h04c) begin
                  if ((^xu147_o_003)===1'bx)
                    $fatal(1,"XU_CLEAR_REJECT unknown bias destination");
                  a=xu147_o_003;
                  old_mask=xu_clear_bias_seen[a];
                end else begin
                  if ((^xu147_o_000)===1'bx)
                    $fatal(1,"XU_CLEAR_REJECT unknown legacy bias destination");
                  a=xu147_o_000;
                  old_mask=xu_clear_legacy_seen[a];
                end
                if (xu147_o_006[11:0]==12'h048 ||
                    xu147_o_006[11:0]==12'h02c) begin
                  if (old_mask[3:0]!=0)
                    $fatal(1,"XU_CLEAR_REJECT duplicate bias low clear");
                  new_mask=old_mask|5'b01111;
                end else begin
                  if (old_mask[4])
                    $fatal(1,"XU_CLEAR_REJECT duplicate bias high clear");
                  new_mask=old_mask|5'b10000;
                end
                if (xu147_o_006[11:0]==12'h048 ||
                    xu147_o_006[11:0]==12'h04c) begin
                  xu_clear_bias_seen[a]=new_mask;
                  if (new_mask==5'b11111) xu_clear_bias_count=xu_clear_bias_count+1;
                end else begin
                  xu_clear_legacy_seen[a]=new_mask;
                  if (new_mask==5'b11111) xu_clear_legacy_count=xu_clear_legacy_count+1;
                end
              end
              default: $fatal(1,"XU_CLEAR_REJECT unexpected pretask MMIO write");
            endcase
          end
        end
      end
      payload_phase=xu_clear_complete;
    end
  endtask

  reg xu_payload_phase=0;
  integer xu_request_cycle=-1, xu_accept_cycle=-1, xu_initial_wait=0;
  integer xu_formal_cycles=0, xu_clear_first_cycle=-1, xu_clear_last_cycle=-1;
  reg [31:0] xu_request_addr;

  task xu_observe_clear_window;
    reg source_request, source_accept, clear_write;
    begin
      source_request=cmd_valid && cmd_read && cmd_addr>=BASE && cmd_addr<BASE+'h18800;
      source_accept=source_request && cmd_ready;
      clear_write=!xu_clear_complete && xu_clear_writes<33697 &&
                  xu147_o_009 && xu147_o_008 && !xu147_o_007;
      if (clear_write) begin
        if (xu_clear_first_cycle<0) begin
          xu_clear_first_cycle=cycles;
          $display("XU_TASK_CLEAR_BEGIN task=%0d cycle=%0d tick=%0.0f",xu_global_task,cycles,$realtime*1000000.0);
        end
        xu_clear_last_cycle=cycles;
      end
      xu_observe_candidate();
      // Once per post-reset edge, before any payload observation or SAIF start.
      xu_observe_task_clear(source_request,xu_payload_phase);
      if (clear_write && xu_clear_writes==33697)
        $display("XU_TASK_CLEAR_LAST_WRITE task=%0d cycle=%0d tick=%0.0f writes=33697",xu_global_task,cycles,$realtime*1000000.0);
      if (source_request && xu_request_cycle<0) begin
        if (!xu_clear_complete || xu_saif_started || xu_saif_stopped ||
            xu_w_count!=0 || xu_bias_count!=0 || xu_x_count!=0 || xu_starts!=0)
          $fatal(1,"clear recipe did not begin from verified empty payload state");
        xu_request_cycle=cycles;
        xu_request_addr=cmd_addr;
        xu_saif_started=1;
`ifndef XU_TASK_ACTIVITY_HOST_CHECK
        $toggle_start();
`endif
        $display("XU_SOURCE_REQUEST task=%0d cycle=%0d tick=%0.0f",xu_global_task,cycles,$realtime*1000000.0);
        $display("XU_ACTIVITY_BEGIN task=%0d tick=%0.0f",xu_global_task,$realtime*1000000.0);
        $display("XU_CACHE_INITIAL task=%0d fresh_process=1 cache_enable=0 busy=0 prior_uploads=0 prior_starts=0",xu_global_task);
      end
      if (xu_request_cycle>=0 && xu_accept_cycle<0) begin
        if (!source_request || cmd_addr!==xu_request_addr)
          $fatal(1,"first source request changed before acceptance");
        if (source_accept) begin
          xu_accept_cycle=cycles;
          if (xu_initial_wait!=xu_accept_cycle-xu_request_cycle)
            $fatal(1,"initial source wait count differs");
          $display("XU_SOURCE_ACCEPT task=%0d cycle=%0d tick=%0.0f",xu_global_task,cycles,$realtime*1000000.0);
        end else xu_initial_wait=xu_initial_wait+1;
      end
      if (xu_saif_started && !xu_saif_stopped) xu_formal_cycles=xu_formal_cycles+1;
    end
  endtask

  // Observation only: these counters never drive the SoC or its memory model.
  // A phase includes software and bus gaps between its first and last operation.
  // Load phases end when the final data-write response retires; writeback ends
  // at every group's final Y-write response. Accepted operations start a new
  // phase on that edge, while an ending response changes the following edge.
  localparam PERF_OTHER = 0, PERF_W = 1, PERF_X = 2, PERF_BIAS = 3,
             PERF_COMPUTE = 4, PERF_WRITEBACK = 5;
  integer perf_phase;
  reg perf_active, perf_mmio_end_phase, perf_shared_end_writeback;
  integer perf_cycles, perf_w_load, perf_x_load, perf_bias_load;
  integer perf_compute_wait, perf_writeback, perf_other;
  integer perf_busy, perf_mac_fire, perf_starts, perf_dones;
  integer perf_mmio_reads, perf_mmio_writes, perf_mmio_stall;
  integer perf_shared_reads, perf_shared_writes, perf_shared_stall;
  integer perf_auto_rows, perf_auto_pops, perf_auto_overlap, perf_auto_full;

  task reset_performance;
    begin
      perf_phase=PERF_OTHER;
      perf_active=0; perf_mmio_end_phase=0; perf_shared_end_writeback=0;
      perf_cycles=0; perf_w_load=0; perf_x_load=0; perf_bias_load=0;
      perf_compute_wait=0; perf_writeback=0; perf_other=0;
      perf_busy=0; perf_mac_fire=0; perf_starts=0; perf_dones=0;
      perf_mmio_reads=0; perf_mmio_writes=0; perf_mmio_stall=0;
      perf_shared_reads=0; perf_shared_writes=0; perf_shared_stall=0;
      perf_auto_rows=0; perf_auto_pops=0; perf_auto_overlap=0; perf_auto_full=0;
    end
  endtask

  task observe_performance;
    integer phase_now, phase_next;
    reg shared_accept, shared_retire, mmio_accept, mmio_retire, start_accept;
    reg in_window, row_start_accept;
    begin
      shared_accept=cmd_valid && cmd_ready;
      shared_retire=rsp_valid && rsp_ready;
      mmio_accept=xu147_o_009 && xu147_o_008;
      mmio_retire=xu147_o_030 && xu147_o_029;
      start_accept=mmio_accept && !xu147_o_007 &&
                   xu147_o_006[11:0]==12'h008 &&
                   xu147_o_010[0] && !(xu147_o_015 || xu147_o_016 || xu147_o_024);
      row_start_accept=(xu147_o_009 && xu147_o_008 && !xu147_o_007 &&
        xu147_o_006[11:0] == 12'h0c0 && xu147_o_011 == 4'hf &&
        xu147_o_010 == 32'd1 && xu147_o_004 && !((xu147_o_015 || xu147_o_016 || xu147_o_024)) && !xu147_o_024 &&
        !xu147_o_014 && !xu147_o_059 && !xu147_o_056 && xu147_o_017 == 0);
      xu_observe_candidate_reset_window();
      // Match the existing inclusive first-input/final-Y-response interval.
      in_window=perf_active || (first_cycle<0 && shared_accept && cmd_read &&
                               cmd_addr>=BASE && cmd_addr<BASE+'h18800);
      if (dumpwave==2 && !perf_active && in_window) begin
        $dumpon;
        $display("ACTIVITY_BEGIN layer=%0d time=%0t",layer,$time);
      end
      if (in_window) begin
        if (!perf_active) begin
          $display("PPA_WINDOW_BEGIN layer=%0d cycle=%0d time_ns=%0.12f tick_fs=%0.0f",layer,cycles,$realtime,$realtime*1000000.0);

        end
        perf_active=1;
        phase_now=perf_phase;
        phase_next=perf_phase;
        if ((mmio_retire && perf_mmio_end_phase) ||
            (shared_retire && perf_shared_end_writeback) ||
            (xu147_o_013 && (!xu147_o_016 || perf_phase==PERF_COMPUTE)))
          phase_next=PERF_OTHER;

        if (mmio_accept && !xu147_o_007) begin
          case (xu147_o_006[11:0])
            12'h01c, 12'h020, 12'h024, 12'h054, 12'h058, 12'h05c: begin
              phase_now=PERF_W; phase_next=PERF_W;
            end
            12'h014, 12'h018, 12'h060, 12'h064, 12'h068: begin
              phase_now=PERF_X; phase_next=PERF_X;
            end
            12'h028, 12'h02c, 12'h030,
            12'h040, 12'h044, 12'h048, 12'h04c: begin
              phase_now=PERF_BIAS; phase_next=PERF_BIAS;
            end
            12'h034: begin
              phase_now=PERF_WRITEBACK; phase_next=PERF_WRITEBACK;
            end
            default: begin end
          endcase
        end
        // The read-only window has no RESULT_INDEX write to start writeback.
        if (mmio_accept && xu147_o_007 &&
            ((xu147_o_006[11:0]>=12'h080 && xu147_o_006[11:0]<=12'h0bc) ||
             (xu147_o_006[11:0]>=12'h100 && xu147_o_006[11:0]<=12'h13c))) begin
          phase_now=PERF_WRITEBACK; phase_next=PERF_WRITEBACK;
        end
        if (start_accept || row_start_accept) begin
          phase_now=PERF_COMPUTE; phase_next=PERF_COMPUTE;
        end
        if (mmio_accept && xu147_o_007 && xu147_o_006[11:0]==12'h0c4) begin
          phase_now=PERF_COMPUTE; phase_next=PERF_COMPUTE;
        end
        // Source reads can precede their matching MMIO load operation.
        if (shared_accept && cmd_read) begin
          if (cmd_addr>=BASE+'h08000 && cmd_addr<BASE+'h18000) begin
            phase_now=PERF_W; phase_next=PERF_W;
          end else if (cmd_addr>=BASE && cmd_addr<BASE+'h06300) begin
            phase_now=PERF_X; phase_next=PERF_X;
          end else if (cmd_addr>=BASE+'h18000 && cmd_addr<BASE+'h18800) begin
            phase_now=PERF_BIAS; phase_next=PERF_BIAS;
          end
        end
        perf_phase=phase_next;
        perf_cycles=perf_cycles+1;
        case (phase_now)
          PERF_W: perf_w_load=perf_w_load+1;
          PERF_X: perf_x_load=perf_x_load+1;
          PERF_BIAS: perf_bias_load=perf_bias_load+1;
          PERF_COMPUTE: perf_compute_wait=perf_compute_wait+1;
          PERF_WRITEBACK: perf_writeback=perf_writeback+1;
          default: perf_other=perf_other+1;
        endcase
        if (xu147_o_015 || xu147_o_023 ||
            (xu147_o_016 && xu147_o_012)) perf_busy=perf_busy+1;
        if (row_start_accept) perf_auto_rows=perf_auto_rows+1;
        if (xu147_o_019) perf_auto_pops=perf_auto_pops+1;
        if (xu147_o_023 && phase_now==PERF_WRITEBACK)
          perf_auto_overlap=perf_auto_overlap+1;
        if (xu147_o_016 && xu147_o_017==2 && !xu147_o_023)
          perf_auto_full=perf_auto_full+1;
        // All eight PEs share this enable: one fire means eight signed16 MACs.
        if (xu147_o_038)
          perf_mac_fire=perf_mac_fire+1;
        if (start_accept || (xu147_o_016 && xu147_o_012))
          perf_starts=perf_starts+1;
        if (xu147_o_013) perf_dones=perf_dones+1;
        if (mmio_accept) begin
          if (xu147_o_007) perf_mmio_reads=perf_mmio_reads+1;
          else perf_mmio_writes=perf_mmio_writes+1;
        end
        if (shared_accept) begin
          if (cmd_read) perf_shared_reads=perf_shared_reads+1;
          else perf_shared_writes=perf_shared_writes+1;
        end
        // A stall is a cycle with either blocked channel, counted once.
        if ((xu147_o_009 && !xu147_o_008) ||
            (xu147_o_030 && !xu147_o_029))
          perf_mmio_stall=perf_mmio_stall+1;
        if ((cmd_valid && !cmd_ready) || (rsp_valid && !rsp_ready))
          perf_shared_stall=perf_shared_stall+1;
        if (shared_retire && final_write_pending) begin
          $display("PPA_WINDOW_END layer=%0d cycle=%0d time_ns=%0.12f tick_fs=%0.0f",layer,cycles,$realtime,$realtime*1000000.0);
          if (xu_request_cycle<0 || xu_accept_cycle<xu_request_cycle ||
              xu_formal_cycles!=cycles-xu_request_cycle+1 ||
              xu_formal_cycles!=perf_cycles+xu_initial_wait ||
              xu_w_count!=16384 || xu_bias_count!=256 || xu_x_count!=6336 ||
              xu_rows!=99 || xu_starts!=3168 || xu_dones!=3168 || xu_pops!=3168 ||
              xu_w_pairs!=8192 || xu_x_pairs!=3168 || xu_result_words!=0 ||
              xu_w_cursor_setups!=1 || xu_x_cursor_setups!=99 || xu_cache_mode_writes!=2 ||
              xu_result_response_pending ||
              xu147_o_016 || xu147_o_023 || xu147_o_017!=0 ||
              xu147_o_020!=32 || xu147_o_022!=32 || xu147_o_036 ||
              !xu_saif_started || xu_saif_stopped)
            $fatal(1,"XU_CANDIDATE_REJECT incomplete actual task coverage/window/FIFO drain");
`ifndef XU_TASK_ACTIVITY_HOST_CHECK
          $toggle_stop();
`endif
          xu_saif_stopped=1;
          $display("XU_ACTIVITY_END task=%0d tick=%0.0f",xu_global_task,$realtime*1000000.0);
          $display("XU_TASK_WINDOW task=%0d request_cycle=%0d accept_cycle=%0d end_cycle=%0d initial_wait_cycles=%0d legacy_inclusive_cycles=%0d formal_inclusive_cycles=%0d formal_elapsed_cycles=%0d",xu_global_task,xu_request_cycle,xu_accept_cycle,cycles,xu_initial_wait,perf_cycles,xu_formal_cycles,xu_formal_cycles-1);
          $display("XU_CANDIDATE_UPLOAD_PASS task=%0d w_commits=16384 bias=256 x_commits=6336 rows=99 starts=3168 dones=3168 pops_retired=3168 w_pack32=8192 x_pack32=3168 fifo_empty=1 checked_data=1",xu_global_task);
`ifndef XU_TASK_ACTIVITY_HOST_CHECK
          $toggle_report("task.saif",1.0e-15,"tb_xu_soc_ppa.dut");
`endif
          perf_active=0;
          if (dumpwave==2) begin
            $display("ACTIVITY_END layer=%0d time=%0t",layer,$time);
            $dumpoff;
          end
        end
      end

      // Retiring metadata belongs to the old response even when the next
      // command is accepted on the same edge. Each endpoint has one slot.
      if (mmio_retire) perf_mmio_end_phase=0;
      if (mmio_accept)
        perf_mmio_end_phase=!xu147_o_007 &&
          ((xu147_o_006[11:0]==12'h024 &&
            xu147_o_054==7 && xu147_o_053==2047) ||
           (xu147_o_006[11:0]==12'h018 && xu147_o_057==63) ||
           (xu147_o_006[11:0]==12'h058 && xu147_o_055==16383) ||
           (xu147_o_006[11:0]==12'h064 && xu147_o_058==63) ||
           (xu147_o_006[11:0]==12'h05c && xu147_o_055==16382) ||
           (xu147_o_006[11:0]==12'h068 && xu147_o_058==62) ||
           (xu147_o_006[11:0]==12'h030 && xu147_o_000==7) ||
           (xu147_o_006[11:0]==12'h040 && xu147_o_010[0]));
      if (shared_retire) perf_shared_end_writeback=0;
      if (shared_accept)
        perf_shared_end_writeback=!cmd_read && cmd_addr>=BASE+YOFF &&
          cmd_addr<BASE+YOFF+50688*4 && cmd_addr[5:0]==6'h3c;
    end
  endtask

  task report_performance;
    begin
      if (perf_cycles!=last_cycle-first_cycle+1 ||
          perf_w_load+perf_x_load+perf_bias_load+perf_compute_wait+
          perf_writeback+perf_other!=perf_cycles)
        $fatal(1,"performance interval or phase sum mismatch");
      if (perf_auto_rows!=0) begin
        if (perf_auto_rows!=99 || perf_auto_pops!=3168 || xu147_o_016 ||
            xu147_o_022!=32 || xu147_o_020!=32 || xu147_o_017!=0 ||
            perf_auto_overlap==0)
          $fatal(1,"autonomous row/POP retirement or overlap contract mismatch");
        $display("AUTO_TASK layer=%0d rows=%0d pops_retired=%0d compute_writeback_overlap=%0d fifo_full_wait=%0d",
          layer,perf_auto_rows,perf_auto_pops,perf_auto_overlap,perf_auto_full);
      end
      $display("PERF_TASK layer=%0d cycles=%0d w_load=%0d x_load=%0d bias_load=%0d compute_wait=%0d writeback=%0d other=%0d busy=%0d mac_fire=%0d mmio_reads=%0d mmio_writes=%0d shared_reads=%0d shared_writes=%0d shared_stall=%0d mmio_stall=%0d starts=%0d dones=%0d",
        layer,perf_cycles,perf_w_load,perf_x_load,perf_bias_load,
        perf_compute_wait,perf_writeback,perf_other,perf_busy,perf_mac_fire,
        perf_mmio_reads,perf_mmio_writes,perf_shared_reads,perf_shared_writes,
        perf_shared_stall,perf_mmio_stall,perf_starts,perf_dones);
    end
  endtask

  xu_soc_ppa_top dut (
    .hfextclk(clk), .lfextclk(lfclk), .io_pads_aon_erst_n_i_ival(rst_n),
    .io_pads_jtag_TCK_i_ival(1'b0), .io_pads_jtag_TMS_i_ival(1'b0),
    .io_pads_jtag_TDI_i_ival(1'b0), .io_pads_gpioA_i_ival(32'b0),
    .io_pads_gpioB_i_ival(32'b0), .io_pads_qspi0_dq_0_i_ival(1'b0),
    .io_pads_qspi0_dq_1_i_ival(1'b0), .io_pads_qspi0_dq_2_i_ival(1'b0),
    .io_pads_qspi0_dq_3_i_ival(1'b0), .io_pads_bootrom_n_i_ival(1'b0),
    .io_pads_dbgmode0_n_i_ival(1'b1), .io_pads_dbgmode1_n_i_ival(1'b1),
    .io_pads_dbgmode2_n_i_ival(1'b1), .io_pads_aon_pmu_dwakeup_n_i_ival(1'b1),
    .hfxoscen(), .lfxoscen(), .io_pads_jtag_TDO_o_oval(), .io_pads_jtag_TDO_o_oe(),
    .io_pads_gpioA_o_oval(), .io_pads_gpioA_o_oe(), .io_pads_gpioB_o_oval(), .io_pads_gpioB_o_oe(),
    .io_pads_qspi0_sck_o_oval(), .io_pads_qspi0_cs_0_o_oval(),
    .io_pads_qspi0_dq_0_o_oval(), .io_pads_qspi0_dq_0_o_oe(),
    .io_pads_qspi0_dq_1_o_oval(), .io_pads_qspi0_dq_1_o_oe(),
    .io_pads_qspi0_dq_2_o_oval(), .io_pads_qspi0_dq_2_o_oe(),
    .io_pads_qspi0_dq_3_o_oval(), .io_pads_qspi0_dq_3_o_oe(),
    .io_pads_aon_pmu_padrst_o_oval(), .io_pads_aon_pmu_vddpaden_o_oval()
  );

// Non-synthesizable preload: no force, no changes to live bus timing.
function automatic [63:0] xu_pack_vendor_row;
  input [15:0] a0,a1,a2,a3;
  integer b;
  begin
    for (b=0;b<16;b=b+1)
      xu_pack_vendor_row[4*b +: 4]={a3[b],a2[b],a1[b],a0[b]};
  end
endfunction
task xu_preload_itcm;
  begin
    $xu_private147_itcm();
  end
endtask
task xu_preload_shared;
  begin
    $xu_private147_shared();
  end
endtask

  task load_layer(input integer index);
    string directory;
    integer i;
    begin
      directory = $sformatf("%s/layer_%02d/", vectors, index);
      $readmemh({directory,"x.mem"}, x);
      $readmemh({directory,"w.mem"}, w);
      $readmemh({directory,"bias.mem"}, bias);
      $readmemh({directory,"y.mem"}, golden);
      for (i=0; i<6336; i=i+1) ram[i] = {16'b0,x[i]};
      for (i=0; i<16384; i=i+1) ram['h8000/4+i] = {16'b0,w[i]};
      for (i=0; i<256; i=i+1) begin
        ram['h18000/4+2*i] = bias[i][31:0];
        ram['h18000/4+2*i+1] = {{24{bias[i][39]}},bias[i][39:32]};
      end
      // Poison output memory on every layer; no result survives as evidence.
      for (i=0; i<50688; i=i+1) ram[YOFF/4+i] = 32'hdeadbeef;
      xu_preload_shared();
      $display("XU_CACHE_RELOAD task=%0d done_before_begin=1 scope=shared_fixture tick=%0.0f",xu_global_task,$realtime*1000000.0);
      writes = 0; first_cycle = -1; final_write_pending = 0;
      reset_performance();
    end
  endtask

  initial begin : initialize
    integer i;
    $xu_private147_prepare();
    $xu_unknown167_prepare();
    if (!$value$plusargs("TESTCASE=%s",testcase) ||
        !$value$plusargs("VECTORS=%s",vectors) ||
        !$value$plusargs("TASKS=%d",tasks)) $fatal(1,"missing plusargs");
    if (tasks < 1 || tasks > 12) $fatal(1,"invalid task count");
    if (!$value$plusargs("MAX_CYCLES=%d",max_cycles)) max_cycles=200000000;
    if (!$value$plusargs("XU_GLOBAL_TASK=%d",xu_global_task) ||
        xu_global_task<0 || xu_global_task>11 || tasks!=1)
      $fatal(1,"candidate requires valid global task and TASKS=1 fresh process");
    for (i=0;i<256;i=i+1) begin xu_bias_seen[i]=0; xu_clear_bias_committed[i]=0; end
`ifndef XU_TASK_ACTIVITY_HOST_CHECK
    $set_gate_level_monitoring("rtl_on");
    $set_toggle_region(tb_xu_soc_ppa.dut);
`endif
    #1; // Finish vendor initialization before the first HF edge.
    for (i=0; i<65536; i=i+1) program_bytes[i]=0;
    $readmemh({testcase,".verilog"},program_bytes);
    for (i=0; i<8192; i=i+1)
      xu_program_words[i] = {program_bytes[8*i+7],program_bytes[8*i+6],
        program_bytes[8*i+5],program_bytes[8*i+4],program_bytes[8*i+3],
        program_bytes[8*i+2],program_bytes[8*i+1],program_bytes[8*i]};
    xu_preload_itcm();
    ram[HOST/4]=tasks;
    load_layer(0);
    if ($value$plusargs("DUMPWAVE=%d",dumpwave) && dumpwave) begin
      $dumpfile("tb_accel_soc.vcd");
      if (dumpwave==2) begin
        $dumpvars(0,dut);
        $dumpoff;
      end else $dumpvars(0,tb_xu_soc_ppa);
    end
    #(200-$realtime);
    if (xu_reset_edges!=30) $fatal(1,"nominal150 reset HF edge count=%0d",xu_reset_edges);
    rst_n=1;
    $display("PPA_CLOCK mode=nominal150 hf_nominal_period_ns=6.666666666666667 precision_fs=1 reset_hf_edges=%0d",xu_reset_edges);
  end

  always @(posedge clk) begin : memory_and_scoreboard
    integer offset, word_index;
    reg [63:0] expected;
    $xu_private147_sample(2);
    cycles <= cycles+1;
    if (cycles>0 && cycles%1000000==0) begin
      $display("PPA_PROGRESS cycles=%0d layer=%0d writes=%0d completed=%0d",cycles,layer,writes,completed);
      $fflush();
    end
    if (cycles > max_cycles) $fatal(1,"SoC timeout layer=%0d writes=%0d",layer,writes);
    if (rst_n) begin
      observe_performance();
      // A response must correspond to exactly one unretired shared-memory command.
      if (rsp_valid && outstanding != 1) $fatal(1,"orphan shared response");
      if (rsp_valid && rsp_ready) outstanding=outstanding-1;
      if (cmd_valid && cmd_ready) outstanding=outstanding+1;
      if (outstanding<0 || outstanding>1) $fatal(1,"shared outstanding count");
      if (rsp_valid && rsp_ready && final_write_pending) begin
        last_cycle=cycles;
        final_write_pending=0;
      end
      if (rsp_valid && rsp_err) $fatal(1,"shared endpoint error");
      if (cmd_ready !== ((!rsp_valid || rsp_ready) && (cycles % 7 != 0)))
        $fatal(1,"shared endpoint backpressure phase differs cycle=%0d",cycles);
      if (cmd_ready) begin
        if (cmd_valid) begin
          if (cmd_addr < BASE || cmd_addr >= BASE+'h80000 || cmd_addr[1:0]!=0)
            $fatal(1,"invalid shared address %h",cmd_addr);
          offset=cmd_addr-BASE;
          word_index=offset/4;
          if (cmd_read) begin
            if (offset < 'h18800 && first_cycle<0) first_cycle=cycles;
          end else begin
            if (cmd_wmask != 4'hf) $fatal(1,"partial shared write");
            if (offset>=YOFF && offset<YOFF+50688*4) begin
              if (offset != YOFF+writes*4) $fatal(1,"write order %h index %0d",offset,writes);
              expected={{16{golden[writes/2][47]}},golden[writes/2]};
              if (cmd_wdata !== (writes%2 ? expected[63:32] : expected[31:0]))
                $fatal(1,"result mismatch layer=%0d word=%0d got=%h expected=%h",
                  layer,writes,cmd_wdata,writes%2 ? expected[63:32] : expected[31:0]);
              ram[word_index]=cmd_wdata;
              writes=writes+1;
              if (writes==50688) final_write_pending=1;
            end else if (offset==HOST+8) firmware_cycles=cmd_wdata;
            else if (offset==HOST+4) begin
              if (cmd_wdata!=layer+1 || writes!=50688 || final_write_pending || first_cycle<0)
                $fatal(1,"premature or incorrect writeback ACK");
              $display("TASK_PASS layer=%0d outputs=25344 writes=50688 cycles=%0d firmware_cycles=%0d",
                layer,last_cycle-first_cycle+1,firmware_cycles);
              report_performance();
              $fflush();
              completed=completed+1;
              layer=layer+1;
              if (layer<tasks) load_layer(layer);
            end else $fatal(1,"unexpected shared write %h",cmd_addr);
          end
        end
      end
      if (xu147_o_061 && xu147_o_060==32'h80000086) begin
        if (xu147_o_062!=1 || completed!=tasks)
          $fatal(1,"firmware failure gp=%0d completed=%0d",xu147_o_062,completed);
        if (!xu_saif_stopped || xu_lf_static_checks<=0) $fatal(1,"missing candidate SAIF end/LF checks");
        $display("XU_LF_CLOCK_STATIC_PASS nominal_hz=32768 checked_edges=%0d max_phase_error_fs=1",xu_lf_static_checks);
        $display("XU_CLOCK_STATIC_PASS checked_hf_edges=%0d",xu_static_checks);
        $xu_private147_gate();
        $fatal(1,"XU_PRIVATE147_QUALIFICATION_GATE_PENDING physical_storage_readback native_warning_timing conditional_SRAM_joint_energy all_unresolved_gates_retained");
        $display("SOC_PASS tasks=%0d outputs=%0d writes=%0d",completed,completed*25344,completed*50688);
        $finish;
      end
    end
  end
endmodule
