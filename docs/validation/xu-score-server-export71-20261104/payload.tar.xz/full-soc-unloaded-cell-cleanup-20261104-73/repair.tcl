if {[catch {
set_host_options -max_cores 2
set_app_var target_library [list {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db}]
set_app_var link_library [list * {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ss-extract/S40/smic/SCC40NLL_VHSC40_RVT_V0.1/SCC40NLL_VHSC40_RVT_V0p1/liberty/1.1v/scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db} {/storage2/2026contest/server4/s4_23usr/Desktop/xu-work/xu-libs/xu-ramsp1024x16-ss-0p99v-125c.db}]
set_svf repair.svf
read_verilog {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-unloaded-cell-cleanup-20261104-63/mapped.v}
current_design xu_soc_ppa_top
if {![link]} {error {DC link failed}}
set XU_CLOCK_MODE envelope
set XU_PLL_DIV 0
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-score-optimization-20261102/full-soc-pt-compatible-05/constraints.sdc}
set XU_AUDIT_FORWARD_CLOCK_EXPERIMENT 1
source {/storage2/2026contest/server4/s4_23usr/Desktop/xu-ts16.tcl}
set_dont_touch [get_cells -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}] true

set xu_before_cells [sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]
set xu_parent_counts [dict create]
foreach_in_collection h [get_cells -hierarchical -filter {is_hierarchical == true}] {dict incr xu_parent_counts [get_attribute $h ref_name]}
set xu_remove {}
set xu_upstream [dict create]
set f [open removal-preflight.tsv w]
puts $f "cell\tref\tis_sequential\toutput\tleaf_connections\tparent_ref_instance_count"
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U74}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U74/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U79}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U79/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U99}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AND2V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_branchslv/U99/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_excp/U73}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AND2V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_excp}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_commit/u_e203_exu_excp/U73/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U408}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_exu/u_e203_exu_decode/U408/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U147}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND4BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U147/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U190}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U190/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U205}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U205/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U252}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U252/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U258}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OA31V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U258/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U260}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U260/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U262}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND4CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U262/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U303}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U303/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U311}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U311/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U315}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U315/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U321}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI31V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U321/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U323}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AND2V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U323/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U330}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U330/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U347}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U347/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U374}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U374/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U381}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U381/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U383}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND3BBV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U383/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U386}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND3CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U386/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U387}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U387/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U389}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AND2V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U389/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U392}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U392/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U393}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U393/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U395}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U395/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U396}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U396/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U399}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U399/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U402}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U402/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U405}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAOI211V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U405/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U408}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U408/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U410}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U410/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U411}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U411/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U418}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U418/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U420}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U420/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U425}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U425/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U429}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U429/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U433}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U433/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U435}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI21V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U435/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U440}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U440/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U441}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR3CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U441/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U445}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U445/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U451}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U451/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U452}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NOR2CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U452/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U457}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U457/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U478}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OR2V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U478/Z}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U500}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {OAI22V0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U500/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U513}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {NAND4CV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U513/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U517}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U517/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U520}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {CLKINV0_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U520/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]
set c [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U69}]
if {[sizeof_collection $c]!=1 || [get_attribute $c ref_name] ne {AOAI211V1_12TR40} || [get_attribute $c is_hierarchical]} {error {cleanup73 exact leaf/reference differs}}
# No new sequential cell has a source-level unused-state proof.
# Missing native classification is a refusal, never an assumed false value.
set seq [get_attribute -quiet $c is_sequential]
if {![string is boolean -strict $seq]} {error {cleanup73 cannot prove combinational cell classification}}
if {$seq} {error {cleanup73 sequential removal has no RTL unused-state proof}}
set owner [get_cells -quiet {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode}]
if {[sizeof_collection $owner]!=1} {error {cleanup73 owner missing}}
set parent_ref [get_attribute $owner ref_name]
if {![dict exists $xu_parent_counts $parent_ref] || [dict get $xu_parent_counts $parent_ref]!=1} {error {cleanup73 parent design is shared}}
set actual_outputs [get_pins -of_objects $c -filter {direction == out}]
if {[sizeof_collection [get_pins -of_objects $c -filter {direction == inout}]]!=0} {error {cleanup73 inout cannot be removed}}
set expected [list {u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_cpu/u_e203_core/u_e203_ifu/u_e203_ifu_ifetch/u_e203_ifu_minidec/u_e203_exu_decode/U69/ZN}]
if {[lsort [get_object_name $actual_outputs]] ne [lsort $expected]} {error {cleanup73 whole-cell output set differs}}
foreach_in_collection p $actual_outputs {
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]!=1} {error {cleanup73 output net count differs}}
 set con [all_connected -leaf $n]
 if {[sizeof_collection $con]!=1 || [get_object_name $con] ne [get_object_name $p] || [get_attribute $con object_class] ne "pin" || [get_attribute $con direction] ne "out"} {error {cleanup73 cross-hierarchy receiver appeared}}
 puts $f [join [list [get_object_name $c] [get_attribute $c ref_name] $seq [get_object_name $p] [get_object_name $con] [dict get $xu_parent_counts $parent_ref]] "\t"]
}
foreach_in_collection ip [get_pins -of_objects $c -filter {direction == in}] {
 foreach_in_collection n [get_nets -of_objects $ip] {
  foreach_in_collection driver [all_connected -leaf $n] {
   if {[get_attribute $driver object_class] eq "pin" && [get_attribute $driver direction] eq "out"} {dict set xu_upstream [get_object_name $driver] 1}
  }
 }
}
lappend xu_remove [get_object_name $c]

close $f
if {[llength $xu_remove]!=53 || [llength [lsort -unique $xu_remove]]!=53} {error {cleanup73 must remove exact53 cells}}
# All187 candidates have passed before the first deletion. No remove_port or
# hierarchy cleanup, and no recursive deletion of newly dangling upstream logic.
set f [open removed-cells.tsv w]
puts $f "cell\tremoved"
foreach name $xu_remove {
 set c [get_cells -quiet $name]
 if {[sizeof_collection $c]!=1} {error {cleanup73 preflight cell vanished}}
 remove_cell $c
 if {[sizeof_collection [get_cells -quiet $name]]!=0} {error {cleanup73 exact removal did not apply}}
 puts $f [join [list $name 1] "\t"]
}
close $f
if {[sizeof_collection [get_cells -hierarchical -filter {is_hierarchical == false}]]!=$xu_before_cells-53} {error {cleanup73 unexpected leaf-cell change}}
set f [open post-cleanup-upstream.tsv w]
puts $f "driver\towner_ref\tnet_count\tleaf_connections\tsource_only"
foreach name [lsort [dict keys $xu_upstream]] {
 set p [get_pins -quiet $name]
 if {[sizeof_collection $p]==0} {continue}
 if {[sizeof_collection $p]!=1} {error {cleanup73 upstream pin ambiguous}}
 set n [get_nets -of_objects $p]
 if {[sizeof_collection $n]>1} {error {cleanup73 upstream output net ambiguous}}
 set con {}
 if {[sizeof_collection $n]==1} {set con [all_connected -leaf $n]}
 set source_only [expr {[sizeof_collection $n]==0 || ([sizeof_collection $con]==1 && [get_object_name $con] eq [get_object_name $p])}]
 puts $f [join [list $name [get_attribute [get_cells -of_objects $p] ref_name] [sizeof_collection $n] [get_object_name $con] $source_only] "\t"]
}
close $f
# Exact post-elaboration macro groups; overlapping matches and missing/extra cells fail.
set xu_seen [dict create]
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_itcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: itcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP itcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top/u_e203_srams/u_e203_dtcm_ram/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 32} {error {wrong macro count: dtcm}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP dtcm count=32 macro_ref=RAMSP1024X16 logical_bits=524288 physical_bits=524288 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_shared/storage/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 256} {error {wrong macro count: shared}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP shared count=256 macro_ref=RAMSP1024X16 logical_bits=4194304 physical_bits=4194304 padding_bits=0"
set xu_cells [get_cells -quiet -hierarchical -filter {full_name =~ u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave/* && ref_name == RAMSP1024X16 && is_hierarchical == false}]
if {[sizeof_collection $xu_cells] != 16} {error {wrong macro count: accelerator_weights}}
foreach_in_collection xu_c $xu_cells {
  set xu_n [get_object_name $xu_c]
  if {[dict exists $xu_seen $xu_n]} {error "overlapping SRAM group: $xu_n"}
  dict set xu_seen $xu_n 1
  if {[get_attribute $xu_c ref_name] != {RAMSP1024X16}} {error "wrong SRAM reference: $xu_n"}
}
puts "XU_SRAM_GROUP accelerator_weights count=16 macro_ref=RAMSP1024X16 logical_bits=262144 physical_bits=262144 padding_bits=0"
# RAMSP is the explicit technology SRAM namespace; reject every extra leaf/reference.
set xu_allowed_refs [list {RAMSP1024X16}]
set xu_all_macros [get_cells -quiet -hierarchical -filter {ref_name =~ RAMSP* && is_hierarchical == false}]
if {[sizeof_collection $xu_all_macros] != 336 || [dict size $xu_seen] != 336} {error {full-SoC SRAM total must be exactly 336}}
foreach_in_collection xu_c $xu_all_macros {
  if {[lsearch -exact $xu_allowed_refs [get_attribute $xu_c ref_name]] < 0} {error {unexpected SRAM reference}}
  if {![dict exists $xu_seen [get_object_name $xu_c]]} {error {ungrouped/unaccounted SRAM macro}}
}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_accel_icb_slave && ref_name =~ accel_icb_slave*}]] != 1} {error {missing/wrong accelerator}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_cpu_top && ref_name =~ e203_cpu_top*}]] != 1} {error {missing/wrong cpu}}
if {[sizeof_collection [get_cells -quiet -hierarchical -filter {full_name == u_soc/u_e203_subsys_top/u_e203_subsys_main/u_e203_subsys_perips/u_sirv_ppi_fab && ref_name =~ sirv_icb1to16_bus*}]] != 1} {error {missing/wrong interconnect}}
report_constraint -all_violators -verbose > dc-all-constraints.rpt
report_units > dc-units.rpt
report_area -hierarchy > area.rpt
report_qor > qor.rpt
report_timing -delay_type max -max_paths 50 > dc-setup.rpt
report_timing -delay_type min -max_paths 50 > dc-hold.rpt
report_constraint -all_violators > dc-violations.rpt
write -format verilog -hierarchy -output mapped.v
write -format ddc -hierarchy -output mapped.ddc
write_sdc mapped.sdc

puts {XU_CLEANUP73_DC_DONE_NOT_QUALIFIED}
} xu_error]} {
  puts stderr "XU_FATAL: $xu_error"
  exit 1
}
exit 0
